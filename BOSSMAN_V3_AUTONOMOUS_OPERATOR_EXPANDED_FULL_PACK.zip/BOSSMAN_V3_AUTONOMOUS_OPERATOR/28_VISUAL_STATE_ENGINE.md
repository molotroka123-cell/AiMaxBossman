# VISUAL STATE ENGINE (VSE)

## Why it exists

UCA cannot become a robust computer operator if every action starts from a fresh screenshot and an LLM guess.

Visual State Engine maintains a compact, durable representation of what BOSSMAN currently believes is on screen and how that state changed.

---

# Responsibilities

```text
frame / accessibility tree / DOM / app metadata
→ normalize
→ detect regions
→ identify semantic objects
→ detect changes
→ build compact VisualState
→ expose deltas to UCA
```

VSE should support:
- browser pages;
- desktop windows;
- modal dialogs;
- menus;
- forms;
- tables;
- media editors;
- charts;
- terminals;
- native app surfaces where supported.

---

# VisualState

```text
environment_id
window_id
app_id
page_id
timestamp
frame_hash
semantic_tree_hash
focused_element
interactive_elements
regions
loading_state
modal_state
error_state
changed_regions
confidence
```

Never put full-resolution screenshot bytes directly into active WorldState.

Screenshots are evidence artifacts referenced by id.

---

# Change detection

Prefer:
- DOM/accessibility delta;
- region hash delta;
- OCR text delta;
- perceptual image delta.

Only invoke expensive vision when cheap signals cannot resolve the state.

---

# Semantic object model

Example:
```json
{
  "object_id": "obj_42",
  "role": "button",
  "name": "Generate",
  "state": {"enabled": true},
  "bounds": [0.62, 0.85, 0.78, 0.94],
  "source": ["accessibility", "vision"],
  "confidence": 0.97
}
```

---

# State transitions

VSE should make transitions explicit:

```text
FORM_EMPTY
→ FORM_CONFIGURED
→ SUBMITTED
→ JOB_RUNNING
→ JOB_COMPLETE
```

This is much more useful than:
“pixel changed”.

---

# UI drift

If a button moves but semantic role/name stays:
same object meaning, changed visual coordinates.

If label changes:
lower confidence and use contextual landmarks.

If modal blocks flow:
emit blocker, do not click through blindly.

---

# Performance

Target:
- cheap observation loop;
- expensive visual model only on uncertainty;
- changed-region OCR;
- frame downscale for overview;
- high-res crop only for required region.

---

# Acceptance

`V3-VSE-STATE-001`
Build VisualState from a real page.

`V3-VSE-DELTA-001`
Detect meaningful state change without reprocessing whole screen.

`V3-VSE-DRIFT-001`
Semantic target survives layout movement.

`V3-VSE-UNCERTAINTY-001`
Ambiguous risky target causes safe stop/owner takeover, not random click.
