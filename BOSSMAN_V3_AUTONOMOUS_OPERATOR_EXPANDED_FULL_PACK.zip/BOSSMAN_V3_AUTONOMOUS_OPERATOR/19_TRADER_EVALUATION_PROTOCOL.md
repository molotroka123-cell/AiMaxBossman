# TRADER APPRENTICE — EVALUATION PROTOCOL

## Why strict evaluation matters

A trading learner can look impressive if:
- future candles leak;
- teacher commentary leaks;
- sample selection is cherry-picked;
- training and test overlap;
- results ignore drawdown;
- no-trade cases are excluded.

V3 must prevent that.

---

# Dataset split

Prefer chronological split:
- TRAIN
- VALIDATION
- BLIND TEST

Never randomly mix adjacent clips from the same event across train/test if that leaks context.

---

# Blind lock

For each blind episode:
1. create input snapshot at decision timestamp;
2. hash/freeze input;
3. run apprentice;
4. persist answer;
5. only then reveal teacher continuation and future market;
6. score.

---

# Score dimensions

### Teacher imitation score
Weighted dimensions:
- decision type;
- direction;
- entry plan;
- invalidation;
- stop;
- targets;
- wait conditions;
- confidence.

### Independent performance
- expectancy;
- risk-adjusted return;
- max drawdown;
- MFE/MAE;
- false positive trade rate;
- no-trade discipline.

These two scores are separate.

A model can imitate teacher well but teacher may be wrong.

---

# Regime stratification

Tag:
- trend;
- range;
- breakout;
- high volatility;
- low volatility;
- event/news;
- squeeze;
- liquidation cascade if identifiable.

Report per regime.

---

# Sample-size honesty

Never claim “perfectly learned” from a handful of episodes.

Always show:
- N;
- confidence/uncertainty;
- per-regime counts;
- missing regimes.

---

# Human comparison

Useful optional evaluation:
- BOSSMAN decision;
- teacher decision;
- second independent trader/model;
- realized outcome.

Do not let realized outcome alone define quality; process and risk matter.

---

# Promotion to live

Outside initial V3 acceptance.

Requires a separate explicit owner decision and new safety review.
