# V3 MASTER BACKLOG

This is a structured backlog, not a mandate to implement all optional items before freeze.

## P0 Foundations
- canonical V3 mission/event schemas
- continuation semantics
- Teach Me recorder redaction
- UCA semantic replay
- skill candidate lifecycle
- independent promotion verifier
- failure fingerprinting
- approval boundary regression
- cost governor continuity

## P1 Autonomy
- skill dedupe
- skill merge
- skill aging
- self-healing recovery library
- Night Shift task queue
- morning report
- Software Factory objective/spec/build graph
- Trader video ingestion
- transcript/frame alignment
- blind evaluation
- owner-facing V3 UX

## P1 Reliability
- browser UI drift recovery
- stale session recovery
- model call timeout classification
- resource pressure handling
- checkpoint compaction
- failure evidence minimization
- telemetry redaction
- restart hydrate

## P1 Economy
- local-first routing
- Fable escalation gate
- model tournament
- prompt cache telemetry
- skill ROI metrics
- teacher-call reduction metric

## P2 UX
- skill diff visualization
- timeline replay
- demonstration scrubber
- trader episode visual explorer
- regime heatmap
- overnight activity story
- benchmark history comparison

## P2 Future hooks
- digital twin action simulation interface
- fleet host registry
- capability advertisement
- artifact migration between hosts

---

# Defer rule

Any P2 item that threatens mandatory V3 completion moves to:
`docs/v3/POST_V3_BACKLOG.md`.
