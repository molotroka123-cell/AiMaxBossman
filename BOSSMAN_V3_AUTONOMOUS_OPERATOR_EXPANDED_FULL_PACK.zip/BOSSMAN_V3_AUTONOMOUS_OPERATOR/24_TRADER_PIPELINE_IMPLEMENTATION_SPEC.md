# TRADER APPRENTICE — DEEP PIPELINE IMPLEMENTATION SPEC

## System decomposition

```text
Source Registry
  ↓
Media Fetch/Import
  ↓
Chunk Planner
  ├─ Audio/ASR
  ├─ Scene Detection
  ├─ Adaptive Frame Selector
  └─ Metadata
  ↓
Chart Analyzer
  ↓
Transcript Aligner
  ↓
Episode Extractor
  ↓
Outcome Attacher
  ↓
Pattern Miner
  ↓
Blind Evaluator
  ↓
Trader Apprentice UX
```

---

# Source registry

Store:
```text
source_id
provider
url/local_path
channel
title
published_at
duration
content_hash
ingest_status
language
teacher_identity_label
```

Do not rely on title as identity.

---

# Chunk planner

Long videos must process incrementally.

Suggested logical chunk:
- 2–10 minutes depending on scene density;
- overlap around boundaries;
- resumable;
- content-hash keyed.

A crash must resume without retranscribing the whole video.

---

# ASR

Store:
- segment start/end;
- text;
- confidence if available;
- language;
- speaker label if possible.

Keep source transcript artifact out of model context unless needed.

---

# Frame selection

Frame policy inputs:
- speech keywords;
- scene changes;
- chart motion;
- cursor/drawing activity;
- trade-panel changes;
- price volatility;
- OCR change score.

Output:
```text
frame_timestamp
reason_selected
importance
region hints
```

---

# Chart region model

Detect likely:
- main price chart;
- order book;
- OI;
- CVD;
- volume;
- liquidations;
- indicator labels.

Do not assume fixed screen coordinates across videos.

---

# OCR and vision

Extract what is actually legible.

Every numeric value should carry:
```text
value
confidence
timestamp
region
source frame
```

If uncertain:
store uncertain, do not fabricate precision.

---

# Alignment

Transcript statement:
> “OI растёт, CVD падает”

must align with what was visible near that timestamp.

Alignment should consider:
- speech timestamps;
- current/nearby frames;
- lag between verbal reference and cursor action;
- pauses.

Spot-check alignment manually during early acceptance.

---

# Episode extraction

Candidate episode triggers:
- directional thesis;
- no-trade decision;
- entry;
- stop;
- target;
- invalidation;
- regime assessment;
- management action.

Episodes need contextual lead-in and follow-through.

---

# Outcome attachment

Outcome is added only AFTER decision data is frozen.

Store multiple horizons.

Never let outcome fields enter blind inference prompt.

---

# Pattern representation

A pattern should not be:
> “when CVD down, long”

It should express:
- necessary conditions;
- supporting conditions;
- invalidation;
- regime;
- action/no-action;
- confidence;
- sample size.

Example:

```text
Pattern:
Aggressive sells absorbed near structural support while OI rises.

Supporting:
- price fails to make proportional new low
- CVD continues lower
- OI expands
- reclaim of micro structure

Action:
wait for reclaim; long only after confirmation

Invalidation:
accepted price below support with continued OI expansion
```

---

# Blind evaluator implementation

Two distinct objects:
```text
BlindInput
LockedPrediction
```

`LockedPrediction` must be persisted before teacher/future reveal.

A content hash links evaluation snapshot.

---

# Dataset contamination checks

Detect:
- same video segment in train and test;
- adjacent overlapping chunks;
- transcript continuation leaking answer;
- future frames accidentally included;
- cached teacher summary attached to blind input.

---

# Compute strategy on 128GB unified memory hardware

Prefer sequential/queued specialized models:
- ASR;
- vision/OCR;
- LLM extraction.

Avoid keeping all large models resident simultaneously unless measured beneficial.

Pipeline should expose memory pressure to Resource Brain.

---

# Batch processing

Night Shift is ideal for archive processing:
- local-first;
- checkpoints by source/chunk;
- morning report;
- failed source does not abort whole batch.

---

# Evaluation UI

Show:
- source progress;
- processed hours;
- extracted episode count;
- blind N;
- regime distribution;
- imitation score;
- teacher performance separately;
- uncertainty;
- no-lookahead status.

Do not show a single “AI accuracy” number without sample context.
