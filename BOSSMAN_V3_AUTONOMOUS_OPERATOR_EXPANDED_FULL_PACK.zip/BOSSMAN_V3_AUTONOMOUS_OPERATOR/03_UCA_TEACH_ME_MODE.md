# UNIVERSAL COMPUTER APPRENTICE 2.0 + TEACH ME

## Product goal

Owner says:
> “Смотри, я сейчас покажу один раз.”

BOSSMAN watches the task, builds a structured procedure, asks only necessary questions, and later reproduces the workflow semantically.

---

# Demonstration lifecycle

```text
TEACH_START
→ ENV_SNAPSHOT
→ OBSERVE_ACTIONS
→ CAPTURE_EFFECTS
→ SEGMENT_STEPS
→ INFER_PARAMETERS
→ INFER_PRECONDITIONS
→ INFER_POSTCONDITIONS
→ IDENTIFY_RISKY_STEPS
→ BUILD_CANDIDATE_SKILL
→ DRY_REPLAY
→ OWNER_REVIEW
→ PROMOTE_OR_REVISE
```

---

# What is recorded

Allowed observable facts:
- app/window/page identity;
- semantic element labels;
- URLs excluding secrets;
- text entered after secret redaction;
- visible state;
- action type;
- timing;
- expected effect;
- actual effect;
- screenshots/evidence under retention rules.

Never record:
- raw passwords;
- API keys;
- cookies;
- hidden tokens;
- raw clipboard secrets.

Secret interactions become parameter references:
```text
${credential:service/account}
```

---

# Semantic action schema

```json
{
  "action": "click",
  "target": {
    "role": "button",
    "name": "Generate",
    "semantic_hints": ["primary", "generation"]
  },
  "preconditions": [
    "prompt field non-empty",
    "model selected"
  ],
  "expected_effect": "generation job appears",
  "timeout_policy": "long_job",
  "recovery": ["re-resolve target", "refresh state", "ask owner if auth wall"]
}
```

---

# Generalization

A learned workflow must distinguish:
- constant;
- parameter;
- secret;
- environment-specific value;
- derived value.

Example:
```text
video path      -> parameter
prompt          -> parameter
output folder   -> parameter/default
account login   -> credential reference
model name      -> configurable default
button position -> NEVER a durable constant if semantic target exists
```

---

# Replay

Replay is NOT literal macro playback.

Priority:
1. semantic target resolution;
2. role/name/accessible tree;
3. DOM/visual feature;
4. relative structural fallback;
5. coordinate fallback only when unavoidable and verified.

After each meaningful side effect:
verify actual state.

---

# UI drift test

Acceptance `V3-UCA-UI-DRIFT-001`:
- reorder controls;
- alter non-semantic layout;
- keep semantic meaning;
- learned workflow still succeeds.

---

# Owner editing

Teach Me should generate a human-readable skill card:
- goal;
- inputs;
- steps;
- approvals;
- failure recovery;
- expected output;
- learned-from demonstrations;
- confidence;
- last verified date.

Owner can:
- rename;
- disable step;
- require approval;
- change default;
- rerun test;
- promote/reject.

---

# Skill promotion gates

Candidate → Verified → Promoted

Required:
- successful demonstration parse;
- dry replay;
- independent verification;
- no secret leakage;
- no unsafe side-effect policy bypass;
- parameterization score;
- minimum successful reuse threshold configurable.

---

# Minimum first real acceptance

Use a real benign workflow on owner hardware:
- open app/site;
- navigate;
- set fields;
- execute safe action;
- verify output;
- save artifact.

Repeat on fresh state with changed parameters.
No owner action during replay unless approval is genuinely required.
