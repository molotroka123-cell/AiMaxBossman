# V3 MISSION CONTROL UX

V3 UX builds on Command Center UX 2.0.

## New owner surfaces

### Learn
- Start Teach Me
- Demonstrations
- Candidate Skills
- Promotion Queue

### Trader Apprentice
- Sources
- Processing Queue
- Episodes
- Blind Tests
- Imitation Score
- Shadow Performance
- Teacher Pattern Library

### Skill Factory
- Active skills
- Candidate skills
- Merges
- Quarantine
- ROI / success / cost

### Night Shift
- Tonight Queue
- approval policy
- cloud cap
- estimated local resources
- morning report

### Software Factory
- objective
- spec
- build graph
- live preview
- tests
- verifier
- artifact

---

# Thinking process V3

Continue the safe observability panel.

Add:
- learning state;
- current skill;
- skill retrieval reason;
- candidate skill created;
- failure classification;
- recovery action;
- tournament state;
- shadow evaluation state.

Still NEVER raw chain-of-thought.

---

# Owner convenience

Home should show:
```text
What BOSSMAN is doing
What it learned today
What failed
What it fixed
What needs owner approval
What skill improved
What cost was spent
What happened overnight
```

---

# Notifications

Only surface owner-important events:
- approval needed;
- mission blocked;
- skill promotion ready;
- Night Shift complete;
- serious security issue;
- blind evaluation milestone.

Do not spam every internal agent event.
