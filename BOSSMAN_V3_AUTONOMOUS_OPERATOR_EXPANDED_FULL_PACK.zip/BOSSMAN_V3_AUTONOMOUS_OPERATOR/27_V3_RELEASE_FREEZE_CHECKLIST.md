# V3 RELEASE / FREEZE CHECKLIST

## Repository truth
- [ ] fresh remote HEAD recorded
- [ ] clean/known worktree
- [ ] V2 baseline regression green
- [ ] V3 migrations backward compatible
- [ ] no stale capsule claiming old phase

## UCA / Teach Me
- [ ] real demonstration
- [ ] secret redaction
- [ ] semantic skill
- [ ] changed-input replay
- [ ] UI drift replay
- [ ] effect receipts
- [ ] owner takeover
- [ ] recovery

## Skill Factory
- [ ] candidate lifecycle
- [ ] dedupe
- [ ] promotion verifier
- [ ] metrics
- [ ] quarantine
- [ ] rollback
- [ ] unseen transfer proof

## Failure / Recovery
- [ ] taxonomy
- [ ] fingerprint
- [ ] no identical retry loop
- [ ] one injected recoverable failure
- [ ] one typed blocker
- [ ] evidence retained

## Night Shift
- [ ] queue
- [ ] resource policy
- [ ] cost policy
- [ ] approval waiting
- [ ] restart
- [ ] same mission_id
- [ ] no duplicate effect
- [ ] morning report

## Software Factory
- [ ] objective
- [ ] requirements
- [ ] architecture
- [ ] build
- [ ] tests
- [ ] security
- [ ] real browser
- [ ] local artifact/demo

## Trader Apprentice
- [ ] real source ingest
- [ ] long video chunking
- [ ] transcript
- [ ] adaptive frames
- [ ] chart alignment
- [ ] episodes
- [ ] blind split
- [ ] locked prediction
- [ ] no future leak
- [ ] regime metrics
- [ ] shadow only default
- [ ] live action disabled unless separate policy

## Model economy
- [ ] local-first
- [ ] ProblemBundle
- [ ] Fable reserved for leverage
- [ ] prompt cache observed
- [ ] cost ledger
- [ ] durable reservation
- [ ] fallback typed

## UX
- [ ] V3 navigation
- [ ] Learn
- [ ] Skills
- [ ] Night Shift
- [ ] Software Factory
- [ ] Trader Apprentice
- [ ] Failure Diagnosis
- [ ] Thinking process safe telemetry
- [ ] no raw CoT
- [ ] no secrets
- [ ] desktop
- [ ] mobile

## Security
- [ ] owner approval
- [ ] replay denial
- [ ] side-effect ledger
- [ ] protected paths
- [ ] credential isolation
- [ ] independent verifier
- [ ] telemetry redaction
- [ ] no live-money trade in base acceptance

## Final evidence
- [ ] exact-SHA V3 benchmark
- [ ] CI green
- [ ] final report
- [ ] key-function touch matrix
- [ ] open P0 = 0
- [ ] open P1 documented
- [ ] post-V3 backlog
- [ ] pushed final HEAD

Final:
`BOSSMAN_V3_AUTONOMOUS_OPERATOR_READY=YES`
only if evidence supports it.
