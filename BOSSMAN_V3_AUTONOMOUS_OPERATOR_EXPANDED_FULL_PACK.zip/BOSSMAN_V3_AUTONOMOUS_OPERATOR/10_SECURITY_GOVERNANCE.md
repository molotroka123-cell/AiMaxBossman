# V3 SECURITY & GOVERNANCE

## Principle

More autonomy requires stronger boundaries, not fewer.

---

# Side-effect classes

```text
READ_ONLY
LOCAL_REVERSIBLE
LOCAL_PERSISTENT
REMOTE_REVERSIBLE
REMOTE_IRREVERSIBLE
FINANCIAL
CREDENTIAL
PRODUCTION
```

Policy is based on side-effect class.

---

# Owner approval

Approval object:
```text
approval_id
mission_id
action_digest
requester
target
side_effect_class
reason
scope
created_at
expires_at
nonce
status
```

Must be:
- durable;
- digest-bound;
- replay-resistant;
- expiring where applicable.

---

# Protected examples

Always require explicit policy/approval:
- send email/message;
- publish content;
- buy something;
- move funds;
- live trade;
- production deployment;
- credential rotation;
- destructive remote action.

---

# Secret boundary

Secrets must stay in trusted credential broker/transport.

Never:
- put secrets in ProblemBundle;
- send keys to untrusted teacher process;
- save keys in skill memory;
- show them in Thinking process;
- log auth headers.

---

# Demonstration redaction

Teach Me must recognize secret fields and store references instead of values.

---

# Trader Apprentice

No live-money execution in normal V3 acceptance.

Shadow evaluation is sufficient.

Any future live trading must be a separately enabled capability with:
- venue whitelist;
- max exposure;
- max loss;
- per-trade limits;
- kill switch;
- approval policy;
- full audit.

---

# Independent verifier

High-risk code changes cannot be self-certified by author agent.

Verifier receives:
- invariant list;
- diff;
- targeted evidence;
- acceptance criteria.

Verifier should not mutate the code under review.

---

# Security regression

Required areas:
- auth;
- approvals;
- replay;
- path protections;
- command execution;
- secret redaction;
- durable budget;
- restart idempotency;
- telemetry redaction.
