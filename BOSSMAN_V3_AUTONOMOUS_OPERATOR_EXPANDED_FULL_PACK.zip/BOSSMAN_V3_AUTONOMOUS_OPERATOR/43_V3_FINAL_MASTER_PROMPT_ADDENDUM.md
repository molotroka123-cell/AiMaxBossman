# V3 MASTER PROMPT ADDENDUM — DO NOT MISS THESE SYSTEMS

This addendum extends `01_V3_MASTER_EXECUTION_PROMPT.md`.

The implementation lead must also account for:

1. Visual State Engine
2. Event-Driven Boss
3. Recovery Kernel
4. Data Flywheel + training quality filter
5. Local model distillation
6. Capability Registry + permission scopes
7. Sandbox / trust zones
8. Structured observability
9. Resource Scheduler / model residency
10. Backup + disaster recovery
11. Explicit autonomy levels
12. V2→V3 migration and rollback
13. Red-team campaign
14. Artifact/provenance registry
15. Connector architecture

These are not all required to be implemented at maximum depth before the first V3 usable release.

Priority:

```text
P0:
Visual State Engine contracts
Recovery Kernel
Data quality filter
Capability/permission model
migration/rollback
observability
provenance

P1:
Event-Driven Boss
resource scheduler
backup/restore
distillation pipeline
red-team
connector architecture

P2:
advanced optimizations
```

Do not use this addendum as an excuse for endless scope expansion.

Finish-first remains active.

The V3 release should be a coherent vertical slice where:
- the owner teaches;
- BOSSMAN sees;
- BOSSMAN acts;
- BOSSMAN verifies;
- BOSSMAN learns;
- BOSSMAN recovers;
- BOSSMAN remembers;
- BOSSMAN reports;
- BOSSMAN can continue after restart.

Only after that, deepen optional subsystems.
