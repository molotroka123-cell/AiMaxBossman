# V4 COMPATIBILITY — BUILD V3 WITHOUT PAINTING INTO A CORNER

V4 likely introduces:
- Digital Twin;
- Simulation-before-Action;
- Fleet Mode;
- multi-machine scheduling;
- environment replicas.

V3 should expose interfaces now without implementing full V4.

---

# Required future-friendly hooks

Every action:
```text
plan()
simulate?()
authorize()
execute()
verify()
receipt()
```

Every environment adapter should support:
- snapshot identity;
- capability declaration;
- side-effect class;
- optional simulation support.

---

# Fleet-ready IDs

Do not assume one host forever.

Use:
```text
host_id
worker_id
environment_id
mission_id
```

But keep V3 single-owner-machine first.

---

# Digital Twin compatibility

WorldState should distinguish:
```text
OBSERVED_REAL
SIMULATED
PREDICTED
OWNER_ASSERTED
```

Never mix them.

---

# Artifact portability

Skills should declare:
- OS;
- app/site;
- required capabilities;
- version constraints;
- credentials needed;
- safety class.

This allows future fleet scheduling.
