# DATA FLYWHEEL + QUALITY FILTER

## Why

Autonomous learning can make a system worse if every interaction becomes training data.

V3 needs an explicit quality filter.

---

# Learning pipeline

```text
raw episode
→ sanitize
→ classify
→ verify outcome
→ score quality
→ detect contamination
→ dedupe
→ accept / quarantine / reject
→ training/evaluation store
```

---

# Never train from

- unresolved failures labeled as success;
- secrets;
- hidden chain-of-thought;
- corrupted transcripts;
- synthetic answers presented as real outcomes;
- look-ahead trading episodes;
- duplicated episodes;
- verifier-rejected patches;
- adversarial/untrusted imported skills without review.

---

# Training quality score

Components:
```text
outcome_verified
source_trust
novelty
signal_density
label_confidence
environment_relevance
security_clean
duplicate_score
```

Store components, not only final scalar.

---

# Buckets

```text
GOLD
SILVER
EXPERIMENTAL
QUARANTINE
REJECTED
```

GOLD requires independent verification.

---

# Negative examples

Failures are valuable if labeled correctly.

Store:
- action;
- context;
- failure;
- root cause;
- corrected behavior.

Do not erase failed attempts from learning history.

---

# Data drift

Track:
- app versions;
- UI versions;
- model versions;
- market regimes;
- operating system;
- environment.

Older data can remain useful but may need lower weight.

---

# Anti-collapse

Do not continuously fine-tune on BOSSMAN's own generated outputs without external/verified anchor data.

Maintain:
- human demonstrations;
- real outcomes;
- independent verifier labels;
- holdout sets.

---

# Acceptance

`V3-DATA-FILTER-001`
Known bad/unverified episode rejected.

`V3-DATA-SECRET-001`
Credential-bearing episode sanitized/rejected.

`V3-DATA-DEDUPE-001`
Near-duplicate training episodes deduplicated.

`V3-DATA-HOLDOUT-001`
Evaluation holdout never enters training set.
