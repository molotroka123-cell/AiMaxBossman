# RESOURCE SCHEDULER + MODEL RESIDENCY

## Goal

Use owner hardware efficiently without memory thrashing.

---

# Resource model

Track:
```text
RAM total/free
GPU/unified memory total/free
CPU load
GPU load
disk
temperature if exposed
active model residency
queued model requirements
```

---

# Work item estimate

```text
ram_estimate
vram_or_unified_estimate
cpu_class
gpu_class
io_class
expected_duration
priority
```

---

# Scheduler rules

- avoid simultaneous large-model residency when unnecessary;
- keep small router/classifier resident if cheap;
- unload specialists after configurable idle period;
- serialize heavy ASR/vision/LLM workloads under memory pressure;
- prioritize owner-interactive task over Night Shift batch.

---

# Trader pipeline

Do not keep:
- ASR;
- large VLM;
- large LLM

all loaded if sequential processing is faster overall on target hardware.

Measure.

---

# Graceful pressure

Before OOM:
- stop admitting heavy jobs;
- checkpoint;
- unload idle model;
- reduce batch;
- continue lightweight work.

---

# Acceptance

`V3-RESOURCE-PRESSURE-001`
System avoids deliberate overcommit scenario.

`V3-RESOURCE-PRIORITY-001`
Owner interactive task preempts/deprioritizes background batch safely.
