# V3 RED TEAM PLAN

## Objective

Attack V3 autonomy claims before freeze.

---

# Attack areas

### UCA
- misleading button labels;
- duplicate controls;
- modal overlays;
- UI layout drift;
- stale page;
- destructive button near safe button.

### Teach Me
- secret entry;
- accidental irrelevant actions;
- owner correction mid-demo;
- inconsistent two demonstrations.

### Skills
- malicious imported skill;
- stale skill;
- duplicate skill;
- skill that succeeds only on fixture.

### Recovery
- crash after side effect;
- partial DB write;
- corrupted checkpoint;
- retry storm.

### Event Boss
- duplicate event;
- event loop;
- adversarial webhook payload.

### Trader
- future frame leakage;
- transcript leakage;
- repeated clip across train/test;
- cherry-picked profitable examples.

### Software Factory
- dependency confusion;
- secret committed;
- vulnerable generated endpoint;
- fake browser test.

### Night Shift
- owner absent;
- one model down;
- disk pressure;
- one task blocked on approval.

---

# Red team process

```text
attack case
→ expected invariant
→ execute
→ evidence
→ severity
→ fix
→ regression test
```

---

# Release condition

No open P0.
P1 explicitly reviewed.
No known benchmark leakage.
No known approval bypass.
