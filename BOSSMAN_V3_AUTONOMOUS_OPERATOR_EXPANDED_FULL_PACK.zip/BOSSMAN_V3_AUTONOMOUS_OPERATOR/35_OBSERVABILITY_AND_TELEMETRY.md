# V3 OBSERVABILITY + TELEMETRY

## Goal

Owner and verifier can answer:
- what happened;
- why it happened at public operational level;
- what it cost;
- whether it succeeded;
- whether it is stuck.

Without exposing private hidden reasoning.

---

# Metrics

Mission:
```text
elapsed
completed work items
failed work items
owner interventions
restart count
```

Models:
```text
calls
latency
input/output tokens
cache reads
cost
timeouts
fallbacks
```

Skills:
```text
selection count
success
failure
recovery
cost avoided
teacher calls avoided
```

UCA:
```text
observations
actions
target ambiguity
recovery rate
takeovers
```

Trader:
```text
hours processed
episodes
blind N
regime distribution
```

---

# Traces

Use correlation:
```text
mission_id
work_item_id
attempt_id
model_call_id
action_id
effect_receipt_id
```

---

# Logs

Structured.
Redacted.
Bounded.
Durable when needed.

Do not log full secrets or chain-of-thought.

---

# Owner Thinking process

Is a projection of telemetry:
- current state;
- current tool/model;
- elapsed;
- last event;
- public rationale summary;
- blocker;
- next action.

---

# Stall detector

Use:
- heartbeat age;
- known active model/tool;
- queue state;
- worker health.

Avoid fake spinning indicator.

---

# Acceptance

`V3-OBS-CORRELATE-001`
One mission action trace can be followed end-to-end.

`V3-OBS-REDACT-001`
Secrets absent from telemetry.

`V3-OBS-STALL-001`
Real stalled worker distinguished from known long-running call.
