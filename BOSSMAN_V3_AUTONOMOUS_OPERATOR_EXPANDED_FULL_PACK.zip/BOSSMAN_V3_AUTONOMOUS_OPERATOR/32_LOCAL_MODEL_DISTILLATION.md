# LOCAL MODEL DISTILLATION / TEACHER-TO-STUDENT LOOP

## Goal

Use expensive/strong teacher models to make local BOSSMAN better over time without copying hidden reasoning.

---

# Allowed training material

Use:
- sanitized input;
- final teacher answer/patch;
- public rationale summary if available;
- verifier result;
- outcome;
- correction delta.

Do NOT store/train on:
- hidden provider chain-of-thought;
- system secrets;
- credentials;
- private scratchpads.

---

# Existing opportunity

Fable transcript recording can become a durable corpus source where already implemented.

V3 should transform teacher episodes into:
```text
problem
→ teacher result
→ independent verification
→ generalized lesson
→ student training/eval pair
```

Only verified episodes become high-quality distillation data.

---

# Distillation stages

1. collect verified pairs;
2. dedupe;
3. remove repo-specific transient literals when appropriate;
4. split train/validation/holdout;
5. fine-tune or adapter-train local model;
6. run unchanged holdout;
7. compare cost/latency/accuracy;
8. promote only if better on required tasks.

---

# Promotion criteria

Local student must not be promoted because loss decreased.

Require:
- benchmark improvement;
- no safety regression;
- no catastrophic forgetting on core tasks;
- stable structured-output adherence;
- acceptable latency/memory.

---

# Specialization

Prefer multiple small specialists over one continually fine-tuned universal model if evidence supports it:
- coding fixer;
- UI operator;
- classifier/router;
- trader episode extractor;
- verifier assistant.

---

# Rollback

Model registry keeps:
- active;
- previous known good;
- candidate;
- benchmark evidence.

---

# Acceptance

`V3-DISTILL-PAIR-001`
Verified teacher episode converted to sanitized training pair.

`V3-DISTILL-HOLDOUT-001`
Holdout isolated.

`V3-DISTILL-PROMOTE-001`
Student promotion tied to benchmark evidence.
