# CONNECTORS + EXTERNAL APP ARCHITECTURE

## Goal

BOSSMAN should interact with external systems through explicit adapters/capabilities, not random ad-hoc automation.

---

# Connector categories

```text
repository
email
calendar
drive
messaging
browser-only service
market data
media sources
local filesystem
```

---

# Adapter contract

```text
discover capabilities
authenticate through trusted broker
read
propose mutation
execute authorized mutation
return receipt
health
```

---

# Browser fallback

If no API/connector exists:
UCA can use browser.

But browser automation still declares side effects and receipts.

---

# Connector health

A failed connector should become:
`BLOCKED_BY_CONNECTOR`
or trigger safe browser fallback if policy permits.

---

# Acceptance

`V3-CONNECTOR-RECEIPT-001`
External mutation returns durable receipt.

`V3-CONNECTOR-FALLBACK-001`
Unavailable connector can safely route to approved browser path.
