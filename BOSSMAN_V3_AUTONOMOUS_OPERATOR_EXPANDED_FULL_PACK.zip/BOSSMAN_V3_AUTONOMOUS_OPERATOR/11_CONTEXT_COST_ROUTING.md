# V3 CONTEXT / COST / MODEL ROUTING CONTRACT

## Goal

Maximize verified autonomy improvement per context token and cloud dollar.

---

# Active context budgets

Default:
```text
manager target: 18k
manager hard: 28k
local scout: 6k
Fable focused input: 10–12k
Fable hard focused input: 18k
Fable output target: <=2.5k
final review target: 14k
```

Split tasks instead of blindly raising limits.

---

# Read policy

```text
fresh HEAD
→ current capsule
→ failure/evidence
→ symbol search
→ narrow excerpt
→ diff
→ direct dependency
→ whole file only if necessary
```

---

# ProblemBundle

```text
problem_id
goal
HEAD/tree
failure fingerprint
expected
actual
relevant invariants
small code excerpts
attempts
targeted tests
security boundary
budget
output schema
```

---

# Cheapest competent model

Route:
```text
deterministic
→ local small
→ local strong
→ cheap cloud if configured
→ Fable
→ fallback only if justified
```

Fable is not for:
- grep;
- rename;
- bulk docs;
- routine CSS;
- raw log reading.

---

# Model tournament

Use when:
- uncertainty is high;
- competing architectural approaches;
- decision matters.

2–4 candidates.
Typed outputs.
One evaluator.

No tournament for trivial work.

---

# Prompt cache

Cache stable prefix:
- architecture;
- security;
- tool contracts;
- output schema.

Append volatile:
- HEAD;
- diff;
- failure;
- current mission.

Track actual cache read/write token metrics.

---

# Durable cost reservation

Before paid call:
reserve worst-case.
After:
commit actual.
Failure:
release if safely known unused.

No double commit.
Conservative uncertain in-flight reservation after crash.

---

# Finish-first

Reserve context/cost for:
- final verifier;
- exact-SHA benchmark;
- report;
- emergency P0.

When budget low:
stop optional discovery.
