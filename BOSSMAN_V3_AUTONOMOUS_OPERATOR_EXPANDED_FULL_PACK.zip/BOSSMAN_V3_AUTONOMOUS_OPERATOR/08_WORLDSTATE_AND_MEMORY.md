# WORLDSTATE 2.0 + MEMORY

## Goal

One canonical durable source of mission truth across long-running work.

---

# State boundaries

WorldState is NOT a giant transcript.

It stores structured facts.

```text
MissionState
TaskGraph
EnvironmentState
ActorState
ObservationIndex
ActionLedger
EvidenceIndex
ApprovalLedger
FailureState
SkillReferences
ModelCallLedger
CostLedger
ResourceState
ContinuationState
```

---

# Evidence-first

Every important claim should reference evidence:
- test result;
- screenshot;
- commit;
- effect receipt;
- verifier report;
- benchmark record.

Avoid storing unsupported prose as fact.

---

# Memory layers

## L0 Immutable contracts
security / approval / side-effect invariants

## L1 Architecture
stable repo/system facts

## L2 Mission
objective, DoD, constraints

## L3 Current work item
small current state

## L4 Evidence
only relevant excerpts

## L5 Learned skill
generalized durable behavior

## L6 Historical archive
full logs/artifacts kept out of active context

---

# Compression

Compaction must preserve:
- IDs;
- current HEAD;
- current goal;
- open blockers;
- last verified state;
- next exact action;
- side effects;
- approvals;
- budget;
- relevant evidence references.

---

# Conflict handling

When memory conflicts with source:
source wins.

When two evidence items conflict:
mark uncertainty and schedule verification.

Never silently merge contradictions.

---

# Forgetting

Safe forgetting candidates:
- superseded logs;
- redundant successful outputs;
- obsolete speculative hypotheses;
- repeated tool narration.

Never forget:
- unresolved P0;
- approval state;
- side-effect receipts;
- rollback info;
- acceptance failure;
- current mission continuity.
