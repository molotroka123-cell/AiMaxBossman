# V3 IMPLEMENTATION PHASES

## Phase 0 — V2 baseline lock
Before V3:
- freeze V2;
- UX 2.0 green;
- exact current HEAD;
- CI green;
- known blockers recorded.

No V3 feature if V2 regression is unresolved P0.

---

## Phase 1 — WorldState + continuation interfaces
Deliver:
- V3 mission schema;
- event schema;
- skill references;
- failure record;
- continuation capsule.

Acceptance:
restart and resume same mission state.

---

## Phase 2 — UCA Teach Me
Deliver:
- demonstration recorder;
- semantic action capture;
- candidate skill builder;
- dry replay;
- owner review.

Acceptance:
one real safe workflow learned and replayed.

---

## Phase 3 — Skill Factory
Deliver:
- candidate store;
- dedupe;
- scoring;
- promotion;
- aging;
- reuse selector.

Acceptance:
related unseen task solved with reused skill.

---

## Phase 4 — Failure Diagnosis / Self-Healing
Deliver:
- fingerprint;
- taxonomy;
- diagnosis engine;
- recovery playbooks;
- skill update proposal.

Acceptance:
injected failure repaired without identical blind retry loop.

---

## Phase 5 — Night Shift
Deliver:
- safe task queue;
- approval waiting;
- restart;
- morning report.

Acceptance:
real overnight-style mission simulation.

---

## Phase 6 — Software Factory
Deliver:
- objective→spec;
- build graph;
- tests;
- security;
- browser demo.

Acceptance:
one functioning local app.

---

## Phase 7 — Trader Apprentice ingest
Deliver:
- video/audio pipeline;
- ASR;
- adaptive frames;
- episode extraction;
- chart/transcript alignment.

Acceptance:
one real long-form video fully processed into structured episodes.

---

## Phase 8 — Trader blind learning
Deliver:
- pattern store;
- blind test split;
- imitation metrics;
- no-lookahead enforcement;
- shadow dashboard.

Acceptance:
unseen episode benchmark.

---

## Phase 9 — Tournament / optimization
Deliver:
- local candidate strategies;
- evaluator;
- strong model escalation;
- cost/value ledger.

---

## Phase 10 — V3 UX integration
Wire:
- Learn;
- Skill Factory;
- Night Shift;
- Software Factory;
- Trader Apprentice;
- Failure Diagnosis.

---

## Phase 11 — Long-horizon V3 freeze
One mission exercises:
- Teach Me;
- skill reuse;
- failure diagnosis;
- restart;
- Night Shift;
- cost governor;
- verifier;
- UI;
- final exact-SHA benchmark.


---

## Expanded cross-cutting phases

### Phase 1A — Visual State Engine
Add semantic state/delta layer before deep Teach Me replay.

### Phase 1B — Capability Registry
Make planner aware of real allowed capabilities.

### Phase 4A — Recovery Kernel
Turn diagnosis results into safe deterministic restoration.

### Phase 5A — Event-Driven Boss
Resume and trigger work from real events with dedupe.

### Phase 8A — Data Flywheel
Filter training/learning data and protect holdout.

### Phase 9A — Local distillation
Convert verified teacher episodes into student training/eval pairs.

### Phase 10A — Observability / Provenance
Tie every major action/artifact to mission/work-item/evidence.

### Phase 11A — Red Team / Disaster Recovery
Attack restart, approval, leakage, recovery, event loops and dataset contamination.
