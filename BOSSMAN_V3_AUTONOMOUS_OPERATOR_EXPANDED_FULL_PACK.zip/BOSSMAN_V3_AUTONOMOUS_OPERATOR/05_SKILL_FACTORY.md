# SKILL FACTORY

## Core idea

Skills become BOSSMAN's reusable operational capital.

A skill is not just a prompt.
It is a versioned behavior object with:
- goal;
- applicability;
- inputs;
- outputs;
- procedure;
- preconditions;
- postconditions;
- risk;
- approvals;
- recovery;
- metrics;
- provenance;
- tests.

---

# Lifecycle

```text
OBSERVED
→ CANDIDATE
→ SANDBOX_VERIFIED
→ PROMOTED
→ ACTIVE
→ AGING
→ SUPERSEDED / QUARANTINED / ARCHIVED
```

---

# Candidate sources

- owner demonstration;
- successful autonomous mission;
- teacher-assisted fix;
- repeated manual recovery;
- Fable-generated strategy;
- imported signed/approved skill;
- Software Factory workflow.

---

# Skill identity

Canonical fingerprint should incorporate:
- semantic goal;
- input/output schema;
- action graph;
- pre/post conditions;
- domain;
- safety class.

Avoid duplicates caused by wording differences.

---

# Metrics

Per skill:
```text
attempts
successes
failures
success_rate
verification_rate
median_latency
p95_latency
local_compute_cost
cloud_cost
teacher_calls_avoided
owner_interventions
recovery_count
last_used
last_verified
regime/domain
```

---

# Skill selection score

Example conceptual score:

```text
utility =
  applicability_confidence
  * verified_success_rate
  * recency_factor
  * safety_factor
  * cost_efficiency
  * latency_efficiency
```

Do not hard-code one opaque formula as truth.
Keep components inspectable.

---

# Merge

If two skills overlap:
1. compare goal and schemas;
2. compare action graph;
3. identify shared core;
4. identify environment-specific branches;
5. create merged candidate;
6. replay historical tests;
7. promote only if not worse.

---

# Aging

A skill should lose confidence if:
- UI changed;
- target version changed;
- repeated failures;
- unused too long;
- verifier confidence drops.

Aging does not necessarily delete the skill.

---

# Security

Before promotion:
- redact secrets;
- detect hard-coded tokens;
- detect unsafe shell;
- validate approvals;
- verify protected paths;
- ensure side effects are declared.

---

# Teacher reduction benchmark

Strong proof:
- Task A requires external teacher;
- generalized skill is created;
- related Task B is unseen;
- BOSSMAN retrieves skill;
- solves B without teacher;
- independent verifier passes.

Target:
`teacher_calls_B < teacher_calls_A`
Best:
`teacher_calls_B = 0`.
