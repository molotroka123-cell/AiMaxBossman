# EVENT-DRIVEN BOSS

## Goal

BOSSMAN should react to meaningful events without polling everything constantly or requiring the owner to manually relaunch workflows.

Event-Driven Boss is the trigger layer for V3 autonomy.

---

# Event sources

```text
mission events
filesystem events
repo/CI events
browser/app events
scheduled events
model completion
approval resolution
resource pressure
skill degradation
failure events
incoming connector/webhook events where authorized
market/video ingest completion
```

---

# Event envelope

```text
event_id
event_type
source
timestamp
mission_id?
correlation_id?
payload_ref
risk_class
dedupe_key
ttl
```

---

# Trigger rule

```text
WHEN event
IF predicates
THEN create work item / resume mission / request approval / notify owner
```

Rules must be:
- explicit;
- auditable;
- bounded;
- idempotent;
- disableable.

---

# Examples

```text
WHEN benchmark.failed
IF current_head == benchmark_head
THEN create diagnosis work item
```

```text
WHEN video.ingest.complete
THEN queue episode extraction
```

```text
WHEN approval.resolved
THEN resume exact blocked work item
```

```text
WHEN skill.failure_rate_high
THEN quarantine candidate and schedule verification
```

---

# Event storms

Protect against:
- duplicate webhooks;
- file watcher loops;
- retry storms;
- feedback loops.

Use:
- dedupe keys;
- debounce;
- max fanout;
- per-rule rate limit;
- correlation cycle detection.

---

# Security

An external event never directly performs a risky action.

It creates a governed work item.

Risky work still passes approval/policy.

---

# Acceptance

`V3-EVENT-DEDUP-001`
Duplicate event does not create duplicate work.

`V3-EVENT-RESUME-001`
Approval event resumes exact blocked work item.

`V3-EVENT-LOOP-001`
Self-triggering loop is detected and stopped.
