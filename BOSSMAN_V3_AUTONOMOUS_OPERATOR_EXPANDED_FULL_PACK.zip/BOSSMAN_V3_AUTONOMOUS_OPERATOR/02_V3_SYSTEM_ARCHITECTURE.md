# V3 SYSTEM ARCHITECTURE

## High-level graph

```text
Owner
  ↓
Mission Control / Desktop App
  ↓
Mission Manager
  ├─ WorldState
  ├─ Continuation Engine
  ├─ Approval Broker
  ├─ Cost / Context Governor
  ├─ Failure Diagnosis Engine
  ├─ Skill Runtime
  ├─ Skill Factory
  ├─ UCA / Computer Operator
  ├─ Trader Apprentice
  ├─ Software Factory
  ├─ Night Shift Scheduler
  ├─ Model Router / Tournament
  └─ Independent Verifier
```

## Architectural principle

The manager owns **mission truth**.
Agents own **proposals/work items**, not canonical truth.
Verifier owns **accept/reject evidence**, not mutation.
Skills are reusable behavior assets, not prompts with mythology.

---

## Layer 1 — Owner / UX

Responsibilities:
- create mission;
- teach workflow;
- review skill;
- approve risky action;
- inspect Thinking process telemetry;
- see blockers/cost/resources;
- take over browser;
- compare learned behavior.

Never:
- bypass backend policy;
- manufacture PASS;
- directly mutate protected side-effect state.

---

## Layer 2 — Mission Manager

Canonical responsibilities:
- mission lifecycle;
- task graph;
- dependency scheduling;
- checkpoint;
- restart/recovery;
- work-item routing;
- resource reservation;
- budget;
- approval gating;
- final acceptance aggregation.

Every operation is associated with:
- mission_id
- work_item_id
- attempt_id
- evidence ids
- current HEAD/tree
- side-effect classification

---

## Layer 3 — WorldState

State model:
```text
GoalState
TaskState
EnvironmentState
ObservationState
ActionState
EvidenceState
ApprovalState
SkillState
ModelCallState
BudgetState
FailureState
ContinuationState
```

WorldState is durable and queryable.

Do not store hidden raw model reasoning.

---

## Layer 4 — UCA

Ports:
```text
Observer
Actuator
Verifier
Recovery
Takeover
DemonstrationRecorder
SemanticTargetResolver
EffectReceipt
```

UCA must separate:
- intended action;
- performed action;
- observed outcome;
- verified effect.

---

## Layer 5 — Learning / Skill Factory

Pipeline:
```text
episode
→ successful trajectory
→ abstraction
→ parameterization
→ invariants
→ verification
→ candidate skill
→ sandbox replay
→ score
→ promotion
```

Bad skills:
- decay;
- quarantine;
- merge;
- supersede;
- archive.

---

## Layer 6 — Domain Apprentices

Trader Apprentice is the first domain specialization.

Future apprentices can reuse same interface:
```text
ingest
normalize
align
episode extraction
decision representation
outcome evaluation
skill proposal
blind benchmark
```

---

## Layer 7 — Model Economy

Local workers do:
- search;
- parse;
- mechanical edits;
- OCR/ASR;
- summarization;
- small code changes;
- test generation.

Fable/strong models do:
- hard cross-module diagnosis;
- strategy comparison;
- high-value skill abstraction;
- security-sensitive design;
- final review.

---

## Layer 8 — Independent Verification

Verifier should be able to say:
- ACCEPT
- REJECT
- BLOCKED_BY_ENVIRONMENT
- INSUFFICIENT_EVIDENCE

Never let patch author self-certify a high-risk change.

---

## Event bus

Canonical event classes:
```text
mission.created
mission.phase.changed
task.started
task.completed
task.failed
observation.captured
action.proposed
action.executed
effect.verified
approval.requested
approval.resolved
skill.candidate.created
skill.promoted
skill.rejected
failure.classified
recovery.started
recovery.completed
model.call.started
model.call.finished
budget.reserved
budget.committed
checkpoint.written
continuation.resumed
```

Thinking process UI subscribes to a redacted projection of these events.
