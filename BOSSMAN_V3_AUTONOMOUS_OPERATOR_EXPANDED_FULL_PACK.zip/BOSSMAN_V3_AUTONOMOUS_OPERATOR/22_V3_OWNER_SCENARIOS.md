# V3 OWNER SCENARIOS

## Scenario A — Teach Higgsfield workflow
Owner demonstrates:
- open Higgsfield;
- choose model;
- upload media;
- enter prompt;
- generate;
- wait;
- inspect;
- save result.

BOSSMAN:
- records semantics;
- redacts secrets;
- identifies parameters;
- creates skill;
- dry-replays with different prompt/input;
- asks approval only where needed.

## Scenario B — Trader learning
Owner adds K!MBA playlist/VOD.
BOSSMAN:
- queues videos;
- transcribes;
- finds chart moments;
- extracts episodes;
- builds pattern hypotheses;
- runs blind tests;
- shows imitation score and uncertainty.

## Scenario C — Night SEO work
Owner:
> audit Fresh Vibes pages, prepare fixes and drafts overnight; do not publish.

BOSSMAN:
- audits;
- drafts;
- tests;
- prepares artifacts;
- does not publish;
- morning report shows changes.

## Scenario D — Software Factory
Owner:
> make a local lead intake dashboard.

BOSSMAN:
- spec;
- design;
- build;
- test;
- browser E2E;
- demo;
- asks before any production deployment.

## Scenario E — Hard coding bug
Local agents fail.
Fable diagnoses.
BOSSMAN verifies.
A generalized recovery skill is recorded.
Later related bug is solved locally without Fable.

These scenarios should inform real acceptance tests.
