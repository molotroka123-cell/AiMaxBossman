# NIGHT SHIFT

## Goal

Owner can queue meaningful work at night and receive a trustworthy morning result.

Night Shift is not “let agents run endlessly”.
It is a governed long-horizon execution mode.

---

# Night mission structure

```text
mission
goals
must_do
nice_to_have
approval_policy
time_budget
cloud_budget
resource_policy
stop_conditions
morning_report_time
```

---

# Execution

```text
LOAD MISSION
→ PREFLIGHT
→ RESOURCE CHECK
→ BUILD DAG
→ EXECUTE LOCAL-FIRST
→ CHECKPOINT
→ ESCALATE HARD ITEMS
→ VERIFY
→ COMMIT/PUSH VERIFIED WORK
→ CONTINUE
→ SAFE STOP / COMPLETE
→ MORNING REPORT
```

---

# Owner absent policy

Allowed:
- read;
- analyze;
- local test;
- code changes within repo;
- safe browser work;
- create drafts;
- create demos;
- commit/push verified development changes if mission allows.

WAIT_APPROVAL:
- sending messages;
- purchases;
- production deployments;
- destructive file deletion outside safe sandbox;
- credential changes;
- live trading;
- irreversible business actions.

---

# Failure policy

Do not wake owner for:
- one model failure;
- context rotation;
- temporary test failure;
- recoverable browser failure.

Wake/stop only when:
- unresolved P0;
- unsafe state;
- repo integrity issue;
- all allowed routes exhausted;
- owner approval genuinely required for progress.

---

# Morning report

Must include:
```text
mission_id
start/end
HEAD before/after
completed
failed
blocked
owner approvals waiting
skills created/promoted/rejected
tests
security findings
cloud cost
local resource usage
commits/pushes
important screenshots/artifacts
next recommended action
```

---

# Restart test

Night Shift must survive one deliberate manager restart:
same mission_id, no duplicate side effect.
