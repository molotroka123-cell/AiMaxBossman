# CAPABILITY REGISTRY + PERMISSION MODEL

## Why

An autonomous operator needs to know exactly what it can do in each environment.

---

# Capability record

```text
capability_id
provider/adapter
environment
operations
risk_classes
requires_approval
credentials_required
network_required
resource_cost
health
version
```

---

# Examples

```text
browser.navigate
browser.download
terminal.run_sandboxed
terminal.run_project
github.read
github.push
email.draft
email.send
trader.shadow_predict
trader.live_order
```

Capabilities are not equivalent in risk.

---

# Resolution

Before planning:
1. inspect available capabilities;
2. filter by policy;
3. filter by environment health;
4. choose cheapest safe tool.

Do not plan around unavailable fantasy tools.

---

# Permission layers

```text
NEVER
ASK
ALLOWED
```

But enforcement belongs in backend policy, not UI labels.

---

# Temporary grants

Owner may authorize:
- one action;
- one mission;
- one target;
- limited duration.

Grant must be scope-bound.

---

# Acceptance

`V3-CAP-RESOLVE-001`
Planner chooses available capability.

`V3-CAP-DENY-001`
Unavailable/forbidden capability is rejected.

`V3-CAP-SCOPE-001`
Temporary permission cannot escape its scope.
