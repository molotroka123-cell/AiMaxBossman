# PERSONAL SOFTWARE FACTORY

## Objective

Owner provides business/product objective, not implementation micromanagement.

BOSSMAN performs a gated software lifecycle.

---

# Pipeline

```text
OBJECTIVE
→ RESEARCH
→ REQUIREMENTS
→ ACCEPTANCE CRITERIA
→ ARCHITECTURE
→ UI/UX
→ IMPLEMENTATION
→ UNIT/INTEGRATION TESTS
→ REAL BROWSER TEST
→ SECURITY REVIEW
→ PERFORMANCE CHECK
→ LOCAL DEPLOY/DEMO
→ OWNER REVIEW
```

---

# Research

Research must distinguish:
- public facts;
- repo facts;
- assumptions;
- owner requirements.

No invented constraints.

---

# Requirements artifact

Minimum:
- users;
- user stories;
- functional requirements;
- non-functional requirements;
- security;
- data;
- integrations;
- explicit out-of-scope;
- acceptance criteria.

---

# Build graph

Split:
- frontend;
- backend;
- persistence;
- tests;
- security;
- docs;
- deployment.

Use local workers in parallel only when files/state do not conflict.

---

# UI

Use existing BOSSMAN UX quality bar:
- real actions;
- no fake controls;
- responsive;
- accessible;
- owner-readable;
- error states.

---

# Security

Independent pass for:
- auth;
- secrets;
- injection;
- path traversal;
- command execution;
- CSRF/replay where relevant;
- data exposure;
- unsafe defaults.

---

# Deployment

V3 default:
local demo only.

Production deploy requires explicit policy/owner approval.

---

# Acceptance example

`V3-SOFTWARE-FACTORY-001`:
Owner supplies one compact real product objective.
BOSSMAN generates a functioning local app, tests it, opens it in browser, fixes at least one discovered issue, and presents verified artifact.
