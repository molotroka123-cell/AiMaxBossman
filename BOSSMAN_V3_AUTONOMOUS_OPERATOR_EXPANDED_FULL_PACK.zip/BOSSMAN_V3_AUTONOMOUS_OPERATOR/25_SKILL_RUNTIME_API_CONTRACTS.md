# SKILL RUNTIME — API / CONTRACT SPEC

## Skill as executable knowledge

A skill should have declarative metadata plus executable steps.

Recommended fields:

```yaml
id: higgsfield.generate_video
version: 3
goal: Generate a video in Higgsfield from input media and prompt
domain: computer-use
risk_class: remote_reversible
inputs:
  media_path: file
  prompt: string
  model: string?
outputs:
  artifact_path: file
preconditions:
  - browser authenticated
approvals:
  - condition: external_paid_generation
steps:
  - ...
verification:
  - output artifact exists
recovery:
  - ...
```

---

# Skill selector contract

Input:
```text
goal
environment
available capabilities
risk
known app/site
historical context
```

Output:
```text
selected skill/version
applicability score
alternatives
reason summary
required approvals
known risks
```

---

# Execution modes

```text
DRY_RUN
SANDBOX
SHADOW
LIVE_ALLOWED
```

Skills declare allowed modes.

A Trader Apprentice skill defaults to SHADOW.

---

# Versioning

Promoting a new version does not delete the prior known-good version.

Support:
- active version;
- rollback version;
- canary version.

---

# Provenance

Every version:
```text
created_from
demonstration_ids
mission_ids
teacher_call ids if relevant
author agent
verifier
tests
commit SHA
```

---

# Skill tests

A skill package may ship:
- contract tests;
- fixture/sandbox replay;
- real acceptance reference.

Do not allow a skill to mark its own test PASS without external runtime result.

---

# Skill quarantine

Automatic quarantine candidates:
- secret leak detected;
- repeated side-effect mismatch;
- approval bypass attempt;
- high failure rate after environment change;
- verifier rejection.

Quarantine prevents auto-selection but preserves evidence.

---

# Skill retrieval context economy

Do not inject all skill bodies.

Retrieve:
1. metadata shortlist;
2. best candidate summary;
3. exact skill body only when selected.

This prevents skill library from consuming context.

---

# Skill learning events

```text
skill.candidate.created
skill.validation.started
skill.validation.passed
skill.validation.failed
skill.promoted
skill.execution.started
skill.execution.verified
skill.execution.failed
skill.quarantined
skill.superseded
```

These feed Mission Control and long-term metrics.
