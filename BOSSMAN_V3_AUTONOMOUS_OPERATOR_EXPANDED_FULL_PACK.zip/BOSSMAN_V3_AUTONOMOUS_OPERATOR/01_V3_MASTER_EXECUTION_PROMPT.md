# MASTER EXECUTION PROMPT — BOSSMAN V3 AUTONOMOUS OPERATOR

Repository: `molotroka123-cell/AiMaxBossman`
Branch: `claude/bossman-control-v03-43igbk`
Reference HEAD at prompt creation: `8de51ce9b387e3fba0cf615d2caf8c3845a935eb`

## ABSOLUTE FIRST ACTION

Fetch remote.
Resolve actual branch HEAD.
Read the current V2 freeze/UX state.
Continue from the real newest state.

Never roll back valid work just to match this prompt.

---

# V3 PRIMARY OBJECTIVE

Transform BOSSMAN from a powerful orchestration platform into a **local autonomous operator that can learn repeatable human workflows and improve from evidence**.

Owner-level contract:

```text
OWNER SHOWS / DESCRIBES GOAL
→ BOSSMAN OBSERVES
→ MODELS TASK
→ EXECUTES
→ VERIFIES RESULT
→ DIAGNOSES FAILURE
→ LEARNS REUSABLE SKILL
→ REUSES SKILL NEXT TIME
→ ESCALATES ONLY WHEN NEEDED
→ RECORDS OUTCOME
→ IMPROVES SKILL ECONOMY
```

V3 must be measurable. No “looks autonomous” acceptance.

---

# V3 MANDATORY FOUNDATIONS

Implement these as integrated runtime capabilities, reusing V2 foundations where they already exist.

## A. Universal Computer Apprentice 2.0
- semantic browser/GUI observations;
- real application workflows;
- observe / act / verify / recover;
- safe human takeover;
- robust replay using semantic targets, not fixed coordinates only;
- action receipts;
- recovery after UI drift.

## B. Teach Me Mode
- owner starts a demonstration session;
- BOSSMAN records structured observable actions/state;
- creates an editable procedure representation;
- generalizes literals into parameters;
- proposes validation rules;
- performs a dry replay;
- owner can approve the learned skill;
- production skill promotion only after evidence.

## C. Trader Apprentice
- ingest YouTube/Twitch/VOD/video;
- transcribe speech;
- align transcript to chart/visual state;
- detect high-value moments;
- extract market state + trader thesis + action/no-action + invalidation;
- track outcome later;
- learn decision patterns;
- blind-test against unseen content;
- mandatory shadow mode before any live execution;
- no autonomous real-money trading without explicit separate owner authorization.

## D. Skill Factory
- extract reusable skills from successful workflows;
- select/reuse skills;
- deduplicate;
- merge compatible skills;
- age/decay poor skills;
- track success/failure/cost/latency;
- promote only after evidence;
- reject skills that leak secrets or hard-code transient data.

## E. Night Shift
- owner submits safe mission queue;
- local-first execution;
- cloud escalation under budget;
- WAIT_APPROVAL for risky actions;
- recover from failures;
- checkpoint;
- morning report;
- no owner continuation prompt merely because context/model call ended.

## F. Personal Software Factory
Objective:
```text
idea
→ research
→ requirement spec
→ architecture
→ implementation
→ tests
→ browser/UI verification
→ security review
→ local demo
→ owner presentation
```
No production deployment without policy/approval.

## G. WorldState 2.0
One durable canonical mission state:
- objectives;
- subgoals;
- task graph;
- environment observations;
- actors;
- resources;
- approvals;
- evidence;
- side effects;
- learned skills;
- model state;
- cost/context state;
- blockers;
- continuation capsule.

## H. Failure Diagnosis / Self-Healing
Not `retry()`.

Required pipeline:
```text
failure
→ fingerprint
→ classify
→ gather minimal evidence
→ hypothesis set
→ local reproduce
→ minimal repair
→ targeted test
→ verifier
→ resume
```

## I. Model / Strategy Tournament
When justified:
- 2–4 cheap/local candidate strategies;
- comparable typed outputs;
- deterministic evaluator;
- stronger model only for unresolved disagreement/high-value residual;
- record cost vs improvement.

## J. V3 Mission Control
Owner must see:
- what is being learned;
- current mission;
- current skill;
- current failure diagnosis;
- current model/tool;
- liveness;
- approvals;
- cost;
- learning progress;
- skill promotion/rejection;
- blind evaluation results.

---

# CONTEXT AND COST DISCIPLINE

Use the separate persistent contract `11_CONTEXT_COST_ROUTING.md`.

Key rules:
- do not feed entire repo to Fable;
- local deterministic work first;
- summarize by blob/tree SHA;
- ProblemBundle only;
- checkpoint early;
- frequent verified commits + pushes;
- Fable for hard reasoning/high leverage;
- no broad repeated audits.

---

# FREQUENT PUSH POLICY

After every meaningful atomic verified improvement:

```text
patch
→ focused test
→ verifier if high risk
→ commit
→ push
→ checkpoint
→ continue
```

Do not accumulate hours of verified work locally.

Do not commit every typo separately.
Commit cohesive, independently useful improvements.

---

# LONG-HORIZON RULE

“One mission” means one durable `mission_id`.

Internal agent/model contexts may rotate.

The owner must NOT be asked to manually continue because:
- context ended;
- one model hit limits;
- one worker failed;
- checkpoint restarted;
- manager restarted.

Resume through durable state.

---

# V3 LEARNING RULE

Never claim learning from:
- raw chat history;
- a hard-coded test replacement;
- replaying a known exact patch;
- a hand-authored expected answer inside the test;
- hidden future information.

Learning evidence must show:
1. experience A;
2. generalized reusable representation;
3. unseen problem B;
4. skill retrieval/application on B;
5. independent verification;
6. reduced external teacher dependence where measurable.

---

# TRADER APPRENTICE SAFETY

Trader Apprentice is a research/shadow-learning system first.

Before any live-money action:
- owner explicitly enables a separate live policy;
- action limits;
- venue/account constraints;
- max risk;
- kill switch;
- durable approval;
- replay protection;
- independent pre-trade verification as required.

V3 acceptance does NOT require real-money trading.

Preferred acceptance:
high-quality blind shadow evaluation.

---

# REQUIRED ARTIFACTS

Create/update:

```text
docs/v3/V3_ARCHITECTURE.md
docs/v3/V3_ACCEPTANCE.md
docs/v3/UCA_TEACH_ME.md
docs/v3/TRADER_APPRENTICE.md
docs/v3/SKILL_FACTORY.md
docs/v3/NIGHT_SHIFT.md
docs/v3/SOFTWARE_FACTORY.md
docs/v3/WORLDSTATE_V2.md
docs/v3/FAILURE_DIAGNOSIS.md
docs/v3/SECURITY_MODEL.md
docs/v3/V3_CONTEXT_COST.md
docs/v3/V3_KEY_FUNCTION_TOUCH_MATRIX.md
docs/v3/V3_FINAL_REPORT.md
```

---

# REQUIRED V3 ACCEPTANCE IDS

At minimum:

```text
V3-UCA-LEARN-001
V3-UCA-REPLAY-001
V3-UCA-UI-DRIFT-001
V3-TEACHME-PARAM-001
V3-SKILL-REUSE-001
V3-SKILL-DEDUP-001
V3-SKILL-PROMOTION-001
V3-NIGHTSHIFT-001
V3-NIGHTSHIFT-RESTART-001
V3-SOFTWARE-FACTORY-001
V3-FAILURE-DIAG-001
V3-SELF-HEAL-001
V3-TOURNAMENT-001
V3-TRADER-INGEST-001
V3-TRADER-ALIGN-001
V3-TRADER-BLIND-001
V3-TRADER-NO-LEAK-001
V3-OWNER-APPROVAL-001
V3-COST-GOVERNOR-001
V3-CONTINUATION-001
```

---

# STOP CONDITIONS

Stop optional feature discovery and enter completion mode when:
- mandatory gates implemented;
- no open P0;
- no unresolved high-value P1 blocking acceptance;
- two improvement waves find no material blocker;
- context/cost reserves need preservation.

Defer cosmetics and speculative features.

---

# FINAL COMPLETION MODE

Sequence:
1. current V2 regression;
2. targeted V3 security;
3. long-horizon V3 mission;
4. one deliberate restart;
5. UCA learn/replay;
6. Skill Factory proof;
7. Night Shift proof;
8. Software Factory proof;
9. Trader shadow blind evaluation;
10. exact-SHA benchmark;
11. independent final verifier;
12. current CI;
13. final report;
14. push;
15. `BOSSMAN_V3_AUTONOMOUS_OPERATOR_READY=YES|NO`.

---

# FINAL RESPONSE FORMAT

```text
FINAL_HEAD=
V2_REGRESSION=
V3_UCA=
TEACH_ME=
SKILL_FACTORY=
NIGHT_SHIFT=
SOFTWARE_FACTORY=
TRADER_APPRENTICE=
WORLDSTATE=
SELF_HEALING=
MODEL_TOURNAMENT=
RESTART_CONTINUATION=
OWNER_APPROVAL=
CLOUD_COST=
OPEN_P0=
OPEN_P1=
DEFERRED=
BOSSMAN_V3_AUTONOMOUS_OPERATOR_READY=
```
