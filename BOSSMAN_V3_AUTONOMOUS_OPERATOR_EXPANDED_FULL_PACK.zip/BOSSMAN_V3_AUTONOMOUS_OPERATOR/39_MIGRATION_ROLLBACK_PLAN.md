# V2 → V3 MIGRATION / ROLLBACK PLAN

## Goal

V3 must not require one giant irreversible migration.

---

# Strategy

Use:
- feature flags;
- additive schema;
- versioned migrations;
- adapters;
- dual-read only temporarily if required;
- explicit cutover.

---

# Order

1. backup;
2. schema compatibility tests;
3. add V3 fields/tables;
4. keep V2 read paths;
5. write V3 in shadow;
6. verify;
7. enable feature per subsystem.

---

# Feature flags

Suggested conceptual:
```text
V3_WORLDSTATE
V3_TEACH_MODE
V3_SKILL_FACTORY
V3_NIGHT_SHIFT
V3_SOFTWARE_FACTORY
V3_TRADER
V3_EVENT_BOSS
```

Do not leave flags as permanent architecture if no longer needed.

---

# Rollback

Each migration must document:
- forward;
- rollback;
- data loss risk;
- compatibility.

---

# Acceptance

`V3-MIGRATION-V2-001`
Existing V2 mission/skills remain readable.

`V3-MIGRATION-ROLLBACK-001`
Rollback returns system to working V2-compatible state.
