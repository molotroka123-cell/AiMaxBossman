# V3 CANONICAL DATA SCHEMAS

This document defines conceptual schemas. Implementation may use typed Python/Pydantic/SQL while preserving semantics.

---

## DemonstrationEpisode

```json
{
  "id": "demo_...",
  "mission_id": "m_...",
  "started_at": "...",
  "ended_at": "...",
  "environment": {},
  "actions": [],
  "effects": [],
  "redactions": [],
  "owner_notes": []
}
```

## SkillCandidate

```json
{
  "skill_id": "skill_...",
  "version": 1,
  "goal": "...",
  "domain": "...",
  "inputs_schema": {},
  "outputs_schema": {},
  "preconditions": [],
  "steps": [],
  "postconditions": [],
  "approvals": [],
  "recovery": [],
  "provenance": [],
  "metrics": {},
  "status": "CANDIDATE"
}
```

## FailureRecord

```json
{
  "failure_id": "fail_...",
  "fingerprint": "...",
  "class": "UI_DRIFT",
  "evidence": [],
  "hypotheses": [],
  "selected_hypothesis": null,
  "recovery_attempts": [],
  "resolution": null
}
```

## TraderDecisionEpisode

```json
{
  "episode_id": "tradeep_...",
  "source": {},
  "time_window": {},
  "market_state": {},
  "teacher": {
    "observation": "",
    "thesis": "",
    "action": "wait",
    "entry": null,
    "stop": null,
    "targets": [],
    "invalidation": ""
  },
  "future_outcome": null,
  "blind_eligible": true
}
```

## NightShiftMission

```json
{
  "mission_id": "night_...",
  "tasks": [],
  "approval_policy": {},
  "resource_policy": {},
  "cloud_budget": 0,
  "stop_conditions": [],
  "report_policy": {}
}
```
