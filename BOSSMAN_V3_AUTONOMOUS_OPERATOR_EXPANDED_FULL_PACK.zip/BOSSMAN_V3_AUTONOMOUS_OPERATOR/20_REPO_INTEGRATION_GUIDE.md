# REPOSITORY INTEGRATION GUIDE

## First rule

Inspect current code and REUSE existing foundations.

Do not create:
- `worldstate_v3_new_final2.py`
- parallel approval stores;
- parallel mission manager;
- parallel skill registry;
- duplicate routers.

Extend canonical implementations.

---

# Integration discovery checklist

Find current:
- mission model/store;
- WorldState;
- checkpoint/capsule;
- skill registry;
- UCA ports;
- browser actuator;
- EffectReceipt;
- owner approval;
- side-effect ledger;
- cost governor;
- direct Fable transport;
- teacher sandbox;
- model router;
- Command Center APIs;
- event/telemetry path;
- benchmark path.

Document exact symbols before modifying.

---

# Migration strategy

Prefer:
- additive schema fields;
- adapters;
- versioned migrations;
- compatibility tests.

Avoid:
- destructive schema reset;
- rewriting stable V2 subsystems in one giant commit.

---

# Commit sequence guidance

Suggested:
```text
feat(v3): add durable v3 mission/event schemas
feat(apprentice): add teach-me demonstration recorder
feat(skills): add candidate lifecycle and promotion evidence
feat(recovery): add failure diagnosis engine
feat(night): add governed night-shift mission runner
feat(factory): add software factory pipeline
feat(trader): add video episode ingestion
feat(trader): add blind evaluation harness
ui(v3): expose learning and autonomy surfaces
test(v3): add long-horizon acceptance
docs(v3): record final v3 evidence
```

---

# Frequent push

Push each verified atomic milestone.

Do not wait until the entire V3 branch is one enormous unreviewable change.

---

# Backward compatibility

V2 owner flows must remain operational throughout staged V3 development.

A V3 migration cannot silently break:
- current missions;
- approvals;
- existing skills;
- Command Center;
- browser;
- terminal;
- cost ledger.
