# V3 BENCHMARK & ACCEPTANCE

## Philosophy

V3 must prove autonomy on unseen/restarted/changed conditions.

No benchmark that encodes the answer directly.

---

# Benchmark families

## 1. Computer Apprentice
- learn workflow;
- replay with changed parameters;
- UI drift;
- restart midway;
- recover from missing target.

## 2. Skill transfer
- source task A;
- derived skill;
- unseen related task B;
- reduced teacher usage.

## 3. Failure diagnosis
Inject typed failure and require correct diagnosis/recovery path.

## 4. Night Shift
Long mission with:
- multiple tasks;
- one failure;
- one restart;
- one approval-wait item;
- morning report.

## 5. Software Factory
Build a real small app from objective to local demo.

## 6. Trader Apprentice
Blind unseen episodes with strict no-lookahead.

---

# Key metrics

Autonomy:
- owner interventions / mission;
- recovery success;
- restart continuity;
- skill reuse rate;
- external teacher reduction.

Reliability:
- verified task success;
- duplicate side effects;
- recovery correctness;
- false PASS rate.

Economy:
- cloud cost;
- token use;
- cache utilization;
- local/cloud ratio.

Learning:
- skill promotion precision;
- rejected bad skill rate;
- transfer success;
- blind imitation quality.

---

# Mandatory “truth gates”

A test must record:
- real vs simulated;
- environment;
- SHA;
- timestamps;
- evidence refs;
- verifier.

No “passed” based only on agent prose.

---

# Exact-SHA

Final release benchmark must run against the exact final SHA.
Historical report cannot substitute for current release evidence.
