# TRADER APPRENTICE

## Goal

Learn a trader's observable decision process from:
- YouTube videos;
- Twitch streams/VODs;
- screen recordings;
- charts;
- spoken explanation;
- visible indicators;
- timestamps;
- later market outcomes.

The first intended teacher can be K!MBA TV or another chosen trader.

The system must learn **observable decision rules**, not imitate personality and not hallucinate an edge.

---

# Ingestion pipeline

```text
source
→ metadata
→ audio extraction
→ ASR transcript
→ scene/shot segmentation
→ adaptive frame sampling
→ chart-region detection
→ OCR/vision extraction
→ transcript↔frame alignment
→ market episode extraction
→ decision episode
→ later outcome attachment
→ skill hypothesis
→ blind evaluation
```

---

# Adaptive frame policy

Do not analyze 30 FPS continuously.

Baseline:
- low-rate frames during normal discussion;
- increase sampling around:
  - entry discussion;
  - stop/target changes;
  - indicator references;
  - drawn levels;
  - trade execution;
  - sudden price move;
  - regime explanation.

Keep full-resolution evidence only for important moments.

---

# Decision episode schema

```text
episode_id
source_id
timestamp_start
timestamp_end

visible_market_state:
  instrument
  timeframe
  price
  structure
  levels
  CVD
  OI
  volume
  liquidation context
  other visible indicators

trader_observation
trader_thesis
action:
  long | short | no_trade | manage | exit | wait

entry_plan
stop_plan
targets
invalidation
confidence
conditions_to_wait

future_outcome:
  horizon_1
  horizon_2
  max_favorable_excursion
  max_adverse_excursion
  whether_invalidation_hit
```

---

# Critical anti-leak rule

When evaluating the apprentice:
- hide teacher commentary for the test episode;
- hide future outcome;
- give only information available at decision time;
- apprentice answers first;
- reveal teacher answer after lock;
- then compare.

No look-ahead.

---

# Metrics

Track separately:

## Imitation
- direction match;
- action/no-action match;
- entry zone overlap;
- stop/invalidation similarity;
- target similarity;
- timing;
- confidence calibration;
- rationale factor overlap.

## Trading-quality shadow metrics
- expectancy;
- win/loss;
- profit factor;
- drawdown;
- MFE/MAE;
- risk-adjusted result;
- regime-specific performance.

Do not optimize only win rate.

---

# Teacher quality

The system must also evaluate the teacher.

A teacher pattern is not promoted merely because it was said confidently.

Store:
```text
pattern frequency
teacher historical success
regime dependence
sample size
uncertainty
```

---

# Multiple teachers

Future:
```text
Teacher A
Teacher B
Market data
BOSSMAN own historical evidence
→ regime-conditioned strategy selection
```

Conflicts must be explicit.

---

# Shadow-only initial release

Trader Apprentice V3 acceptance is SHADOW.

No real-money order submission required.

If live execution is ever enabled later:
- separate policy;
- owner opt-in;
- max exposure;
- max loss;
- venue whitelist;
- durable approvals;
- kill switch;
- no secret leakage;
- full audit trail.

---

# Suggested data milestone

Do not hard-code “weeks = mastery”.

Track:
- total hours;
- number of decision episodes;
- number of distinct regimes;
- blind sample size.

Useful milestones:
- 20–40 hours: vocabulary/layout bootstrap;
- 50–100+ hours: early pattern model;
- 150–300 hours: meaningful blind imitation evaluation;
- longer historical diversity improves regime coverage.

These are planning targets, not guaranteed performance.

---

# Acceptance

`V3-TRADER-INGEST-001`
Ingest a real long video and produce aligned episodes.

`V3-TRADER-ALIGN-001`
Transcript/chart alignment passes timestamp spot checks.

`V3-TRADER-NO-LEAK-001`
Blind test sees no teacher future commentary or future prices.

`V3-TRADER-BLIND-001`
Run unseen episodes and produce locked decisions before teacher reveal.

`V3-TRADER-LEARN-001`
Repeated patterns become skill hypotheses with evidence and regime boundaries.
