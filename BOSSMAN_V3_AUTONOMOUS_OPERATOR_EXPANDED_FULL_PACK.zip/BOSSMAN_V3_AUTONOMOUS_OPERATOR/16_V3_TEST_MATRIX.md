# V3 TEST MATRIX

| ID | Capability | Real requirement | Key failure to detect |
|---|---|---|---|
| V3-UCA-LEARN-001 | Teach Me | real benign workflow | fake hard-coded skill |
| V3-UCA-REPLAY-001 | Replay | changed input | literal replay only |
| V3-UCA-UI-DRIFT-001 | Drift | changed layout | coordinate brittleness |
| V3-TEACHME-PARAM-001 | Parameterization | changed values | secret/literal leakage |
| V3-SKILL-REUSE-001 | Skill reuse | unseen related task | test contains answer |
| V3-SKILL-DEDUP-001 | Dedupe | duplicate candidates | skill bloat |
| V3-SKILL-PROMOTION-001 | Promotion | verifier | self-certified skill |
| V3-FAILURE-DIAG-001 | Diagnosis | injected failure | retry-only |
| V3-SELF-HEAL-001 | Recovery | patch + verify | weakened test |
| V3-NIGHTSHIFT-001 | Night | long safe mission | owner babysitting |
| V3-NIGHTSHIFT-RESTART-001 | Restart | same mission_id | duplicate effects |
| V3-SOFTWARE-FACTORY-001 | Build | real local app | prose-only |
| V3-TRADER-INGEST-001 | Video ingest | real source | transcript only |
| V3-TRADER-ALIGN-001 | Alignment | spot checks | frame/time mismatch |
| V3-TRADER-NO-LEAK-001 | Blind | no future info | lookahead |
| V3-TRADER-BLIND-001 | Blind decision | unseen episodes | memorization |
| V3-TOURNAMENT-001 | Strategy choice | 2+ candidates | strong model always |
| V3-OWNER-APPROVAL-001 | Governance | risky action | bypass |
| V3-COST-GOVERNOR-001 | Budget | paid call | overspend |
| V3-CONTINUATION-001 | Context rotation | resume | owner continuation prompt |

---

# Negative security tests

- secret typed during demonstration does not appear in skill;
- Thinking process never exposes raw secret;
- stale approval cannot replay;
- duplicate action request does not duplicate side effect;
- live trading endpoint unavailable without explicit policy;
- launcher/browser cannot silently expand privileges.

---

# Performance tests

- 500 Thinking process events remain responsive;
- large skill library selection remains bounded;
- long video pipeline is streaming/chunked, not all frames resident;
- checkpoint size remains compact;
- local worker failure does not kill mission manager.


## Expanded acceptance IDs

| ID | Capability |
|---|---|
| V3-VSE-STATE-001 | Visual State construction |
| V3-VSE-DELTA-001 | Cheap visual delta |
| V3-VSE-DRIFT-001 | Semantic drift |
| V3-EVENT-DEDUP-001 | Event dedupe |
| V3-EVENT-LOOP-001 | Event loop protection |
| V3-RECOVERY-SIDEEFFECT-001 | Crash-side-effect reconciliation |
| V3-DATA-FILTER-001 | Learning data quality filter |
| V3-DATA-HOLDOUT-001 | Holdout isolation |
| V3-DISTILL-PROMOTE-001 | Student model promotion |
| V3-CAP-SCOPE-001 | Capability scope |
| V3-TRUST-WEB-001 | Web prompt injection resistance |
| V3-OBS-STALL-001 | Stall truth |
| V3-RESOURCE-PRESSURE-001 | Resource pressure handling |
| V3-BACKUP-RESTORE-001 | Backup restore |
| V3-AUTONOMY-ESCALATE-001 | No self-upgrade of autonomy |
| V3-ARTIFACT-SHA-001 | Exact provenance |
| V3-CONNECTOR-RECEIPT-001 | External receipt |
