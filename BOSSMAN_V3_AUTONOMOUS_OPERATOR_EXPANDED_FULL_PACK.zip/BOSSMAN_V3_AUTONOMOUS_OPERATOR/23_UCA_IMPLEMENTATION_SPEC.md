# UCA 2.0 — DEEP IMPLEMENTATION SPEC

## Objective

The Universal Computer Apprentice must operate real software through a typed observe/act/verify contract and be able to convert owner demonstrations into reusable workflows.

## Recommended domain interfaces

```python
class ObservationPort(Protocol):
    async def observe(self, target: EnvironmentTarget) -> Observation: ...

class ActionPort(Protocol):
    async def execute(self, action: ProposedAction) -> ActionReceipt: ...

class EffectVerifier(Protocol):
    async def verify(self, expected: ExpectedEffect, before: Observation, after: Observation) -> VerificationResult: ...

class DemonstrationRecorder(Protocol):
    async def start(self, session: TeachSession) -> None: ...
    async def record(self, event: DemonstrationEvent) -> None: ...
    async def finish(self) -> DemonstrationEpisode: ...
```

Exact names should conform to existing repository style; do not create duplicate canonical interfaces if equivalent ports already exist.

---

# Observation model

Observation should separate:
- environment metadata;
- window/page/app;
- accessible semantic tree;
- important visible text;
- focused element;
- pointer/keyboard state if needed;
- screenshots as evidence references;
- redacted sensitive fields;
- known loading/busy states.

Do not make raw screenshot bytes the only representation.

---

# Semantic target resolution

Target candidates can use:
1. accessibility role + name;
2. label;
3. stable DOM attribute;
4. text relation;
5. neighboring landmark;
6. visual detector;
7. coordinate fallback.

Resolution returns:
```text
candidate list
confidence
why selected
ambiguity
```

If ambiguity exceeds threshold on a risky action:
do not guess.

---

# Effect receipts

Every state-changing action should emit:

```text
receipt_id
mission_id
action_id
attempt
requested_action
resolved_target
started_at
finished_at
transport_result
observed_after_ref
verification
side_effect_class
idempotency_key
```

This enables restart truth and duplicate protection.

---

# Teach session boundaries

Teach Mode must have:
- explicit start;
- explicit stop;
- visual recording indicator;
- secret-redaction indicator;
- optional owner annotation;
- pause;
- discard session.

The owner must know when actions are being captured.

---

# Step segmentation

A demonstration should not become one action = one skill step mechanically.

Segment around:
- state transitions;
- user intent boundaries;
- waiting conditions;
- decision points;
- side effects;
- verification points.

Example:
```text
"configure generation"
  includes:
  select model
  set prompt
  set duration
```
versus:
```text
"submit generation"
```
as a separately verified side effect.

---

# Parameter inference

For repeated demonstrations:
compare values across episodes.

Candidate parameter if:
- same semantic field;
- value changes between demos;
- output depends on it.

Candidate constant if:
- stable across demos;
- domain rationale supports it.

Candidate secret if:
- password/credential field;
- redaction detector;
- owner marks secret.

---

# Recovery strategies

Per step:
```text
RE_RESOLVE_TARGET
WAIT_FOR_READY
REFRESH_OBSERVATION
REOPEN_PANEL
BACK_NAVIGATION
REAUTH_REQUIRED
OWNER_TAKEOVER
ABORT_SAFE
```

Do not hard-code infinite retries.

---

# Browser and desktop parity

UCA contracts should be environment-neutral enough to support:
- Chromium;
- PWA;
- desktop wrapper;
- future native app automation.

Browser implementation may be richer initially.

---

# Testing levels

Unit:
- target ranking;
- parameter extraction;
- secret redaction;
- effect verification.

Integration:
- real browser fixture with semantic drift;
- state-change receipts;
- recovery.

Live:
- one real owner-approved benign external workflow.

---

# Performance

Avoid:
- full-frame vision for every tiny action;
- repeated OCR of unchanged regions;
- large screenshot payloads in active model context.

Use:
- hashes;
- changed-region detection;
- semantic tree deltas;
- adaptive vision escalation.
