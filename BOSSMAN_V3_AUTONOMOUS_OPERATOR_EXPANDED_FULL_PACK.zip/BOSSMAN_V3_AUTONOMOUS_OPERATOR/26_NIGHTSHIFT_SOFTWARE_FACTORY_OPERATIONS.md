# NIGHT SHIFT + SOFTWARE FACTORY — OPERATIONS SPEC

## Why combine operationally

Night Shift is the long-horizon execution envelope.
Software Factory is one workload type that benefits from it.

---

# Night Shift scheduler

Task states:
```text
QUEUED
READY
RUNNING
WAITING_DEPENDENCY
WAITING_APPROVAL
VERIFYING
DONE
FAILED_RECOVERABLE
FAILED_BLOCKING
DEFERRED
```

---

# Resource-aware scheduling

Before work item:
- memory estimate;
- CPU/GPU estimate;
- model residency;
- cloud budget;
- current system load.

Avoid loading vision + 70B LLM + ASR concurrently if it causes thrash.

---

# Backpressure

If resources constrained:
- serialize heavy tasks;
- keep lightweight parsing/testing running;
- preserve active mission state;
- do not crash from overcommit.

---

# Software Factory work items

Research and spec can often parallelize.

Implementation should respect file ownership.

Example:
```text
W1 requirements
W2 API contract
W3 UX concept
W4 backend
W5 frontend
W6 integration
W7 security
W8 E2E
```

W4/W5 only parallel if contract stable.

---

# Evidence bundle per work item

```text
work_item_id
input refs
files changed
tests
artifact refs
verifier
cost
status
```

---

# Auto commit/push

For development missions where owner policy allows:
- verified atomic change;
- meaningful commit message;
- push;
- checkpoint.

Never push knowingly failing security state as “final”.

---

# Morning UX

Owner sees:
- timeline;
- commits;
- screenshots;
- skills learned;
- cost;
- blockers;
- approvals.

One-click:
- inspect change;
- continue;
- approve pending;
- rollback safe change;
- open artifact.

---

# Software Factory completion tiers

Tier 1:
spec only.

Tier 2:
local prototype.

Tier 3:
tested local product.

Tier 4:
release candidate.

Production deployment remains separate approval.
