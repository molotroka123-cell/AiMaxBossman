# BOSSMAN AUTONOMY LEVELS

## Purpose

Owner should know how autonomous a mission is allowed to be.

---

# Levels

### L0 — Observe
Read/inspect only.

### L1 — Propose
Can generate plans/drafts but no state-changing action.

### L2 — Safe local execution
Can perform reversible/local work within sandbox/repo.

### L3 — Governed external execution
Can perform pre-authorized external actions in narrow scopes.

### L4 — Long-horizon autonomous operator
Can plan, execute, recover and learn within explicit policy/budget; risky boundaries still require approval.

### L5 — Reserved
Future high-autonomy/fleet/simulation level. Not a V3 default.

---

# Per-mission policy

Mission declares max autonomy level.

A worker cannot self-upgrade mission autonomy.

---

# UI

Mission card shows:
- current autonomy level;
- what is allowed;
- what still requires owner.

---

# Acceptance

`V3-AUTONOMY-ESCALATE-001`
Agent cannot exceed mission level.

`V3-AUTONOMY-UI-001`
Owner can see effective permissions.
