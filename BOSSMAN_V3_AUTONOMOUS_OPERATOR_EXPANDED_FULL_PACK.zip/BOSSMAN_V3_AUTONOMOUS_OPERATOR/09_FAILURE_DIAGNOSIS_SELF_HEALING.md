# FAILURE DIAGNOSIS + SELF-HEALING

## Anti-pattern

```python
for i in range(10):
    try_again()
```

is not self-healing.

---

# Canonical pipeline

```text
DETECT
→ NORMALIZE
→ FINGERPRINT
→ CLASSIFY
→ COLLECT MINIMAL EVIDENCE
→ GENERATE HYPOTHESES
→ RANK
→ REPRODUCE
→ PATCH/RECOVER
→ TARGETED VERIFY
→ INDEPENDENT VERIFY if high-risk
→ RECORD LESSON
→ RESUME
```

---

# Taxonomy

At minimum:
- TRANSIENT_NETWORK
- RATE_LIMIT
- AUTH
- ENVIRONMENT
- MISSING_DEPENDENCY
- LOGIC
- DATA_CONTRACT
- UI_DRIFT
- TIMEOUT
- RESOURCE_EXHAUSTION
- CONCURRENCY
- STATE_CORRUPTION
- POLICY_BLOCK
- OWNER_APPROVAL_REQUIRED
- PROVIDER_FAILURE
- UNKNOWN

---

# Failure fingerprint

```text
failure_class
acceptance/test id
component
symbol
normalized message
top relevant frame
environment hash
tree SHA
```

No identical retry without new evidence.

---

# Recovery hierarchy

1. deterministic correction;
2. safe retry with changed condition;
3. fallback local implementation;
4. skill-based known recovery;
5. small-agent diagnosis tournament;
6. Fable escalation;
7. approved fallback provider;
8. typed blocker.

---

# Learning from recovery

Successful recovery can propose:
- recovery rule;
- regression test;
- skill update;
- environment guard;
- better liveness metric.

No automatic promotion without validation.

---

# Self-healing safety

Self-healing cannot:
- weaken tests;
- disable security;
- bypass owner approval;
- delete evidence;
- force-push over valid remote state;
- broaden credentials.
