# ARTIFACT + PROVENANCE REGISTRY

## Goal

Every important generated file/result should have traceable provenance.

---

# Artifact record

```text
artifact_id
mission_id
work_item_id
type
path/ref
content_hash
created_at
created_by
source_refs
verification
retention
sensitivity
```

---

# Types

- patch;
- report;
- screenshot;
- video;
- dataset shard;
- model adapter;
- skill package;
- benchmark;
- build artifact.

---

# Why

Prevents:
- stale screenshot presented as current;
- wrong benchmark tied to wrong SHA;
- unverified model file promoted;
- unknown training data provenance.

---

# Acceptance

`V3-ARTIFACT-SHA-001`
Release artifact links to exact source SHA.

`V3-ARTIFACT-PROVENANCE-001`
Training artifact references source episodes and verification state.
