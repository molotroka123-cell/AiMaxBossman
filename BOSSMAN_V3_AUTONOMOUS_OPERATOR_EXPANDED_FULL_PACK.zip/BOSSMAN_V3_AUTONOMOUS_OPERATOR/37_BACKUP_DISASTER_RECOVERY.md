# BACKUP + DISASTER RECOVERY

## What must survive

- mission state;
- approval ledger;
- side-effect receipts;
- skills;
- skill metrics;
- benchmark evidence;
- model registry metadata;
- cost ledger;
- critical configuration.

---

# Backup classes

```text
CONFIG
STATE_DB
SKILL_LIBRARY
EVIDENCE_INDEX
MODEL_METADATA
```

Large regenerable media may use separate retention.

---

# Backup policy

At minimum:
- before risky migration;
- before V3 freeze;
- before model/skill registry migration.

---

# Restore test

A backup is not valid until restore is tested.

Restore into isolated location and verify:
- schema;
- mission read;
- skill read;
- approval history;
- checksums.

---

# Disaster cases

- corrupted DB;
- interrupted migration;
- bad skill schema release;
- bad configuration;
- disk full.

---

# Acceptance

`V3-BACKUP-RESTORE-001`
Isolated restore succeeds.

`V3-MIGRATION-ROLLBACK-001`
Failed migration returns to known-good state.
