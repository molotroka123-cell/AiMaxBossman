# RECOVERY KERNEL

## Purpose

Failure Diagnosis determines what went wrong.
Recovery Kernel is the deterministic runtime responsible for bringing BOSSMAN back to a safe known state.

---

# Recovery levels

```text
R0 retry-safe operation
R1 refresh observation
R2 reopen local surface
R3 restart worker
R4 restart manager with continuation
R5 rollback local change
R6 restore known-good checkpoint
R7 quarantine subsystem/skill
R8 typed owner intervention required
```

---

# Recovery Plan

```text
recovery_id
failure_id
current_state
target_safe_state
steps
side_effect_class
rollback
verification
max_attempts
```

---

# Recovery invariants

- never duplicate irreversible side effect;
- never discard durable receipt;
- never reset approval state incorrectly;
- never lose mission_id;
- never force-push over unknown remote work;
- never “fix” by disabling failing security tests.

---

# Known-good state

Maintain references to:
- last verified commit;
- last valid DB migration state;
- last mission checkpoint;
- last verified skill version;
- last healthy config.

---

# Worker crash

Worker crash:
- mark attempt incomplete;
- inspect side-effect receipt;
- determine whether action happened;
- reconcile;
- resume or escalate.

Never blindly rerun a side-effect action after crash.

---

# Corruption

If state checksum/schema invariant fails:
- stop mutation;
- snapshot evidence;
- restore from valid checkpoint if safe;
- run integrity verification.

---

# Acceptance

`V3-RECOVERY-WORKER-001`
Worker crash resumes task.

`V3-RECOVERY-MANAGER-001`
Manager restart resumes same mission.

`V3-RECOVERY-SIDEEFFECT-001`
Crash after uncertain side effect does not duplicate action.

`V3-RECOVERY-ROLLBACK-001`
Bad local change can return to verified state.
