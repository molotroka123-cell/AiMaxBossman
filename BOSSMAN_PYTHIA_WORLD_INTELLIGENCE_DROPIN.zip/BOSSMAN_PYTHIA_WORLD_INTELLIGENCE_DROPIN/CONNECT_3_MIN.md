# Bossman ↔ PYTHIA — 3-minute drop-in connection

Prepared against AiMaxBossman HEAD `1522f207b29d1ba944e7b96eb70bc0e5e7a9c85e`.
This ZIP changes **nothing** by itself. It contains an isolated `bossman/world_intelligence/` package plus an idempotent installer.

## 1) Make sure PYTHIA is running
Default Bossman adapter target: `http://127.0.0.1:8088`.
Verify PYTHIA itself with `GET /health`.

The adapter uses only documented PYTHIA endpoints:
- `GET /health`
- `GET /agent/view`
- `GET /agent/events`
- `GET /predictions`
- `GET /world`
- `GET /health-score`

It does not call `/predict`, change models, mutate signal rules, or execute actions.

## 2) From this extracted folder run

Windows PowerShell:
```powershell
python .\install_dropin.py C:\path\to\AiMaxBossman
```

Linux/macOS:
```bash
python ./install_dropin.py /path/to/AiMaxBossman
```

The installer does only three things, all idempotent:
1. copies `dropin/bossman/world_intelligence/` → `bossman-core/bossman/world_intelligence/`;
2. inserts `("bossman.world_intelligence", "build_subsystem")` into `_register_subsystems()`;
3. inserts `"bossman.world_intelligence"` into `_include_stage_routers()` and appends env examples.

It creates `.bak.pythia` copies before modifying central files.

## 3) Smoke test
Start Bossman Core, then with normal Bossman auth call:
- `GET /world-intelligence/health`
- `GET /world-intelligence/context?q=bitcoin&q=energy`
- `GET /world-intelligence/predictions?horizon=24h&min_probability=0.7`

Expected when PYTHIA is offline: Bossman still starts; `/context` returns `stale_or_unavailable=true` instead of crashing Core.

## Design rule
PYTHIA is **evidence/context**, never an actuator. A prediction remains marked as a prediction with probability/horizon; it is not converted into an observed fact. The adapter filters context before it reaches a planner to avoid stuffing the full world state into every prompt.
