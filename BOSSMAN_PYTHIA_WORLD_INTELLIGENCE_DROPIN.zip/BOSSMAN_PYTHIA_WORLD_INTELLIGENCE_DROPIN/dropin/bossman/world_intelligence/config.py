from __future__ import annotations

import os
from dataclasses import dataclass


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class WorldIntelligenceConfig:
    enabled: bool = _bool("BOSSMAN_PYTHIA_ENABLED", True)
    base_url: str = os.getenv("BOSSMAN_PYTHIA_URL", "http://127.0.0.1:8088").rstrip("/")
    timeout_s: float = _float("BOSSMAN_PYTHIA_TIMEOUT_S", 4.0)
    min_salience: float = _float("BOSSMAN_PYTHIA_MIN_SALIENCE", 0.65)
    max_events: int = int(os.getenv("BOSSMAN_PYTHIA_MAX_EVENTS", "25"))
    max_predictions: int = int(os.getenv("BOSSMAN_PYTHIA_MAX_PREDICTIONS", "20"))


CONFIG = WorldIntelligenceConfig()
