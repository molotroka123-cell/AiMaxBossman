from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field

Horizon = Literal["24h", "week", "month", "year"]


class WorldSignal(BaseModel):
    kind: Literal["observed_event", "prediction"]
    title: str
    summary: str = ""
    source: str = "pythia"
    domain: str | None = None
    salience: float | None = None
    probability: float | None = None
    horizon: str | None = None
    timestamp_ms: int | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class CompactWorldContext(BaseModel):
    provider: str = "pythia"
    generated_at: int | None = None
    summary: str = ""
    events: list[WorldSignal] = Field(default_factory=list)
    predictions: list[WorldSignal] = Field(default_factory=list)
    market_watch: dict[str, Any] = Field(default_factory=dict)
    stale_or_unavailable: bool = False
