from __future__ import annotations

from typing import Iterable

from .client import PythiaClient, PythiaUnavailable
from .config import CONFIG
from .models import CompactWorldContext, WorldSignal


class WorldIntelligenceService:
    def __init__(self, client: PythiaClient):
        self.client = client

    @staticmethod
    def _matches(text: str, topics: Iterable[str]) -> bool:
        hay = text.lower()
        topics = [t.strip().lower() for t in topics if t and t.strip()]
        return not topics or any(t in hay for t in topics)

    async def compact_context(self, *, topics: list[str] | None = None,
                              min_salience: float | None = None,
                              max_events: int | None = None,
                              max_predictions: int | None = None) -> CompactWorldContext:
        topics = topics or []
        min_salience = CONFIG.min_salience if min_salience is None else min_salience
        max_events = CONFIG.max_events if max_events is None else max_events
        max_predictions = CONFIG.max_predictions if max_predictions is None else max_predictions
        try:
            view = await self.client.agent_view()
        except PythiaUnavailable:
            return CompactWorldContext(stale_or_unavailable=True)

        events: list[WorldSignal] = []
        for domain, items in (view.get("events_by_domain") or {}).items():
            for item in items or []:
                salience = float(item.get("salience") or 0.0)
                text = f"{item.get('title','')} {item.get('summary','')} {domain}"
                if salience < min_salience or not self._matches(text, topics):
                    continue
                events.append(WorldSignal(
                    kind="observed_event",
                    title=str(item.get("title") or ""),
                    summary=str(item.get("summary") or ""),
                    source=str(item.get("source") or "pythia"),
                    domain=str(domain), salience=salience,
                    timestamp_ms=item.get("ts"), raw=dict(item),
                ))
        events.sort(key=lambda x: x.salience or 0.0, reverse=True)

        predictions: list[WorldSignal] = []
        for pred in view.get("predictions") or []:
            title = str(pred.get("title") or pred.get("claim") or pred.get("prediction") or "")
            summary = str(pred.get("reasoning") or pred.get("summary") or "")
            text = f"{title} {summary} {pred.get('horizon','')}"
            if not self._matches(text, topics):
                continue
            probability = pred.get("probability")
            predictions.append(WorldSignal(
                kind="prediction", title=title, summary=summary,
                source="pythia", probability=float(probability) if probability is not None else None,
                horizon=str(pred.get("horizon") or "") or None, raw=dict(pred),
            ))
        predictions.sort(key=lambda x: x.probability or 0.0, reverse=True)

        return CompactWorldContext(
            generated_at=view.get("generated_at"),
            summary=str(view.get("summary") or ""),
            events=events[:max_events],
            predictions=predictions[:max_predictions],
            market_watch=dict(view.get("market_watch") or {}),
        )
