from __future__ import annotations

from typing import Any
import httpx

from .config import CONFIG, WorldIntelligenceConfig


class PythiaUnavailable(RuntimeError):
    pass


class PythiaClient:
    """Thin fail-soft client for PYTHIA's documented local agent API."""

    def __init__(self, config: WorldIntelligenceConfig = CONFIG, transport=None):
        self.config = config
        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout_s,
            transport=transport,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def _get(self, path: str, **params) -> dict[str, Any]:
        if not self.config.enabled:
            raise PythiaUnavailable("PYTHIA integration disabled")
        try:
            response = await self._client.get(path, params={k: v for k, v in params.items() if v is not None})
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, dict):
                raise PythiaUnavailable(f"PYTHIA returned non-object payload for {path}")
            return payload
        except (httpx.HTTPError, ValueError) as exc:
            raise PythiaUnavailable(f"PYTHIA unavailable at {self.config.base_url}: {exc}") from exc

    async def health(self) -> dict[str, Any]:
        return await self._get("/health")

    async def links(self) -> dict[str, Any]:
        return await self._get("/links")

    async def agent_view(self) -> dict[str, Any]:
        return await self._get("/agent/view")

    async def events(self, *, domain: str | None = None, source: str | None = None,
                     min_salience: float | None = None, since: int = 0,
                     limit: int | None = None) -> dict[str, Any]:
        return await self._get(
            "/agent/events", domain=domain, source=source,
            min_salience=min_salience, since=since, limit=limit,
        )

    async def predictions(self, *, horizon: str | None = None,
                          min_probability: float = 0.0) -> dict[str, Any]:
        return await self._get("/predictions", horizon=horizon, min_probability=min_probability)

    async def world(self) -> dict[str, Any]:
        return await self._get("/world")

    async def health_score(self) -> dict[str, Any]:
        return await self._get("/health-score")
