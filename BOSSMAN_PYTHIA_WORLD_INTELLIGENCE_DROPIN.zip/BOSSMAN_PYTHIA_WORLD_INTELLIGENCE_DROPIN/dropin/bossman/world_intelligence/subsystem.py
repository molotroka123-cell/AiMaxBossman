from __future__ import annotations

from .config import CONFIG
from .runtime import CLIENT


class WorldIntelligenceSubsystem:
    name = "world_intelligence"
    critical = False

    async def validate(self):
        # PYTHIA is intentionally optional/fail-soft. Bossman must boot without it.
        return None

    async def start(self):
        return None

    async def stop(self):
        await CLIENT.close()


def build_subsystem():
    return WorldIntelligenceSubsystem() if CONFIG.enabled else None
