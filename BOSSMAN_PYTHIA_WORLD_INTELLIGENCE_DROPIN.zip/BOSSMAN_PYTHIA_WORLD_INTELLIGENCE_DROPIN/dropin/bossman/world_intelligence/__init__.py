from .client import PythiaClient, PythiaUnavailable
from .service import WorldIntelligenceService

__all__ = [
    "PythiaClient",
    "PythiaUnavailable",
    "WorldIntelligenceService",
    "CLIENT",
    "SERVICE",
    "router",
    "build_subsystem",
]


def __getattr__(name):
    if name in {"CLIENT", "SERVICE"}:
        from .runtime import CLIENT, SERVICE
        return {"CLIENT": CLIENT, "SERVICE": SERVICE}[name]
    if name == "router":
        from .routes import router
        return router
    if name == "build_subsystem":
        from .subsystem import build_subsystem
        return build_subsystem
    raise AttributeError(name)
