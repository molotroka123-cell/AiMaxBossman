from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from bossman.perimeter import SCOPE_CHAT, require_scope
from .runtime import CLIENT, SERVICE

router = APIRouter(
    prefix="/world-intelligence",
    tags=["world-intelligence"],
    dependencies=[Depends(require_scope(SCOPE_CHAT))],
)


@router.get("/health")
async def health():
    try:
        pythia = await CLIENT.health()
        return {"connected": True, "provider": "pythia", "pythia": pythia}
    except Exception as exc:  # optional provider: never take Bossman down
        return {"connected": False, "provider": "pythia", "error": str(exc)}


@router.get("/context")
async def context(
    q: list[str] = Query(default=[]),
    min_salience: float | None = None,
    max_events: int | None = None,
    max_predictions: int | None = None,
):
    return await SERVICE.compact_context(
        topics=q, min_salience=min_salience,
        max_events=max_events, max_predictions=max_predictions,
    )


@router.get("/predictions")
async def predictions(horizon: str | None = None, min_probability: float = 0.0):
    return await CLIENT.predictions(horizon=horizon, min_probability=min_probability)


@router.get("/events")
async def events(domain: str | None = None, source: str | None = None,
                 min_salience: float = 0.0, since: int = 0, limit: int = 100):
    limit = max(1, min(limit, 500))
    return await CLIENT.events(domain=domain, source=source, min_salience=min_salience, since=since, limit=limit)
