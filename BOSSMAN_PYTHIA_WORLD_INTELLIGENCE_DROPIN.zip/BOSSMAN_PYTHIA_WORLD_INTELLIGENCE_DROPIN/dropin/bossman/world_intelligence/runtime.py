from .client import PythiaClient
from .service import WorldIntelligenceService

CLIENT = PythiaClient()
SERVICE = WorldIntelligenceService(CLIENT)
