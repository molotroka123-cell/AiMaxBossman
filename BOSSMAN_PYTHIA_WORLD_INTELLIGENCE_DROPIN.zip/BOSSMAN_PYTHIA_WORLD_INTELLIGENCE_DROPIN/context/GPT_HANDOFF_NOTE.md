# GPT HANDOFF NOTE — PYTHIA drop-in

AiMaxBossman baseline checked while generating this pack:
- repository: `molotroka123-cell/AiMaxBossman`
- default/current branch observed: `claude/bossman-control-v03-43igbk`
- observed HEAD: `1522f207b29d1ba944e7b96eb70bc0e5e7a9c85e`
- Cost Governor and notifications/Telegram were already registered in `bossman-core/bossman/api.py`.

Existing historical GPT handoff was also verified in Git history:
- commit `51be3b2f37068f214c3c4050d72a33059b6d647b`
- message: `docs: GPT handoff folder — session report, stage statuses, hardware audit, worklog`
- contained a session report explicitly written "для передачи GPT".

Integration intent:
- do not vendor or fork PYTHIA;
- connect over localhost HTTP;
- PYTHIA remains an optional provider;
- no Bossman boot failure when PYTHIA is absent;
- predictions stay semantically separate from observed events;
- feed planner only compact/relevant context.
