# BOSSMAN PYTHIA WORLD INTELLIGENCE DROP-IN

Purpose: prebuilt, isolated adapter for later ~3-minute integration into AiMaxBossman without changing the repository now.

Architecture:
`PYTHIA localhost API -> WorldIntelligenceClient -> relevance/salience filter -> Bossman API/planner context`

The package is optional and fail-soft. It preserves Bossman's existing auth boundary by mounting its read routes behind `SCOPE_CHAT`. It makes no arbitrary shell calls, carries no credentials, and does not duplicate Cost Governor, Telegram, Gateway, memory, planner, or Stage13.

See `CONNECT_3_MIN.md`.
