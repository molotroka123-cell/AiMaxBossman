import asyncio
import json
import sys
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "dropin"))

from bossman.world_intelligence.client import PythiaClient
from bossman.world_intelligence.config import WorldIntelligenceConfig
from bossman.world_intelligence.service import WorldIntelligenceService


def run(coro):
    return asyncio.run(coro)


def test_compact_context_filters_salience_and_topics():
    def handler(request):
        assert request.url.path == "/agent/view"
        payload = {
            "generated_at": 123,
            "summary": "world summary",
            "events_by_domain": {
                "markets": [
                    {"title":"Bitcoin ETF flow jumps", "summary":"BTC demand", "source":"x", "salience":0.9, "ts":1},
                    {"title":"Small cap move", "summary":"irrelevant", "source":"x", "salience":0.2, "ts":2},
                ]
            },
            "predictions": [
                {"title":"Bitcoin volatility rises", "probability":0.74, "horizon":"24h", "reasoning":"market signal"},
                {"title":"Rain in Peru", "probability":0.9, "horizon":"24h"},
            ],
            "market_watch": {"watchlist":["BTC-USD"]},
        }
        return httpx.Response(200, json=payload)
    cfg = WorldIntelligenceConfig(enabled=True, base_url="http://pythia", timeout_s=1, min_salience=0.65, max_events=25, max_predictions=20)
    client = PythiaClient(cfg, transport=httpx.MockTransport(handler))
    service = WorldIntelligenceService(client)
    ctx = run(service.compact_context(topics=["bitcoin"]))
    assert [x.title for x in ctx.events] == ["Bitcoin ETF flow jumps"]
    assert [x.title for x in ctx.predictions] == ["Bitcoin volatility rises"]
    assert ctx.stale_or_unavailable is False
    run(client.close())


def test_fail_soft_when_pythia_down():
    def handler(request):
        raise httpx.ConnectError("down", request=request)
    cfg = WorldIntelligenceConfig(enabled=True, base_url="http://pythia", timeout_s=1, min_salience=0.65, max_events=25, max_predictions=20)
    client = PythiaClient(cfg, transport=httpx.MockTransport(handler))
    service = WorldIntelligenceService(client)
    ctx = run(service.compact_context())
    assert ctx.stale_or_unavailable is True
    run(client.close())
