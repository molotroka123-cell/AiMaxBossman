from __future__ import annotations
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def insert_once(text: str, needle: str, insertion: str) -> tuple[str, bool]:
    if insertion.strip() in text:
        return text, False
    if needle not in text:
        raise RuntimeError(f"integration anchor not found: {needle!r}")
    return text.replace(needle, needle + insertion, 1), True


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python install_dropin.py /path/to/AiMaxBossman")
        return 2
    repo = Path(sys.argv[1]).expanduser().resolve()
    core = repo / "bossman-core"
    api = core / "bossman" / "api.py"
    env_example = core / ".env.example"
    target = core / "bossman" / "world_intelligence"
    if not api.exists():
        raise SystemExit(f"Not an AiMaxBossman checkout: missing {api}")

    source = HERE / "dropin" / "bossman" / "world_intelligence"
    target.mkdir(parents=True, exist_ok=True)
    for src in source.glob("*.py"):
        shutil.copy2(src, target / src.name)

    original = api.read_text(encoding="utf-8")
    patched = original
    # Match the verified current api.py registration pattern.
    patched, a = insert_once(
        patched,
        '        ("bossman.notifications", "build_subsystem"),\n',
        '        ("bossman.world_intelligence", "build_subsystem"),\n',
    )
    patched, b = insert_once(
        patched,
        '        "bossman.notifications",\n',
        '        "bossman.world_intelligence",\n',
    )
    if patched != original:
        backup = api.with_suffix(api.suffix + ".bak.pythia")
        if not backup.exists():
            backup.write_text(original, encoding="utf-8")
        api.write_text(patched, encoding="utf-8")

    env_added = False
    additions = (HERE / ".env.additions").read_text(encoding="utf-8")
    if env_example.exists():
        current = env_example.read_text(encoding="utf-8")
        if "BOSSMAN_PYTHIA_URL=" not in current:
            backup = env_example.with_suffix(env_example.suffix + ".bak.pythia")
            if not backup.exists():
                backup.write_text(current, encoding="utf-8")
            env_example.write_text(current.rstrip() + "\n\n" + additions, encoding="utf-8")
            env_added = True

    print("PYTHIA drop-in installed")
    print(f"package: {target}")
    print(f"api registration changed: {a or b}")
    print(f"env example changed: {env_added}")
    print("Next: start PYTHIA, start Bossman, GET /world-intelligence/health")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
