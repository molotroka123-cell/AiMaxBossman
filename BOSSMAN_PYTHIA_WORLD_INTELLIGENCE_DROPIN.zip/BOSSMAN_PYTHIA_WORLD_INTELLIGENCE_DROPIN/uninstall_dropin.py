from __future__ import annotations
import shutil
import sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("Usage: python uninstall_dropin.py /path/to/AiMaxBossman")
repo = Path(sys.argv[1]).expanduser().resolve()
core = repo / "bossman-core"
api = core / "bossman" / "api.py"
env = core / ".env.example"
for f in (api, env):
    bak = f.with_suffix(f.suffix + ".bak.pythia")
    if bak.exists():
        shutil.copy2(bak, f)
        bak.unlink()
target = core / "bossman" / "world_intelligence"
if target.exists():
    shutil.rmtree(target)
print("PYTHIA drop-in removed; backups restored where present")
