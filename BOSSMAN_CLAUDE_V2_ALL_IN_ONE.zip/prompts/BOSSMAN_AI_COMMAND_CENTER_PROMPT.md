# BOSSMAN AI COMMAND CENTER — Session Goal for Claude Code

## Контекст

Ты работаешь внутри проекта **BOSSMAN** на моей локальной AI-машине.

Основной setup и ограничения описаны в файле:

`BOSSMAN_CLAUDE_CODE_SETUP.md`

Сначала прочитай его полностью и считай его правила безопасности обязательными.

---

# ЦЕЛЬ ЭТОЙ СЕССИИ

Создать **BOSSMAN AI Command Center** — локальный dashboard и control plane для управления всеми моими AI-моделями, агентами, задачами и автоматизациями на одной машине.

По удобству и возможностям он должен быть **лучше OpenCode именно для моего сценария**, но не копировать OpenCode вслепую.

OpenCode использовать как **архитектурный референс**:

- сначала изучить фактическую архитектуру и текущий upstream;
- проверить лицензию;
- понять, какие идеи стоит переиспользовать;
- не предполагать внутреннее устройство по памяти;
- не копировать код, если лицензия/условия этого не позволяют;
- если разумнее интегрироваться с OpenCode, а не форкать его — предложить это.

Главная задача — создать собственный удобный слой управления AI поверх локальных и облачных моделей.

---

# 1. Что должен представлять собой продукт

Я открываю dashboard и вижу:

```text
BOSSMAN AI COMMAND CENTER

Models
Agents
Orchestrator
Tasks
Schedules
Projects
Sessions
Tools
Browser
Terminal
Memory
Files
Usage
Costs
Logs
System
Settings
```

Из одного интерфейса я должен уметь:

- подключать локальные модели;
- подключать облачные модели по API;
- назначать модели на разные роли;
- создавать AI-агентов;
- объединять агентов в команды;
- давать им задачу;
- запускать задачу сейчас;
- запускать задачу на 24 часа;
- запускать задачу на неделю;
- задавать расписание;
- делать повторяющиеся задачи;
- задавать stop conditions;
- задавать бюджет;
- задавать лимиты токенов;
- давать агентам инструменты;
- видеть, что они делают в реальном времени;
- вмешиваться в работу;
- ставить задачу на паузу;
- продолжать её;
- менять модель в середине задачи;
- переносить задачу между локальной и cloud-моделью;
- смотреть расходы;
- смотреть загрузку железа;
- видеть результаты и историю.

---

# 2. Основной принцип

**UI должен быть простым, а архитектура мощной.**

Я не хочу вручную писать JSON-конфиги для каждой задачи.

Большинство действий должны выполняться через нормальный интерфейс:

- dropdown;
- switches;
- model picker;
- agent cards;
- task composer;
- scheduler;
- visual orchestration;
- approval queue;
- live logs;
- charts.

Но все настройки должны храниться в понятном формате и быть доступны через API.

---

# 3. Архитектура

Сначала изучи существующий репозиторий и OpenCode.

Затем предложи архитектуру.

Предпочтительная концепция:

```text
                   ┌─────────────────┐
                   │     Web UI      │
                   └────────┬────────┘
                            │
                   ┌────────▼────────┐
                   │   Control API   │
                   └────────┬────────┘
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
┌──────▼──────┐      ┌──────▼──────┐     ┌──────▼──────┐
│ Model Router│      │ Orchestrator│     │ Task Engine │
└──────┬──────┘      └──────┬──────┘     └──────┬──────┘
       │                    │                    │
┌──────▼────────────────────▼────────────────────▼──────┐
│                 Agent Runtime / Workers               │
└──────┬────────────────────┬────────────────────┬──────┘
       │                    │                    │
 Local LLMs            Cloud APIs             Tools
```

Компоненты должны быть слабо связаны.

Не делать один огромный monolith.

---

# 4. Provider / Model Layer

Нужен единый Model Provider API.

Минимально поддержать архитектурно:

## Local

- llama.cpp server
- Ollama
- vLLM
- SGLang
- LM Studio / любой OpenAI-compatible endpoint

## Cloud

- OpenAI
- Anthropic
- Google Gemini
- OpenRouter
- Z.ai / GLM
- любой OpenAI-compatible API

Не обязательно реализовывать абсолютно все providers в первой сессии.

Но архитектура должна позволять добавлять новый provider одним adapter.

---

# 5. Model Registry

В dashboard нужна страница **Models**.

Для каждой модели показывать:

```text
Name
Provider
Local / Cloud
Endpoint
Status
Context window
Vision
Tool calling
Reasoning
Coding
Input price
Output price
RAM usage
GPU usage
Current speed
Prompt tok/s
Generation tok/s
Active jobs
Health
```

Должна быть кнопка:

**Test Model**

Она запускает стандартный benchmark и записывает результат.

---

# 6. Local Model Manager

Для локальных моделей сделать manager.

Функции:

- discover running endpoints;
- start model;
- stop model;
- unload model;
- restart;
- health check;
- benchmark;
- context test;
- memory usage;
- idle unload;
- max concurrent jobs;
- queue.

Нельзя автоматически скачивать огромные модели без моего подтверждения.

Перед скачиванием показывать:

```text
Model size
Expected RAM
Expected disk
Quant
Estimated compatibility
```

---

# 7. Smart Model Router

Это одна из ключевых функций.

Я не хочу каждый раз выбирать модель вручную.

Создать routing rules.

Пример:

```text
cheap classification
→ local fast model

coding
→ main local coder

vision
→ local vision worker

deep reasoning
→ heavy local model

local model failed
→ GLM / cloud fallback

critical architecture review
→ premium cloud model
```

Router должен учитывать:

- тип задачи;
- способности модели;
- доступную RAM;
- очередь;
- скорость;
- стоимость;
- context size;
- предыдущие ошибки;
- user preference.

---

# 8. Model Fallback

Поддержать цепочки:

```text
Model A
↓ fail / low confidence
Model B
↓ fail
Cloud Model C
```

Настраивать через UI.

Например:

```text
Primary:
Qwen local

Fallback:
GLM cloud

Final reviewer:
GPT / Claude
```

---

# 9. Agents

Страница **Agents**.

Каждый агент имеет:

```text
Name
Role
System prompt
Primary model
Fallback models
Tools
Memory
Max runtime
Budget
Permissions
Workspace
Status
```

Примеры:

```text
Lead Hunter
Website Auditor
Sales Agent
Coding Agent
Vision QA
Research Agent
Architecture Reviewer
Project Manager
```

---

# 10. Agent Templates

Создать шаблоны:

### Coding Agent

Инструменты:

- filesystem;
- git;
- terminal;
- browser;
- tests.

### Research Agent

- browser;
- search;
- files;
- notes.

### Sales Agent

- CRM;
- email draft;
- website audit;
- pricing rules.

### Vision QA

- screenshots;
- UI review;
- browser.

---

# 11. Agent Teams / Orchestra

Главная функция: **Orchestrator**.

Я должен иметь возможность создать команду:

```text
PROJECT MANAGER
       ↓
 ┌─────┼─────────────┐
 ↓     ↓             ↓
Coder Researcher   Vision
 ↓                   ↓
Tests              QA
 └─────────┬─────────┘
           ↓
        Reviewer
```

UI должен позволять:

- назначить manager;
- назначить workers;
- назначить reviewer;
- указать модели;
- указать инструменты;
- указать порядок;
- указать parallel / sequential;
- указать условия перехода;
- указать max retries.

---

# 12. Orchestra Modes

Поддержать режимы:

## Sequential

```text
A → B → C
```

## Parallel

```text
     → B
A →  → C
     → D
```

## Manager / Workers

```text
Manager
↓
delegates dynamically
```

## Debate

Несколько моделей дают решения → judge выбирает.

## Review Loop

```text
Coder
↓
Reviewer
↓
FAIL
↓
Coder fixes
```

с лимитом итераций.

---

# 13. Task Composer

Самая используемая часть UI.

Большое поле:

**What should BOSSMAN do?**

Я пишу обычным языком:

> Проанализируй 100 клиник Праги, найди 20 лучших клиентов, подготовь персональные письма и сделай mockup для трёх лучших.

Ниже:

```text
Orchestra: Sales Team
Priority: High
Run: Now
Duration: 24 hours
Budget: Local only
Approval: Required before email
```

И кнопка:

**START**

---

# 14. Long-running Tasks

Это критично.

Задача должна жить независимо от browser session.

Варианты:

```text
Run once
1 hour
6 hours
24 hours
3 days
7 days
Until completed
Until date
Recurring
```

Task engine должен переживать:

- закрытие browser;
- logout;
- worker restart;
- reboot машины.

После перезапуска продолжать безопасно с checkpoint.

---

# 15. Scheduling

Создать визуальный scheduler.

Поддержать:

```text
Now
At specific time
Every hour
Every day
Every week
Custom cron
Run for N hours
Run until date
```

Пример:

```text
Task:
Find new local LLM releases

Schedule:
Every day 09:00

Notify:
Only if meaningful change
```

---

# 16. Checkpoints

Каждая долгая задача должна сохранять:

```text
state
progress
artifacts
conversation
tool results
current agent
current model
errors
remaining work
```

Чтобы можно было:

**Pause → reboot → Resume**

без начала с нуля.

---

# 17. Task Queue

Dashboard должен показывать:

```text
RUNNING
QUEUED
WAITING APPROVAL
PAUSED
FAILED
COMPLETED
```

Для задачи показывать:

- progress;
- elapsed time;
- agent;
- model;
- tokens;
- cost;
- CPU/GPU/RAM;
- latest action;
- ETA, только если её можно адекватно оценить.

---

# 18. Live Session Viewer

Для каждого активного agent run:

```text
Agent
Model
Current task
Current tool
Current file
Latest result
Errors
Elapsed time
```

Я должен видеть действия в реальном времени.

---

# 19. Human Control

Кнопки:

```text
Pause
Resume
Stop
Approve
Reject
Retry
Change model
Give instruction
Increase budget
Decrease budget
Take over
```

Можно написать агенту прямо во время работы:

> Не трогай backend, исправь только frontend.

Это должно добавляться в текущую задачу без потери контекста.

---

# 20. Approval Queue

Отдельный экран:

**Needs Your Approval**

Примеры:

```text
Send email to client
Deploy production
Create invoice
Accept new price
Delete files
Purchase API credits
Use expensive cloud model
```

Одно действие:

```text
Approve / Reject / Edit
```

---

# 21. Permissions

Каждый agent имеет permissions.

Например:

```text
filesystem.read
filesystem.write
terminal.run
git.commit
browser.read
browser.write
email.draft
email.send
invoice.create
deploy
```

По умолчанию dangerous actions отключены.

---

# 22. Tool Registry

Нужна страница **Tools**.

Подключаемые инструменты:

- terminal;
- filesystem;
- git;
- browser;
- Playwright;
- web search;
- GitHub;
- Gmail;
- calendar;
- CRM;
- database;
- n8n;
- custom MCP servers;
- custom HTTP tools.

Архитектурно поддержать MCP.

---

# 23. MCP Manager

UI:

```text
MCP Server
Status
Tools
Permissions
Latency
Last error
```

Функции:

- add;
- remove;
- enable;
- disable;
- test;
- assign to agent.

---

# 24. Browser Control

Встроенный browser-agent layer.

Нужен live preview:

- текущая страница;
- screenshot;
- URL;
- active agent;
- last action.

Не обязательно строить полноценный Chrome replacement.

Основная задача — наблюдение и управление Playwright/browser worker.

---

# 25. Terminal

Нужен terminal/session viewer.

Показывать команды агентов.

Dangerous commands должны требовать approval.

Не позволять модели скрывать выполненные команды.

---

# 26. Files / Projects

Страница **Projects**.

Примеры:

```text
Fresh Vibes
Nimba Money
SwapMe
Lead Generation
Local AI Setup
```

Для каждого:

- repo;
- workspace;
- agents;
- sessions;
- tasks;
- files;
- memory;
- model policy;
- costs.

---

# 27. Persistent Project Memory

У каждого проекта должна быть долговременная память:

```text
facts
decisions
preferences
architecture
TODO
mistakes
previous sessions
```

Не хранить всё как один гигантский prompt.

Использовать нормальную retrieval architecture.

---

# 28. Session Memory

Каждая сессия должна иметь:

```text
goal
plan
decisions
artifacts
progress
unfinished work
summary
```

При открытии новой сессии agent получает relevant context.

---

# 29. Context Manager

Показывать:

```text
Current context usage
Model context maximum
Files loaded
Memory loaded
Conversation tokens
Tool output tokens
```

Добавить auto-compaction / summarization.

Но не терять:

- важные decisions;
- user requirements;
- current task state.

---

# 30. Cost Control

Очень важный экран.

Для cloud providers:

```text
Today
24h
7d
30d
Per model
Per project
Per agent
Per task
```

Настраивать limits:

```text
Task max $5
Daily max $20
Project max $100
```

При превышении:

```text
STOP
или
ASK FOR APPROVAL
```

---

# 31. Local Compute Metrics

Показывать:

- CPU usage;
- GPU usage;
- RAM;
- VRAM/unified memory;
- SSD;
- temperature;
- model load;
- inference speed;
- active workers.

---

# 32. Resource Scheduler

Не допускать:

```text
Model A uses 70 GB
Model B starts and causes swap/crash
```

Перед запуском model manager должен оценить memory.

Если ресурсов мало:

```text
queue
или
unload idle model
или
ask user
```

---

# 33. Notifications

Поддержать события:

```text
task completed
task failed
approval required
budget exceeded
model crashed
payment received
new client replied
```

Первый этап — внутри dashboard.

Архитектуру оставить расширяемой под:

- Telegram;
- email;
- mobile push.

---

# 34. Search

Глобальный command/search bar.

Пример:

```text
"Qwen"
"Fresh Vibes"
"failed tasks today"
"all runs by Coding Agent"
```

---

# 35. Command Palette

Сделать `Ctrl/Cmd + K`.

Команды:

```text
New Task
New Agent
Load Model
Stop Model
Open Project
View Running Tasks
Pause All
System Status
```

---

# 36. UI

Стиль:

- premium;
- dark/light;
- минималистичный;
- desktop-first, но нормальный mobile;
- быстрый;
- минимум визуального мусора;
- интерфейс должен быть понятен без документации.

Не делать обычный admin template.

Главная страница — реальный **AI control room**.

---

# 37. Home Dashboard

Главный экран примерно:

```text
┌─────────────────────────────────────────────┐
│ BOSSMAN AI                                 │
│ 4 agents active · 3 models · system healthy│
├─────────────────────────────────────────────┤
│ Quick Task                                 │
│ [_______________________________________]  │
│ [Start]                                    │
├──────────────────┬──────────────────────────┤
│ Running Tasks    │ Models                   │
│ 4                │ Qwen      ACTIVE         │
│                  │ Vision    IDLE           │
│                  │ GPT Cloud READY          │
├──────────────────┼──────────────────────────┤
│ Approvals        │ System                   │
│ 2 waiting        │ RAM 61/128 GB            │
│                  │ GPU 72%                  │
├──────────────────┴──────────────────────────┤
│ Recent activity                             │
└─────────────────────────────────────────────┘
```

---

# 38. API First

UI не должен напрямую управлять внутренними сервисами.

Все действия идут через Control API.

Нужно документированное API:

```text
/api/models
/api/agents
/api/tasks
/api/runs
/api/projects
/api/tools
/api/schedules
/api/approvals
/api/system
```

---

# 39. Event System

Для realtime использовать event bus / websocket/SSE.

События:

```text
task.started
task.progress
task.completed
agent.started
agent.tool_call
agent.error
model.loaded
model.unloaded
approval.created
system.warning
```

---

# 40. Database

PostgreSQL.

Минимальные сущности:

```text
providers
models
agents
agent_tools
projects
tasks
task_runs
schedules
sessions
messages
tool_calls
artifacts
approvals
usage
costs
system_metrics
memories
events
```

---

# 41. Queue

Long-running jobs нельзя выполнять внутри обычного HTTP request.

Использовать persistent job queue.

Выбрать решение после анализа текущего stack.

Требования:

- retries;
- priority;
- pause/resume;
- persistence;
- concurrency limits;
- crash recovery.

---

# 42. Secrets

API keys:

- encrypted at rest;
- masked in UI;
- никогда не попадать в logs;
- никогда не отправлять другой модели без необходимости.

---

# 43. Authentication

На первом этапе это локальный single-user product.

Но backend всё равно не должен быть полностью открытым.

Подготовить secure local auth/session.

Не выставлять dashboard напрямую в публичный интернет.

Для удалённого доступа позже использовать безопасную private network/VPN layer.

---

# 44. OpenCode Integration

Исследовать два пути:

## Path A — использовать OpenCode как execution engine

BOSSMAN dashboard управляет OpenCode sessions через adapter.

## Path B — использовать только архитектурные идеи

Свой agent runtime.

Сравнить:

```text
development effort
stability
tool ecosystem
permissions
session handling
local model support
extensibility
licensing
```

Выбрать рациональный путь, а не переписывать всё ради переписывания.

---

# 45. Existing OpenCode Projects

BOSSMAN должен уметь работать с существующими git/project folders.

Не требовать импортировать проект в proprietary format.

---

# 46. Multi-model Chat

Нужен чат, где я могу:

### один агент / одна модель

или:

### несколько моделей

Пример:

```text
Ask:
Qwen
GLM
Gemini

Judge:
Claude
```

И видеть ответы отдельно + итог judge.

---

# 47. Swarm Mode

Опциональная функция:

```text
Spawn 5 workers
```

Manager разбивает задачу.

Но число агентов ограничено resource scheduler.

Нельзя создавать бесконечные agent loops.

---

# 48. Time-boxed Autonomous Mode

Я должен иметь возможность сказать:

> Работай над проектом следующие 24 часа.

Настройки:

```text
Duration: 24h
Goal: ...
Max cloud cost: $10
Max workers: 4
Checkpoint every: 15 min
Stop if:
- goal complete
- critical error
- budget reached
```

Или:

> Работай неделю.

Система должна сама:

- планировать;
- выполнять;
- сохранять checkpoints;
- делать retries;
- пересматривать план;
- останавливаться по правилам.

---

# 49. Daily / Weekly Objectives

Можно задать objective:

```text
Objective:
Получить клиентов на сайты

Duration:
7 days

Daily target:
50 websites reviewed
20 qualified
10 personalized drafts
```

Dashboard показывает progress относительно objective.

---

# 50. Planner

Перед длинной задачей manager-agent делает plan:

```text
Goal
Milestones
Tasks
Dependencies
Agents
Models
Estimated resources
Risks
```

Я могу:

```text
Approve Plan
Edit
Start
```

---

# 51. Automatic Replanning

Если задача провалилась:

не повторять одно и то же бесконечно.

Manager должен:

1. определить причину;
2. изменить подход;
3. при необходимости сменить model/tool;
4. записать решение;
5. продолжить.

Max retries обязательно ограничить.

---

# 52. Evaluation Layer

Для важных задач:

```text
Worker result
↓
Evaluator
↓
score
↓
pass / retry / human review
```

Evaluator желательно может быть другой моделью.

---

# 53. Artifact Management

Результаты задач:

- code;
- screenshot;
- PDF;
- report;
- CSV;
- proposal;
- website.

Все должны отображаться как artifacts внутри task/session.

---

# 54. Logs

Логи должны быть читаемыми человеком.

Фильтры:

```text
task
agent
model
provider
project
severity
time
```

И отдельный raw view для debugging.

---

# 55. Error UX

Если модель упала, UI не должен показывать просто:

`500 Internal Server Error`

Показывать:

```text
Local Qwen stopped responding.
Last successful heartbeat: 21s ago.

Actions:
Restart model
Switch to fallback
Retry task
Open logs
```

---

# 56. Health Checks

Проверять:

- database;
- queue;
- model endpoints;
- worker;
- browser;
- OpenCode adapter;
- n8n;
- disk;
- memory.

---

# 57. Backups

Подготовить backup strategy для:

- PostgreSQL;
- configs;
- prompts;
- agent definitions;
- project memory.

Не копировать огромные model weights в каждый backup.

---

# 58. Import / Export

Можно экспортировать:

```text
Agent config
Orchestra
Task template
Model routing rules
Project settings
```

в переносимый JSON/YAML.

---

# 59. Task Templates

Примеры:

```text
24h Coding Sprint
Website Audit
Lead Hunting
Daily Research
Weekly Market Watch
Repo Refactor
SEO Audit
Bug Hunt
```

---

# 60. Natural Language Configuration

Дополнительно:

Я пишу:

> Создай мне команду из главного Qwen, vision агента и GLM как fallback. Пусть они работают над сайтами максимум 12 часов, а облако тратит не больше $3.

Система преобразует это в config.

Перед применением показывает:

**Proposed configuration**

и просит подтверждение.

---

# 61. Что НЕ делать

Не надо в первой сессии:

- пытаться реализовать все 60 функций production-ready;
- создавать Kubernetes;
- делать microservices ради microservices;
- строить облачный SaaS;
- делать billing пользователей;
- делать multi-tenant;
- создавать мобильное приложение;
- скачивать десятки моделей;
- писать новый LLM runtime.

---

# 62. Задача этой сессии — MVP

Нужно довести до реально работающего **MVP Command Center**.

Обязательно реализовать:

### A. Dashboard shell

- Home
- Models
- Agents
- Tasks
- System
- Settings

### B. Model Providers

Минимум:

- OpenAI-compatible local endpoint
- один cloud provider adapter

### C. Model registry

- add;
- edit;
- test;
- health.

### D. Agents

- create;
- edit;
- assign model;
- system prompt;
- basic tools.

### E. Task runner

- create task;
- choose agent;
- run;
- status;
- persistent result.

### F. Persistent queue

- task survives page refresh;
- worker execution;
- retries.

### G. Scheduler

Минимум:

- run now;
- specific time;
- daily;
- custom interval.

### H. Live logs

- realtime run events.

### I. System metrics

- CPU;
- RAM;
- GPU if accessible.

### J. Safety

- secrets;
- no dangerous auto actions;
- approval architecture.

---

# 63. После MVP

Только после рабочего MVP переходить к:

### Phase 2

- multi-agent orchestra;
- model fallback;
- routing;
- Playwright;
- OpenCode adapter;
- MCP manager;
- project memory;
- approval queue.

### Phase 3

- long-running 24h/7d autonomous objectives;
- automatic replanning;
- evaluator;
- cost budgets;
- second ROG worker;
- remote secure access;
- notification integrations.

---

# 64. Definition of Done — эта сессия

Сессия считается успешной, если я могу:

1. открыть BOSSMAN dashboard;
2. добавить local OpenAI-compatible model endpoint;
3. добавить cloud model API;
4. увидеть обе модели online/offline;
5. создать агента;
6. выбрать ему модель;
7. написать system prompt;
8. создать задачу;
9. запустить её;
10. закрыть/обновить страницу;
11. снова открыть dashboard;
12. увидеть, что задача продолжилась или завершилась;
13. посмотреть live/history logs;
14. поставить задачу по расписанию;
15. посмотреть CPU/RAM/GPU;
16. увидеть результаты задачи;
17. остановить активную задачу.

Если хотя бы базовый путь этого workflow не работает — MVP не готов.

---

# 65. UX Definition of Done

Я не должен пользоваться терминалом для обычных операций:

- добавить модель;
- выбрать модель;
- создать agent;
- запустить task;
- создать schedule;
- остановить task;
- посмотреть logs.

Терминал остаётся для advanced/debugging.

---

# 66. Development Workflow

Перед началом:

1. прочитать `BOSSMAN_CLAUDE_CODE_SETUP.md`;
2. изучить repo;
3. проверить git status;
4. изучить актуальный OpenCode upstream/архитектуру/лицензию;
5. создать `docs/COMMAND_CENTER_ARCHITECTURE.md`;
6. создать `docs/COMMAND_CENTER_PLAN.md`;
7. показать мне краткий план;
8. затем начинать реализацию.

Не удалять существующую работу.

Создать отдельную branch:

`feature/bossman-command-center`

---

# 67. Автономность в рамках этой сессии

После утверждения плана:

- работай самостоятельно;
- не спрашивай подтверждение на каждую мелочь;
- исправляй обычные coding errors сам;
- запускай tests;
- проверяй UI;
- используй screenshots;
- делай итерации.

Но спрашивай подтверждение перед:

- удалением существенных данных;
- изменением системной безопасности;
- публикацией в интернет;
- покупкой API/услуг;
- использованием секретов, которые не были предоставлены;
- production deployment.

---

# 68. UI QA

После каждого значимого UI этапа:

1. запустить приложение;
2. открыть browser;
3. проверить desktop;
4. проверить mobile;
5. сделать screenshots;
6. проверить основные actions;
7. исправить визуальные/functional bugs.

---

# 69. Tests

Минимум:

- provider adapter tests;
- task persistence test;
- scheduler test;
- queue retry test;
- basic API tests;
- UI smoke test.

---

# 70. Documentation

После MVP создать:

`docs/COMMAND_CENTER_REPORT.md`

В нём:

```text
Architecture
Implemented
Not implemented
How to run
Ports
Services
Database
Providers
How to add local model
How to add cloud model
How to create agent
How to schedule task
Known issues
Performance
Next phase
```

---

# FINAL INSTRUCTION

Не строй красивый mockup без backend.

Не строй backend без usable UI.

Нужен **сквозной рабочий продукт**.

Главный критерий:

> Я открываю BOSSMAN, подключаю локальную Qwen и облачную модель, создаю агента, назначаю ему задачу на несколько часов или по расписанию, закрываю браузер, возвращаюсь позже и вижу результат, логи и состояние машины.

Именно это является целью.

Начинай с анализа текущего проекта и OpenCode, затем создай архитектуру и план, покажи их мне и только после этого переходи к реализации.
