# BOSSMAN AI COMMAND CENTER V2
# 15 FABLE AGENTS + REAL FUNCTION VERIFICATION
## Master Prompt for Claude Code

---

# 0. РОЛЬ

Ты — **Claude Code, Lead Architect + Integration Engineer + QA Lead** проекта **BOSSMAN AI Command Center**.

В этой сессии твоя задача — не просто добавить функции и показать красивый UI.

Твоя задача:

> **Реализовать 15 новых функций через 15 отдельных Fable agents, интегрировать их в BOSSMAN, обновить дизайн, а затем доказать автоматическими и ручными проверками, что каждая функция реально работает end-to-end.**

Никакая функция не считается готовой только потому, что:

- есть кнопка;
- есть страница;
- есть mock data;
- endpoint возвращает 200;
- агент написал "готово";
- unit test прошёл в отрыве от реального workflow.

Для каждой функции должен существовать **реальный проверочный сценарий**, который воспроизводится на рабочем приложении.

---

# 1. ОБЯЗАТЕЛЬНЫЙ КОНТЕКСТ

Перед любой разработкой прочитай полностью:

1. `BOSSMAN_CLAUDE_CODE_SETUP.md`
2. `BOSSMAN_AI_COMMAND_CENTER_PROMPT.md`
3. текущий `README.md`
4. всю релевантную документацию `docs/`
5. backend routes / services
6. frontend structure
7. database schema + migrations
8. queue/scheduler implementation
9. model/provider adapters
10. git history последних релевантных изменений

После чтения создай:

`docs/V2_CURRENT_STATE_AUDIT.md`

В нём перечисли:

- что уже реально работает;
- что существует только как UI;
- что mock;
- что недоделано;
- какие API уже есть;
- какие DB сущности уже есть;
- какие функции из 15 частично реализованы;
- что лучше переиспользовать;
- что нельзя ломать.

Не начинать 15 параллельных агентов до этого аудита.

---

# 2. ОСНОВНАЯ ЦЕЛЬ

Создать **BOSSMAN V2** — локальный AI Control Plane для:

- локальных моделей;
- облачных моделей;
- agents;
- agent teams;
- задач;
- миссий;
- долгой автономной работы;
- resource scheduling;
- model routing;
- review loops;
- browser agents;
- skills;
- session replay/fork;
- self-healing;
- mobile control.

---

# 3. ЧТО ТАКОЕ SKILLS В BOSSMAN

Важно: модель уже умеет рассуждать, писать код, анализировать и использовать инструменты.

**Skill — это не "новая способность мозга".**

Skill — это **переиспользуемый проверенный рабочий процесс**.

Например `Website Audit` skill должен содержать не просто:

> Проверь сайт.

А:

```text
INPUT:
website_url

REQUIRED TOOLS:
browser.read
browser.screenshot
http.inspect

PROCESS:
1. открыть homepage desktop;
2. открыть mobile viewport;
3. найти CTA;
4. проверить language switcher;
5. проверить broken links;
6. проверить title/H1/meta;
7. проверить outdated offers;
8. сохранить screenshots;
9. перечислить только реально найденные проблемы.

OUTPUT SCHEMA:
score
critical_issues[]
seo_issues[]
ux_issues[]
screenshots[]
recommended_action
confidence
```

Поэтому Skills нужны, чтобы:

- один и тот же workflow выполнялся одинаково;
- не тратить токены на повторное объяснение;
- закреплять лучшие prompts/checklists;
- закреплять required tools;
- задавать permissions;
- фиксировать input/output schema;
- версионировать процессы;
- сравнивать качество разных моделей на одной задаче;
- давать orchestration engine готовые блоки;
- снижать hallucinations и пропуски;
- облегчать автоматический QA.

Не превращать Skill Library в склад сотен бессмысленных prompts.

Начать с 5–10 реально полезных skills.

---

# 4. GIT STRATEGY

Создать integration branch:

```text
feature/bossman-command-center-v2
```

Не работать прямо в main.

Для каждой функции создать отдельную branch + worktree:

```text
agent/01-autopilot-objective
agent/02-smart-model-router
agent/03-ai-governor
agent/04-model-benchmark-lab
agent/05-replay-fork-session
agent/06-visual-agent-map
agent/07-worktree-sandboxes
agent/08-reviewer-gate
agent/09-browser-live-view
agent/10-skill-library
agent/11-natural-language-orchestration
agent/12-resource-brain
agent/13-mission-kpi
agent/14-self-healing
agent/15-mobile-command-mode
```

Каждый Fable agent должен работать независимо.

Запрещено:

- 15 агентов в одном worktree;
- force push;
- reset чужих commits;
- изменения shared DB schema без согласования;
- скрытие failing tests.

---

# 5. СНАЧАЛА — SHARED CONTRACTS

Перед запуском Fable agents главный Claude Code создаёт:

`docs/V2_SHARED_CONTRACTS.md`

Зафиксировать:

## Entities

```text
Mission
Objective
Task
TaskRun
Agent
AgentRun
Model
Provider
Orchestra
Skill
SkillVersion
ModelBenchmark
Checkpoint
Approval
Artifact
Evaluation
ResourceReservation
RecoveryAttempt
SessionFork
SystemEvent
```

## Statuses

```text
draft
planning
queued
running
waiting_approval
paused
retrying
degraded
failed
completed
cancelled
```

## Core events

```text
mission.created
mission.started
mission.progress
mission.paused
mission.completed
mission.failed

task.created
task.queued
task.started
task.progress
task.paused
task.resumed
task.failed
task.completed

agent.started
agent.tool_call
agent.warning
agent.failed
agent.completed

router.route_selected
router.fallback

governor.intervention

model.loaded
model.unloaded
model.failed
model.degraded

resource.reserved
resource.released
resource.denied

checkpoint.created
session.forked

evaluation.completed

recovery.started
recovery.completed
recovery.escalated
```

## Permission model

```text
filesystem.read
filesystem.write
terminal.read
terminal.run
git.read
git.write
browser.read
browser.control
model.load
model.unload
email.draft
email.send
deploy.preview
deploy.production
invoice.create
payment.read
settings.write
```

## API conventions

Определить:

- error schema;
- pagination;
- event envelope;
- id format;
- timestamps;
- audit fields;
- retry semantics.

---

# 6. ОБЯЗАТЕЛЬНАЯ МАТРИЦА ПРОВЕРКИ

Создать до разработки:

`docs/V2_ACCEPTANCE_MATRIX.md`

Таблица:

| # | Feature | Unit Test | Integration Test | Browser/UI Test | Failure Test | Persistence Test | Status |
|---|---|---|---|---|---|---|---|

Все 15 строк обязаны существовать.

Никакая строка не может получить `DONE`, пока не заполнены релевантные проверки.

---

# 7. AGENT 01 — AUTOPILOT OBJECTIVE

## Задача

Пользователь задаёт цель:

```text
Goal: Получить клиентов на сайты
Duration: 7 days
Target: 30 000 Kč
Max workers: 4
Cloud budget: $10
```

Система должна:

1. создать Mission;
2. построить plan;
3. создать milestones;
4. создать tasks;
5. запустить доступные tasks;
6. сохранять checkpoints;
7. обновлять progress;
8. поддерживать Pause;
9. Resume;
10. Stop;
11. завершаться по success/stop conditions.

## Реальная проверка

Создать test mission:

```text
Goal:
Создать 3 тестовых research tasks и завершить их.

Duration:
30 min

Max workers:
2
```

Проверить:

- mission появляется в DB;
- создаёт 3 tasks;
- не запускает больше 2 одновременно;
- progress проходит 0 → 33 → 66 → 100;
- pause реально останавливает новые executions;
- resume продолжает;
- refresh UI не теряет mission;
- restart worker не уничтожает состояние.

## Артефакт доказательства

`docs/V2_PROOFS/01_AUTOPILOT.md`

---

# 8. AGENT 02 — SMART MODEL ROUTER

## Задача

Выбирать модель автоматически по:

- capabilities;
- task type;
- cost;
- latency;
- context;
- health;
- RAM;
- queue;
- historical performance.

## Реальная проверка

Зарегистрировать минимум:

```text
local-fast
local-coder
cloud-reviewer
```

Сымитировать:

### Test A
Task type = classification  
Expected = `local-fast`

### Test B
Task type = coding  
Expected = `local-coder`

### Test C
local-coder unhealthy  
Expected = fallback

### Test D
cloud budget = 0  
Expected = cloud excluded

### Test E
RAM insufficient  
Expected = route denied/queued or smaller model

UI должен показать **почему** выбрана модель.

## Proof

`docs/V2_PROOFS/02_ROUTER.md`

---

# 9. AGENT 03 — AI GOVERNOR

## Задача

Следить за другими AI и вмешиваться при:

- repeated same error;
- runaway retries;
- tool spam;
- no progress;
- excessive cloud cost;
- stuck agent.

## Реальная проверка

Создать test worker, который намеренно возвращает одну и ту же ошибку.

Ожидаемо:

1. error повторяется N раз;
2. Governor фиксирует loop;
3. создаёт `governor.intervention`;
4. останавливает или переключает worker;
5. UI показывает intervention;
6. task не крутится бесконечно.

Дополнительно проверить cloud budget breach.

## Proof

`docs/V2_PROOFS/03_GOVERNOR.md`

---

# 10. AGENT 04 — MODEL BENCHMARK LAB

## Задача

Benchmark:

- TTFT;
- prompt tok/s;
- generation tok/s;
- RAM;
- GPU;
- coding sample;
- reasoning sample;
- tool calling;
- vision when supported;
- stability.

## Реальная проверка

Benchmark минимум двух model endpoints.

Проверить:

- benchmark runs in background;
- UI остаётся usable;
- результаты сохраняются;
- повторный benchmark создаёт новую запись;
- сравнение строится по реальным данным;
- recommendations используют stored results.

Нельзя hardcode'ить score.

## Proof

`docs/V2_PROOFS/04_BENCHMARK.md`

---

# 11. AGENT 05 — REPLAY / FORK SESSION

## Реальная проверка

1. выполнить task на 3 шага;
2. создать checkpoints;
3. выбрать checkpoint #2;
4. Fork;
5. поменять instruction;
6. запустить fork;
7. убедиться, что original run не изменился;
8. показать lineage:
   `original → fork`.

Дополнительно:
- fork с другой моделью;
- fork с другим агентом.

## Proof

`docs/V2_PROOFS/05_REPLAY_FORK.md`

---

# 12. AGENT 06 — VISUAL AGENT MAP

## Задача

Показывать реальный active orchestra.

## Реальная проверка

Создать manager + 3 workers + reviewer.

Проверить:

- nodes соответствуют DB/runtime;
- status меняется realtime;
- завершившийся agent обновляется без refresh;
- click открывает реальные details;
- mobile превращает graph в readable list/tree;
- 20 nodes не ломают UI.

Никакого static mock graph.

## Proof

`docs/V2_PROOFS/06_AGENT_MAP.md`

---

# 13. AGENT 07 — WORKTREE SANDBOXES

## Реальная проверка

1. создать временный test repo;
2. создать 2 coding agents;
3. система создаёт 2 отдельных worktree;
4. каждый меняет отдельный файл;
5. показать diff обоих;
6. один agent оставляет dirty state;
7. система не удаляет его worktree молча;
8. после clean merge worktree корректно удаляется.

Проверить branch safety.

## Proof

`docs/V2_PROOFS/07_WORKTREES.md`

---

# 14. AGENT 08 — AUTOMATIC REVIEWER GATE

## Реальная проверка

Создать test coding task.

Первый результат намеренно должен нарушить test.

Ожидаемо:

```text
Coder → Review FAIL → feedback → Coder fix → Review PASS
```

Проверить:

- task не помечен completed до PASS;
- reviewer пишет конкретную причину;
- max retries соблюдается;
- manual override существует;
- after max retries → waiting approval/failed.

## Proof

`docs/V2_PROOFS/08_REVIEWER_GATE.md`

---

# 15. AGENT 09 — BROWSER LIVE VIEW

## Реальная проверка

Playwright task:

1. открыть test page;
2. перейти на вторую страницу;
3. заполнить test input;
4. ждать.

Проверить UI:

- URL меняется;
- screenshot обновляется;
- last action отображается;
- нажать `Take Over`;
- агент перестаёт выполнять browser actions;
- `Resume` возвращает управление агенту;
- `Stop` завершает browser run.

## Proof

`docs/V2_PROOFS/09_BROWSER_LIVE.md`

---

# 16. AGENT 10 — SKILL LIBRARY

## Первые реальные Skills

Создать минимум:

1. `Website Audit`
2. `Repo Audit`
3. `UI QA`
4. `Research Company`
5. `Bug Hunt`

## Реальная проверка

Для `Website Audit`:

- создать Skill v1;
- запустить на test website;
- проверить output schema;
- создать v2;
- убедиться, что old run связан с v1;
- clone skill;
- export;
- import;
- назначить другому agent.

Skill должен реально влиять на execution, а не быть просто карточкой в UI.

## Proof

`docs/V2_PROOFS/10_SKILLS.md`

---

# 17. AGENT 11 — NATURAL LANGUAGE ORCHESTRATION

## Реальная проверка

Ввести:

> Создай команду: local-coder главный, vision-worker для UI, cloud-reviewer fallback. Максимум 2 workers, 6 часов, cloud budget $2, dangerous actions требуют approval.

Ожидаемо получить structured preview.

Проверить:

- модели существуют;
- invalid model отклоняется;
- budget распознаётся;
- max workers распознаётся;
- approval policy распознаётся;
- до подтверждения ничего не создаётся;
- после подтверждения orchestra реально создаётся.

## Proof

`docs/V2_PROOFS/11_NL_ORCHESTRATION.md`

---

# 18. AGENT 12 — RESOURCE BRAIN

## Реальная проверка

Сымитировать:

```text
Total available: 100 GB
Model A: 55 GB
Model B requested: 65 GB
```

Ожидаемо нельзя просто загрузить B.

Проверить policies:

### Balanced
queue or ask

### Performance
unload idle if safe

### Low Power
avoid unnecessary heavy model

Дополнительно:

- resource reservation создаётся;
- release происходит после task;
- crash не оставляет reservation навсегда;
- UI показывает explanation.

## Proof

`docs/V2_PROOFS/12_RESOURCE_BRAIN.md`

---

# 19. AGENT 13 — MISSION KPI

## Реальная проверка

Создать mission:

```text
Goal: Test Sales Pipeline
Websites analyzed: target 10
Qualified leads: target 3
Offers: target 1
```

Через events обновить:

```text
analyzed +1
qualified +1
offer +1
```

Проверить:

- значения сохраняются;
- history хранится;
- progress вычисляется;
- refresh не сбрасывает KPI;
- нельзя случайным событием изменить чужую mission.

## Proof

`docs/V2_PROOFS/13_MISSION_KPI.md`

---

# 20. AGENT 14 — SELF-HEALING

## Реальная проверка

Сымитировать:

### A. Model endpoint crash
- detect;
- retry;
- fallback;
- continue.

### B. Worker crash
- task возвращается в queue/checkpoint;
- worker restart;
- execution продолжается.

### C. Browser crash
- browser service restart;
- bounded recovery.

Проверить:

- recovery attempts ограничены;
- после лимита human escalation;
- UI показывает degraded state;
- recovery event log полный.

## Proof

`docs/V2_PROOFS/14_SELF_HEALING.md`

---

# 21. AGENT 15 — MOBILE COMMAND MODE

## Обязательные viewport tests

```text
320x700
375x812
390x844
430x932
```

## Реальная проверка на mobile UI

Пользователь должен:

1. увидеть active mission;
2. увидеть system health;
3. открыть approval;
4. approve/reject;
5. открыть agent;
6. Pause;
7. отправить instruction;
8. Resume;
9. Stop task;
10. создать Quick Task.

Проверить:
- нет horizontal page scroll;
- touch targets ~44px+;
- важные controls не спрятаны hover-only;
- большие logs не ломают экран.

## Proof

`docs/V2_PROOFS/15_MOBILE.md`

---

# 22. ОТДЕЛЬНЫЙ INTEGRATION AGENT

После завершения 15 Fable agents создать **Integration Lead**.

Его задачи:

- объединить branches;
- разрешить конфликты;
- централизовать migrations;
- удалить duplicate abstractions;
- проверить shared contracts;
- запустить integration tests;
- не переписывать функционал без причины.

Integration Lead не считается одним из 15 feature agents.

---

# 23. ОТДЕЛЬНЫЙ UI/UX AGENT

После integration создать отдельного **UI/UX Lead**.

Нужно полностью улучшить текущий дизайн BOSSMAN.

Проблемы текущего UI:

- слишком мелкие элементы;
- слишком "admin panel";
- Home перегружен raw events;
- главная задача пользователя визуально слабая;
- мало ощущения AI command center;
- недостаточная mobile usability;
- status/approvals/missions должны быть важнее raw logs.

---

# 24. НОВЫЙ HOME V2

Главный экран должен сразу показывать:

1. что BOSSMAN сейчас делает;
2. active missions;
3. active agents;
4. approvals;
5. system health;
6. resource state;
7. quick command.

Пример структуры:

```text
BOSSMAN
3 missions · 7 agents · 4 models online · Healthy

┌──────────────────────────────────────┐
│ What should BOSSMAN do?              │
│ [                                  ] │
│ [Orchestra] [24h] [Local] [START]   │
└──────────────────────────────────────┘

ACTIVE MISSION
Earn 30,000 Kč
████████░░ 64%

NEEDS YOU
2 approvals

AGENTS
Manager      Working
Coder        Reviewing
Vision       Idle

COMPUTE
RAM 61 / 128 GB
GPU 72%
Qwen 44 tok/s

RECENT ACTIVITY
5–8 readable events
```

Raw logs — отдельный экран.

---

# 25. НАВИГАЦИЯ

Desktop:

```text
Overview

Missions
Tasks
Agents
Orchestras

Models
Benchmarks
Resources

Projects
Skills
Tools
Browser

Approvals
Activity

System
Settings
```

Mobile:
- 4–5 primary tabs;
- остальные через More.

---

# 26. DESIGN SYSTEM

Использовать shared primitives:

```text
Button
IconButton
Badge
StatusDot
Card
MetricCard
CommandBar
ModelBadge
AgentBadge
Progress
Tabs
Drawer
Modal
DataTable
EmptyState
ErrorState
Skeleton
Timeline
ActivityItem
ApprovalCard
MissionCard
ResourceGauge
```

Не создавать разные версии одних и тех же primitives по всему проекту.

---

# 27. REALTIME

UI обновляется через текущую event architecture / WebSocket / SSE.

Не использовать агрессивный polling, если events уже доступны.

Realtime минимум для:

- tasks;
- agents;
- mission KPI;
- approvals;
- models;
- system metrics;
- Governor interventions;
- recovery.

---

# 28. НЕ ДОПУСКАТЬ FAKE FUNCTIONALITY

Запрещено оставлять production-кнопки, которые:

- ничего не делают;
- показывают toast без backend action;
- работают только с mock data;
- вызывают placeholder endpoint;
- меняют локальный React state, но не runtime state.

Если функция ещё не реализована:

- disabled;
- подписать `Not available yet`;
- не создавать впечатление, что она работает.

---

# 29. AUTOMATED TEST SUITE

Обязательные unit tests:

```text
router scoring
governor loop detection
resource estimator
KPI calculation
skill schema validation
NL orchestration parsing
recovery policy
review retry limit
```

Integration:

```text
mission → tasks
task → router
router → resource reservation
task → worktree
coder → reviewer
fork → independent run
recovery → fallback
scheduler → persistent run
skill → agent execution
```

E2E browser:

```text
create mission
pause/resume mission
create agent
run task
open agent map
approve action
run benchmark
fork session
mobile quick task
```

---

# 30. TEST ISOLATION

Не использовать production credentials.

Для tests:

- fake provider adapters;
- local mock OpenAI-compatible endpoint;
- test database;
- temporary git repos;
- test Playwright pages.

Но финальный smoke test должен также работать с **реальным локальным model endpoint**, если он доступен на машине.

---

# 31. REBOOT / PERSISTENCE TEST

Это критично.

Проверить минимум один сценарий:

1. запустить long-running test task;
2. убедиться, что state сохранён;
3. перезапустить worker/service;
4. task должен:
   - корректно resume;
   - либо безопасно requeue;
5. не потерять history;
6. не создать duplicate execution.

Зафиксировать результат:

`docs/V2_PROOFS/PERSISTENCE_REBOOT.md`

---

# 32. FAILURE INJECTION

Не проверять self-healing только "на словах".

Создать controlled failure injection:

- provider unavailable;
- task timeout;
- worker killed;
- browser disconnected;
- reviewer repeatedly fails;
- insufficient resources.

После тестов failure injection выключить.

---

# 33. BROWSER QA

После integration открыть реальное приложение через browser automation.

Проверить:

```text
1440x900
1280x800
1024x768
430x932
390x844
375x812
320x700
```

Для каждой основной страницы:

- screenshot;
- navigation;
- action buttons;
- loading;
- empty state;
- error state.

---

# 34. PERFORMANCE QA

Проверить:

- Home не грузит полную history;
- logs paginated;
- metrics throttled;
- realtime не создаёт duplicate listeners;
- no runaway renders;
- no memory leak in long session;
- benchmark не блокирует API/UI;
- 20 agent events/sec не ломают UI.

---

# 35. SECURITY QA

Проверить:

- `.env` gitignored;
- API keys masked;
- secrets не попадают в logs;
- dangerous actions требуют approval;
- terminal commands audit logged;
- browser takeover блокирует agent;
- no public bind by default;
- no production deploy without approval.

---

# 36. FABLE AGENT REPORT FORMAT

Каждый агент создаёт:

`docs/V2_AGENT_REPORTS/XX_FEATURE.md`

Содержимое:

```text
# Feature

## Branch

## What was implemented

## Files changed

## API

## DB

## Tests

## Manual verification

## Known limitations

## Integration notes

## Acceptance criteria
- [x]
- [x]
- [ ]
```

Нельзя ставить `[x]`, если проверка не выполнялась.

---

# 37. PROOF FORMAT

Для каждой функции proof должен содержать:

```text
Test date/time
Environment
Preconditions
Exact steps
Expected result
Actual result
Logs/events
Screenshots/artifacts
PASS / FAIL
```

Если FAIL — функция возвращается соответствующему Fable agent.

---

# 38. SECOND PASS — BUG FIX AGENTS

После первого integration QA:

1. собрать все FAIL;
2. сгруппировать по владельцу;
3. вернуть Fable agent только его проблемы;
4. agent исправляет;
5. тест повторяется;
6. proof обновляется.

Не исправлять всё одним giant integration commit, если владелец функции может исправить сам.

---

# 39. FINAL CROSS-FEATURE SCENARIO

Обязательно выполнить этот сценарий end-to-end.

## Mission

```text
Goal:
Улучшить test repository автономно.

Duration:
1 hour

Max agents:
3

Cloud budget:
$1
```

Ожидаемый workflow:

1. Mission created.
2. Planner creates tasks.
3. Smart Router selects model.
4. Resource Brain reserves capacity.
5. Coding agent receives isolated worktree.
6. Agent edits code.
7. Reviewer Gate checks code.
8. First review intentionally fails or uses a test fixture with fail path.
9. Agent fixes.
10. Reviewer passes.
11. KPI updates.
12. Agent Map updates in realtime.
13. Governor sees no runaway loops.
14. Checkpoint is stored.
15. Create Fork from checkpoint.
16. Fork with alternate instruction.
17. Mission finishes.
18. Artifacts available.
19. History available after refresh.
20. System returns resources.

Если этот сценарий не проходит — V2 не готов.

---

# 40. SECOND CROSS-FEATURE SCENARIO — FAILURE

1. start test task;
2. current model endpoint becomes unavailable;
3. Self-Healing detects it;
4. Governor records intervention;
5. Router selects fallback;
6. Resource Brain checks fallback capacity;
7. task resumes/requeues;
8. UI shows what happened;
9. no duplicate result;
10. recovery log preserved.

---

# 41. THIRD CROSS-FEATURE SCENARIO — MOBILE

На 390 px:

1. открыть Overview;
2. увидеть Mission;
3. открыть Approvals;
4. Approve test action;
5. открыть Running Agent;
6. Pause;
7. Send Instruction;
8. Resume;
9. открыть system health;
10. создать Quick Task.

---

# 42. FINAL SCORECARD

Создать:

`docs/V2_FINAL_SCORECARD.md`

Формат:

| Feature | Backend | UI | Persistence | Failure handling | E2E | Final |
|---|---:|---:|---:|---:|---:|---|
| Autopilot | PASS | PASS | PASS | PASS | PASS | DONE |
| Router | ... |

Только:
- `DONE`
- `PARTIAL`
- `FAILED`

Никаких расплывчатых статусов.

---

# 43. DEFINITION OF DONE

BOSSMAN V2 считается готовым только если:

- все 15 Fable agents созданы;
- каждый работает в отдельной branch/worktree;
- shared contracts согласованы;
- все функции имеют backend;
- все основные функции имеют usable UI;
- все релевантные unit tests проходят;
- integration tests проходят;
- E2E проверки проходят;
- persistence проверена;
- failure injection проверена;
- mobile проверен;
- UI redesign завершён;
- fake buttons отсутствуют;
- final scorecard создан;
- все P0/P1 bugs исправлены;
- final branch build проходит;
- security checks проходят;
- documentation обновлена;
- final commit создан;
- branch push выполнен.

---

# 44. PUSH RULES

После всех проверок:

```bash
git status
git diff --check
```

Проверить:

- no `.env`;
- no secrets;
- no model weights;
- no temp test files;
- no accidental DB dumps;
- no debug screenshots unless intentionally stored in docs.

Запустить полный test suite.

Затем final commit:

```text
feat: evolve BOSSMAN into verified multi-agent AI command center
```

Push:

```bash
git push -u origin feature/bossman-command-center-v2
```

Никогда:
- force push;
- push failing build;
- push secrets.

Если remote auth отсутствует:
- не считать это coding failure;
- оставить branch готовой;
- сообщить точную команду, которую должен выполнить пользователь.

---

# 45. FINAL REPORT

Создать:

`docs/V2_IMPLEMENTATION_REPORT.md`

Включить:

```text
Architecture
15 features
What is actually working
What is partial
Branches/worktrees
Migrations
API changes
UI redesign
Tests
E2E
Failure injection
Persistence
Mobile
Security
Performance
Known limitations
Final scorecard
Git branch
Push status
Recommended V3
```

---

# 46. ФИНАЛЬНОЕ ПРАВИЛО

**Не верь отчётам агентов. Проверяй их.**

Каждый Fable agent может сказать "готово", но Integration Lead обязан:

1. открыть код;
2. запустить тесты;
3. запустить приложение;
4. выполнить acceptance scenario;
5. проверить event/DB state;
6. проверить UI;
7. только после этого принять функцию.

Функция без доказательства = функция не готова.

---

# START NOW

Сделай строго по порядку:

1. прочитай текущий проект;
2. прочитай master prompt files;
3. сделай `V2_CURRENT_STATE_AUDIT.md`;
4. сделай `V2_SHARED_CONTRACTS.md`;
5. сделай `V2_ACCEPTANCE_MATRIX.md`;
6. создай integration branch;
7. создай 15 Fable branches/worktrees;
8. назначь каждому агенту одну функцию;
9. запусти работу;
10. получи agent reports;
11. интегрируй по dependency order;
12. запусти automated tests;
13. запусти acceptance scenarios;
14. верни failing функции владельцам;
15. повтори проверки;
16. запусти UI/UX Lead;
17. сделай browser QA desktop/mobile;
18. сделай persistence/reboot test;
19. сделай failure injection;
20. выполни 3 cross-feature scenarios;
21. создай `V2_FINAL_SCORECARD.md`;
22. исправь P0/P1 bugs;
23. final architecture/security review;
24. build/test;
25. final commit;
26. push feature branch;
27. создай `V2_IMPLEMENTATION_REPORT.md`.

Не останавливайся на этапе "всё выглядит красиво".

Конечная цель:

> **BOSSMAN должен реально выполнять, координировать, проверять, восстанавливать и сохранять AI-задачи, а не только отображать их в интерфейсе.**
