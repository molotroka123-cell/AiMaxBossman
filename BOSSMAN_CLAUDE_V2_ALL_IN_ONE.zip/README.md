# BOSSMAN Claude V2 — All-in-One Pack

One archive containing the architecture decisions, prewritten code, portable
skills, tests, master prompts and UX references prepared before the full
15-agent V2 implementation.

Start with:

`CLAUDE_START_HERE.md`

Then:

`docs/CLAUDE_LIMIT_SAVER_HANDOFF.md`

Do not copy the whole archive blindly over the repository. The prewritten code
is intended to be merged into the current branch by Claude Code after checking
current paths and migrations.
