# AI Company Mode

User gives one high-level objective.
Bossman coordinates multiple specialized agents as a virtual company.

Example:
"Increase qualified leads by 30% in 60 days."

Possible workstreams:
strategy, growth, SEO, ads, content, analytics, CRM, support, operations,
finance, research, legal/compliance advisory.

AI Company Mode is an orchestration layer over existing Bossman systems.
Do not duplicate Gateway, Tool Registry, Policy, Approval, Secret Store,
EventBus, Memory, Cost, Session, Scheduler, Artifact, Verification or Flight Recorder.

Suggested typed core:
CompanyObjective, ObjectiveConstraint, KPI, Department, AgentRole, Workstream,
TaskDependency, CompanyTask, BudgetEnvelope, ApprovalRequirement,
EvidenceRequirement, CompanyPlan, CompanyRunState, WorkResult, CompanyReport.

Runtime:
objective -> KPI -> constraints -> decomposition -> role assignment -> task DAG ->
model/capability assignment -> budget policy -> approvals -> execution ->
fresh observation -> verification -> KPI aggregation -> replanning ->
final report -> learning records.

Role is context, not authority.
"Finance Agent" cannot spend money without policy+approval.
"Legal Agent" cannot enter commitments.
"Growth Agent" cannot publish/buy ads without permission.
"Admin Agent" gets no secrets merely by title.

Feature flag:
AI_COMPANY_MODE_ENABLED=false

Initial synthetic demo:
"Improve a synthetic website's SEO readiness."
