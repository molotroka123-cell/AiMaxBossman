# Agent Learning Trace Policy

Bossman should accumulate engineering knowledge from every strong model that works on the repository.

Every meaningful coding, debugging, security, architecture or operational task should produce a learning trace.

Record:
- symptom
- reproduction
- observations/evidence
- hypotheses considered
- rejected hypotheses and why
- root cause
- fix strategy
- alternatives
- tests
- adversarial variants
- regression
- verification
- transferable lessons

Do not store:
- hidden chain-of-thought
- secret tokens/passwords/credentials
- raw personal data
- speculation presented as fact

Statuses:
VERIFIED, FAILED_EXPERIMENT, PARTIAL, UNVERIFIED, REJECTED.

Only VERIFIED enters canonical retrieval/training corpus.

Canonical paths:
docs/learning/fix_logs/<TASK_ID>.md
data/learning/fix_cases.jsonl
data/learning/failed_experiments.jsonl
schemas/learning_fix_case.schema.json

Promotion invariant:
No case becomes authoritative because the same model says it succeeded.
Promotion requires fresh evidence and independent verification where objective effects can be checked.
