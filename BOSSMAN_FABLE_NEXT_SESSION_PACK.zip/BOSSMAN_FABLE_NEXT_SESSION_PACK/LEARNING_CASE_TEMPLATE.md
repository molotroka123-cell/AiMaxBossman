# Learning Case: <TASK_ID>

## Metadata
MODEL:
AGENT:
START_SHA:
END_SHA:
LEARNING_STATUS:
VERIFIED_BY:
CONFIDENCE:

## Task
## Symptom
## Reproduction
## Evidence
## Hypotheses considered
## Rejected hypotheses + why
## Root cause
## Relevant code paths
## Fix strategy
## Alternatives considered
## Why this fix was chosen
## Files changed
## Tests added
## Original reproduction after fix
## Adversarial variants
## Regression
## Fresh external verification
## Failed approaches / recovery lessons
## Generalizable lessons

## Teach local model
- Recognize:
- Inspect first:
- Avoid:
- Prefer:
- Verify using:
- General invariant:

## Limitations / follow-up
