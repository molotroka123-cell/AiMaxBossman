# BOSSMAN — Fable Next Session Pack

This pack combines three objectives:

1. Finish the current Fable 5.1 security remediation.
2. Implement the Deep Fix Learning Layer so every serious coding/reasoning agent leaves reusable learning traces for future local models.
3. Add the architectural foundation for AI Company Mode: one objective -> coordinated multi-agent workforce with policy, approvals, evidence, verification, budgets and learning.

Expected branch:
`claude/bossman-control-v03-43igbk`

Expected checkpoint HEAD:
`1283894dc46b11d37534be373bde2c4e2edbb5ef`

Always:
- git fetch
- verify remote HEAD and record START_SHA
- reconcile if branch advanced
- never force-push
- never hard-reset away unrelated work
- never weaken tests to get green

Canonical invariant:
`intent -> typed action -> policy/scopes -> approval -> executor -> fresh observation -> verification`

Never:
`LLM -> arbitrary shell`
