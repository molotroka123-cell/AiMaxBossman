# Implementation Checklist

Security: resume checkpoint; close F-009/F-012/F-013/F-014/F-006/F-007/F-008/F-016; disposition all other Fable findings; close BUG-004/005 where reproducible; full re-attack.

Deep Fix Learning: policy; schema; verified/failed stores; redaction; promotion rules; retrieval filters; backfill F-001/F-002/F-003 and new fixes.

Deep Fix Mode: state machine; reproduce gate; root-cause record; minimal patch; original repro; variants; regression; independent verifier; auto learning record; flag OFF by default.

AI Company Mode: typed objective; roles/workstreams; DAG; KPI; budget envelope; approvals; evidence; final report; learning records; flag OFF; synthetic SEO demo.

Final: core regression; command-center regression; security suite; compileall; secret scan; final docs; final remote SHA; SAFE_FOR_V2_FREEZE verdict.
