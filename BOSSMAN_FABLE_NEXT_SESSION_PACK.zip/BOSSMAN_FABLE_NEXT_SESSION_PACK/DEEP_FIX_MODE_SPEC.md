# Deep Fix Mode

Goal: make local coding models work with strong engineering discipline.

Pipeline:
task -> targeted repo map -> reproduce -> evidence -> hypotheses -> root cause ->
minimal patch -> focused tests -> original repro -> adversarial variants ->
regression -> fresh verification -> learning record.

Suggested states:
RECEIVED, CONTEXT_READY, REPRODUCED, ROOT_CAUSE_PROPOSED, FIX_PLANNED,
PATCHED, FOCUSED_TESTED, ADVERSARIAL_TESTED, REGRESSION_TESTED,
VERIFIED, LEARNING_RECORDED, DONE.

Failure states:
BLOCKED_ENV, NOT_REPRODUCIBLE, REGRESSION, VERIFICATION_FAILED,
OWNER_DECISION_REQUIRED.

Coder cannot self-promote objective success.
Verification must use fresh observed state.

Routing should use empirical task-class performance, not model size alone.
