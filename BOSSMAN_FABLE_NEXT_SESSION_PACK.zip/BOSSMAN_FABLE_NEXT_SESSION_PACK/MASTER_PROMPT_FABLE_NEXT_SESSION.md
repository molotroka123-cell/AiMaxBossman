# BOSSMAN — NEXT FABLE SESSION
## COMPLETE REMEDIATION + DEEP FIX LEARNING + AI COMPANY FOUNDATION

ROLE:
You are the senior implementation and security lead for AiMaxBossman.

Repository:
https://github.com/molotroka123-cell/AiMaxBossman

Branch:
claude/bossman-control-v03-43igbk

Expected checkpoint HEAD:
1283894dc46b11d37534be373bde2c4e2edbb5ef

FIRST:
1. git fetch
2. verify branch remote HEAD
3. record START_SHA
4. read `docs/security/REMEDIATION_STATE.md`
5. read existing Fable 5.1 audit docs
6. continue from the recorded remediation/ownership plan
7. do not repeat broad discovery unless repo changed materially

# PART A — FINISH SECURITY REMEDIATION

Priority:
P0 F-009 terminal sandbox confinement
P0 F-012 verification spoofing / fresh evidence
P0 F-013/F-014 MCP identity/trust
P1 F-006/F-007 untrusted-data boundary
P1 F-008/F-016 cloud fail-closed routing

Then close/disposition:
F-004/F-005/F-010/F-011/F-015/F-017/F-018
plus BUG-004, BUG-005, redaction gaps, discovery bounds,
code-index symlink escape, bounded 429 recovery and remaining RunPod gaps.

For every finding:
REPRODUCE -> ROOT CAUSE -> MINIMAL FIX -> FOCUSED TEST ->
ORIGINAL PoC -> VARIANT PoC -> REGRESSION -> EXTERNAL VERIFICATION.

Never mark runtime issues fixed when the required runtime is unavailable.
Use `NOT_TESTED_ON_THIS_HOST` / `BLOCKED_ENV`.

# PART B — IMPLEMENT DEEP FIX LEARNING LAYER

Goal:
Every meaningful coding/security/architecture task leaves a structured, verified learning trace that future local Bossman models can retrieve.

This is NOT hidden chain-of-thought storage.
Do not store private hidden reasoning.
Store concise engineering decision records.

Canonical learning pipeline:
Task -> Reproduction -> Evidence -> Hypotheses -> Rejected hypotheses + evidence ->
Root cause -> Fix strategy -> Alternatives -> Tests -> Original repro retest ->
Adversarial variants -> Full regression -> External verification -> Learning record ->
Promotion to verified corpus.

Canonical locations:
docs/learning/fix_logs/
data/learning/fix_cases.jsonl
data/learning/failed_experiments.jsonl
schemas/learning_fix_case.schema.json

Required fields:
TASK_ID, MODEL, AGENT, START_SHA, END_SHA, TASK, SYMPTOM, REPRODUCTION,
EVIDENCE, ROOT_CAUSE_HYPOTHESES, REJECTED_HYPOTHESES, ROOT_CAUSE,
RELEVANT_CODE_PATHS, FIX_STRATEGY, ALTERNATIVES_CONSIDERED, WHY_THIS_FIX,
FILES_CHANGED, TESTS_ADDED, ORIGINAL_REPRO_RESULT, ADVERSARIAL_VARIANTS,
REGRESSION_RESULT, EXTERNAL_VERIFICATION, FAILURE_RECOVERY_LESSONS,
GENERALIZABLE_LESSONS, TEACH_LOCAL_MODEL, CONFIDENCE, LIMITATIONS,
VERIFIED_BY, LEARNING_STATUS.

Statuses:
VERIFIED
FAILED_EXPERIMENT
PARTIAL
UNVERIFIED
REJECTED

Only VERIFIED may enter the primary retrieval/training corpus.
FAILED_EXPERIMENT stays separate.

Add tests:
- required fields
- status validation
- VERIFIED requires evidence + verifier
- failed experiments cannot enter verified corpus
- secrets redacted
- no raw chain-of-thought field
- deterministic IDs/hashes where useful
- retrieval filters by domain/bug class/component/severity/outcome

Backfill records for F-001/F-002/F-003 and every newly closed finding.

# PART C — DEEP FIX MODE

Implement feature-gated Deep Fix Mode for local coding agents.

Pipeline:
bug/task -> repo map -> targeted context -> reproduce -> root-cause hypotheses ->
code-path tracing -> minimal patch -> focused tests -> original repro ->
adversarial variants -> regression -> independent verification -> evidence ->
learning record -> commit.

A coding agent cannot self-promote objective success.

Require:
- original bug reproduced before patch unless impossible and documented
- at least one variant after patch
- no unrelated broad diff
- regression evidence
- fresh external verification where objective effect exists
- learning record emitted automatically

Default feature flag OFF until green.

# PART D — AI COMPANY MODE FOUNDATION

Goal:
Prepare Bossman for a Strawberry-like mode:
ONE BUSINESS OBJECTIVE -> COORDINATED AI WORKFORCE -> VERIFIED BUSINESS OUTPUTS.

Do not build a huge parallel business suite.
Build the minimal orchestration foundation behind flags.

Example objective:
"Increase qualified leads by 30% in 60 days."

Possible workstreams:
strategy, growth, SEO, ads, content, analytics, CRM, operations, finance,
research, support, legal/compliance advisory.

All actions remain inside Bossman's canonical security architecture.

Suggested typed concepts:
CompanyObjective
ObjectiveConstraint
KPI
Department
AgentRole
Workstream
TaskDependency
CompanyTask
BudgetEnvelope
ApprovalRequirement
EvidenceRequirement
CompanyPlan
CompanyRunState
WorkResult
CompanyReport

Pipeline:
objective -> measurable KPIs -> constraints -> decomposition -> role assignment ->
task DAG -> model/capability assignment -> budget/resource limits -> approvals ->
execution -> fresh evidence -> KPI aggregation -> replanning -> final report ->
learning records.

No direct LLM authority over spending, credentials, publishing, legal commitments or destructive actions.

Reuse existing:
Gateway, Tool Registry, Policy, Approval, Secret Store, EventBus, Memory, Cost,
Session, Artifact, Verification, Scheduler, Flight Recorder.

Do NOT duplicate these engines.

Feature flag:
AI_COMPANY_MODE_ENABLED=false

Implement one harmless deterministic synthetic E2E:
Objective: "Improve a synthetic website's SEO readiness."

Expected outputs:
- objective
- task DAG
- assigned roles
- execution trace
- evidence
- before/after KPI-like score
- final verified artifact
- learning records

No real ad spend, publishing, credentials or irreversible operations.

# PART E — LOCAL MODEL LEARNING ARCHITECTURE

Stage 1 Retrieval:
retrieve only VERIFIED similar cases with provenance.

Stage 2 Eval:
build evals from verified cases; keep holdout hidden.

Stage 3 Skill/prompt improvement:
compare Direct vs Bossman Deep Fix with same model.

Stage 4 Optional future fine-tuning:
export sanitized VERIFIED corpus only.

Preserve Learning Guard:
proposal -> benchmark -> shadow -> verified -> owner promotion.

# PART F — POLICY FOR ALL FUTURE AGENTS

Create:
docs/learning/AGENT_LEARNING_TRACE_POLICY.md

Every serious coding/reasoning agent, regardless of vendor/model, should create reusable learning traces:
Fable, Opus, GLM, OpenAI, Gemini, local Qwen and future Bossman agents.

Policy must require:
- important technical decisions
- failed approaches
- evidence
- no hidden chain-of-thought
- secret redaction
- hypothesis/fact separation
- confidence/limitations
- independent verification before promotion

Where practical wire this policy into agent task compiler/templates.

# PART G — DOCUMENTATION QUALITY

Do not write diary logs.
Write high-signal teaching material.

Future local model should learn:
1. What failed?
2. How reproduced?
3. What evidence mattered?
4. What hypotheses were plausible?
5. What disproved wrong hypotheses?
6. Root cause?
7. Why this fix?
8. Which tempting fix should be avoided?
9. How was fix attacked?
10. How was real success verified?
11. Which invariant transfers to future bugs?

# PART H — TESTS/GATES

Run:
bossman-core full regression
command-center full regression
security/Fable PoCs
Deep Fix tests
Learning Trace tests
AI Company foundation tests
compileall
secret scan

Then re-run all repaired attacks.

If environment allows: >=100 mixed-task soak.

Security gates:
- no open CRITICAL
- no open HIGH
- F-009, F-012, F-013/F-014, F-006/F-007, F-008/F-016 closed
- no arbitrary shell
- no approval bypass
- cloud fail-closed
- verified success requires fresh evidence
- no security regression

Learning gates:
- schema works
- verified and failed corpora separated
- secrets redacted
- no raw chain-of-thought
- backfilled security cases exist
- retrieval can select verified similar cases

AI Company gates:
- feature flag OFF by default
- no duplicate core engines
- synthetic demo completes
- DAG and roles observable
- canonical approvals/policy
- final result has evidence
- learning records emitted

# PART I — COMMIT/PUSH DISCIPLINE

Commit in reviewable slices.
Before every push: git fetch, reconcile, no force push.

# PART J — FINAL OUTPUT

Return:
START_SHA=
FINAL_LOCAL_SHA=
FINAL_REMOTE_SHA=
SECURITY_FINDINGS_TOTAL=
SECURITY_FIXED=
SECURITY_OPEN_CRITICAL=
SECURITY_OPEN_HIGH=
SECURITY_OPEN_MEDIUM=
SECURITY_OPEN_LOW=
F009=
F012=
F013=
F014=
F006=
F007=
F008=
F016=
BUG004=
BUG005=
CORE_REGRESSION=
COMMAND_CENTER_REGRESSION=
SECURITY_REGRESSION=
DEEP_FIX_MODE=
LEARNING_TRACE_POLICY=
LEARNING_SCHEMA=
VERIFIED_CASES_COUNT=
FAILED_EXPERIMENT_CASES_COUNT=
BACKFILLED_SECURITY_CASES=
AI_COMPANY_MODE_FOUNDATION=
AI_COMPANY_FLAG_DEFAULT=
AI_COMPANY_SYNTHETIC_E2E=
CLOUD_CALLS=
SECRETS_LEAKED=
ARBITRARY_SHELL=
APPROVAL_BYPASS=
VERIFICATION_FRESH_EVIDENCE=
SAFE_FOR_V2_FREEZE=YES/NO
UNRESOLVED_BLOCKERS=

Do not claim PASS without proof.
Continue autonomously until safe work is complete or a real owner/environment decision blocks progress.
