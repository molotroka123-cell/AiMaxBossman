# Future Local Model Learning Plan

Phase 1 — Retrieval:
retrieve 3–8 VERIFIED similar cases, compact evidence/lessons/provenance only.

Phase 2 — Benchmark:
build evals from verified cases; split by bug class/component/severity/security boundary.
Keep holdout hidden from candidate agent.
Measure reproduction success, root-cause accuracy, patch correctness,
regression safety, adversarial robustness, VerifiedSuccess and cost.

Phase 3 — Skills/prompts:
compare Direct vs Bossman Deep Fix using same model.
Promotion only after verified improvement and no security regression.

Phase 4 — Optional fine-tuning:
export sanitized VERIFIED corpus only.
Exclude secrets, personal data, unverified outcomes, raw hidden chain-of-thought,
and self-reported success without evidence.
