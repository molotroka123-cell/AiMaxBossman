# MASTER PROMPT — Finish AiMaxBossman V1

You are the final acceptance engineer for repository `molotroka123-cell/AiMaxBossman`.
Work on branch `claude/bossman-control-v03-43igbk` and ALWAYS fetch/verify current remote HEAD before doing anything. The audit baseline when this pack was generated was `ac9506fd298d5d7ecdfb1445515929b8f27c9ed0`; if remote HEAD is newer, inspect the delta and continue from the newer HEAD. Never reset valid newer work.

GOAL: finish V1 through evidence-based OWNER HARDWARE FULL SYSTEM ACCEPTANCE. This is not a feature-development sprint.

Before changing code, read repository truth docs:
- `docs/context/CURRENT_STATE.md`
- `docs/context/NEXT.md`
- `docs/context/FINAL_HARDENING_STATUS.md`
- `docs/context/EVENING_LIVE_ACCEPTANCE.md`
- `docs/context/BOSSMAN_V1_RC_FINAL_AUDIT_HANDOFF.md`
Then read every file in this finish pack.

NON-NEGOTIABLE ARCHITECTURE:
- do not create a second Gateway, Tool Registry, Policy, Approval, Secret Store, Event Bus, Browser, Telegram, MCP, Memory, Cost or Session engine;
- never introduce `LLM -> arbitrary string -> host shell`;
- cloud model traffic goes through existing Stage3 Gateway + Cost Governor;
- local model uses existing Gateway -> Ollama path and `cloud_policy=never` when validating zero-cloud mode;
- secrets are references/masked only;
- no force-push;
- never call a NOT_TESTED/SKIP case PASS.

START WITH READ-ONLY AUDIT:
1. Fetch remote HEAD, recent commits, workflows and current docs.
2. Verify that previous Lane-4 and hardening fixes are still present.
3. Run targeted regressions first, then full available tests.
4. Produce a short delta report: what changed since baseline, open P0/P1/P2, and whether hardware acceptance can proceed.

IF CURRENT CODE IS HEALTHY, DO NOT REWRITE IT. Move directly into OWNER HARDWARE acceptance.

MANDATORY LIVE MATRIX:
A. Ollama -> Gateway -> Planner -> Stage13 -> Windows -> Notepad -> fresh observation; prove CLOUD_CALLS=0 and unsafe app DENY.
B. Restart/recovery for Bossman and Command Center; prove no duplicate side effects and approval anti-replay.
C. Long-context compact/checkpoint/restart/resume with measurable retained state.
D. Real plugin reads where credentials exist; mutations require ASK and exactly one effect; missing creds are honest SKIP_EXTERNAL_CREDENTIAL.
E. Real browser navigation + approval + fresh observation; browser-down must become honest OFFLINE/DEGRADED.
F. On compatible Linux/KVM host, execute strong sandbox runtime and verify containment/egress/fail-closed.
G. Real Dev Factory task through existing Gateway/model/editor/sandbox, producing diff + tests, no auto-publish.
H. Chaos: provider/Ollama/browser/Pythia/plugin credential down -> honest degraded states.
I. Live red-team: SSRF, path/symlink escape, secret leak, SQL write, unknown MCP, unsafe n8n, approval replay, arbitrary shell, unsafe APP_LAUNCH.
J. Full host regression including compile, secrets, JS, core, command-center, plugins, LSP, memory, approvals, Gateway, Cost, Stage13, Pythia, browser, MCP and security.

KNOWN OPERATIONAL ITEM:
Two command-center tests have historically hung on GitHub runners while passing locally. Reproduce them on self-hosted hardware before changing production logic. Remove the CI skip only after a real root cause/fix is proven.

BUG POLICY:
- P0/P1 discovered -> reproduce, minimally fix, add targeted regression, run relevant full regression, commit with precise message, then restart affected acceptance sections.
- P2 -> fix only if safe and bounded or record explicit residual risk.
- P3 -> defer unless trivial and zero-risk.
- No opportunistic refactor during acceptance.

EVIDENCE:
Create/update `docs/context/V1_FINAL_OWNER_HARDWARE_ACCEPTANCE.md` using the evidence template. Every row needs exact PASS/FAIL/SKIP state and concrete evidence. Update `CURRENT_STATE.md` and `NEXT.md` to match reality.

FINAL OUTPUT MUST INCLUDE:
- final remote SHA;
- CI state;
- exact test counts and skips;
- mandatory live matrix result A-J;
- P0/P1/P2 list;
- regressions/fake-green findings;
- files/commits changed during acceptance;
- release verdict PASS or BLOCKED;
- if BLOCKED, the smallest exact next action.

Do not declare completion from unit tests alone. V1 is complete only after real owner-hardware evidence proves the system.
