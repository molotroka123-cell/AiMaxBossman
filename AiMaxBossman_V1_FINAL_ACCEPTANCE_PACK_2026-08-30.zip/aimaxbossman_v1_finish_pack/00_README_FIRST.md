# AiMaxBossman V1 — Finish Pack

Target repository: molotroka123-cell/AiMaxBossman
Target branch: claude/bossman-control-v03-43igbk
Frozen audit baseline SHA: ac9506fd298d5d7ecdfb1445515929b8f27c9ed0
Prepared: 2026-08-30

## Purpose
This pack is for the FINAL V1 acceptance phase. Do not redesign architecture and do not add new subsystems unless a reproducible blocker proves the existing design cannot satisfy acceptance.

The code-hardening phase is effectively complete. Remaining work is dominated by live host validation, evidence capture, and a few operational/policy items.

## Non-negotiable rules
1. Continue from current remote HEAD. Never reset/cherry-pick old audit-only branches blindly.
2. Preserve single-engine architecture: no duplicate Gateway, Tool Registry, Policy, Approval, Secret Store, Event Bus, Browser, MCP, Memory, Cost or Session engine.
3. No fake-green. Every unexecuted live check must say NOT_TESTED / SKIP_HOST / SKIP_EXTERNAL_SERVICE / SKIP_EXTERNAL_CREDENTIAL.
4. No force-push.
5. Every fix must have a reproducer + targeted test + full relevant regression.
6. Do not mark OWNER HARDWARE acceptance PASS until real hardware evidence exists.

Read files in this order:
1. 01_CURRENT_VERDICT.md
2. 02_REMAINING_WORK.md
3. 03_OWNER_HARDWARE_ACCEPTANCE.md
4. 04_EVIDENCE_TEMPLATE.md
5. 05_DONE_DEFINITION.md
6. 06_MASTER_PROMPT.md
