# V1 FINAL OWNER HARDWARE ACCEPTANCE — evidence template

## Identity
- Date/time:
- Operator:
- Branch:
- SHA:
- Working tree clean: YES/NO
- Host OS:
- Hardware:
- Python:
- Container/sandbox runtime:
- Ollama version/model:

## Results table
| ID | Scenario | Result | Evidence | Notes |
|---|---|---|---|---|
| A1 | Ollama -> Gateway -> Stage13 -> Notepad | NOT_TESTED | | |
| A2 | Type BOSSMAN-V1-LIVE | NOT_TESTED | | |
| A3 | CLOUD_CALLS == 0 | NOT_TESTED | | |
| A4 | Unsafe app -> DENY | NOT_TESTED | | |
| B1 | Bossman restart recovery | NOT_TESTED | | |
| B2 | Command Center restart/session persistence | NOT_TESTED | | |
| B3 | Approval replay prevention | NOT_TESTED | | |
| C1 | Context compact/checkpoint/restart/resume | NOT_TESTED | | |
| D1 | Live read-only plugins | NOT_TESTED | | |
| D2 | Mutations ASK + exactly one effect | NOT_TESTED | | |
| E1 | Browser live navigation/approval/observation | NOT_TESTED | | |
| F1 | Strong sandbox execution/egress | NOT_TESTED | | |
| G1 | Dev Factory live edit/test/diff | NOT_TESTED | | |
| H1 | Dependency chaos honest degraded states | NOT_TESTED | | |
| I1 | Live red-team | NOT_TESTED | | |
| J1 | Full host regression | NOT_TESTED | | |
| K1 | Optional OpenCode benchmark | NOT_TESTED | | |

Allowed result vocabulary:
- PASS
- FAIL
- NOT_TESTED
- SKIP_HOST
- SKIP_EXTERNAL_SERVICE
- SKIP_EXTERNAL_CREDENTIAL

## Failures discovered
For every FAIL:
- severity: P0/P1/P2/P3
- exact reproducer
- expected behavior
- actual behavior
- root cause
- files changed
- targeted regression test
- full regression result
- fix SHA

## Final verdict
- Open P0:
- Open P1:
- Open security P2:
- Full host regression:
- Fake-green found: YES/NO
- Release verdict: PASS / BLOCKED

PASS is legal only if mandatory A-J items have real evidence and there are no open P0/P1.
