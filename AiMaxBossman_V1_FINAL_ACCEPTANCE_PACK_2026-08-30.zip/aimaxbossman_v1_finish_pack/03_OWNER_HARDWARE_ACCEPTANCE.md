# OWNER HARDWARE FULL SYSTEM ACCEPTANCE

Run against one frozen SHA. If code changes, record the new SHA and restart affected acceptance sections.

## Preflight
- Record OS, CPU/GPU/RAM, Python, Docker/runtime versions.
- Record exact git SHA and confirm clean working tree.
- Start bossman-core + command-center.
- Start local Ollama and load a small compatible model.
- Set `cloud_policy=never` for the local-only scenario.
- Ensure secrets are in env/Vault only.

## A. Local AI -> PC action
Flow must be real:
`Ollama -> Stage3 Gateway -> Planner -> Stage13 Computer Operator -> Windows -> fresh observation -> audit`

1. Ask: `Открой Блокнот`.
PASS only if Notepad physically opens and fresh observation proves it.
2. Ask to type `BOSSMAN-V1-LIVE`.
PASS only if text appears in Notepad.
3. Prove `CLOUD_CALLS == 0`.
4. Attempt unsafe/non-allowlisted app launch -> must DENY.
5. Verify correlation/audit ids for the action chain.

## B. Restart/recovery
- Restart FactStore/Bossman mid-task: restore durable state, no duplicate effect.
- Restart Command Center: coding sessions survive, active state is not lost, merge does not repeat.
- Replay approval/event: anti-replay must prevent duplicate side effect.

## C. Long context retention
Create a long deterministic session, compact/checkpoint, restart, resume.
PASS only if agent still knows:
- objective;
- invariants;
- decisions;
- current task;
- relevant files;
- test state;
- failures/blockers;
- exact next step.

## D. Live plugins
With available credentials/services, call real read-only capabilities first:
- github repo_read;
- ollama.chat;
- telegram.status;
- mcp.tool_list;
- browser.open.

Mutation capabilities must require ASK and produce exactly one effect after approval.
`sql.read` -> real rows from read-only DB. `sql.write` -> DENY.
Missing credentials -> honest SKIP_EXTERNAL_CREDENTIAL, never PASS.

## E. Browser / Computer Operator
- real allowlisted navigation;
- approvals on sensitive input/submit;
- fresh observation after action;
- browser down -> honest degraded/offline state.

## F. Strong sandbox
On compatible host:
- run strong-runtime tests;
- execute one real sandbox task;
- verify containment and egress barrier;
- unavailable strong runtime -> fail closed, not fallback to unsafe host execution.

## G. Dev Factory live
- real model plans a small code change;
- real editor changes isolated worktree/copy;
- run tests in sandbox;
- inspect diff;
- do not auto-push/publish;
- merge only from clean committed session according to current merge policy.

## H. Chaos/degraded states
Deliberately bring down one dependency at a time:
- provider;
- Ollama;
- browser;
- Pythia;
- plugin credential.
UI/API must report explicit degraded/offline/missing status and never fake READY.

## I. Live red-team
Verify blocks for SSRF, path/symlink escape, secret leak, SQL write, unknown MCP, unsafe n8n, approval replay, arbitrary shell path, unsafe APP_LAUNCH.
No open P0/P1 allowed at final acceptance.

## J. Full host regression
Run full available suites for bossman-core and command-center plus:
- secret scan;
- compileall;
- JS syntax checks;
- plugin/LSP/memory/approval/Gateway/Cost/Stage13/Pythia/browser/MCP/security paths.
All skips must use an honest reason.

## K. Optional benchmark
If OpenCode is actually available, run 10 matched coding tasks and record:
success, tests-green, interventions, time, tokens, cost, retries, bad edits, security violations, resume behavior.
If unavailable: NOT_TESTED, not failure and not PASS.
