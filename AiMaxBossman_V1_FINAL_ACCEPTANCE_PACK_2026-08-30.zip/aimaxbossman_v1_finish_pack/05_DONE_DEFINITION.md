# Definition of Done — V1

V1 is DONE only when all are true:

- A single frozen remote SHA is identified.
- Required GitHub CI for that SHA is green.
- No open P0 or P1.
- Security residuals are explicitly classified and accepted or fixed.
- Real local-only Ollama -> Gateway -> Stage13 -> Windows action passes with zero cloud calls.
- Fresh observation proves computer actions occurred.
- Restart/recovery and anti-replay pass.
- Context checkpoint/restart/resume passes.
- Browser live path is honest and functional.
- Strong sandbox is executed on suitable hardware or explicitly blocks release if it is mandatory for target deployment.
- Dev Factory performs one real isolated edit/test/diff cycle.
- Chaos modes report degraded/offline honestly.
- Live red-team has no P0/P1.
- Full host regression is green with only honest skips.
- Final evidence file is committed, recommended path:
  `docs/context/V1_FINAL_OWNER_HARDWARE_ACCEPTANCE.md`
- `CURRENT_STATE.md` and `NEXT.md` are updated to final truth.
- Branch/release protection is configured or owner explicitly records why not.

After this point: FREEZE V1. New applications/features go into the next phase, not into the acceptance patch.
