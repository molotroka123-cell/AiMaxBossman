# Remaining work — ordered by priority

## P0 — release gate (not necessarily a code bug)
### 1. OWNER HARDWARE FULL SYSTEM ACCEPTANCE
Run the real host matrix from `03_OWNER_HARDWARE_ACCEPTANCE.md`. This is the main remaining gate.

### 2. Strong sandbox runtime on actual host
Current runner cannot prove gVisor/runsc or MicroVM/KVM execution. On Linux/KVM-capable hardware:
- install/provide runsc and/or `/dev/kvm` as intended by project design;
- run `tests/test_sandbox_strong_runtimes.py`;
- execute a real DEVELOPER/HOSTILE task;
- verify egress confinement and fail-closed behavior.

### 3. LOCAL-LIVE Dev Factory
Run one real end-to-end code-edit task through existing Gateway + model + sandbox:
- planner receives task;
- editor makes a real isolated patch;
- tests execute;
- result is shown for review;
- no automatic publish/push.

## P1 — operational acceptance
### 4. Reproduce two GitHub-runner-only hangs on self-hosted hardware
Known tests:
- `tests/test_discovery.py::test_open_port_that_stays_silent_is_not_called_absent`
- `tests/test_v21_failure_injection.py::test_provider_failure_retries_are_bounded_and_status_is_honest`

They are skipped in CI through `BCC_CI_SKIP_RUNNER_HANGS=1` because they hang on GitHub runner while passing locally. On self-hosted hardware:
- reproduce;
- identify teardown/async engine cause;
- add bounded timeout/fixture fix if reproduced;
- remove skip flag only after evidence.
Do not modify production discovery logic without a reproducer.

### 5. Branch protection owner decision
Configure required checks for the protected release/default branch. Suggested minimum:
- Bossman Core CI security/pytest groups;
- compile + secret scan;
- Command Center pytest;
- Command Center secret/JS/forbidden-file checks.
This is repository policy, not application logic.

### 6. Remote exposure/Tailscale policy owner decision
Externally expose only the intended `/remote` surface. Verify policy rather than assuming localhost or private network equals authentication.

## P2 / recurring practice
### 7. Live red-team replay
Repeat attacks after final fixes:
- scope bypass;
- WS events without events scope;
- AI Lab path traversal/symlink escape;
- argv/shell injection attempts;
- editor escape outside working copy;
- SSRF private IP/hostname/redirect;
- secret leakage;
- SQL write;
- unknown MCP capability;
- unsafe n8n URL;
- approval replay;
- unsafe app launch.

## Explicitly NOT remaining
Do not reopen unless regression proves otherwise:
- Lane-4 fake-green health.
- Session/Diff/Merge target-ref movement.
- LSP document URI confinement.
- Client-controlled merge target.
