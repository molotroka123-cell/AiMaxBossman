# PASS 3 implementation handoff

## Order

1. Inspect current HEAD and produce a reuse/delta map against this package.
2. Freeze one normalized cache-observation schema and golden provider fixtures.
3. Reconcile Gateway and direct Anthropic telemetry without merging incompatible payload builders.
4. Add Context Waste Detector in observe-only mode.
5. Add Cache Advisor in advisory-only mode with immutable security ordering.
6. Add dashboard panels with measured and estimated values separated.
7. Connect Autonomy Trainer candidates to existing Learning Guard and holdout protection.
8. Run same-model A/B for cognitive reuse; keep local-model path disabled until non-inferiority passes.
9. Run adversarial, staleness, concurrency, streaming, cost-accounting and rollback tests.
10. Enable by narrow feature flags, monitor, then widen gradually.

## Suggested flags

- BOSSMAN_CACHE_TELEMETRY_V2
- BOSSMAN_CONTEXT_WASTE_OBSERVE
- BOSSMAN_CACHE_ADVISOR
- BOSSMAN_AUTONOMY_TRAINER_SHADOW
- BOSSMAN_COGNITIVE_REUSE_EXPERIMENT

All default OFF except compatible numeric telemetry that has no request-content persistence.

## Definition of done

- no duplicate cache/request/learning engine;
- both provider routes emit the shared schema;
- hit/write/miss classification uses provider evidence;
- token and money accounting fixtures pass without double counting;
- no raw prompt, secret or cache content is persisted;
- security context cannot be moved or weakened by the Advisor;
- fresh state invalidates or overrides reused cognition;
- learning promotion requires independent verification and excludes holdouts;
- local-model reuse passes same-model A/B non-inferiority;
- rollback works and is documented;
- live Anthropic hit is either proven with provider usage or honestly marked unproven;
- affected regressions and secret scan pass;
- final report includes exact SHAs and evidence.
