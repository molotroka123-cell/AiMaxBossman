# Anthropic prompt-cache integration handoff

## Provider facts to encode

- Add cache_control only at stable provider-supported breakpoints.
- Default ephemeral lifetime is five minutes; use ttl: 1h only for a deliberately configured long human-in-the-loop session.
- A request containing cache_control is not proof of a cache write or hit.
- A real read is evidenced by cache_read_input_tokens greater than zero.
- A real write is evidenced by cache_creation_input_tokens greater than zero.
- Preserve the provider's exact usage fields before normalizing totals.

## Stable ordering

Keep stable content first:

1. immutable policy and safety context;
2. tool schemas;
3. stable agent role and project invariants;
4. verified architecture map;
5. dynamic task, current diff, observations and tool results.

Never reorder, omit or weaken security context to improve cache reuse.

## Dual-path architecture

AiMaxBossman currently has an OpenRouter/Gateway path and a direct Command Center Anthropic path. Do not force them into one request builder if payload contracts differ. Instead:

- keep provider shaping close to each adapter;
- share TTL validation, usage normalization where semantics match, telemetry schema, dashboard calculations and safety invariants;
- preserve cloud policy, Cost Governor reserve/call/commit-or-release, circuit breakers, provider failover, authentication and streaming byte-for-byte behavior.

## Required tests

- identical stable prefix: second live call reports read tokens;
- changed dynamic tail: stable prefix can still hit;
- changed system/tools: write or miss, never falsely classified as hit;
- 5m and 1h request shapes;
- unsupported provider and cache-disabled fail open without cache fields;
- streaming usage captured without changing streamed bytes;
- cost accounting does not double-count fresh/read/write tokens;
- cache metadata rejection retries at most once and never bypasses policy or budget;
- raw prompts, secrets and cache contents absent from telemetry.

## Live acceptance

Unit tests prove request shaping. Production readiness additionally requires two safe calls with the same sufficiently large stable prefix and provider-returned usage showing a write followed by a read. If no key or provider access exists, report LIVE_CACHE_HIT_NOT_PROVEN; do not convert a simulated hit into PASS.
