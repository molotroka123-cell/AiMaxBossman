# FINAL SPEC TEMPLATE

Executive objective
Current systems reused
Shared primitives
Module-by-module architecture/math/API/state/failure modes/tests/decision
Cross-module dataflow
Threat model
Learning integration
Metrics + hidden benchmarks
Resource economics
Rollout + rollback
IMPLEMENT_NOW
PROTOTYPE
DEFER
REJECT
Fable new mechanisms
Exact first implementation task
