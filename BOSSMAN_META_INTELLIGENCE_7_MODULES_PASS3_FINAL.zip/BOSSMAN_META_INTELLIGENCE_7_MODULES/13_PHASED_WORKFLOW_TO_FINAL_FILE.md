# SEVEN PASSES TO FINAL SPEC

PASS 1 FOUNDATION: clarify objective, shared primitives, invariants, dependencies, minimal data model. Output FOUNDATION_REVIEW.md.
PASS 2 ARCHITECTURE: component boundaries, APIs/dataflow, reuse map, flags, rollout. Output ARCHITECTURE_REVIEW.md.
PASS 3 AUDIT: security, staleness, Goodhart, cost blowups, self-validation, races, drift, eval leakage, recovery. Output ARCHITECTURE_AUDIT.md.
PASS 4 BUG/TEST: executable unit/integration/A-B/adversarial/stale/resume/resource/holdout tests. Output BENCHMARK_AND_BUG_TESTS.md.
PASS 5 OWN PROPOSALS: independent alternatives + new mechanisms + ranking. Output FABLE_META_INTELLIGENCE_PROPOSALS.md.
PASS 6 FINAL SYNTHESIS: reconcile all passes into BOSSMAN_META_INTELLIGENCE_7_FINAL_SPEC.md with IMPLEMENT_NOW / PROTOTYPE / DEFER / REJECT.
PASS 7 IMPLEMENTATION HANDOFF: exact implementation order, risks, first code targets, tests. Output IMPLEMENTATION_HANDOFF.md.

Preserve prior pass evidence rather than rewriting history.
