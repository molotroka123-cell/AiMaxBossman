# Cross-Model Knowledge Distillation

Goal: strong models leave normalized, evidence-grounded knowledge that improves weaker local models without storing hidden chain-of-thought.

Distillation unit: failure pattern→decisive observation→relevant invariant→root cause→failed strategy→successful strategy→verification recipe→generalizable lesson. Teacher/student ladder: L0 task only, L1 failure-pattern hint, L2 evidence hint, L3 invariant/boundary hint, L4 strategy hint, L5 verified reference case. Build model×task_class×failure_pattern×minimum_help_level×VerifiedSuccess×cost×latency competence-gap map. Use it for router, context compiler, weakness autopatcher, skills and future optional fine-tuning. Prevent hidden-holdout leakage.
