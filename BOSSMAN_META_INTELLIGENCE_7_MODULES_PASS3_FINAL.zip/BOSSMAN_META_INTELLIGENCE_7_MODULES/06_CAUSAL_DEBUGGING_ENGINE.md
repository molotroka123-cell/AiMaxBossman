# Causal Debugging Engine

Goal: hard bugs should be solved by proving causal chains, not correlating suspicious files.

Represent candidate chains as Event/Change A→internal state B→boundary/function C→observable D. Keep competing graphs as hypotheses until controlled interventions/evidence discriminate them. Techniques: dependency tracing, timelines, safe fault injection, differential execution, invariant checks, counterfactual tests, causal slicing and minimal reproduction. Trigger for repeated failed fixes, async/race/distributed/security classes, contradictory evidence, high severity or uncertain root cause. Avoid ceremonial causal graphs on trivial bugs. Fable must define a practical implementation and test when it adds value.
