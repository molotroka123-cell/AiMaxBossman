# PASS 3 FINAL — cumulative implementation handoff

This package preserves every Foundation file and adds the third-pass audit and implementation layer. Give only this cumulative ZIP to the implementing model together with the current AiMaxBossman repository.

The repository already contains prompt-cache work. At the inspected HEAD a2c2fd4f8281e1747018770d79adefc101daee1d, reuse and extend these paths instead of creating a second cache engine:

- bossman-core/bossman/gateway/prompt_cache.py
- bossman-core/bossman/gateway/telemetry.py
- bossman-core/tests/test_prompt_cache_openrouter.py
- command-center/bcc/providers.py
- command-center/bcc/engine.py
- command-center/tests/test_providers.py
- BOSSMAN_PROMPT_CACHE_OPUS5_DROPIN.zip

PASS 3 adds an Autonomy Trainer learning loop, Anthropic cache integration handoff, cache telemetry contract, Cache Savings & Intelligence dashboard, Cache Intelligence Advisor, Context Waste Detector, hard audit, executable prototypes, schemas and seven focused tests.

Important distinction:

- Provider prompt cache is an API optimization measured from provider usage.
- Cognitive Cache reuses verified knowledge artifacts with freshness and provenance.
- Memory preserves continuity.
- Retrieval finds relevant evidence.
- Execution Cache reuses deterministic verified tool results.

Never merge these into an untyped “smart cache.”

For local models, do not optimize credit savings. Enable cognitive reuse only when controlled A/B evidence shows equal or better VerifiedSuccess, stronger long-task continuity, or lower time/compute without intelligence loss. Fresh observation always outranks cached cognition.

Start with PASS3_IMPLEMENTATION_HANDOFF.md, then use ANTHROPIC_CACHE_PROMPT.md as the implementation prompt.
