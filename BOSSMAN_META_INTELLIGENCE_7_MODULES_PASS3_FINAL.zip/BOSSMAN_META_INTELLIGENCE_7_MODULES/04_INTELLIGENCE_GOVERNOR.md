# Intelligence Governor

Goal: meta-controller choosing model, protocol, context budget, retrieved experience, cognitive-cache reuse, weakness compensation, reasoning budget, verification strength and escalation policy.

Input: canonical TaskState, risk/policy constraints, competence profiles, resources, budget, latency target, provider health and verified outcomes. Output: typed IntelligenceDecision. Optimize P(VerifiedSuccess|state,strategy) subject to security/authority/budget/deadline/resource constraints. Costs include tokens, money, latency, VRAM/RAM, model load and opportunity cost. Track predicted vs actual outcome/cost to calibrate. Unknown classification must fail closed. Governor never bypasses Policy/Approval/Executor/Verification. Fable must challenge whether one governor, hierarchical control or another design is better and avoid a god-object.
