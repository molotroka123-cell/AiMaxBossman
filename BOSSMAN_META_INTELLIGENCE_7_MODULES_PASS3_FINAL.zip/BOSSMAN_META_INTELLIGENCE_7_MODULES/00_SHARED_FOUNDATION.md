# SHARED FOUNDATION

Do not build seven isolated products. Prefer shared typed primitives.

TaskState: task_id, objective, task_class, difficulty/risk, phase, proven_facts, hypotheses, unresolved_questions, constraints, affected_components, observations, expected_state, blockers, attempted_strategies, current_diff_ref, verification_plan_ref, freshness_epoch, next_best_action.

Evidence: id, source_type, producer, timestamp, freshness, task/run relation, content_ref, trust_class, independence_class, supports, contradicts, verification_method.

ModelCompetence: model/version, task_class, failure_pattern, sample_count, verified_success + uncertainty, minimum_help_level, common_errors, best_protocols/context profile, escalation_gain, cost/latency/resource history.

CognitiveArtifact: id, type, source_sha, environment fingerprint, dependencies, evidence refs, invalidation rules, token reconstruction cost, reuse value, author, status VERIFIED/STALE/FAILED_EXPERIMENT.

IntelligenceDecision: state_ref, model, protocol, context_budget, artifacts, weakness compensations, reasoning_budget, verification_strength, escalation_threshold, predicted_success/uncertainty/cost, concise rationale.

Fable must simplify these if a smaller abstraction provides the same power.
