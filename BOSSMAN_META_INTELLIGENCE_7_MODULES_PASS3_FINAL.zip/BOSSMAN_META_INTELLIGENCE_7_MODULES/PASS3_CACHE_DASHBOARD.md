# Cache Savings & Intelligence dashboard

The dashboard answers two separate questions: did provider caching save API input work, and did cognitive reuse improve intelligence or continuity?

## Provider economics panel

- measured hit rate and eligible-request denominator;
- cache read, cache write, fresh input and output tokens;
- actual provider cost;
- estimated fresh-input baseline, visually labelled ESTIMATE;
- measured/estimated saved amount, never mixed;
- TTL distribution, prefix stability, provider drift and miss reasons;
- cost per task, agent, model and route;
- warning when cache_control exists but no provider usage evidence was returned.

## Intelligence panel

- same-model VerifiedSuccess with reuse ON vs OFF;
- false-success rate;
- long-task resume success and time-to-resume;
- time-to-root-cause and retry count;
- compute time, tokens and model swaps;
- stale-artifact rejection rate;
- fresh-observation override count;
- promoted, rolled-back and quarantined learning candidates.

## Status colors

Green requires measured provider evidence or independently verified task success. Yellow means estimate, partial evidence or sample too small. Red means regression, stale reuse, security-context movement, false savings or promotion-rule violation.

## Anti-Goodhart rule

Cache hit rate is diagnostic, not an optimization target. A lower hit rate is correct when state changed, a fresh observation is required, or security context must remain prominent. The primary product metric is verified task success under hard security constraints.
