# PASS 3 current-repository reuse map

## Existing assets that must remain canonical

| Concern | Existing canonical path | PASS 3 action |
|---|---|---|
| OpenRouter request shaping | bossman-core/bossman/gateway/prompt_cache.py | Extend; do not replace or fork |
| Gateway cache metrics | bossman-core/bossman/gateway/telemetry.py | Add typed events/advice on top |
| OpenRouter cache tests | bossman-core/tests/test_prompt_cache_openrouter.py | Extend with live-evidence and adversarial cases |
| Direct Anthropic request shaping | command-center/bcc/providers.py | Preserve stable-prefix breakpoints and measured usage |
| Command Center cache logging | command-center/bcc/engine.py | Normalize into shared telemetry contract |
| Direct-provider tests | command-center/tests/test_providers.py | Keep cache-disabled and measured-hit tests |
| Learning promotion guard | bossman-core/bossman/learning_guard/ | Reuse for Autonomy Trainer promotion |
| Verified execution cache | bossman-core/bossman/exec_cache.py | Keep separate from cognitive and prompt cache |
| Learning traces | learning/trace.py, docs/learning/ | Store concise evidence, never hidden CoT |

## Integration rule

The Gateway and Command Center may have different provider adapters, but they must emit one normalized cache-observation contract. Request shaping can stay adapter-specific. Economics, dashboard aggregation, miss classification and safety rules should be shared.

Before editing, the implementing model must inspect current HEAD because this handoff is additive and the repository may have advanced. If a named component already exists, reconcile and extend it. Never copy a prototype over production code blindly.

## Non-duplication gate

Reject a change if it creates any of the following without proving the current implementation cannot be extended:

- second prompt-cache request shaper for the same provider path;
- second telemetry store for the same event;
- second learning-promotion mechanism outside Learning Guard;
- cache contents or prompt text persisted for metrics;
- a new security-policy layer inside the Cache Advisor.
