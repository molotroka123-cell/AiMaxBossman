# Cache telemetry contract

Telemetry contains hashes and numeric evidence only. It must never contain raw prompts, tool arguments, credentials, message text or cached content.

## Required event fields

| Field | Meaning |
|---|---|
| event_version | Schema version |
| timestamp | UTC event time |
| task_id_hash, session_id_hash | Opaque stable correlation keys |
| provider, model, route | Provider/model and Gateway or direct route |
| ttl | 5m, 1h or null |
| cache_control_applied | Request-shaping fact only |
| prefix_hash, prefix_tokens | Stability metadata, no content |
| fresh_input_tokens | Tokens neither read nor written from cache |
| cache_read_tokens | Provider-measured read tokens |
| cache_write_tokens | Provider-measured creation tokens |
| output_tokens | Completion/output tokens |
| state | HIT, WRITE, MISS, BYPASS, UNKNOWN, DEGRADED |
| miss_reason | Stable-prefix change, TTL expiry, provider drift, too short, unsupported or unknown |
| actual_cost_usd | Provider/Cost Governor measured value when available |
| baseline_cost_usd | Reconstructable counterfactual, marked estimated unless billed data proves it |
| verified_success | Independent task outcome, never inferred from cache state |
| environment_fingerprint | Scope and staleness control |
| security_context_hash | Detect security-context movement without storing it |

## Token accounting invariant

Maintain mutually exclusive normalized buckets:

total_input = fresh_input + cache_read + cache_write

If a provider's input_tokens already includes cached buckets, do not add them again. Preserve raw numeric usage separately so an adapter-specific normalizer can prove its interpretation.

## State classification

- HIT: read tokens greater than zero.
- WRITE: no read tokens and write tokens greater than zero.
- MISS: eligible request with provider usage but no read/write tokens.
- BYPASS: disabled, unsupported or deliberately ineligible.
- UNKNOWN: provider did not return enough usage evidence.
- DEGRADED: optional cache metadata failed or telemetry is partial, while the model request may still succeed.
