# AUDIT / FAILURE MODEL

Attack intelligence correctness as well as security.

Semantic state: stale fact promoted, hypothesis promoted without evidence, conflicting facts, wrong SHA, obsolete resume action.
Governor: cheap-model bias, cloud under local-only policy, calibration drift, giant-model overuse, provider unavailability, bad feedback loops.
Reasoning budget: infinite retries, no verification reserve, repeated strategy, premature stop.
Cognitive cache: branch/version collision, stale artifact, failed experiment treated as verified, secret leakage.
Weakness autopatcher: one-benchmark overfit, harmful compensation persists, wrong model version.
Distillation: holdout leakage, unverified teacher lesson, model-specific pattern treated as universal.
Causal engine: correlation labeled causation, unsafe intervention, unverified graph gains authority.

Compromised planner must not be able to label its own evidence VERIFIED. Fable must produce invariants and enablement gates per module.
