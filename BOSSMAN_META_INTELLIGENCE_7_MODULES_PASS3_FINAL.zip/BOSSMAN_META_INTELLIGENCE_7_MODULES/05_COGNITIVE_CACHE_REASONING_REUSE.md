# Cognitive Cache / Reasoning Reuse

Goal: stop paying strong models to reconstruct stable verified understanding such as architecture maps, dependency graphs, subsystem invariants, provider capability maps, failure taxonomies and benchmark interpretations.

Cache VERIFIED cognitive artifacts, not unverified final answers. Bind cache keys to repo/source SHA or compatible lineage, component/version, environment fingerprint, artifact type, dependencies, evidence and security context. Invalidate on code/dependency/config/runtime/security changes. ReuseValue≈RecomputeCostSaved×P(still_valid)×TaskRelevance−StaleRisk−RetrievalCost. Progressive disclosure: tiny summary→structured map→evidence/source slices→recompute. Never cache secrets; stale cognition never overrides fresh observation. Fable must distinguish this from prompt caching, memory and retrieval.
