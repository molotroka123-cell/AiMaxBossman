# Reasoning Budget Allocator

Goal: dynamically allocate reasoning, retries, hypotheses, context expansion and escalation only when expected marginal verified value is positive.

Core decision: EV(a|s)=P(improvement|a,s)*Value(success)-TokenCost-LatencyCost-ComputeCost-OpportunityCost-Risk. Use risk-sensitive CVaR for severe tasks. Difficulty must use task class, ambiguity, failed attempts, evidence conflict, verifier confidence, historical model competence and impact—not prompt length. A retry must introduce new evidence, context, protocol, model, hypothesis or verifier. Reserve enough budget for verification, learning trace, commit and push. Fable must compare VOI, sequential tests, bandits or a simpler practical approximation and benchmark them.
