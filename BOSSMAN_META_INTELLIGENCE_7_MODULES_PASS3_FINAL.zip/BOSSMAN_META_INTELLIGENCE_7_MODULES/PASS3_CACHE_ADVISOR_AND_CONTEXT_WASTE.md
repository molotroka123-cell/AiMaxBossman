# Cache Intelligence Advisor and Context Waste Detector

## Advisor scope

The Advisor produces recommendations only. It may suggest stable/dynamic separation, TTL changes, artifact invalidation, progressive disclosure or a same-model A/B experiment. It cannot edit policy, reorder security context, enable cloud access, increase budget, promote learning or mark evidence verified.

Every recommendation contains:

- evidence window and sample size;
- affected model/task class/route;
- predicted benefit and uncertainty;
- security and staleness check;
- experiment and rollback plan;
- explicit NO_ACTION when evidence is weak.

## Context Waste Detector signals

- stable prefix hash changes without a semantic reason;
- timestamps, current diff or tool results placed before stable context;
- repeated retrieval of the same verified artifact in full;
- cached artifact loaded but unused by the task;
- giant context while verifier confidence does not improve;
- repeated strategy with no new evidence;
- duplicate system/tool schemas across layers;
- security-sensitive or live state proposed for caching;
- local-model reuse that reduces compute but also reduces VerifiedSuccess;
- cache misses caused by provider/session drift.

## Safe actions

Safe automatic actions are limited to logging, metric aggregation and running an already-approved experiment in an isolated evaluation scope. Production prompt reordering, TTL changes, cache invalidation rules and learning promotion require the existing approval/policy path.
