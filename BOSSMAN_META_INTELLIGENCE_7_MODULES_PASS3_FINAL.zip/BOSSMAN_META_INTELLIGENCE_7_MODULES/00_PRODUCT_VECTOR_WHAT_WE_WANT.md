# PRODUCT VECTOR — WHAT WE WANT

Bossman should become an intelligence operating layer around local/cloud models, not a pile of prompts. A raw model has limited context, session loss, blind spots, overconfidence, first-hypothesis anchoring, repeated rediscovery and inefficient compute. Bossman must compensate without pretending the underlying weights changed.

Desired flow:
TASK→canonical structured state→Intelligence Governor→model weakness compensation→verified cognitive reuse/context→reasoning budget→model/protocol→causal reasoning when needed→typed action→policy/scopes→approval→executor→fresh observation→verification→learning trace→cross-model distillation→updated competence map.

The central question becomes: what combination of model + state + evidence + context + protocol + compute + verifier maximizes probability of verified success under security, budget, latency and resource constraints?

Primary objectives: maximize VerifiedSuccess, IntelligenceRetention, evidence quality, reuse, local autonomy and recovery; minimize tokens/API spend, rediscovery, stale-context errors, false success, unnecessary escalation, model swaps, latency and duplication. Security and owner authority are hard constraints.

Desired empirical end state: Bossman can say which model/task combination succeeds unaided, which hint/skill raises success, what escalation gain is measured, and which route is the cheapest one satisfying the task risk threshold.
