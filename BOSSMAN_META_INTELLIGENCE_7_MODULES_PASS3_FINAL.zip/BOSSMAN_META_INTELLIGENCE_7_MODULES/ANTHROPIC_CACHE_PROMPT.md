# Claude/Fable implementation prompt — PASS 3

Continue from CURRENT REMOTE HEAD of molotroka123-cell/AiMaxBossman. This ZIP is a cumulative implementation handoff, not a separate project.

First inspect the existing prompt-cache, telemetry, direct Anthropic adapter, Cost Governor, cloud policy, streaming, Learning Guard, execution cache and Command Center dashboard. Extend the current architecture; do not create duplicate cache engines or overwrite newer code with prototypes from this package.

Implement the smallest coherent PASS 3 slice:

1. one normalized cache-observation schema used by Gateway and direct Anthropic paths;
2. provider-evidence classification using cache read/write token fields;
3. Cache Savings & Intelligence dashboard with measured/estimated values clearly separated;
4. Context Waste Detector and advisory-only Cache Intelligence Advisor;
5. Autonomy Trainer candidate/promotion loop through the existing Learning Guard;
6. local-model cognitive reuse gated by A/B VerifiedSuccess, continuity and compute/time impact;
7. hard security/staleness/Goodhart tests and rollback flags.

Hard rules:

- cache_control alone never means HIT or WRITE;
- cache_read_input_tokens greater than zero means measured read;
- cache_creation_input_tokens greater than zero means measured write;
- five minutes is default, one hour is explicit configuration;
- never persist raw prompt/cache contents or secrets for telemetry;
- never cache unverified final answers as authoritative cognition;
- never let cached state override fresh observation;
- never move or weaken security context for hit rate;
- planner cannot verify or promote its own learning candidate;
- holdouts never enter training or cache-advice learning.

Run targeted tests first, then affected full regressions, compile checks, secret scan and ZIP/schema validation where relevant. Produce exact pass/fail counts, changed files, live evidence status, remaining gaps, final local SHA and remote SHA. Commit in small logical units and push without force only if all required gates pass.
