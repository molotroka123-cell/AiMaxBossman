# Model Weakness Autopatcher

Goal: compensate model-specific recurring weaknesses before the attempt instead of demanding universal competence.

Inputs: model/version competence profile, task class, failure pattern, context pressure, tool requirements and risk. Examples: async weakness→lifecycle trace + verified case; security weakness→boundary invariants + adversarial checklist; long-context degradation→compress/reorder; weak coding but strong triage→restrict role; tool hallucination→stronger schemas + verifier. Compensations must be empirically learned with sample/confidence thresholds, never one-benchmark stereotypes. Same-model baseline vs compensation A/B must measure VerifiedSuccess, token cost, latency and new failure modes. Fable must design adaptation, rollback, drift handling and anti-overfit gates.
