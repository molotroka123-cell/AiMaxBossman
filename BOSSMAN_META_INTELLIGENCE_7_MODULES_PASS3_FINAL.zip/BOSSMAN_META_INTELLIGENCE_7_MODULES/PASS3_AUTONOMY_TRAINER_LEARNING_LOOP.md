# Autonomy Trainer learning loop

## Objective

Turn verified task outcomes into safe, reversible improvements to routing, context selection, skills, cache policy and model-specific compensation. The trainer does not change model weights by default and never grants authority.

## Loop

1. Observe a task episode with immutable task/run/model/environment identifiers.
2. Record objective metrics: verified success, verifier identity, cost, latency, retries, context size, cache evidence, failure pattern and recovery.
3. Form a concise engineering hypothesis, not hidden chain-of-thought.
4. Generate a candidate intervention: hint, context slice, skill, route, budget, cache rule or verification rule.
5. Run same-model A/B on eligible tasks. Keep hidden holdouts excluded from learning.
6. Require minimum sample count, independent verification and no security regression.
7. Promote behind a feature flag with scope, model version, task class and environment fingerprint.
8. Monitor drift and automatically disable on regression.
9. Write an evidence-grounded learning trace including rejected hypotheses.

## Promotion gate

A candidate is promotable only if all are true:

- at least three independent verified episodes, with a higher threshold for risky domains;
- VerifiedSuccess is non-inferior and the target metric improves;
- false-success and security-regression rates do not increase;
- the verifier is independent from the proposing planner;
- no holdout episode or secret benchmark content entered training;
- model version, task class and environment scope are explicit;
- rollback is executable and tested.

## Cache-specific learning

The trainer may learn stable-prefix structure, TTL choice and when cognitive reuse helps. It may not learn to move policy/security content to increase hit rate, cache unverified answers, suppress fresh observation, or claim savings without provider evidence.

## Local-model objective

For local models, optimize:

VerifiedSuccess + continuity gain + recovery gain - compute/time cost - stale-risk

Do not use API-dollar savings as the objective when no API billing exists.
