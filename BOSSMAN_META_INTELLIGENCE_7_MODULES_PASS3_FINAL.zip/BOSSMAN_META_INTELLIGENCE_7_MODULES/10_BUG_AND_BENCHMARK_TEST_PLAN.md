# BUG / BENCHMARK PLAN

Benchmark families: simple fast-path tasks; hidden variants of known coding bugs; async lifecycle; security boundaries; interrupted long-horizon resume; 8k/16k/32k context stress; stale cognitive-cache invalidation; L0→L5 student teaching; fixed-model vs Governor routing; budget exhaustion with mandatory verification/checkpoint reserve.

Metrics: VerifiedSuccess, FalseSuccessRate, IntelligenceRetention, tokens, API cost, latency, VRAM, model swaps, retries, time-to-root-cause, verification completeness, resume success. Use same-model A/B where possible. Promotion requires no security regression, hidden holdout, independent verification and rollback.
