# MORNING COMPLETION CHECKLIST

- Foundation review
- Architecture review
- Architecture audit
- Bug/benchmark plan
- Fable proposals
- Final reconciled spec
- Implementation handoff
- Learning schema
- Rankings and dependencies
- Security invariants
- Token/API/GPU economics
- Hidden eval + rollback
- No fake green
- No hidden CoT storage
