from decimal import Decimal

from prototypes.pass3_intelligence import (
    AdvisorInput,
    CognitiveReuseOutcome,
    LearningEpisode,
    allow_local_cognitive_reuse,
    cache_advice,
    classify_cache_evidence,
    counterfactual_cost,
    normalize_anthropic_usage,
    promotable,
)


def test_cache_control_is_not_hit_evidence():
    assert classify_cache_evidence(
        eligible=True,
        cache_control_applied=True,
        read_tokens=0,
        write_tokens=0,
    ) == "MISS"


def test_read_and_write_provider_evidence_are_distinct():
    assert classify_cache_evidence(
        eligible=True,
        cache_control_applied=True,
        read_tokens=900,
        write_tokens=0,
    ) == "HIT"
    assert classify_cache_evidence(
        eligible=True,
        cache_control_applied=True,
        read_tokens=0,
        write_tokens=900,
    ) == "WRITE"


def test_missing_usage_is_unknown_not_fake_miss_or_hit():
    assert classify_cache_evidence(
        eligible=True,
        cache_control_applied=True,
        read_tokens=None,
        write_tokens=None,
        usage_present=False,
    ) == "UNKNOWN"


def test_token_buckets_and_cost_do_not_double_count():
    tokens = normalize_anthropic_usage(
        input_tokens=100,
        cache_read_input_tokens=900,
        cache_creation_input_tokens=0,
        output_tokens=50,
    )
    assert tokens.total_input == 1000
    actual, baseline = counterfactual_cost(
        tokens=tokens,
        fresh_price_per_million=Decimal("5"),
        read_price_per_million=Decimal("0.5"),
        write_price_per_million=Decimal("6.25"),
        output_price_per_million=Decimal("25"),
    )
    assert actual == Decimal("0.0022")
    assert baseline == Decimal("0.00625")


def test_local_reuse_requires_intelligence_noninferiority_and_benefit():
    good = CognitiveReuseOutcome(
        .91, .90, continuity_delta=.2, compute_delta=-.1
    )
    bad = CognitiveReuseOutcome(
        .80, .90, continuity_delta=.4, compute_delta=-.5
    )
    stale = CognitiveReuseOutcome(
        .91,
        .90,
        continuity_delta=.2,
        compute_delta=-.1,
        stale_error_delta=.01,
    )
    assert allow_local_cognitive_reuse(good)
    assert not allow_local_cognitive_reuse(bad)
    assert not allow_local_cognitive_reuse(stale)


def test_advisor_blocks_security_reordering_and_small_samples():
    assert cache_advice(
        AdvisorInput(.9, .9, 100, security_context_moved=True)
    )[0].startswith("BLOCK")
    assert cache_advice(
        AdvisorInput(.1, .0, 3)
    ) == ("NO_ACTION: insufficient evidence",)


def test_learning_promotion_requires_verified_scoped_non_holdout_episodes():
    good = [
        LearningEpisode(True, True, environment_fingerprint="env-a")
        for _ in range(3)
    ]
    assert promotable(good)
    assert not promotable(good[:2])
    assert not promotable(
        good[:2]
        + [
            LearningEpisode(
                True,
                True,
                holdout=True,
                environment_fingerprint="env-a",
            )
        ]
    )
    assert not promotable(
        good[:2]
        + [
            LearningEpisode(
                True,
                False,
                environment_fingerprint="env-a",
            )
        ]
    )
    assert not promotable(
        good[:2]
        + [
            LearningEpisode(
                True,
                True,
                environment_fingerprint="env-b",
            )
        ]
    )
