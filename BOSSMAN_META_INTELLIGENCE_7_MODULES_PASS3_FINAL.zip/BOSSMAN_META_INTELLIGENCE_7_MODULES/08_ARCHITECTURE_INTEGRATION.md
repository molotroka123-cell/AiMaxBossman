# TARGET ARCHITECTURE

Task→Task Classifier→Semantic State Machine→Intelligence Governor, consulting competence profile, Weakness Autopatcher, Cognitive Cache/Experience Retrieval, Context Compiler, Reasoning Budget Allocator and Router→model/protocol execution→normal/hypothesis/causal path→Typed Action→Policy/Scope/Approval→Executor→Fresh Observation→Independent Verification→state transition→Learning Trace→Cross-Model Distillation→competence update→future Governor improves.

Principles: fast path remains fast; hard reasoning activates adaptively; fresh observation beats cached cognition; verified history beats confidence; security boundaries remain outside Governor; adaptive policies require telemetry/rollback; experiments feature-gated; reuse existing Bossman engines.

Fable must explicitly find unnecessary layers, missing loops, circular dependencies, token explosions, stale risks, authority leaks and duplicated systems, then propose the architecture it would actually ship.
