"""Executable PASS 3 reference logic, not a production drop-in.

Production integration must extend the existing AiMaxBossman Gateway,
telemetry and Learning Guard rather than copy this module wholesale.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable


CACHE_STATES = {"HIT", "WRITE", "MISS", "BYPASS", "UNKNOWN", "DEGRADED"}


def classify_cache_evidence(
    *,
    eligible: bool,
    cache_control_applied: bool,
    read_tokens: int | None,
    write_tokens: int | None,
    usage_present: bool = True,
) -> str:
    """Classify provider evidence; cache_control is never proof of a hit."""
    del cache_control_applied
    if not eligible:
        return "BYPASS"
    if not usage_present or read_tokens is None or write_tokens is None:
        return "UNKNOWN"
    if max(0, int(read_tokens)) > 0:
        return "HIT"
    if max(0, int(write_tokens)) > 0:
        return "WRITE"
    return "MISS"


@dataclass(frozen=True, slots=True)
class TokenBuckets:
    fresh_input: int
    cache_read: int
    cache_write: int
    output: int

    @property
    def total_input(self) -> int:
        return self.fresh_input + self.cache_read + self.cache_write


def normalize_anthropic_usage(
    *,
    input_tokens: int,
    cache_read_input_tokens: int = 0,
    cache_creation_input_tokens: int = 0,
    output_tokens: int = 0,
) -> TokenBuckets:
    """Keep Anthropic input_tokens as the uncached/fresh bucket."""
    values = [
        input_tokens,
        cache_read_input_tokens,
        cache_creation_input_tokens,
        output_tokens,
    ]
    if any(int(value) < 0 for value in values):
        raise ValueError("token counts must be non-negative")
    return TokenBuckets(*(int(value) for value in values))


def counterfactual_cost(
    *,
    tokens: TokenBuckets,
    fresh_price_per_million: Decimal,
    read_price_per_million: Decimal,
    write_price_per_million: Decimal,
    output_price_per_million: Decimal,
) -> tuple[Decimal, Decimal]:
    """Return actual and all-fresh baseline; label baseline estimated."""
    million = Decimal(1_000_000)
    actual = (
        Decimal(tokens.fresh_input) * fresh_price_per_million
        + Decimal(tokens.cache_read) * read_price_per_million
        + Decimal(tokens.cache_write) * write_price_per_million
        + Decimal(tokens.output) * output_price_per_million
    ) / million
    baseline = (
        Decimal(tokens.total_input) * fresh_price_per_million
        + Decimal(tokens.output) * output_price_per_million
    ) / million
    return actual, baseline


@dataclass(frozen=True, slots=True)
class CognitiveReuseOutcome:
    verified_success_on: float
    verified_success_off: float
    continuity_delta: float
    compute_delta: float
    stale_error_delta: float = 0.0


def allow_local_cognitive_reuse(
    outcome: CognitiveReuseOutcome,
    *,
    noninferiority_margin: float = 0.0,
) -> bool:
    """Local reuse needs intelligence non-inferiority and a real benefit."""
    success_ok = (
        outcome.verified_success_on + noninferiority_margin
        >= outcome.verified_success_off
    )
    stale_ok = outcome.stale_error_delta <= 0
    useful = outcome.continuity_delta > 0 or outcome.compute_delta < 0
    return bool(success_ok and stale_ok and useful)


@dataclass(frozen=True, slots=True)
class AdvisorInput:
    prefix_stability: float
    hit_rate: float
    sample_count: int
    security_context_moved: bool = False


def cache_advice(signal: AdvisorInput) -> tuple[str, ...]:
    """Advisory-only output with a hard security-context invariant."""
    if signal.security_context_moved:
        return ("BLOCK: restore immutable security-context order",)
    if signal.sample_count < 20:
        return ("NO_ACTION: insufficient evidence",)
    advice: list[str] = []
    if signal.prefix_stability < 0.8:
        advice.append(
            "EXPERIMENT: move non-security dynamic fields after stable prefix"
        )
    if signal.hit_rate < 0.2 and signal.prefix_stability >= 0.8:
        advice.append(
            "CHECK: TTL expiry, provider drift and minimum cacheable size"
        )
    return tuple(
        advice or ["NO_ACTION: cache behavior is within observed bounds"]
    )


@dataclass(frozen=True, slots=True)
class LearningEpisode:
    verified_success: bool
    independent_verifier: bool
    holdout: bool = False
    security_regression: bool = False
    environment_fingerprint: str = ""


def promotable(
    episodes: Iterable[LearningEpisode],
    *,
    min_samples: int = 3,
) -> bool:
    rows = tuple(episodes)
    if len(rows) < min_samples or not rows:
        return False
    environments = {row.environment_fingerprint for row in rows}
    return bool(
        len(environments) == 1
        and all(row.verified_success for row in rows)
        and all(row.independent_verifier for row in rows)
        and not any(
            row.holdout or row.security_regression for row in rows
        )
    )
