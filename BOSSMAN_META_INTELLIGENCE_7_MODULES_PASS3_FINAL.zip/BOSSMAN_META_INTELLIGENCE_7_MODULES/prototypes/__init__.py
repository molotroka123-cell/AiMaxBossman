"""PASS 3 executable reference prototypes."""
