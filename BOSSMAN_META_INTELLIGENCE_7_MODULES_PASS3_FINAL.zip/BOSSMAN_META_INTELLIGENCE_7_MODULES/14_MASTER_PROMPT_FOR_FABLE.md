# MASTER PROMPT FOR FABLE

Read this ZIP once as the foundation for the next Bossman meta-intelligence layer. Selected modules: Reasoning Budget Allocator, Semantic State Machine, Cross-Model Knowledge Distillation, Intelligence Governor, Cognitive Cache/Reasoning Reuse, Causal Debugging Engine, Model Weakness Autopatcher.

Mission: not blindly implement seven modules. Understand the vector: make weaker/local models systematically more capable by supplying the right verified state, knowledge, compensation, compute and verification at the right time. Challenge design, simplify shared abstractions, improve math, find missing feedback loops, token/API/GPU waste, stale-state and Goodhart risks, and fake-intelligence patterns.

All adaptation remains subordinate to Policy→Approval→Executor→fresh observation→Verification. No hidden CoT storage. Log concise engineering hypotheses, evidence, failures, decisions and transferable lessons.

Work order: PASS 1 FOUNDATION→PASS 2 ARCHITECTURE→PASS 3 AUDIT→PASS 4 BUG/BENCHMARK TESTS→PASS 5 YOUR OWN PROPOSALS→PASS 6 FINAL SYNTHESIS→PASS 7 IMPLEMENTATION HANDOFF.

For every module classify IMPLEMENT_NOW / PROTOTYPE / DEFER / REJECT. In PASS 5 add at least 10 new meta-intelligence mechanisms. Final spec must include goals/non-goals, component boundaries, typed objects, algorithms/equations, persistence/invalidation, security, benchmarks, failure handling, observability, rollout/rollback, token/latency/compute impact, dependencies and learning integration. Prefer evidence/tests over essays.
