# PASS 3 hard audit

| Risk | Failure | Required control | Enablement gate |
|---|---|---|---|
| Stale cached authority | Old architecture/state drives a current action | SHA, dependency and environment binding; fresh observation wins | Stale-invalidation adversarial tests pass |
| Prompt-injection retention | Malicious retrieved text becomes reusable authority | Trust class, provenance, quarantine, no unverified promotion | Injection corpus cannot reach VERIFIED |
| Wrong-window replay | Artifact from another repo/branch/session is reused | Namespace plus source lineage and environment fingerprint | Cross-branch/repo collision tests pass |
| Fake savings | Tokens counted twice or cache_control treated as a hit | Mutually exclusive buckets; provider usage evidence | Golden usage fixtures and live write-to-read proof |
| Self-training on bad output | Planner promotes its own answer | Independent verifier; minimum samples; holdout exclusion | Promotion tests and audit log pass |
| GUI overfit | Skill works only on one resolution/layout | Multi-layout evaluation and visual-state freshness | Holdout layouts pass before promotion |
| Security-context reordering | Advisor moves policy to improve hit rate | Immutable security order/hash; advisory-only role | Mutation attempt is blocked and logged |
| Cache poisoning race | Concurrent writers promote conflicting artifacts | Atomic versioned writes and compare-and-swap | Race/failure-injection tests pass |
| Infinite reuse loop | Cached plan repeatedly fails without new evidence | Retry novelty invariant; stale mark after failure | Repeated-strategy test terminates safely |
| Goodhart hit-rate bias | System avoids needed fresh checks | VerifiedSuccess primary; hit rate diagnostic only | Fresh-state benchmark shows no regression |
| Holdout leakage | Hidden eval enters learning/retrieval | Sealed IDs; defense-in-depth filters | Canary and secret-holdout tests pass |
| Cost Governor bypass | Cache retry creates unreserved calls | Reserve every attempt and commit/release exactly once | Failure-path accounting test passes |
| Streaming corruption | Usage collector changes bytes/order | Observe-only collector; byte equality test | Golden SSE stream identical |
| Secret leakage | Prefix or prompt content stored in metrics | hashes/numbers only; redaction and secret scan | No raw-content fields; scan passes |

## PASS 3 verdict

The architecture is viable only as an evidence-and-control layer. It becomes dangerous if caching is allowed to confer authority, if the planner self-verifies, or if cost metrics are optimized independently of verified success. All adaptive behavior must remain feature-gated, scoped, observable and reversible.
