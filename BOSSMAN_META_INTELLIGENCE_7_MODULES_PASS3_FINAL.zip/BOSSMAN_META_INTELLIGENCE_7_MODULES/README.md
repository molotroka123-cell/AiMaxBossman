# BOSSMAN META-INTELLIGENCE — 7 MODULES

Foundation pack for seven selected modules: Reasoning Budget Allocator, Semantic State Machine, Cross-Model Knowledge Distillation, Intelligence Governor, Cognitive Cache/Reasoning Reuse, Causal Debugging Engine, Model Weakness Autopatcher.

Read 00_PRODUCT_VECTOR_WHAT_WE_WANT.md first and 14_MASTER_PROMPT_FOR_FABLE.md as execution entry point.
