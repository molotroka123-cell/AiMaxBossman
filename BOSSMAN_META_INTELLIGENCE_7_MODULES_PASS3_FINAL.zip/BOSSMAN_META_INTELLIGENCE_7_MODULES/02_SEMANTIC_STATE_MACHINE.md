# Semantic State Machine

Goal: move continuity from chat text into typed semantic state.

Canonical states: NEW→SCOPED→REPRODUCED→HYPOTHESES_ACTIVE→ROOT_CAUSE_PROVEN→FIX_IN_PROGRESS→FOCUSED_VERIFIED→ADVERSARIAL_VERIFIED→REGRESSION_VERIFIED→LEARNING_RECORDED→COMMITTED→PUSHED→DONE, with BLOCKED_ENV / INSUFFICIENT_EVIDENCE / FAILED_EXPERIMENT / ROLLBACK_REQUIRED. Facts must be PROVEN / OBSERVED / INFERRED / HYPOTHESIS / REFUTED / STALE and carry provenance/freshness. HEAD/runtime/config changes invalidate dependent facts. A new model should resume from objective, canonical state, proven facts, open hypotheses, blockers, last verified SHA and exact next action—not hours of chat. Fable must reuse EventBus/Flight Recorder/Memory rather than duplicate.
