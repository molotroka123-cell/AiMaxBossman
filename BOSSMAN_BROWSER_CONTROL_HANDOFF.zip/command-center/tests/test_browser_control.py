from bcc.browser_control import BrowserPolicy, DEFAULT_RULES

def test_browser_policy_defaults():
    p = BrowserPolicy.from_dict({})
    assert p.decision("navigate", url="https://example.com") == "auto"
    assert p.decision("screenshot") == "auto"
    assert p.decision("login", url="https://example.com/login") == "ask"
    assert p.decision("payment", url="https://example.com/pay") == "deny"

def test_blocked_domain_wins():
    p = BrowserPolicy.from_dict({
        "allowed_domains": ["*.example.com"],
        "blocked_domains": ["bank.example.com"],
    })
    assert p.domain_allowed("https://app.example.com/x")
    assert not p.domain_allowed("https://bank.example.com/x")
    assert p.decision("navigate", url="https://bank.example.com/x") == "deny"

def test_allow_list():
    p = BrowserPolicy.from_dict({"allowed_domains": ["github.com", "*.google.com"]})
    assert p.domain_allowed("https://github.com/foo")
    assert p.domain_allowed("https://maps.google.com/")
    assert not p.domain_allowed("https://evil.example/")

def test_rule_override():
    p = BrowserPolicy.from_dict({"rules": {"click": "ask", "type": "deny"}})
    assert p.decision("click", url="https://example.com") == "ask"
    assert p.decision("type", url="https://example.com") == "deny"
    assert p.decision("purchase", url="https://example.com") == "deny"
