# BOSSMAN Browser Control Handoff Package

Prepared for `AiMaxBossman` to reduce Claude Code/Fable token usage.

Contents:

- `command-center/bcc/browser_control.py` — Playwright runtime + policy engine
- `command-center/tests/test_browser_control.py` — policy tests
- `command-center/ui/browser-control.html` — standalone debug/live-control UI
- `docs/CLAUDE_BROWSER_CONTROL_HANDOFF.md` — exact integration plan and decisions
- `docs/INTEGRATION_SNIPPETS.md` — minimal code snippets for current API/DB

Important: the GitHub connector available to ChatGPT in this session has READ access
but returned HTTP 403 on both branch creation and file writes. Therefore this package
could not be pushed automatically. No repository state was modified.
