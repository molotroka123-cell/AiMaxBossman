#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
cd "$ROOT/bossman-core"
python -m compileall -q bossman/gateway tests/test_gateway_stage3.py tests/test_gateway_router_stage3.py
pytest -q tests/test_gateway_stage3.py tests/test_gateway_router_stage3.py
