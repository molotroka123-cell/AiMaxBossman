#!/usr/bin/env python3
from __future__ import annotations
import shutil, sys
from pathlib import Path

HANDOFF = Path(__file__).resolve().parents[1]

def copytree(src: Path, dst: Path):
    if not src.exists():
        raise SystemExit(f"missing handoff path: {src}")
    dst.mkdir(parents=True, exist_ok=True)
    for p in src.rglob("*"):
        if p.is_dir(): continue
        rel=p.relative_to(src); target=dst/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,target)

def main():
    if len(sys.argv)!=2:
        raise SystemExit("usage: apply_stage_3.py /path/to/AiMaxBossman")
    repo=Path(sys.argv[1]).resolve(); core=repo/"bossman-core"
    if not (core/"bossman").exists():
        raise SystemExit("bossman-core/bossman not found")
    copytree(HANDOFF/"code/bossman-core/bossman/gateway", core/"bossman/gateway")
    for test in (HANDOFF/"code/bossman-core/tests").glob("test_gateway*stage3.py"):
        shutil.copy2(test, core/"tests"/test.name)
    copytree(HANDOFF/"docs/stage-3", repo/"docs/stage-3")
    ex=HANDOFF/"config/gateway.example.yaml"
    (repo/"config").mkdir(exist_ok=True); shutil.copy2(ex,repo/"config/gateway.example.yaml")
    print("Stage 3 source copied. Claude must adapt pyproject + llm lifecycle after inspecting current repo. No secrets were created.")

if __name__=="__main__": main()
