# Claude Code — ЭТАП 3

This archive contains Stage 1, Stage 2.222 and a complete Stage 3 gateway implementation. Do not rewrite it from scratch.

Order:

1. Inspect actual current repo and git state.
2. Read `docs/stage-3/ЭТАП_3_AI_GATEWAY_MODEL_ROUTER.md`.
3. Read Stage 3 source and tests.
4. Apply/copy Stage 3.
5. Adapt dependency/script entries in the actual `pyproject.toml`.
6. Run Stage 3 tests in isolation.
7. Integrate existing `bossman/llm.py` through the gateway behind a compatibility adapter.
8. Integrate Stage 2.222 embeddings and Stage 1 vision aliases where technically compatible.
9. Run all old tests. Fix regressions, do not suppress them.
10. Test shutdown and no orphan HTTP clients.
11. Run repository hygiene/secret scan.
12. Create Stage 3 audit.

Never commit real keys. Never expose Gateway publicly. Never claim iPhone security is complete in Stage 3: this stage only builds the secure local gateway foundation.
