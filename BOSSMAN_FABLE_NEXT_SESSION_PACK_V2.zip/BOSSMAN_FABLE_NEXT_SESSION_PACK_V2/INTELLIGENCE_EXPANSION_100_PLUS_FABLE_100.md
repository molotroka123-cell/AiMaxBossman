
# BOSSMAN — Intelligence Expansion Overlay v2
## Owner proposals + Fable independent invention + verified learning capture

This overlay is mandatory for BOTH the remediation/Deep-Fix/AI-Company pack and the Model Intelligence pack.

The owner has supplied 10 core intelligence mechanisms. For EACH core mechanism there are now 10 additional candidate extensions below (100 owner-proposed extensions total).

These are CANDIDATES, not mandatory features.

Fable must:
1. Use its own broad engineering/model-systems knowledge, not merely echo this document.
2. Critique every core mechanism and its 10 extensions.
3. For EACH core mechanism invent 10 additional Fable-originated extensions (100 additional ideas).
4. Deduplicate overlapping ideas.
5. Identify interactions, contradictions and shared primitives.
6. Score and rank candidates.
7. Decide IMPLEMENT_NOW / PROTOTYPE / DEFER / REJECT.
8. Implement only the highest-value evidence-backed subset that fits the current roadmap, security gates and session budget.
9. Never sacrifice unresolved V2 security freeze blockers for speculative intelligence work.
10. Log ALL evaluated ideas, including rejected ones, in a structured learning corpus for future local models.

## Global decision model

Do not blindly use one scalar, but calculate a decision aid:

`EVI = ΔVerifiedSuccess * Confidence * Reuse * Coverage`
`Cost = TokenCost + APIcost + LatencyCost + ComputeCost + EngineeringCost`
`Risk = SecurityRisk + RegressionRisk + GoodhartRisk + ComplexityRisk`
`PriorityAid = EVI / max(epsilon, Cost) - RiskPenalty`

Also produce Pareto analysis across:
- VerifiedSuccess
- IntelligenceRetention
- security
- token/API cost
- latency
- VRAM/RAM
- implementation complexity
- maintainability
- false-success/tail risk.

Use measured estimates when available; label guesses explicitly.

## Mandatory learning log for ideas

For every candidate idea, log:
IDEA_ID
PARENT_MECHANISM
AUTHOR_SOURCE = OWNER | FABLE
SUMMARY
PROBLEM
HYPOTHESIS
EXPECTED_BENEFIT
EXPECTED_COST
SECURITY_RISK
GOODHART_RISK
DEPENDENCIES
OVERLAPS
BENCHMARK
BASELINE
DECISION
DECISION_EVIDENCE
IMPLEMENTATION_STATUS
RESULT
VERIFICATION
LESSONS
TEACH_LOCAL_MODEL
CONFIDENCE
LIMITATIONS

Do not store hidden chain-of-thought. Store concise decision rationale, tested hypotheses, evidence and transferable lessons.

Recommended:
`docs/learning/intelligence_ideas/<IDEA_ID>.md`
`data/learning/intelligence_ideas.jsonl`

Rejected/deferred ideas remain useful training material but MUST be labeled and must not be retrieved as preferred production behavior.


# 100 OWNER-PROPOSED EXTENSIONS


## Mechanism 1: Experience Retrieval Engine

1.1 **Hybrid retrieval combining semantic embeddings, lexical/BM25, code-path and symbol-graph similarity.**

1.2 **MMR/diversity selection so retrieved cases cover distinct failure modes instead of near-duplicates.**

1.3 **Temporal decay with exception for timeless invariants; distinguish stale implementation details from durable lessons.**

1.4 **Negative retrieval: deliberately fetch VERIFIED counterexamples and FAILED_EXPERIMENT warnings when similar failure patterns exist.**

1.5 **Query decomposition: retrieve separately for symptom, component, invariant, test failure and security boundary, then fuse.**

1.6 **Token-aware case compression with progressive disclosure: summary first, deeper evidence only if uncertainty remains.**

1.7 **Retrieval confidence gate: if similarity/evidence is weak, inject no authoritative case rather than misleading context.**

1.8 **Cross-model usefulness scoring: learn which cases actually improve each local model/task class.**

1.9 **Case lineage/versioning: invalidate or down-rank lessons when relevant code architecture changes.**

1.10 **Retrieval outcome feedback: measure whether each injected case changed success and update ranking weights.**


### Fable mandatory response for Mechanism 1
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Experience Retrieval Engine.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 2: Reasoning Compiler

2.1 **Composable micro-protocols instead of monolithic workflows; assemble reproduce/security/recovery/research modules as needed.**

2.2 **Difficulty estimator selects protocol depth and avoids expensive reasoning on trivial tasks.**

2.3 **Protocol early-exit rules when decisive evidence appears.**

2.4 **Protocol switching when observations contradict the current reasoning strategy.**

2.5 **Constraint compiler turns owner/security invariants into explicit machine-checkable gates before reasoning starts.**

2.6 **Plan linting detects missing verification, circular dependencies and unauthorized effects before execution.**

2.7 **Domain adapters for coding, security, research, operations, data analysis and business objectives.**

2.8 **Protocol outcome telemetry learns which steps add value versus ceremonial token waste.**

2.9 **Protocol mutation sandbox proposes shorter/better workflows and tests them on hidden evals.**

2.10 **Failure-specific recovery protocols automatically selected from verified historical failure signatures.**


### Fable mandatory response for Mechanism 2
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Reasoning Compiler.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 3: Hypothesis Tournament

3.1 **Evidence-disagreement generator: explicitly seek observations that distinguish top hypotheses.**

3.2 **Bayesian posterior updates calibrated from historical root-cause frequencies rather than prose confidence.**

3.3 **Cheap-test-first scheduling using information gain per second/token.**

3.4 **Contrarian hypothesis slot reserved for a structurally different explanation to reduce anchoring.**

3.5 **Dependency-aware hypotheses distinguish root cause from downstream symptoms.**

3.6 **Automatic hypothesis merging when candidates are semantically equivalent.**

3.7 **Stop rule based on posterior margin plus verification sufficiency rather than fixed K tests.**

3.8 **Historical prior conditioning by component, error class, recent commits and environment.**

3.9 **Multi-agent hypothesis generation only when expected diversity benefit exceeds cost.**

3.10 **Postmortem calibration: compare predicted hypothesis probabilities with eventual verified root causes.**


### Fable mandatory response for Mechanism 3
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Hypothesis Tournament.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 4: Verifier-First Development

4.1 **Verification plan generated before patch and hashed/bound to the task to prevent goalpost movement.**

4.2 **Evidence hierarchy: deterministic state/tool observation > independent implementation > model judgment.**

4.3 **Two-channel verification for high-risk actions using independent evidence sources.**

4.4 **Freshness TTL on observations so stale evidence cannot certify success.**

4.5 **Anti-echo verifier that rejects evidence derived only from the candidate's own textual claim.**

4.6 **Negative-control tests that must remain failing/denied to detect overly broad fixes.**

4.7 **Metamorphic verification for outputs without a single exact expected answer.**

4.8 **Verifier calibration dataset measuring false-positive and false-negative rates by verifier type.**

4.9 **Risk-adaptive verification budget: stronger proof for security/financial/destructive effects.**

4.10 **Verification provenance graph linking expected state, action, observed state, evidence and final verdict.**


### Fable mandatory response for Mechanism 4
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Verifier-First Development.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 5: Automatic Context Compiler

5.1 **AST/symbol/call-graph slicing to include executable dependencies rather than whole files.**

5.2 **Change-impact context: prioritize files/symbols touched by recent commits and current diff.**

5.3 **Staleness invalidation whenever tool observations, HEAD or runtime state changes.**

5.4 **Redundancy clustering removes semantically duplicated documentation and code snippets.**

5.5 **Progressive context expansion: start small and fetch deeper layers only when verifier/uncertainty demands.**

5.6 **Context slots with explicit budgets for task, code, evidence, experience, policy and current state.**

5.7 **Loss-aware compression tests whether compressed context preserves answers to critical invariants.**

5.8 **Context contamination detector flags conflicting branches, obsolete docs and unverified memories.**

5.9 **Per-model context profiles learn which information density/order works best for each model.**

5.10 **Context attribution telemetry estimates which chunks contributed to verified success and future pruning.**


### Fable mandatory response for Mechanism 5
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Automatic Context Compiler.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 6: Dynamic Model Router

6.1 **Bayesian per-task-class competence posteriors with uncertainty intervals.**

6.2 **Contextual bandit exploration restricted to safe/shadow tasks.**

6.3 **Drift detector notices model/provider/version performance changes and decays old evidence.**

6.4 **Failure-mode router: choose models based on known weaknesses, not only average success.**

6.5 **Ensemble escalation only when expected disagreement resolution is worth the extra cost.**

6.6 **Model+protocol joint routing: select both model and reasoning workflow as one decision.**

6.7 **Model+context-budget joint optimization instead of choosing model independently of prompt size.**

6.8 **Deadline-aware routing trades latency against quality under explicit time constraints.**

6.9 **Resource-aware local scheduling accounts for VRAM residency/load cost and avoids unnecessary model swaps.**

6.10 **Provider reliability prior includes outages, rate limits and schema/tool-call compliance.**


### Fable mandatory response for Mechanism 6
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Dynamic Model Router.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 7: Adaptive Compute / Escalation

7.1 **Sequential probability ratio stopping: stop retries once evidence says further attempts have low expected gain.**

7.2 **Retry diversity requirement: no identical strategy repeated without new evidence.**

7.3 **Failure-signature escalation routes directly to historically effective next step.**

7.4 **Budget reservation keeps compute available for verification instead of spending everything on generation.**

7.5 **Risk-sensitive CVaR escalation for rare catastrophic failure classes.**

7.6 **Parallel cheap probes before expensive escalation when probes can discriminate strategies.**

7.7 **Token auction allocates remaining session budget across open tasks by expected verified value.**

7.8 **Deadline checkpoint policy automatically stops new work early enough to verify/commit/push.**

7.9 **Cloud escalation requires predicted marginal gain threshold plus policy approval.**

7.10 **Post-escalation attribution records whether extra compute actually improved outcome and recalibrates thresholds.**


### Fable mandatory response for Mechanism 7
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Adaptive Compute / Escalation.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 8: Counterexample Generator

8.1 **Property-based test generation from typed invariants.**

8.2 **Metamorphic variants where transformations should preserve or predictably change output.**

8.3 **Boundary-value generator learned from historical bugs by component.**

8.4 **Stateful sequence attacks: restart/replay/duplicate/out-of-order actions.**

8.5 **Concurrency schedule perturbation for race-sensitive components.**

8.6 **Security-boundary mutation for paths, identities, scopes, symlinks, URLs and tool metadata.**

8.7 **Failure minimizer shrinks a discovered counterexample to the smallest reproducible case.**

8.8 **Coverage-novelty scoring prevents wasting budget on redundant variants.**

8.9 **Cross-fix mutation: replay counterexamples from neighboring historical fixes.**

8.10 **Counterexample-to-benchmark auto-promotion only after independent reproduction and deduplication.**


### Fable mandatory response for Mechanism 8
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Counterexample Generator.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 9: Skill Factory

9.1 **Skill candidates mined from clusters of VERIFIED cases, not raw frequency alone.**

9.2 **Skill contracts declare inputs, outputs, capabilities, side effects, evidence and rollback.**

9.3 **Skill composability checker detects conflicting preconditions/effects before chaining.**

9.4 **Hidden holdout contamination scanner prevents training examples leaking into promotion eval.**

9.5 **Shadow deployment measures real usefulness without granting new authority.**

9.6 **Skill decay/drift monitoring triggers revalidation after dependency or architecture changes.**

9.7 **Skill complexity penalty prefers smaller reusable procedures over giant prompts.**

9.8 **Negative-skill library captures tempting failed patterns as explicit avoid rules.**

9.9 **Per-model skill compatibility scores because the same skill may help 14B and hurt another model.**

9.10 **Automatic rollback and version pinning when production VerifiedSuccess/security metrics regress.**


### Fable mandatory response for Mechanism 9
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Skill Factory.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.


## Mechanism 10: Self-Improvement Laboratory

10.1 **Immutable experiment registry records candidate, baseline, dataset version, code SHA and metrics.**

10.2 **Sequential statistical testing stops experiments early for clear wins/losses while controlling false discovery.**

10.3 **Multiple-comparison correction when many self-improvement candidates compete.**

10.4 **Canary/shadow rollout before production promotion.**

10.5 **Automatic rollback thresholds on VerifiedSuccess, security or tail-risk regression.**

10.6 **Adversarial holdout generated independently from the candidate improvement process.**

10.7 **Evaluation contamination detector tracks whether candidate accessed benchmark answers/cases.**

10.8 **Pareto frontier archive retains specialized candidates instead of forcing one global winner.**

10.9 **Mechanism ablation tests identify which component actually caused an improvement.**

10.10 **Longitudinal drift evaluation re-runs promoted improvements after model/repo/environment changes.**


### Fable mandatory response for Mechanism 10
After evaluating the 10 owner proposals above, invent **10 additional distinct ideas of your own** for Self-Improvement Laboratory.
Do not paraphrase owner ideas.
Use your own knowledge of agent systems, LLM inference, software engineering, statistics, optimization, security and evaluation.
Rank the combined 20 ideas and select only those justified for implementation/prototyping.
Log all 20 decisions for future local-model learning.
