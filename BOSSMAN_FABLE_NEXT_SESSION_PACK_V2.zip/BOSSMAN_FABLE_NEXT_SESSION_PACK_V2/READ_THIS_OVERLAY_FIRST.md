# Mandatory Overlay Instruction

Before finishing work from this pack, read:
`INTELLIGENCE_EXPANSION_100_PLUS_FABLE_100.md`

It adds 100 owner-proposed intelligence extensions (10 for each of the 10 mechanisms).

For every mechanism Fable must add 10 genuinely new proposals of its own, producing at least 100 Fable-originated ideas.

Fable must use its own knowledge, critique owner proposals, deduplicate, mathematically/logically improve them, rank the combined idea pool and decide what should actually be implemented.

Do not implement ideas merely because they exist.

All owner and Fable ideas, decisions, experiments, rejections and verified outcomes must be logged as structured learning material for future local Bossman models.

No hidden chain-of-thought: log concise evidence-based decision rationale only.

Security freeze blockers remain higher priority than speculative intelligence work.
