# BOSSMAN — NEXT RUN CONTEXT HANDOFF

## Immutable rules
One Gateway, approval authority, policy/scope authority, secret broker, event/audit system, browser runtime, Telegram transport, MCP authority and memory authority. Cost Governor remains in cloud path. Pythia is intelligence only. No LLM arbitrary-shell bypass.

## Known facts
- Verified HEAD when this pack was created: `3d04e6644e3e6657a747780009c3d2b84aa8e16a`.
- Substantive V1 gate: `f4a37d9`.
- Core code gates are strong; live host gates are the main unfinished proof.
- Skills/plugins bundle was audited but not vendored because it duplicated infrastructure; integration must be adapter-based.
- V2.1 PARTIAL areas included MCP HTTP, richer retrieval, OpenCode host E2E, live OpenRouter, resource unload behavior, diff-aware reviewer, n8n bidirectional bridge.
- V2.2 improved memory scaling, FactStore, code tools, snapshots, self-learning mechanics and scratch isolation.

## Mission
Raise weak scores to >=8 and core scores toward 9 by closing coding ergonomics, plugin adapters and live-E2E gaps.

Stop when target scorecard is evidence-backed, evening E2E is complete, P0/P1=0 and CI final SHA is green.
