# BOSSMAN — ONE-RUN 8–9+ MASTER PROMPT

Repository: `molotroka123-cell/AiMaxBossman`
Branch: `claude/bossman-control-v03-43igbk`

Mission: in ONE focused development run, raise every weak Bossman category to at least ~8/10 and core coding/orchestration categories toward 9/10, then prepare the system for evening live acceptance.

This is `AUDIT → PRIORITIZE → IMPLEMENT → VERIFY → BENCHMARK → FIX → REPORT`, not a feature brainstorm.

## 0. Source of truth + context retention
Immediately `git fetch`, resolve actual remote HEAD, record `START_HEAD`, read `docs/context/V1_RC_FINAL_REPORT.md`, latest V2.2 report, integration reports, and every MD in `BOSSMAN_NEXT_RUN_8_9_PACK`. Inspect current code before trusting reports.

Create/update `docs/context/NEXT_RUN_LIVE_CONTEXT.md`. After EVERY wave append: HEAD, completed, changed files, decisions, tests, failures, unresolved P0/P1, next exact action. Another model must be able to continue without rereading the repo.

## 1. Absolute architecture rules
Never create a second Gateway, approval engine, policy engine, secret store, audit/event bus, browser runtime, Telegram subsystem, MCP authority, or memory authority.

Preserve `intent → typed capability/action → scopes/policy → approval → executor/adapter → result → audit`.
Local: `agent → Stage3 Gateway → Ollama`, `cloud_policy=never`.
Cloud: `agent → Stage3 Gateway → Cost Governor → provider`.
Pythia: intelligence only. No arbitrary LLM→shell bypass.

## 2. Re-score first
Use `01_SCORECARD_8_9_TARGET.md`. For every row write `CURRENT_SCORE / EVIDENCE / GAP / TARGET / TASKS` to `docs/context/NEXT_RUN_SCORECARD_BEFORE.md`. Do not inherit scores blindly.

## 3. Highest priority — coding-specialist parity
Audit repo indexing, code search, LSP, worktree/session lifecycle, diffs, tests, reviewer, resume/fork, compaction, parallel sessions.

### LSP
If native LSP is missing/incomplete, adapt `code_candidates/lsp_bridge.py` into existing code-tool registry. Required: document/workspace symbols, definition, references, implementation, hover, diagnostics, optional call hierarchy. Workspace confined, argv-only server, timeout, bounded output, fail-soft, no shell, no authority escalation. Deterministic fake-server tests + optional real-host smoke.

### Repo map
Compact important modules/symbols/import edges/recent changes/test mapping. Incremental refresh; do not rebuild whole repo for every action.

### Coding sessions
Persist session id, repo/worktree, task, model, owner, timestamps, changed files, tests, summary, state, parent/fork. Resume after Command Center restart. Parallel sessions isolated; conflict detection before merge/write overlap.

### Reviewer Gate
Reviewer MUST receive acceptance criteria, actual git diff, diagnostics, tests, changed files, security-sensitive changes and unresolved TODO/SKIP. Add negative regression where prose says done but diff/tests prove failure.

## 4. Context quality
Audit compaction. Durable checkpoint must retain objective, invariants, decisions, files changed, evidence, blockers, next action. Test long session → compaction → restart/resume → correct architecture/task reconstruction. Relevance + budget, never dump all memory.

## 5. Native plugin adapters
Use audited bundle only as adapter reference. Integrate priority: GitHub, Obsidian, Browser, Ollama, OpenRouter, Telegram, n8n, Gmail, Calendar, Drive, read-only SQL, MCP. Map into existing scopes/approvals/secrets/events/Gateway/Cost Governor. Unknown DENY, external mutation ASK, destructive ASK, arbitrary shell DENY. Do not vendor duplicate frameworks.

## 6. Security hardening
Mandatory regression: SSRF private IP, hostname resolution, redirect-to-private, traversal, symlink escape, secret VALUE redaction, duplicate approval, side-effect idempotency, disabled plugin, unknown capability, MCP escalation, SQL write, unsafe n8n URL. Fix P0/P1.

## 7. Provider/local AI
Routing evidence should include capability, verified tools, context, latency, price, failures, local/cloud class. No new provider abstraction. On capable host prove `Ollama → Gateway → Planner → Stage13 → Notepad → fresh observation` and `CLOUD_CALLS=0`.

## 8. High-ROI UX only
Audit Command Center and implement only daily-use improvements: session switcher, coding session page, diff/reviewer panel, test panel, model/cost/latency badges, plugin health, approval inbox clarity, resume/fork if backend supports, degraded-state explanations. No cosmetic redesign.

## 9. Observability
Each task trace must answer: model, routing reason, duration, cost, tools, approvals, retries, changed files, tests, final reason. Stable correlation IDs if missing. No secrets.

## 10. OpenCode benchmark
Do not claim superiority by opinion. Use same machine/model/repo snapshot/task/fresh workspace. At least 10 tasks: bug, feature+tests, refactor, failing test, unfamiliar repo, security bug, docs mismatch, interrupted/resumed task, parallel subtask, external-evidence task. Measure success, tests, interventions, elapsed time, tokens, cost, retries, bad edits, security violations, resume quality. Use `code_candidates/eval_scorecard.py`. Write `docs/context/BOSSMAN_VS_OPENCODE_BENCHMARK.md`. If OpenCode unavailable: NOT_TESTED.

## 11. Testing
Targeted after each component, then full core, command-center, code-intelligence, context, plugins, Gateway, Cost Governor, approvals, FactStore, Stage13, Pythia, security, secret scan, compileall, JS syntax. Never hide skips.

## 12. Bug policy
P0: arbitrary execution, secret leak, auth/approval bypass, corruption, duplicate destructive side-effect.
P1: broken coding flow/LSP, Gateway/cost bypass, required state lost on restart, plugin broken, SSRF/path escape, reviewer false PASS.
Every bug: `REPRODUCE → ROOT_CAUSE → REGRESSION_TEST → MINIMAL_FIX → RETEST`.
P2 may be documented if nonessential/risky.

## 13. Save limits
Search existing equivalent before coding. Extend existing seams. Small targeted diffs. Adapt candidate code instead of rewriting. Do not rewrite docs until implementation stabilizes.

## 14. Before/after score
Create `docs/context/NEXT_RUN_SCORECARD_AFTER.md`. Every row: before, after, evidence, exact test, remaining gap. >=8 needs real feature + regression. >=9 needs operational E2E or explicit host limitation. Do not inflate.

## 15. Evening readiness
Read `04_EVENING_LIVE_TEST_MATRIX.md`; create executable checklist/script where practical. No unsafe external mutations without owner approval.

## 16. Final regression/push
Full tests, secret scan, diff, no temp/debug, UTF-8/Cyrillic, Windows compatibility. `git fetch`; reconcile if moved; NO FORCE PUSH. Commit/push, fetch again, record `FINAL_REMOTE_HEAD`, check CI exact SHA.

## 17. Required outputs
- `docs/context/NEXT_RUN_LIVE_CONTEXT.md`
- `docs/context/NEXT_RUN_SCORECARD_BEFORE.md`
- `docs/context/NEXT_RUN_SCORECARD_AFTER.md`
- `docs/context/CODING_PARITY_REPORT.md`
- `docs/context/PLUGIN_ADAPTER_FINAL_REPORT.md`
- `docs/context/BOSSMAN_VS_OPENCODE_BENCHMARK.md`
- `docs/context/EVENING_TEST_READY.md`
- `docs/context/NEXT_RUN_FINAL_REPORT.md`

Final report: START_HEAD, FINAL_REMOTE_HEAD, files changed, P0/P1/P2, exact tests, live vs mock vs skip, before/after scores, OpenCode evidence, evening instructions.

## 18. Final declaration
Only if supported:
`NEXT_RUN_CODE_GATE: PASS`
`ALL_TARGET_SCORES_CODE_LEVEL: >=8`
`CORE_TARGET_SCORES: ~9`
`EVENING_LIVE_TEST: READY`

Never claim `BOSSMAN > OPENCODE` unless benchmark proves it in named categories. Then STOP.
