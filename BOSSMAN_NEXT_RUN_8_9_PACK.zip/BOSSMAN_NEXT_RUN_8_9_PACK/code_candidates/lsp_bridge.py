"""Candidate safe async LSP JSON-RPC bridge.
Adapt into Bossman's EXISTING code-tool registry; do not create another registry.
"""
from __future__ import annotations
import asyncio, json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

class LSPError(RuntimeError): pass

@dataclass(frozen=True)
class LSPConfig:
    argv: tuple[str, ...]
    workspace: Path
    timeout_s: float = 8.0
    max_message_bytes: int = 4 * 1024 * 1024

class LSPClient:
    def __init__(self, config: LSPConfig):
        if not config.argv: raise ValueError("empty LSP argv")
        self.cfg=config; self.proc=None; self._id=1; self._pending={}; self._reader=None; self._diagnostics={}

    async def start(self):
        ws=self.cfg.workspace.resolve(strict=True)
        if not ws.is_dir(): raise ValueError("workspace must be directory")
        self.proc=await asyncio.create_subprocess_exec(*self.cfg.argv,cwd=str(ws),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        self._reader=asyncio.create_task(self._read_loop())
        await self.request("initialize",{"processId":None,"rootUri":ws.as_uri(),"capabilities":{"textDocument":{"definition":{},"references":{},"hover":{},"documentSymbol":{},"implementation":{},"publishDiagnostics":{}},"workspace":{"symbol":{}}}})
        await self.notify("initialized",{})

    async def close(self):
        if not self.proc: return
        try: await self.request("shutdown",None)
        except Exception: pass
        try: await self.notify("exit",None)
        except Exception: pass
        if self.proc.returncode is None:
            try: await asyncio.wait_for(self.proc.wait(),2)
            except asyncio.TimeoutError:
                self.proc.terminate()
                try: await asyncio.wait_for(self.proc.wait(),2)
                except asyncio.TimeoutError: self.proc.kill(); await self.proc.wait()
        if self._reader: self._reader.cancel()

    async def request(self, method:str, params:Any):
        if not self.proc or self.proc.returncode is not None: raise LSPError("not running")
        i=self._id; self._id+=1
        fut=asyncio.get_running_loop().create_future(); self._pending[i]=fut
        await self._send({"jsonrpc":"2.0","id":i,"method":method,"params":params})
        try: return await asyncio.wait_for(fut,self.cfg.timeout_s)
        finally: self._pending.pop(i,None)

    async def notify(self, method:str, params:Any):
        await self._send({"jsonrpc":"2.0","method":method,"params":params})

    async def symbols(self, uri:str): return await self.request("textDocument/documentSymbol",{"textDocument":{"uri":uri}})
    async def workspace_symbols(self,q:str): return await self.request("workspace/symbol",{"query":q})
    async def definition(self,uri,l,c): return await self._pos("textDocument/definition",uri,l,c)
    async def implementation(self,uri,l,c): return await self._pos("textDocument/implementation",uri,l,c)
    async def hover(self,uri,l,c): return await self._pos("textDocument/hover",uri,l,c)
    async def references(self,uri,l,c): return await self.request("textDocument/references",{"textDocument":{"uri":uri},"position":{"line":l,"character":c},"context":{"includeDeclaration":False}})
    def diagnostics(self,uri): return list(self._diagnostics.get(uri,[]))

    async def _pos(self,m,u,l,c):
        if l<0 or c<0: raise ValueError("negative position")
        return await self.request(m,{"textDocument":{"uri":u},"position":{"line":l,"character":c}})

    async def _send(self,payload):
        if not self.proc or not self.proc.stdin: raise LSPError("not running")
        body=json.dumps(payload,separators=(",",":"),ensure_ascii=False).encode()
        if len(body)>self.cfg.max_message_bytes: raise LSPError("message too large")
        self.proc.stdin.write(f"Content-Length: {len(body)}\r\n\r\n".encode("ascii")+body); await self.proc.stdin.drain()

    async def _read_loop(self):
        try:
            while True:
                msg=await self._read_message()
                if msg is None: break
                if "id" in msg and ("result" in msg or "error" in msg):
                    fut=self._pending.get(msg["id"])
                    if fut and not fut.done():
                        fut.set_exception(LSPError(str(msg["error"]))) if "error" in msg else fut.set_result(msg.get("result"))
                elif msg.get("method")=="textDocument/publishDiagnostics":
                    p=msg.get("params") or {}; u=p.get("uri"); d=p.get("diagnostics") or []
                    if isinstance(u,str) and isinstance(d,list): self._diagnostics[u]=d[:2000]
        except asyncio.CancelledError: raise
        except Exception as e:
            for f in self._pending.values():
                if not f.done(): f.set_exception(LSPError(f"read failed: {e}"))

    async def _read_message(self):
        if not self.proc or not self.proc.stdout: return None
        n=None
        while True:
            line=await self.proc.stdout.readline()
            if not line: return None
            if len(line)>8192: raise LSPError("oversized header")
            if line in (b"\r\n",b"\n"): break
            k,_,v=line.decode("ascii","strict").partition(":")
            if k.lower()=="content-length": n=int(v.strip())
        if n is None or n<0 or n>self.cfg.max_message_bytes: raise LSPError("bad content length")
        msg=json.loads((await self.proc.stdout.readexactly(n)).decode())
        if not isinstance(msg,dict): raise LSPError("invalid payload")
        return msg
