from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from eval_scorecard import summarize

def test_summarize():
    rows=[{"executor":"bossman","success":True,"tests_green":True,"elapsed_s":10,"cost_usd":.1},{"executor":"bossman","success":False,"tests_green":False,"elapsed_s":20,"cost_usd":.2},{"executor":"opencode","success":True,"tests_green":True,"elapsed_s":12,"cost_usd":.1}]
    s=summarize(rows)
    assert s["bossman"]["success_rate"]==.5
    assert s["bossman"]["avg_elapsed_s"]==15
    assert s["opencode"]["success_rate"]==1
