"""Comparable A/B benchmark metrics. Input is JSONL, one run per line."""
from __future__ import annotations
import json, statistics
from collections import defaultdict
from pathlib import Path

def load_jsonl(path:Path):
    out=[]
    for n,line in enumerate(path.read_text(encoding="utf-8").splitlines(),1):
        if line.strip():
            row=json.loads(line)
            if not isinstance(row,dict): raise ValueError(f"line {n}: object required")
            out.append(row)
    return out

def summarize(rows):
    groups=defaultdict(list)
    for r in rows: groups[str(r["executor"])].append(r)
    result={}
    for name,items in groups.items():
        n=len(items)
        avg=lambda key: statistics.fmean(float(x.get(key,0) or 0) for x in items)
        result[name]={"runs":n,"success_rate":sum(bool(x.get("success")) for x in items)/n,"tests_green_rate":sum(bool(x.get("tests_green")) for x in items)/n,"avg_human_interventions":avg("human_interventions"),"avg_elapsed_s":avg("elapsed_s"),"avg_cost_usd":avg("cost_usd"),"avg_security_violations":avg("security_violations"),"avg_retries":avg("retries")}
    return result

if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser(); p.add_argument("jsonl",type=Path); a=p.parse_args()
    print(json.dumps(summarize(load_jsonl(a.jsonl)),indent=2,ensure_ascii=False))
