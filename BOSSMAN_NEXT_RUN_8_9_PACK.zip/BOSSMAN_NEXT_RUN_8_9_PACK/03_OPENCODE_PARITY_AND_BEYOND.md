# BOSSMAN vs OPENCODE — PARITY AND BEYOND

OpenCode's current public docs make these a baseline: built-in code/file/shell/web tools, allow/ask/deny permissions, MCP/custom tools, LSP code intelligence, primary/subagents, compaction/summary agents, persistent/resumable sessions, multi-session usage, many providers/local models, terminal/desktop/IDE workflows.

Bossman's differentiation is broader: central control plane, scheduling, durable approvals, FactStore/memory, Cost Governor, browser/computer operator, local-first control, missions, Pythia/world intelligence, external workflows, mobile/dashboard.

Strategy: do not copy OpenCode feature-for-feature. Match LSP/resume/session/diff/test ergonomics, then beat it through orchestration.

A Bossman task should be able to: retrieve memory → research → choose executor/model → isolated coding session → edit → test → reviewer → browser validation → approval → GitHub action → persist result → notify owner.

Never write `Bossman > OpenCode` globally. Use per-category benchmark evidence.
