# BOSSMAN — NEXT RUN EXECUTION PLAN

Goal: raise every weak category to >=8 and core categories to ~9 without destabilizing architecture.

## Wave 0 — baseline
Fetch remote, record START_HEAD, read current RC + this pack, run fast baseline, write before-scorecard, freeze feature ideas.

## Wave 1 — coding-specialist parity
Implement/finish native LSP bridge, repo-map refresh, coding-session metadata, reviewer consuming actual diff/tests/diagnostics, worktree conflict guard, resumable session state.

## Wave 2 — plugins as native adapters
Priority: GitHub → Obsidian → Browser → Ollama → OpenRouter → Telegram → n8n → Gmail → Calendar → Drive → SQL → MCP.

## Wave 3 — observability/context
For every run persist task/session/agent/model/provider/tokens/latency/cost/tools/approvals/retries/status/changed-files/tests. Emit compact handoff checkpoints.

## Wave 4 — real local host
Windows + Ollama: Gateway route, Notepad through production chain, fresh observe, unsafe deny, cloud calls zero.

## Wave 5 — Bossman vs OpenCode benchmark
Same machine/model/repo snapshot/task. At least 10 tasks: bug fix, feature+tests, refactor, failing test, docs/code mismatch, security bug, unfamiliar repo, resume, parallel task, external evidence. Measure success/tests/interventions/time/tokens/cost/bad edits/retries/security/context recovery.

## Wave 6 — evening acceptance
Use `04_EVENING_LIVE_TEST_MATRIX.md`.

## Wave 7 — P0/P1 only
No feature expansion after acceptance begins.

## Wave 8 — final report
Before/after scorecard, evidence, SKIPs, exact OpenCode comparison, FINAL_REMOTE_HEAD.
