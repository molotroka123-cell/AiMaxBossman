# BOSSMAN — EVENING FULL SYSTEM TEST MATRIX

Allowed: `PASS / FAIL / SKIP_HOST / SKIP_EXTERNAL_SERVICE / SKIP_EXTERNAL_CREDENTIAL / NOT_TESTED`.

## Boot/health
Core, Command Center, DB, Redis if configured, schema/migrations, subsystem health.

## Local model
Ollama reachable, model loaded, Gateway route, cloud_policy=never, cloud counter zero.

## Coding
Disposable repo: inspect → LSP symbols → definition/references → edit → tests → diff → reviewer sees diff → restart/resume.

## Windows
Open Notepad via production chain → fresh observation → optional TYPE marker → unsafe app denied → shell-like target denied.

## Memory
Write fact → retrieve → restart → retrieve → memory search → compaction → cold-session resume.

## Browser
Session → navigate → read DOM → click/type → takeover/resume → sensitive action asks.

## Plugins
For each integrated plugin: health, read, ASK operation, reject=zero side effect, approve=exactly one side effect where safe, duplicate callback=no duplicate.

## Cost
reserve/commit/release; exhausted budget stops before network; unknown price fail-closed; local mode cloud denied.

## Pythia
offline fail-soft; auth; no action authority; live/recovery if service exists.

## Chaos
kill local model, browser unavailable, restart UI/core, duplicate approval, cancel, retry.

## Security
path traversal, symlink escape, SSRF/private IP, redirect SSRF, arbitrary shell, unauthorized API, SQL write, MCP unknown capability, secret scan.

## Full regression
core pytest, command-center pytest, new coding/LSP tests, plugin tests, compileall, JS syntax, secret scan, CI exact SHA.

Exit: P0=0, P1=0, host-capable mandatory gates PASS, every SKIP explained.
