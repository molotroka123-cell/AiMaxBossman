# BOSSMAN NEXT RUN 8–9 PACK

Read in order:
1. `00_AUDIT_CURRENT_STATE.md`
2. `01_SCORECARD_8_9_TARGET.md`
3. `05_MASTER_PROMPT_NEXT_RUN.md`

Then use execution plan, OpenCode comparison, evening test matrix and context handoff.

`code_candidates/` contains safe framework-neutral code that should be adapted to existing Bossman seams, not blindly vendored.
