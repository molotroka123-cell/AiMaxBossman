# BOSSMAN — 8–9+ TARGET SCORECARD

- 8.0 = strong daily-use feature with regression tests and graceful failure.
- 9.0 = strong feature + real E2E + observability + recovery + UX.
- 9.5+ = externally benchmarked and consistently better than alternatives.

## Mandatory targets

1. **Coding workflow 9.0** — repo/worktree, repo map, symbol navigation, code search, diagnostics, patch, diff, tests, reviewer sees real evidence, rollback, durable resumable session.
2. **LSP/code intelligence 9.0** — document/workspace symbols, definition, references, implementation, hover, diagnostics, optional call hierarchy; fail-soft without LSP.
3. **Context 9.0** — stable summary, task state, decisions, blockers, changed files, tests, memory refs, compaction under budget, cold recovery.
4. **Parallel sessions 8.8** — isolated worktree/scratch, ownership, conflict detection, cancel, merge preview, no cross-agent leakage.
5. **Reviewer 9.0** — acceptance criteria + actual diff + diagnostics + tests + security changes + unresolved TODO/SKIP. No PASS from prose alone.
6. **Plugins 8.7+** — native adapters for GitHub, Gmail, Calendar, Drive, Telegram, n8n, Obsidian, Browser, monitor, read-only SQL, Ollama, OpenRouter, MCP. No duplicate core systems.
7. **Local AI 9.0** — real `Ollama → Gateway → Planner → typed action → policy → ActionRouter → Windows → fresh observation`; prove `cloud_policy=never`, `CLOUD_CALLS=0`, Notepad live, unsafe launch denied.
8. **UX 8.8** — session switcher, coding workspace, task timeline, diff/review, model/cost badge, approval inbox, plugin health, resume, degraded states.
9. **Reliability 9.0** — provider/Ollama/Pythia/browser failures, restarts, stale/duplicate approvals, retries, no duplicate side effects.
10. **Evidence 9.0** — every score points to test/live log/benchmark/commit SHA.

## Above OpenCode bar

Do not claim universal superiority. Claim category superiority only with A/B evidence.

Aim to beat OpenCode in long-horizon autonomous completion, safety, persistent memory, external-service orchestration, cost control, multi-agent coordination and Windows/computer operation.

Reach parity in code intelligence, coding-session ergonomics, provider flexibility, resumable sessions and diff/test loop.
