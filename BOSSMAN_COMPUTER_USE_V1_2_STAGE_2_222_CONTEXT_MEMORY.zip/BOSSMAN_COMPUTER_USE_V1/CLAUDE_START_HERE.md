# BOSSMAN ComputerUse v1 — START HERE FOR CLAUDE CODE

Target repository: `molotroka123-cell/AiMaxBossman`
Audited branch at package creation: `claude/bossman-control-v03-43igbk`
Package date: 2026-08-29

## Goal
Add one shared **ComputerUse / Browser layer** to Bossman Core so every current and future agent can operate a normal Chromium browser without a site-specific MCP.

This is NOT a Higgsfield bot. Higgsfield is only a test scenario. The capability must work for arbitrary websites.

## Mandatory integration rules
1. Read `TECH_SPEC.md`, `PATCH_MANIFEST.md`, `docs/GITHUB_REPO_HYGIENE.md`, and `docs/AUDIT_PROTOCOL.md` before editing.
2. Inspect the current repository first. Never blindly overwrite newer code.
3. Preserve the existing Bossman architecture: `AgentSpec -> toolkit registry -> runner permission/approval -> events/db`.
4. Integrate the supplied code semantically. If current files differ from the audited branch, adapt the patch instead of reverting unrelated changes.
5. Do not create a separate app/service for browser control unless the current architecture genuinely requires it.
6. Every agent gets ComputerUse by default. Individual agents may opt out with `computer_use: false`.
7. Browser state/profile must be isolated per agent.
8. Never attempt CAPTCHA bypass, anti-bot bypass, rate-limit bypass, paywall bypass, or circumvention of a site's explicit restrictions.
9. Dangerous actions must go through the existing approval system. Generic browser automation must not silently confirm payments, transfers, destructive deletes, publishing, purchases, credential changes, or account/security changes.
10. Run tests and provide an audit report using the naming scheme in `docs/AUDIT_PROTOCOL.md`.

## Desired result
After integration an agent can receive a natural-language task such as:

> Open the site in my logged-in browser profile, create items from this queue one by one, wait for each to finish, save outputs, and stop if login, CAPTCHA, rate limit, billing, or an uncertain destructive action appears.

The agent should be able to do this using Browser tools exposed by the normal Bossman tool loop.

## Definition of done
- `browser.*` tools registered in the existing toolkit.
- Playwright dependency added.
- Chromium install documented.
- Persistent per-agent profiles implemented.
- Current and future agents receive safe ComputerUse tools by default.
- Sensitive click path requires approval.
- Download support works.
- DOM/accessibility observation is available without vision.
- Screenshot capture is available for multimodal/vision integration.
- Sessions survive task boundaries and process restarts via persistent profile data.
- Unit tests pass.
- No secrets/cookies/browser profile data can enter Git.
- Repository docs and audit naming rules are added/updated.

## Deliverable from Claude
Make the actual code changes in the repository, run tests, then create:

`docs/audits/YYYY-MM-DD__computer-use__implementation-audit__v1.md`

Include files changed, tests run, known limitations, security checks, and exact commit SHA.

## Mandatory final gate: emulator bug-check
Before marking the task complete, read `docs/EMULATOR_BUGCHECK.md` and run the unit + emulator E2E checks. A unit-test-only PASS is not sufficient. If Playwright/Chromium cannot launch, report BLOCKED rather than PASS.


# NEW: ЭТАП 2.222 — execute after ComputerUse v1.2

After Stage 1 passes its full browser/emulator gate, read `docs/stage-2.222/ЭТАП_2.222_CONTEXT_MEMORY.md`, then `docs/stage-2.222/INTEGRATION_GUIDE.md`, the `docs/stage-2.222/memory/` folder and `skills/compact/SKILL.md`. Apply `scripts/apply_stage_2_222.py` and wire the provided `bossman.context_engine` code into the real LLM request path only after inspecting the repository. Do not mark Stage 2.222 DONE until its unit tests, repo-specific integration tests and context quality benchmark pass. Do not replace raw history with summaries.
