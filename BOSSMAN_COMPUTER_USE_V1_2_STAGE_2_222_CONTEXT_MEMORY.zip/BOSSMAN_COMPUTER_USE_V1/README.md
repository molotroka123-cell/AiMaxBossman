# BOSSMAN_COMPUTER_USE_V1

Handoff bundle for adding generic browser/computer-use capability to every AiMaxBossman agent.

Start with `CLAUDE_START_HERE.md`.

Contents:
- complete technical spec;
- implementation-ready Playwright toolkit module;
- tests;
- conservative patch helper;
- GitHub repository sorting/hygiene rules;
- durable audit naming and report protocol;
- ready-to-paste Claude Code task prompt.

V1.1 adds a mandatory emulator/test-browser bug-check acceptance gate. Claude must run it before declaring ComputerUse complete.


## ЭТАП 2.222 — Context & Memory Engine

This handoff now also contains a **separate Stage 2.222** implementation under `code/bossman-core/bossman/context_engine/`, plus `docs/stage-2.222/`, a standalone `memory/` specification folder, and `skills/compact/SKILL.md`. Apply Stage 1 ComputerUse first, then Stage 2.222 with `scripts/apply_stage_2_222.py`. Stage 2.222 is quality-first: hybrid retrieval, provenance, adaptive context packing, durable-memory states, conservative distillation, plugin-backed memory, and a compact conversation handoff that preserves recent messages verbatim.
