"""Idempotent mechanical patcher for BOSSMAN ComputerUse v1.2.
Aborts on changed anchors rather than guessing. Claude must inspect git diff after application.
"""
from __future__ import annotations
import shutil, sys
from pathlib import Path

ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
PKG=Path(__file__).resolve().parents[1]
CORE=ROOT/'bossman-core'

def require(p:Path):
    if not p.exists(): raise SystemExit(f'required path not found: {p}')
for p in [CORE/'bossman/toolkit/__init__.py', CORE/'bossman/agents.py', CORE/'pyproject.toml']:
    require(p)

# New implementation + complete tests.
(CORE/'bossman/toolkit').mkdir(parents=True,exist_ok=True); (CORE/'tests').mkdir(exist_ok=True)
for src,dst in [
    ('code/bossman-core/bossman/toolkit/browser.py','bossman/toolkit/browser.py'),
    ('code/bossman-core/tests/test_browser_policy.py','tests/test_browser_policy.py'),
    ('code/bossman-core/tests/test_browser_emulator_e2e.py','tests/test_browser_emulator_e2e.py'),
]: shutil.copy2(PKG/src,CORE/dst)

# Register browser module.
p=CORE/'bossman/toolkit/__init__.py'; s=p.read_text(encoding='utf-8')
anchor='from . import files, shell, gitops, journal, net, media, office'
if 'browser' not in s.split('from . import',1)[-1]:
    if anchor not in s: raise SystemExit('toolkit import anchor changed; integrate browser manually')
    s=s.replace(anchor,anchor+', browser'); p.write_text(s,encoding='utf-8')

# Playwright dependency.
p=CORE/'pyproject.toml'; s=p.read_text(encoding='utf-8')
if '"playwright>=' not in s:
    anchor='    "pydantic>=2.7",\n'
    if anchor not in s: raise SystemExit('pyproject dependency anchor changed')
    s=s.replace(anchor,anchor+'    "playwright>=1.47",\n'); p.write_text(s,encoding='utf-8')

# All current/future agents get ComputerUse unless computer_use:false.
p=CORE/'bossman/agents.py'; s=p.read_text(encoding='utf-8')
if 'BASE_COMPUTER_USE_TOOLS' not in s:
    anchor='CLOUD_POLICIES = ("never", "ask", "allowed")\n'
    block='''CLOUD_POLICIES = ("never", "ask", "allowed")\n\nBASE_COMPUTER_USE_TOOLS: tuple[tuple[str, bool | None], ...] = (\n    ("browser.open", None), ("browser.observe", None), ("browser.frames", None),\n    ("browser.tabs", None), ("browser.tab_switch", None), ("browser.tab_close", None),\n    ("browser.extract", None), ("browser.screenshot", None), ("browser.vision", None),\n    ("browser.wait", None), ("browser.click", None), ("browser.confirmed_click", True),\n    ("browser.type", None), ("browser.press", None), ("browser.confirmed_press", True),\n    ("browser.select", None), ("browser.scroll", None), ("browser.hover", None),\n    ("browser.upload", None), ("browser.download", None), ("browser.checkpoint", None),\n    ("browser.close", None),\n)\n'''
    if anchor not in s: raise SystemExit('agents.py policy anchor changed')
    s=s.replace(anchor,block)
    fn='def load_agent(path: Path) -> AgentSpec:\n'
    helper='''def _merge_computer_use_tools(grants: list[ToolGrant], enabled: bool) -> list[ToolGrant]:\n    if not enabled: return grants\n    existing={g.name for g in grants}; merged=list(grants)\n    for name,confirm in BASE_COMPUTER_USE_TOOLS:\n        if name not in existing: merged.append(ToolGrant(name, confirm=confirm))\n    return merged\n\n\n'''
    if fn not in s: raise SystemExit('agents.py load_agent anchor changed')
    s=s.replace(fn,helper+fn)
    old='        tools=_parse_tools(cfg.get("tools")),\n'
    new='        tools=_merge_computer_use_tools(_parse_tools(cfg.get("tools")), bool(cfg.get("computer_use", True))),\n'
    if old not in s: raise SystemExit('agents.py tools anchor changed')
    s=s.replace(old,new); p.write_text(s,encoding='utf-8')

# Docs + scripts.
(ROOT/'docs').mkdir(exist_ok=True); (ROOT/'tools').mkdir(exist_ok=True)
for name in ['GITHUB_REPO_HYGIENE.md','AUDIT_PROTOCOL.md','EMULATOR_BUGCHECK.md','COMPUTER_USE_OPERATIONS.md']:
    shutil.copy2(PKG/'docs'/name,ROOT/'docs'/name)
shutil.copy2(PKG/'scripts/check_repo_hygiene.py',ROOT/'tools/check_repo_hygiene.py')

# Runtime/profile/download artefacts never enter git.
p=ROOT/'.gitignore'; old=p.read_text(encoding='utf-8') if p.exists() else ''
block='''\n# Bossman ComputerUse runtime\n.browser-profiles/\nbrowser-profiles/\nplaywright/.auth/\n**/browser-profile/\n**/browser-profiles/\n**/.auth/\n**/browser/diagnostics/\n**/browser/vision/\n**/screenshots/\n**/downloads/\n'''
if '# Bossman ComputerUse runtime' not in old: p.write_text(old.rstrip()+block+'\n',encoding='utf-8')
print('ComputerUse v1.2 patch applied. Inspect git diff; install Chromium; run full bug-check; only then mark DONE.')
