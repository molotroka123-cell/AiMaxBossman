"""Apply BOSSMAN ЭТАП 2.222 Context & Memory into an existing repository.

Idempotent file-copy integration. It does not guess the host LLM lifecycle.
Claude must wire the package into the actual request path after inspecting the repo.
"""
from __future__ import annotations
import shutil, sys
from pathlib import Path

ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
PKG=Path(__file__).resolve().parents[1]
CORE=ROOT/'bossman-core'
if not CORE.exists(): raise SystemExit(f'bossman-core not found under {ROOT}')

src_pkg=PKG/'code/bossman-core/bossman/context_engine'
dst_pkg=CORE/'bossman/context_engine'
if dst_pkg.exists(): shutil.rmtree(dst_pkg)
shutil.copytree(src_pkg,dst_pkg)

(CORE/'tests').mkdir(parents=True,exist_ok=True)
for name in ['test_context_engine_stage_2_222.py','test_compact_plugins.py']:
    shutil.copy2(PKG/'code/bossman-core/tests'/name,CORE/'tests'/name)

stage_docs=ROOT/'docs/stage-2.222'
if stage_docs.exists(): shutil.rmtree(stage_docs)
shutil.copytree(PKG/'docs/stage-2.222',stage_docs)

skill_dst=ROOT/'skills/compact'; skill_dst.mkdir(parents=True,exist_ok=True)
shutil.copy2(PKG/'skills/compact/SKILL.md',skill_dst/'SKILL.md')

print('ЭТАП 2.222 copied. Next: inspect host LLM/tool lifecycle, wire ContextCompiler + CompactSkill, then run tests and benchmark before DONE.')
