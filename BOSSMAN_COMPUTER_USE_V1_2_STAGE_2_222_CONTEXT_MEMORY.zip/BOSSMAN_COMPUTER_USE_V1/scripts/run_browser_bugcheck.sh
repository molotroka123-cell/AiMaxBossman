#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$(pwd)}"
PKG="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/bossman-core"
[ -d "$CORE" ] || { echo "BLOCKED: bossman-core not found at $CORE"; exit 2; }
cd "$CORE"
python -m pytest -q tests/test_browser_policy.py tests/test_browser_emulator_e2e.py
python "$PKG/scripts/check_repo_hygiene.py" "$ROOT"
echo "COMPUTERUSE BUGCHECK PASS"
