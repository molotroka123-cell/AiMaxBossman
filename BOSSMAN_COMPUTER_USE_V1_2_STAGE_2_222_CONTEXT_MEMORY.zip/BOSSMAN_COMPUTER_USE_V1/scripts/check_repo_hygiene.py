from __future__ import annotations
import re, sys
from pathlib import Path
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]
for p in ROOT.rglob('*'):
    if '.git' in p.parts: continue
    rel=p.relative_to(ROOT)
    if p.is_dir() and p.name=='__pycache__': errors.append(f'forbidden cache dir: {rel}')
    if p.is_file() and p.suffix in {'.pyc','.pyo'}: errors.append(f'forbidden bytecode: {rel}')
    if p.is_file() and p.parent==ROOT and p.suffix.lower() in {'.zip','.tar','.gz','.7z'}: errors.append(f'archive in repo root: {rel}')
    if p.is_file() and any(x in p.name.lower() for x in ('.env','.pem','.key')) and p.name not in {'.env.example'}:
        errors.append(f'possible secret file: {rel}')
    if p.is_file() and 'docs/audits/' in rel.as_posix():
        if not re.match(r'^\d{4}-\d{2}-\d{2}__[a-z0-9-]+__[a-z0-9-]+__v\d+\.md$', p.name):
            errors.append(f'bad audit filename: {rel}')
if errors:
    print('HYGIENE FAIL')
    print('\n'.join(f'- {e}' for e in errors))
    raise SystemExit(1)
print('HYGIENE PASS')
