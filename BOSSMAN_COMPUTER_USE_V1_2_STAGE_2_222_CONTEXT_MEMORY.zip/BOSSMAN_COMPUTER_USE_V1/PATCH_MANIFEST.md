# Patch Manifest

This package contains implementation-ready files plus an apply helper. Claude must still inspect current code before applying because the repository may have changed after this package was generated.

## New file
Copy/adapt:
- `code/bossman-core/bossman/toolkit/browser.py` -> `bossman-core/bossman/toolkit/browser.py`
- `code/bossman-core/tests/test_browser_policy.py` -> `bossman-core/tests/test_browser_policy.py`

## Existing files to modify
### `bossman-core/bossman/toolkit/__init__.py`
Change module registration line from:

```python
from . import files, shell, gitops, journal, net, media, office
```

to include `browser`.

### `bossman-core/pyproject.toml`
Add dependency:

```toml
"playwright>=1.47",
```

Keep all existing dependencies.

### `bossman-core/bossman/agents.py`
Add default Browser grants for every agent. Recommended behavior is provided in `scripts/apply_patch.py` and described in `TECH_SPEC.md`.

Required semantics:
- config key `computer_use` defaults to true;
- Browser grants are merged into agent-defined grants;
- manual agent settings win where duplicated;
- `browser.confirmed_click` has `confirm=True`;
- agent can disable all defaults with `computer_use: false`.

### `.gitignore`
Ensure these patterns are ignored:

```gitignore
# Bossman ComputerUse runtime
.browser-profiles/
browser-profiles/
playwright/.auth/
**/browser-profile/
**/browser-profiles/
**/.auth/
**/downloads/
```

Do not ignore source test fixtures generically if the repository already uses a tracked `downloads` fixture folder; narrow the rule if needed.

## Optional documentation changes
Add or merge:
- `docs/GITHUB_REPO_HYGIENE.md`
- `docs/AUDIT_PROTOCOL.md`

## Install/runtime step
From `bossman-core`:

```bash
python -m pip install -e .[dev]
python -m playwright install chromium
pytest
```

On Linux Docker images, system libraries may also be required. Prefer `python -m playwright install --with-deps chromium` in the Docker build when appropriate.

## QA additions
- `docs/EMULATOR_BUGCHECK.md` -> repository docs/runbooks or docs/specs (keep filename)
- `code/bossman-core/tests/test_browser_emulator_e2e.py` -> `bossman-core/tests/test_browser_emulator_e2e.py`
- `scripts/run_browser_bugcheck.sh` -> optional repo `scripts/run_browser_bugcheck.sh`

The emulator gate is mandatory before merge.

## ЭТАП 2.222 — Context & Memory

Added implementation-ready context layer:

- `code/bossman-core/bossman/context_engine/` — full Python package.
- `code/bossman-core/tests/test_context_engine_stage_2_222.py`
- `code/bossman-core/tests/test_compact_plugins.py`
- `docs/stage-2.222/` — architecture, memory policy, quality gates, benchmark, integration guide.
- `skills/compact/SKILL.md` — Compact conversation handoff skill with memory-plugin hydration.
- `scripts/apply_stage_2_222.py` — idempotent copy patcher.

Stage 2.222 is intentionally separate from ComputerUse v1.2 and must be integrated after Stage 1 passes.
