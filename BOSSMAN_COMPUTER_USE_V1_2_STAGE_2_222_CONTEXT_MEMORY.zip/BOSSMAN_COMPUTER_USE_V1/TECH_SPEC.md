# Technical Specification — BOSSMAN ComputerUse v1

## 1. Product intent
Bossman must treat browser control as a **core capability available to every agent**, not as a collection of one-off MCP integrations. Agents should use the normal browser UI when no API/MCP exists or when browser interaction is the most practical route.

Primary stack:
- Python 3.11+
- Playwright async API
- Chromium
- Existing Bossman `ToolDef` / `REGISTRY`
- Existing AgentSpec grants and runner approvals

## 2. Architecture

```text
Natural-language task
        |
        v
Bossman runner / agent loop
        |
        v
Agent tool grants
        |
        v
browser.* tools  <---->  BrowserManager
                         |  one persistent context per agent
                         v
                    Chromium profile
                         |
                  normal website UI
```

The LLM should prefer in this order:
1. Stable DOM selectors / accessible roles.
2. Text labels and element references returned by `browser.observe`.
3. Screenshot/vision fallback when DOM information is insufficient.

Do not make vision mandatory for ordinary pages.

## 3. Tool surface

Required safe/read tools:
- `browser.open(url)` — navigate/open URL.
- `browser.observe()` — current URL/title + compact interactive DOM inventory.
- `browser.extract(selector?)` — extract visible text.
- `browser.screenshot(full_page?)` — save screenshot in agent workspace.
- `browser.wait(ms | text | selector)` — bounded waiting.

Required interaction tools:
- `browser.click(target)` — normal click, but MUST refuse labels associated with high-risk actions.
- `browser.confirmed_click(target)` — same action but routed through Bossman's existing approval because `confirm_default=True`.
- `browser.type(target, text, clear?)` — fill field.
- `browser.press(key)` — keyboard key.
- `browser.select(target, value)` — select option.
- `browser.download(target)` — click and save download into the agent workspace.
- `browser.close()` — close the current agent browser context, not delete its profile.

### Target format
A target can be:
- a CSS selector, e.g. `css=#prompt`
- text, e.g. `text=Generate`
- an element ref emitted by `browser.observe`, e.g. `ref=e12`

`observe` must return stable refs for the current page snapshot only.

## 4. Persistent profiles
Each agent gets a separate Chromium user-data directory:

`<profile_root>/<safe-agent-name>/`

Defaults:
- profile root: `~/.bossman/browser-profiles`
- override: `BOSSMAN_BROWSER_PROFILE_ROOT`
- headless override: `BOSSMAN_BROWSER_HEADLESS=1`

Never store profile data below the Git repository.

## 5. Safety / permissions
Bossman already checks whether a tool is granted and whether it needs confirmation. ComputerUse must build on that mechanism.

### Low/medium risk, no confirmation by default
- navigation
- observation
- text extraction
- screenshots
- waiting
- typing text
- selecting non-sensitive form values
- ordinary non-sensitive clicks
- downloads

### High risk, approval required
Examples include buttons or links whose accessible name/text indicates:
- purchase / buy / checkout / place order
- pay / send money / transfer / withdraw
- authorize / sign / confirm transaction
- delete / permanently remove
- publish / post / send message/email where external communication is committed
- change password / security settings / API keys
- account closure

`browser.click` must block a sensitive label and tell the model to call `browser.confirmed_click` instead. `browser.confirmed_click` must have `confirm_default=True` so the existing runner produces the approval card.

The guard is a safety layer, not a perfect classifier. Agent prompts must additionally state: when uncertain whether an action is externally consequential, choose the confirmed path.

### Website controls
Stop and ask the user instead of bypassing:
- CAPTCHA
- explicit automation block
- rate limit
- subscription/billing wall
- MFA or unexpected login security challenge

## 6. Every-agent policy
Add Browser tools to every current and future agent by default at `load_agent()` time. Suggested config:

```yaml
computer_use: true   # default; may be omitted
```

`computer_use: false` removes the base Browser grants for that agent.

Base grants should include all browser tools, with `browser.confirmed_click` explicitly marked `confirm`.

Do not duplicate the same tool if an agent already declares it manually.

## 7. Long-running jobs
The Browser layer itself must not implement a custom Higgsfield queue. Generic long-running behavior belongs in the normal agent loop.

For tasks lasting longer than the current `timeout_min`, the implementation may require the agent's limits to be raised. Do not disable timeouts globally.

The agent should use bounded waits and periodically re-observe the page rather than sleep for huge intervals.

## 8. Recovery
- Browser profile persists across restarts.
- A browser context may be reopened after worker restart.
- Task recovery remains governed by existing Bossman task state.
- A failed browser action returns a compact tool error; it must not crash the worker.

## 9. Observability
Each browser tool call is already logged by the existing runner in `tool_calls`. Preserve this.

Tool results should be compact:
- current URL/title
- action performed
- selected element identity
- relevant state change
- path of saved screenshot/download where applicable

Do not return full HTML unless explicitly requested.

## 10. Vision
v1 must be useful without multimodal support. Screenshots are saved to disk for vision-capable models or later adapter work.

Follow-up v1.1 can extend `llm.py` to attach the screenshot as an image input when the selected local model supports vision. This should not block v1.

## 11. Performance on Ryzen AI Max+ 395 / 128GB unified memory
Browser automation is lightweight relative to local inference. Keep one persistent Chromium context per actively used agent and avoid unnecessary parallel tabs. Default concurrency target: 1–3 active browser agents, configurable later.

## 12. Acceptance tests
At minimum:
1. Every agent gets Browser grants by default.
2. `computer_use: false` disables them.
3. Duplicate grants are not created.
4. Risk classifier catches representative payment/delete/publish/transfer labels.
5. `browser.click` rejects risky target labels.
6. `browser.confirmed_click` is registered with confirmation required.
7. Profile path is outside repository and isolated by agent.
8. Observe output is bounded.
9. Browser module imports safely when Playwright is installed.
10. Existing tests still pass.
