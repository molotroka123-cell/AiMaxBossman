# BOSSMAN Skills v1

Portable skill pack plus V2 architecture addendum.

Copy `.agents/skills/` into the AiMaxBossman repository root.

OpenCode officially discovers `.agents/skills`, so these skills are intentionally
stored there rather than only in an OpenCode-specific directory.

See `docs/V2_OPENROUTER_MCP_TERMINAL_SKILLS_ADDENDUM.md` for the implementation
instructions for Claude/Fable.
