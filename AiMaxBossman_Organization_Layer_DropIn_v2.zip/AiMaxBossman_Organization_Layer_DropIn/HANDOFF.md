# Handoff

Target stage: **Organization Layer / AI Company**.

This package assumes the preceding Executive OS exists or is being built. Integration should implement only the narrow `ExecutiveOSBridge`; do not duplicate planning, action execution, permission logic, or memory internals in this layer.

Recommended first real organization:

- Engineering: lead, coder, reviewer, QA
- Research: lead, researcher, verifier
- Business/Fresh Vibes: planner, content/SEO executor, reviewer
- Trading: analyst + independent risk reviewer, with execution disabled unless explicitly permitted
- Admin: assistant/operator

The next architectural stage after this package is **Fleet / Distributed Bossman**, where organizations can schedule work across multiple machines/workers.


## Fable autonomy
Before integration read `docs/FABLE_10_INNOVATIONS.md`. Improve/refactor/extend this stage on engineering judgment; record material deviations and validate them.
