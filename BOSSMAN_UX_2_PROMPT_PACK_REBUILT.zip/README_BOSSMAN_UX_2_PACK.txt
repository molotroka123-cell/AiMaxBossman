BOSSMAN UX 2.0 PROMPT PACK

1) BOSSMAN_FABLE5_UX_2_MASTER_PROMPT.md
   Основной мастер-промт для Fable 5:
   - UX 2.0
   - Desktop App
   - Thinking process (safe observability, не raw chain-of-thought)
   - проверка кнопок/функций
   - restart/resume
   - Chromium E2E
   - finish-first
   - ограничения контекста

2) BOSSMAN_MASTER_CONTEXT_ECONOMY_2.md
   Отдельный постоянный контракт экономии контекста:
   - лимиты на чтение/изменения
   - delta-first
   - checkpoint/capsule
   - Fable ProblemBundle
   - cache/cost discipline
   - anti-loop
   - security invariants

Рекомендуемый порядок:
A. Сначала дать исполнителю MASTER_CONTEXT_ECONOMY_2.md как постоянный контракт.
B. Затем дать FABLE5_UX_2_MASTER_PROMPT.md как текущую миссию.
C. Исполнитель обязан сначала fetch remote и продолжить с фактического HEAD.
