# AiMaxBossman — MASTER CONTEXT ECONOMY 2.0
## Persistent contract for GLM / Fable 5 / local agents

Purpose: maximize **verified engineering value per context token and cloud dollar** while preserving correctness, safety, durable continuation and auditability.

This file is intentionally independent of any feature prompt.

---

# 1. Core rule

**READ LESS. PROVE MORE. CHECKPOINT EARLY. ESCALATE WITH COMPACT EVIDENCE.**

Every token should do at least one of:
- remove uncertainty;
- produce a patch;
- verify behavior;
- preserve continuity;
- protect safety.

If it does none of these, do not spend it.

---

# 2. Active context limits

Default atomic work item:

```text
MANAGER_SOFT_CONTEXT = 18k tokens
MANAGER_HARD_CONTEXT = 28k tokens

FABLE_TARGET_INPUT = 10k–12k
FABLE_HARD_INPUT = 16k
FABLE_TARGET_OUTPUT = <= 2.5k
FABLE_HARD_OUTPUT = 4k

LOCAL_SCOUT_TARGET = <= 6k
FINAL_REVIEW_TARGET = <= 14k
FINAL_REVIEW_HARD = 18k
```

These are execution budgets, not claims about model maximum windows.

If a task cannot fit, split it.
Do not blindly raise the cap.

---

# 3. Atomic file budget

Per pass:

```text
DEEP_SOURCE_READS <= 8
FILES_MODIFIED <= 6
FOCUSED_TEST_MODULES <= 2
PRIMARY_ACCEPTANCE_GOALS = 1
```

Checkpoint before expanding scope.

---

# 4. Retrieval order

Use:

```text
fresh HEAD
→ current mission capsule
→ exact failing acceptance/test
→ symbol search
→ narrow relevant excerpt
→ changed hunk/diff
→ direct caller/callee
→ whole file only if necessary
→ broad repository scan only as last resort
```

Before each read ask:
**What exact uncertainty will this read remove?**

If none, do not read.

---

# 5. SHA-keyed summaries

Code summaries are valid only while their source identity remains valid.

Key by:
- tree SHA where useful;
- file blob SHA;
- module/content hash.

If unchanged: reuse the summary.
If changed: read changed hunks first.
Current source always outranks cached summary.

---

# 6. Stable vs volatile context

## Stable/cacheable
- architecture invariants;
- security contract;
- module ownership map;
- coding conventions;
- output schemas;
- tool contracts;
- release definition of done.

## Volatile/delta-only
- current HEAD;
- current diff;
- current failing test;
- runtime state;
- approvals;
- browser state;
- cost ledger;
- latest benchmark;
- newest logs.

Never invalidate a large stable prompt because one volatile fact changed.

---

# 7. Delta-first cloud bundle

Paid model request should normally contain only:

```text
PROBLEM_ID=
GOAL=
HEAD=
TREE_SHA=
FAILURE_FINGERPRINT=
EXPECTED=
ACTUAL=
RELEVANT_INVARIANTS=
RELEVANT_CODE_EXCERPTS=
ATTEMPTS_ALREADY_MADE=
TEST_EVIDENCE=
SECURITY_BOUNDARY=
BUDGET_REMAINING=
REQUIRED_OUTPUT_SCHEMA=
```

No secrets.
No whole repo.
No giant history.
No full logs.
No hidden-CoT request.

---

# 8. Failure fingerprint

Normalize failure into:

```text
acceptance/test id
exception/error class
error code
top relevant frame
module/symbol
critical environment fact
tree SHA
```

If fingerprint is unchanged after a failed attempt:
**do not repeat the same attempt.**

Require new evidence, new hypothesis, different route, escalation, or truthful blocker.

---

# 9. Cheapest competent route

Default:

```text
deterministic search/tool
→ narrow local scout
→ local implementer
→ stronger local reasoning
→ configured cheap cloud worker if justified
→ Fable 5
→ approved fallback only after typed Fable failure
```

Do not use Fable for:
- grep;
- formatting;
- basic rename;
- giant log reading;
- trivial tests;
- mechanical CSS work;
- routine docs.

Use Fable for:
- cross-module root cause;
- architecture;
- security boundary;
- repeated same-fingerprint failure;
- nondeterminism;
- conflicting evidence;
- difficult minimal-safe patch;
- final high-value review.

---

# 10. Fable output contract

Prefer:

```text
DIAGNOSIS=
CONFIDENCE=
ROOT_CAUSE=
KEEP=
CHANGE=
DEFER=
MINIMAL_FILES=
PATCH_PLAN=
DELEGATE_TO_SMALL_AGENT=
TARGETED_TESTS=
SECURITY_RISK=
ROLLBACK=
STOP_CONDITION=
```

Ask for full code only when full code is genuinely the highest-value output.

---

# 11. Output economy

Agents do not narrate full internal thought.

End atomic pass with:

```text
PASS_ID=
HEAD=
CHANGED=
WHY=
TESTS=
VERIFIER=
NEW_EVIDENCE=
BLOCKER=
NEXT=
COST=
```

Keep it compact enough for the next agent to consume cheaply.

---

# 12. Log economy

Store full logs locally.

Give models only:
- failing test name;
- assertion/error;
- error code;
- relevant stack frames;
- usually <= 20–60 surrounding lines;
- exact environment fact.

Do not paste thousands of successful lines.

---

# 13. Test economy

After a patch:

```text
1 exact affected test
2 closest module tests
3 security/restart test if boundary touched
4 subsystem regression at checkpoint
5 full regression near freeze/release
```

Do not run huge regression after every cosmetic edit.

---

# 14. Browser/UI economy

For UI:
- exact page/component first;
- one representative desktop viewport;
- mobile after behavior is correct;
- screenshot only meaningful states;
- console/network failure excerpts only;
- real backend state transition > screenshot.

Avoid redundant screenshots/traces.

---

# 15. Durable continuation capsule

Before context degrades:

```text
MISSION_ID=
HEAD=
TREE_SHA=
CURRENT_GOAL=
DONE=
CURRENT_FAILURE=
FAILURE_FINGERPRINT=
FILES_READ=
FILES_CHANGED=
TESTS_PASS=
TESTS_FAIL=
OPEN_P0=
OPEN_P1=
OPEN_P2=
NEXT_EXACT_ACTION=
DO_NOT_REREAD=
CLOUD_USED=
CLOUD_REMAINING=
CONTEXT_PRESSURE=LOW|MEDIUM|HIGH
```

New context resumes from capsule.
Do not replay the whole conversation.

---

# 16. DO_NOT_REREAD list

Every capsule should include unchanged materials the next agent should not reread.

Example:

```text
DO_NOT_REREAD=
- architecture summary blob unchanged
- approval contract unchanged
- router API unchanged
- full test log already reduced to fingerprint
```

---

# 17. Prompt cache

Stable prompt-cache key should include at least:

```text
provider
model
prompt_contract_version
stable_architecture_hash
security_contract_hash
tool_schema_hash
```

Do not key only by mission id.

Track real:
- input tokens;
- cache write tokens;
- cache read tokens;
- output tokens;
- cost.

Never claim cache savings without observed cache-read evidence.

---

# 18. Cost reservation

Before a paid call reserve conservative worst-case cost.

Persist:

```text
reservation_id
provider
model
task_id
reason
worst_case_usd
actual_usd
status
input_tokens
cache_write_tokens
cache_read_tokens
output_tokens
```

Failed/cancelled calls release reservation safely.
Crash/uncertain in-flight state fails conservative.
Never silently leak reservations.

---

# 19. Batch only independent work

Good parallel work:
- independent scouts;
- review hypotheses;
- accessibility scan;
- test-design alternatives;
- security review;
- static route inventory.

Bad parallel work:
- multiple writers on same mutable module;
- sequential browser state;
- approvals;
- dependent git operations;
- edit/test loops sharing state.

High-risk merge stays serial:

```text
patch → targeted test → independent verifier → commit
```

---

# 20. Context pressure modes

## LOW
Normal focused work.

## MEDIUM
- stop broad audit;
- delta reads only;
- defer P2;
- checkpoint more often.

## HIGH
- stop new discovery;
- persist capsule;
- finish mandatory verification;
- compact context;
- route mechanical work to small/local agents;
- preserve final review/report reserve.

Do not wait for overflow.

---

# 21. Anti-loop rule

Forbidden:

```text
audit → plan → audit → new plan → architecture rewrite proposal
```

without production execution.

Every analysis phase must end in:

```text
PATCH
TEST
VERIFIED_NO_CHANGE
BLOCKED
DEFERRED
```

---

# 22. Security never compresses away

Never weaken for token/time savings:
- owner approval;
- authorization;
- nonce/replay protection;
- idempotency;
- durable side-effect ledger;
- credential redaction;
- teacher sandbox;
- independent verifier;
- real-vs-sim evidence labeling;
- protected-path rules.

A skipped security failure is not PASS.

---

# 23. Owner-visible Thinking process policy

`Thinking process` may expose only safe operational telemetry.

Allowed:
- phase;
- task;
- agent/model;
- tool/action;
- elapsed time;
- wait reason;
- retry;
- blocker;
- last verified result;
- next action summary.

Forbidden:
- hidden chain-of-thought;
- private scratchpad;
- provider internal reasoning tokens;
- system/developer prompts;
- API keys;
- credentials;
- raw auth/session data.

Observability should reduce uncertainty without increasing prompt/context leakage.

---

# 24. Finish-first resource reserve

Never spend the entire context/cloud budget during discovery.

Reserve enough for:
- targeted verification;
- independent verifier;
- final regression;
- final compact Fable review;
- checkpoint;
- final report.

If resources tighten:

```text
cut P2
→ stop broad discovery
→ preserve P0/P1 verification
→ finish
```

---

# 25. Stop rule

If current evidence cannot support a verified improvement:
STOP and name the exact missing evidence.

Do not fill context with speculation.

---

# 26. Final principle

**Context is not a warehouse. It is a working set. Keep only what the next verified action needs.**
