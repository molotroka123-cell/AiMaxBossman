# BOSSMAN UX 2.0 — FABLE 5 MASTER IMPLEMENTATION PROMPT

## Mission
Turn the existing AiMaxBossman Command Center into an owner-grade **BOSSMAN Desktop App / Command Center 2.0**: visually coherent, fast, observable, safe, keyboard-friendly, fully clickable, and verified end-to-end.

Repository: `molotroka123-cell/AiMaxBossman`  
Branch: `claude/bossman-control-v03-43igbk`  
Last externally verified remote HEAD when this prompt was created: `272e74955bbcc3bc8aee13e6d711843894cd306e`

**Fetch remote first. If HEAD moved, continue from the newest valid remote HEAD. Do not reset valid later work just to match this prompt.**

This is an implementation mission, not another broad audit.

---

# 1. Product goal

The owner must be able to:

```text
Double-click BOSSMAN
→ app opens as a normal desktop application
→ backend readiness is detected automatically
→ current mission/state appears immediately
→ all important functions are callable visually
→ long-running work is observable
→ optional Thinking process shows whether Bossman is working or stuck
→ risky actions still require proper approval
→ closing/reopening UI does not destroy durable missions
```

The final experience should feel like a serious premium local-AI operating console, not a raw admin panel and not a decorative mockup.

Primary owner language: Russian.

---

# 2. UX 2.0 reference principles

Do **not** copy another product's visual identity. Borrow only proven interaction principles.

Use the best ideas from modern productivity/AI desktop products:

### Raycast-style principles
- `Ctrl/Cmd + K` command/action palette;
- contextual actions instead of hidden functionality;
- clear primary/secondary/destructive action hierarchy;
- keyboard-first discoverability;
- actions grouped by context.

### Linear-style principles
- very fast navigation;
- progressive disclosure;
- compact information density without clutter;
- contextual detail/peek surfaces instead of opening full pages for every detail;
- strong state/progress visibility;
- one consistent component language across the product.

### Modern AI desktop-app principles
- standalone desktop window;
- optional compact companion/quick-control window;
- reopen last useful state;
- clear model/tool execution status;
- app remains useful while another app is in focus;
- configurable global shortcut if safe and non-conflicting.

### BOSSMAN-specific principle
The app is not primarily a chat UI. It is a **mission/control/work execution system**.
Therefore the hierarchy must prioritize:

```text
Mission → Current task → Agent/model → Action/state → Verification → Owner decision
```

not conversation bubbles.

---

# 3. Preserve existing work

The current Command Center already has a shared owner-facing UX layer and a PWA foundation.

Preserve and extend the existing:
- `theme.css`;
- current `bx-*` primitives;
- `_ui.js` helpers;
- Russian status mapping;
- existing routes/pages;
- existing backend contracts;
- current manifest/PWA behavior;
- owner approvals;
- durable mission state;
- auth/idempotency/safety boundaries.

Do not replace the working UI stack with a second design system unless a concrete blocker proves it necessary.

Do not re-redesign pages that are already good merely for aesthetic novelty.

---

# 4. Hard context limits

Context is a hard engineering budget.

## Manager / implementation pass

```text
SOFT_ACTIVE_CONTEXT = 18k tokens
HARD_ACTIVE_CONTEXT = 28k tokens
```

## Fable 5 focused call

```text
TARGET_INPUT = 10k–12k tokens
HARD_INPUT = 16k tokens
TARGET_OUTPUT = <= 2.5k tokens
HARD_OUTPUT = 4k tokens
```

## Final Fable review

```text
TARGET_INPUT = <= 14k tokens
HARD_INPUT = 18k tokens
TARGET_OUTPUT = <= 2.5k tokens
```

## Local/small scouts

```text
TARGET_CONTEXT = <= 6k tokens each
```

## Per atomic pass

```text
DEEP_SOURCE_FILES <= 8
FILES_MODIFIED <= 6
FOCUSED_TEST_MODULES <= 2
PRIMARY_ACCEPTANCE_GOALS = 1
```

Do not solve context pressure by simply increasing the context window.
Split the work.

Never paste into a model unless needed:
- whole repository tree;
- complete historical logs;
- entire successful test output;
- unchanged source files;
- full browser traces;
- whole JSON evidence bundles;
- secrets / `.env`;
- raw hidden reasoning.

Use:

```text
search → symbol → relevant hunk → direct dependency → failing evidence → patch
```

---

# 5. Fable usage policy

Fable 5 is the senior UX/architecture reviewer, not the mechanical worker.

Use Fable for:
- Desktop App packaging choice;
- observability/event contract;
- state/reconnect/stall design;
- difficult cross-module UI→backend wiring;
- security-sensitive approval UX;
- final senior review.

Use local/smaller agents for:
- route inventory;
- button inventory;
- translation consistency;
- CSS migration;
- accessibility checks;
- screenshot capture;
- test scaffolding;
- documentation tables;
- repetitive page conversions.

Do not burn Fable tokens on grep, formatting, trivial renames, or giant logs.

For this UX mission, preserve the broader cloud reserve. Default:

```text
UX_FABLE_DISCOVERY/ARCHITECTURE <= $1.00
UX_FABLE_HARD_PROBLEMS <= $0.75
UX_FABLE_FINAL_REVIEW <= $0.75
UX_FABLE_HARD_CAP <= $2.50
```

If the existing mission has a lower remaining allowance, respect the lower allowance.
Do not spend the full broader $9 mission budget on UX polish.

---

# 6. Mandatory checkpoint capsule

After every verified atomic change, persist a compact continuation capsule:

```text
MISSION_ID=UX-DESKTOP-2-001
HEAD=
TREE_SHA=
CURRENT_PHASE=
DONE=
CURRENT_WORK_ITEM=
FILES_READ=
FILES_CHANGED=
TARGETED_TESTS=
LAST_VERIFIED_RESULT=
OPEN_P0=
OPEN_P1=
OPEN_P2=
LAST_FAILURE_FINGERPRINT=
NEXT_EXACT_ACTION=
DO_NOT_REREAD=
CLOUD_COST=
CONTEXT_PRESSURE=LOW|MEDIUM|HIGH
```

If context rotates, resume from this capsule without owner re-prompt.

---

# 7. Visual system — BOSSMAN UX 2.0

Keep the existing dark BOSSMAN identity but make it more refined.

Desired feel:
- graphite/obsidian base;
- restrained violet/indigo/cyan accents;
- very subtle elevation;
- strong typography hierarchy;
- compact cards but generous click targets;
- clear status hierarchy;
- minimal decorative animation;
- serious, premium, technical;
- not “gaming RGB”; not generic SaaS dashboard.

Use visual emphasis only for:
- active mission;
- owner-required action;
- blocker/error;
- active execution;
- verified completion;
- destructive action.

Support reduced motion.
Do not keep GPU busy for decorative animation.

---

# 8. Finish currently uneven pages

Inspect current HEAD first.
Deeply finish owner-visible pages that still use visibly older/flat UI.

Priority candidates:
1. Models
2. Tasks
3. Skills
4. Mission/Workflow Builder
5. Images
6. any other owner-critical screen still inconsistent

Use the existing shared primitives:
- `bx-pagehead`
- `bx-panel`
- `bx-tile`
- `bx-pill`
- `bx-stat`
- `bx-meter`
- `bx-blank`
- existing tokenized theme

Do not duplicate component logic page-by-page.

---

# 9. Desktop application

BOSSMAN must launch like a normal application, not require the owner to manually open a browser URL.

Required flow:

```text
double-click BOSSMAN icon
→ launcher checks local backend health
→ if backend is already running: reuse it
→ otherwise start supported local backend exactly once
→ wait for readiness
→ open standalone BOSSMAN window
→ restore recent owner UI state
```

Requirements:
- app icon;
- standalone desktop window;
- no browser chrome in normal app mode;
- no duplicate backend process;
- readiness/health check;
- understandable startup state;
- understandable startup failure;
- reconnect after backend restart;
- UI close must not kill durable mission by default;
- no automatic admin privilege;
- no hidden remote exposure;
- browser/PWA route remains available;
- Windows is first-class target for the owner's ACEMAGIC.

## Packaging decision

Inspect the actual stack before choosing.
Prefer the smallest safe solution:

1. current installable PWA if it fully meets launch needs;
2. tiny local launcher around current web UI/backend;
3. lightweight WebView/Tauri-style wrapper only if needed.

Do **not** add Electron by default.
Do not add a huge runtime for cosmetic reasons.

Create:
`docs/ui/DESKTOP_APP_PACKAGING.md`

Document:
- chosen approach;
- startup process;
- backend ownership semantics;
- Windows packaging;
- browser/PWA fallback;
- rollback/uninstall.

---

# 10. Optional Quick BOSSMAN window

If achievable cheaply and safely, add a compact companion/quick-control window inspired by good desktop AI tools.

It should open via a configurable global shortcut, with conflict detection.
Do not hard-code a shortcut that may conflict with another app.

Quick window should show only:
- active mission;
- current task;
- current state;
- pending owner approval;
- pause/resume where safe;
- open full Command Center;
- open Thinking process.

This is optional P1, not a release blocker if it threatens completion.

---

# 11. Thinking process — exact owner-facing title

Add an optional expandable panel titled exactly:

# Thinking process

The owner wants to open it and quickly understand whether Bossman is really working or lagging.

This is **execution observability**, not a raw chain-of-thought viewer.

## Allowed event fields

```text
timestamp
mission_id
task_id
phase
agent
model
route_reason_summary
state
tool/action
elapsed_ms
attempt
last_verified_result
wait_reason
next_action_summary
last_event_age_ms
```

## Human-readable states

```text
thinking          → думает
tool              → выполняет действие
waiting_model     → ждёт модель
waiting_tool      → ждёт инструмент
waiting_owner     → ждёт вашего решения
verifying         → проверяет
retrying          → повторяет после ошибки
blocked           → заблокировано
possibly_stalled  → возможно завис
disconnected      → нет связи
complete          → готово
```

If a provider returns a safe user-facing explanation, show it as:

**Reasoning summary**

and keep it short.

## NEVER display

- raw hidden chain-of-thought;
- private scratchpad;
- internal reasoning tokens;
- system/developer prompts;
- full hidden prompts;
- credentials;
- API keys;
- auth headers;
- cookies;
- `.env`;
- private provider/session internals;
- unredacted sensitive user data.

---

# 12. Thinking process — no-lag architecture

Collapsed by default.
Remember owner preference locally.

Requirements:
- expand/collapse immediately;
- recent bounded event buffer;
- target 300–500 recent events max in active UI memory;
- older events lazy-loaded/paginated;
- coalesce repetitive heartbeat/status events;
- incremental rendering;
- no whole-dashboard rerender per event;
- no token-by-token hidden reasoning stream;
- no unbounded DOM growth;
- reconnect with bounded exponential backoff;
- hydrate recent durable events after reconnect;
- display `last update X sec ago`;
- display current operation elapsed time;
- display mission elapsed time;
- display current model/agent;
- display known long-running operation status.

Choose SSE/WebSocket only if it naturally fits current architecture.
Otherwise use efficient bounded polling.
Do not invent a large realtime subsystem solely for this panel.

---

# 13. Real stall/liveness detection

No fake spinner as proof of progress.

Use real signals:

```text
ACTIVE
recent manager/tool/model activity exists

WAITING
backend reports a known wait condition

LONG_RUNNING
backend reports a known active long operation with start timestamp

POSSIBLY_STALLED
heartbeat/activity stale beyond threshold AND no known healthy long operation

DISCONNECTED
frontend cannot reach backend

BLOCKED
backend reports a typed blocker
```

Do not label a legitimate 3-minute local model inference “stuck” if backend says it is still active.

Allow thresholds to be configured.

---

# 14. Mission Control home — answer in 10 seconds

The owner should be able to glance at Home and know:

- What is Bossman doing?
- Is it alive?
- What mission is active?
- What step is active?
- Which agent/model is working?
- Why was that route chosen?
- Is it blocked?
- Is it waiting for owner input?
- What has been verified?
- How much cloud budget is used?
- Are CPU/RAM/GPU resources under pressure?

Surface:

```text
Current mission
Current phase
Current atomic task
Progress
Agent
Model
Route reason
Last verified action
Blocker
Pending approval
Cloud spend / hard cap
Prompt-cache read/hit summary where available
CPU / RAM / GPU pressure
Backend connection
Thinking process toggle
```

Keep advanced technical data collapsible.

---

# 15. Contextual detail / Peek

Use progressive disclosure.

For missions/tasks/agents/models, prefer a fast side panel / details drawer / peek surface for common inspection instead of forcing full navigation for every detail.

Owner should be able to inspect:
- status;
- last action;
- resources;
- logs summary;
- actions;
- blocking reason;
without losing context.

Do not implement this if the existing architecture already has an equivalent.

---

# 16. Command Palette

Add a lightweight command/action palette if absent.

Shortcut:
`Ctrl/Cmd + K`

Suggested commands:
- Главная
- Миссии
- Новая миссия
- Агенты
- Модели
- Задачи
- Браузер
- Терминал
- Навыки
- Ждут решения
- Система
- Ресурсы
- Открыть Thinking process

Contextual selection may expose safe relevant actions.
Destructive actions must be visibly destructive.

The command palette must NEVER bypass backend approval/auth rules.

---

# 17. Full visual function access

Normal owner operation must not require CLI.

Verify/add visual invocation for:
- create mission;
- start mission;
- pause mission;
- resume mission;
- stop mission;
- assign task to agent;
- create/edit agent;
- model selection/router visibility;
- model connectivity test;
- skill run;
- skill assign;
- skill clone/export;
- browser open;
- browser take-over;
- browser return to agent;
- browser close;
- terminal preview;
- terminal run;
- terminal stop;
- approval allow;
- approval reject;
- task retry;
- healing/recovery status;
- resource policy;
- mission/workflow builder run;
- image generation entry;
- benchmark status;
- release readiness;
- system health;
- durable mission resume.

If backend functionality does not actually exist, do not create a fake green button.
Show a truthful unavailable state and record the gap.

---

# 18. Button Truth Matrix

Every primary owner-facing button must pass:

```text
click
→ UI request/action
→ backend authorization/policy
→ backend acknowledgement
→ real state transition
→ fresh state retrieval
→ correct visible UI update
```

A DOM click handler firing is not proof.

Create:
`docs/ui/OWNER_ACTION_MATRIX.md`

Columns:

```text
screen
control
backend action/endpoint
authorization/approval
expected transition
test
real verification
status
```

Test important negatives:
- duplicate click;
- stale UI state;
- unauthorized/forbidden;
- pending approval;
- backend unavailable;
- reconnect and retry.

---

# 19. Approval UX

For risky actions show:
- what will happen;
- requesting agent;
- target;
- scope;
- why approval is required;
- reversibility if known;
- expiry if applicable.

Buttons:
- Разрешить
- Отклонить

Never weaken:
- nonce validation;
- replay protection;
- digest binding;
- expiry;
- durable approval state.

---

# 20. Restart / resume acceptance

Perform one real safe restart flow.

1. Start a safe mission.
2. Observe it in UI.
3. Record mission_id.
4. Perform one supported manager/backend restart.
5. UI must truthfully show disconnect/reconnecting.
6. Backend returns.
7. UI reconnects.
8. Same mission_id resumes.
9. Thinking process hydrates recent durable events.
10. No duplicate side effect.
11. Owner does not recreate/re-prompt the mission.

Acceptance:
`UX-RESTART-RESUME-001`

---

# 21. Desktop + mobile real Chromium acceptance

Use real Chromium/Playwright where available.

Desktop viewport:
~1580px

Mobile viewport:
~390px

Verify:
- all owner-critical pages open;
- 0 console errors on mandatory owner flow;
- no important clipping;
- no accidental horizontal overflow;
- touch targets >=44px;
- navigation usable;
- command palette usable;
- Thinking process usable;
- approvals usable;
- 500-event Thinking process remains responsive;
- reconnect state understandable;
- supported light theme not broken.

Screenshots are supporting evidence, not the test itself.

Save final screenshots as durable artifacts, not only `/tmp` files.

---

# 22. Performance / lag evidence

Expose compact measurements where safely available:

```text
last_event_age_ms
current_operation_elapsed_ms
mission_elapsed_ms
backend_response_latency_ms
queue health/length if already exposed safely
model_request_elapsed_ms
reconnect state
```

Test Thinking process with ~500 events.

Record measured behavior:
- expand/collapse responsiveness;
- event update responsiveness;
- bounded DOM/list size;
- reconnect behavior;
- CPU/memory regression if measurable cheaply.

Do not fabricate universal millisecond thresholds across hardware.
Report observed measurements.

---

# 23. Accessibility

Requirements:
- semantic buttons;
- keyboard navigation;
- visible focus;
- accessible labels;
- status word + icon/color, not color alone;
- destructive actions clearly distinguished;
- no untranslated primary owner action;
- reduced-motion support;
- sufficient contrast.

---

# 24. App icon integration

A new BOSSMAN master icon is supplied with this mission.

Treat the largest generated icon as canonical design source.
Derive:
- 1024x1024 master;
- 512x512 PNG;
- 192x192 PNG;
- favicon;
- maskable-safe PWA asset;
- Windows multi-size `.ico` if packaging requires it.

Keep safe padding for OS masks.
Do not stretch low-resolution assets.

---

# 25. Independent security verifier

Any change touching:
- approvals;
- terminal;
- browser control;
- auth;
- durable mission state;
- desktop process startup;
- Thinking process telemetry;
- logs;
- model route metadata;
requires independent verification by a role/agent that did not author the high-risk change.

Verifier checks:
- no secret leakage;
- no raw CoT leakage;
- no auth bypass;
- no approval bypass;
- no duplicate side effect;
- no arbitrary-command launcher hole;
- no accidental LAN/Internet exposure;
- telemetry bounded/redacted;
- restart correct;
- tests real.

---

# 26. Test economy

Use:

```text
1. syntax/static check
2. exact affected unit test
3. nearest Command Center module tests
4. action-contract/security tests if touched
5. real target-page Chromium test
6. restart/reconnect E2E
7. full Command Center regression near final
8. whole-project release regression only when current freeze process requires it
```

Do not run 1500+ tests after each CSS/text patch.

---

# 27. Required artifacts

Create/update:

```text
docs/ui/OWNER_ACTION_MATRIX.md
docs/ui/THINKING_PROCESS_OBSERVABILITY.md
docs/ui/DESKTOP_APP_PACKAGING.md
docs/ui/FINAL_UX_ACCEPTANCE.md
docs/ui/POST_RELEASE_UX_BACKLOG.md
```

`THINKING_PROCESS_OBSERVABILITY.md` must define:
- public event schema;
- redaction;
- bounded retention;
- liveness states;
- stall detection;
- reconnect;
- why raw chain-of-thought is intentionally not exposed.

`FINAL_UX_ACCEPTANCE.md` must include:

```text
FINAL_HEAD=
TREE_SHA=
DESKTOP_APP=
PACKAGING=
PAGES_TESTED=
DESKTOP_VIEWPORT=
MOBILE_VIEWPORT=
CONSOLE_ERRORS=
OWNER_ACTIONS_TOTAL=
OWNER_ACTIONS_PASS=
OWNER_ACTIONS_FAIL=
THINKING_PROCESS=
500_EVENT_RESPONSIVENESS=
STALL_DETECTION=
RECONNECT=
RESTART_RESUME=
SAME_MISSION_ID=
DUPLICATE_SIDE_EFFECTS=
SECURITY_VERIFIER=
KNOWN_BLOCKERS=
READY_FOR_OWNER_USE=
```

---

# 28. Atomic commit discipline

Prefer atomic commits such as:

```text
ui(command-center): finish BOSSMAN UX 2.0 visual system
feat(command-center): add safe Thinking process observability
feat(command-center): add desktop app launch and reconnect UX
test(command-center): verify owner actions and restart durability
docs(command-center): record UX 2.0 acceptance
```

For high-risk changes:

```text
patch → targeted tests → independent verifier → commit
```

Do not hold many unrelated verified patches uncommitted.

---

# 29. Finish-first stop condition

Do not create an endless redesign.

Stop optional UX discovery once:
- owner-critical pages are coherent;
- Desktop App works;
- primary actions are visually callable and truth-tested;
- Thinking process is safe and responsive;
- restart/reconnect is proven;
- no UX/security P0/P1 remains.

Move P2 polish to:
`docs/ui/POST_RELEASE_UX_BACKLOG.md`

Never sacrifice final verification/checkpoint to cosmetic polish.

---

# 30. Definition of done

Do not say DONE until applicable items are true:

- fresh remote HEAD verified;
- existing working UX preserved;
- remaining old-looking critical pages finished;
- BOSSMAN launches as a desktop app;
- browser/PWA still works;
- no duplicate backend process;
- backend readiness handled;
- visual access exists for key functions;
- primary buttons trigger verified real state transitions;
- command palette works;
- Thinking process exists and is optional/collapsed by default;
- Thinking process shows real liveness/state;
- raw chain-of-thought is NOT exposed;
- secrets are NOT exposed;
- event list is bounded;
- ~500 events remain responsive;
- stall detection is evidence-based;
- reconnect works;
- deliberate restart resumes same mission_id;
- no duplicate side effect;
- real desktop Chromium passes;
- real mobile Chromium passes;
- mandatory owner flow has 0 console errors;
- independent security verifier passes;
- durable artifacts committed;
- final HEAD pushed;
- continuation capsule updated.

---

# 31. Final Fable 5 review

Reserve one compact final review.

Give Fable only:
- final diff summary;
- OWNER_ACTION_MATRIX summary;
- Desktop App packaging summary;
- Thinking process event/redaction contract;
- restart/reconnect evidence;
- security verifier result;
- browser acceptance summary;
- remaining P1/P2;
- observed performance.

Ask only:

```text
Find issues important enough to block READY_FOR_OWNER_USE
or a very small change with unusually high value.
Do not invent optional redesign work.
Return: BLOCK | FIX_NOW | DEFER | NO_CHANGE_JUSTIFIED.
```

If `NO_CHANGE_JUSTIFIED`, stop asking.

---

# 32. Final response — exact compact format

```text
FINAL_HEAD=
COMMITS=
DESKTOP_APP=
PACKAGING=
PAGES_VERIFIED=
OWNER_ACTIONS_PASS=
OWNER_ACTIONS_FAIL=
THINKING_PROCESS=
CONTEXT_MAX_OBSERVED=
FABLE_COST_USD=
RESTART_RESUME=
SAME_MISSION_ID=
DUPLICATE_SIDE_EFFECTS=
CONSOLE_ERRORS=
SECURITY_VERIFIER=
BLOCKERS=
READY_FOR_OWNER_USE=
```

Do not answer with another broad plan.
Implement, verify, checkpoint, finish.
