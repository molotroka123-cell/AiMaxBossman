# AI 3D Maker — App #2

Target printer: ELEGOO Neptune 3 Plus.
Primary mode: precision mechanical CAD for real FDM printing.
Secondary mode: generative/sculptural mesh workflow.

This ZIP is intentionally separate from BOSSMAN V2.2 foundation closure.
Do not wire it into the canonical App Runtime until that audit says CLOSED.

Verified official Neptune 3 Plus limits used in this seed:
- FDM
- build volume: 320 × 320 × 400 mm
- PEI platform area: 330 × 330 mm
- stock nozzle: 0.4 mm
- maximum nozzle temperature: 260 °C
- maximum bed temperature: 100 °C
- transfer: TF card / USB cable
- manufacturer model formats: STL / OBJ
- manufacturer lists PLA / TPU / PETG / ABS / ASA

For dimension-critical objects, AI must produce a structured DesignSpec first,
then deterministic CAD, validation, slicing and G-code inspection.

For figurines/decor, a generative mesh is allowed, but it still must pass
repair/printability checks.

Read `MASTER_PROMPT_FOR_CLAUDE.md` next.
