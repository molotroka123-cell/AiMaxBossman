from dataclasses import dataclass,asdict
from pathlib import Path
import json

@dataclass(slots=True)
class CalibrationProfile:
    id:str
    printer_profile_id:str
    material:str
    nozzle_mm:float
    layer_height_mm:float
    measured_process_tolerance_mm:float
    xy_scale:float=1.0
    z_scale:float=1.0
    hole_compensation_mm:float=0.0
    note:str=""

    def save(self,path):
        Path(path).write_text(json.dumps(asdict(self),indent=2),encoding="utf-8")

    @classmethod
    def load(cls,path):
        return cls(**json.loads(Path(path).read_text(encoding="utf-8")))

def scale_from_coupon(nominal_mm,measured_mm):
    if nominal_mm<=0 or measured_mm<=0: raise ValueError("positive dimensions required")
    return nominal_mm/measured_mm

def suggest_xy_scale(nx,mx,ny,my):
    return (scale_from_coupon(nx,mx)+scale_from_coupon(ny,my))/2
