from dataclasses import dataclass,asdict
import re
from .profile import PrinterProfile

_PARAM=re.compile(r"([A-Za-z])([-+]?(?:\d+(?:\.\d*)?|\.\d+))")

@dataclass(slots=True)
class GCodeIssue:
    severity:str
    line:int
    message:str
    command:str

BLOCKED={
    "M500":"writes EEPROM/settings",
    "M501":"reloads EEPROM/settings",
    "M502":"factory reset/settings reset",
    "M997":"firmware update/reboot style command",
}

def params(line):
    out={}
    for k,v in _PARAM.findall(line):
        try: out[k.upper()]=float(v)
        except ValueError: pass
    return out

def scan_gcode(text:str,profile:PrinterProfile,strict_unknown=False):
    issues=[]
    pos={"X":0.0,"Y":0.0,"Z":0.0,"E":0.0}
    abs_xyz=True; abs_e=True
    max_seen=dict(pos); min_seen=dict(pos)
    allowed={"G0","G1","G2","G3","G4","G28","G90","G91","G92",
             "M82","M83","M84","M104","M105","M106","M107","M109",
             "M117","M140","M190","M220","M221","M400","M420"}
    for n,raw in enumerate(text.splitlines(),1):
        code=raw.split(";",1)[0].strip()
        if not code: continue
        cmd=code.split()[0].upper()
        if cmd in BLOCKED:
            issues.append(GCodeIssue("ERROR",n,BLOCKED[cmd],cmd)); continue
        if cmd=="G90": abs_xyz=True
        elif cmd=="G91": abs_xyz=False
        elif cmd=="M82": abs_e=True
        elif cmd=="M83": abs_e=False
        p=params(code)
        if cmd in {"M104","M109"} and p.get("S",0)>profile.max_nozzle_temp:
            issues.append(GCodeIssue("ERROR",n,
                f"Nozzle target {p['S']}C exceeds {profile.max_nozzle_temp}C",cmd))
        if cmd in {"M140","M190"} and p.get("S",0)>profile.max_bed_temp:
            issues.append(GCodeIssue("ERROR",n,
                f"Bed target {p['S']}C exceeds {profile.max_bed_temp}C",cmd))
        if cmd in {"G0","G1"}:
            olde=pos["E"]
            for a in "XYZ":
                if a in p: pos[a]=p[a] if abs_xyz else pos[a]+p[a]
            if "E" in p: pos["E"]=p["E"] if abs_e else pos["E"]+p["E"]
            extrusion=pos["E"]>olde+1e-9
            if extrusion:
                for a,limit in {"X":profile.build_x,"Y":profile.build_y,"Z":profile.build_z}.items():
                    if pos[a]<-1e-6 or pos[a]>limit+1e-6:
                        issues.append(GCodeIssue("ERROR",n,
                            f"Extrusion move {a}={pos[a]:g} outside 0..{limit:g} mm",cmd))
            for a in max_seen:
                max_seen[a]=max(max_seen[a],pos[a]); min_seen[a]=min(min_seen[a],pos[a])
        if strict_unknown and (cmd.startswith("G") or cmd.startswith("M")) and cmd not in allowed:
            issues.append(GCodeIssue("WARNING",n,"Unknown command in strict mode",cmd))
    return {
        "status":"FAILED" if any(x.severity=="ERROR" for x in issues) else "PASS",
        "issues":[asdict(x) for x in issues],
        "min_seen":min_seen,"max_seen":max_seen
    }
