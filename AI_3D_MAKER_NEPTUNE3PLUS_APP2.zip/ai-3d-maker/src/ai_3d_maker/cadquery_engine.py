from __future__ import annotations
from pathlib import Path
from .spec import DesignSpec

def available():
    try:
        import cadquery
        return True
    except Exception:
        return False

def build(spec: DesignSpec):
    import cadquery as cq
    result=None
    for f in spec.features:
        p=f.primitive
        if p.kind=="box":
            x,y,z=p.size_mm
            solid=cq.Workplane("XY").box(x,y,z,centered=(p.center,p.center,p.center))
        else:
            d,h=p.size_mm
            solid=cq.Workplane("XY").circle(d/2).extrude(h,both=p.center)
        rx,ry,rz=f.transform.rotate_deg
        if rx: solid=solid.rotate((0,0,0),(1,0,0),rx)
        if ry: solid=solid.rotate((0,0,0),(0,1,0),ry)
        if rz: solid=solid.rotate((0,0,0),(0,0,1),rz)
        tx,ty,tz=f.transform.translate_mm
        if tx or ty or tz: solid=solid.translate((tx,ty,tz))
        if result is None:
            if f.operation=="cut": raise ValueError("first feature cannot be cut")
            result=solid
        elif f.operation=="add": result=result.union(solid)
        else: result=result.cut(solid)
    return result

def export(spec: DesignSpec, step_path: Path, stl_path: Path):
    import cadquery as cq
    obj=build(spec)
    cq.exporters.export(obj,str(step_path))
    cq.exporters.export(obj,str(stl_path))
    return {"step":str(step_path),"stl":str(stl_path)}
