from __future__ import annotations
from enum import StrEnum
from typing import Literal
from pydantic import BaseModel, Field, model_validator

class FitIntent(StrEnum):
    NONE="none"
    CLEARANCE="clearance"
    SLIDING="sliding"
    PRESS="press"

class Primitive(BaseModel):
    id: str = Field(min_length=1, max_length=80)
    kind: Literal["box","cylinder"]
    size_mm: list[float] = Field(min_length=2, max_length=3)
    center: bool = False

    @model_validator(mode="after")
    def validate_dims(self):
        if any(v <= 0 for v in self.size_mm):
            raise ValueError("dimensions must be positive")
        if self.kind == "box" and len(self.size_mm) != 3:
            raise ValueError("box needs x,y,z")
        if self.kind == "cylinder" and len(self.size_mm) != 2:
            raise ValueError("cylinder needs diameter,height")
        return self

class Transform(BaseModel):
    translate_mm: list[float] = [0.0,0.0,0.0]
    rotate_deg: list[float] = [0.0,0.0,0.0]

class Feature(BaseModel):
    primitive: Primitive
    transform: Transform = Transform()
    operation: Literal["add","cut"]="add"

class ManufacturingIntent(BaseModel):
    material: str = "PLA"
    required_tolerance_mm: float | None = None
    fit_intent: FitIntent = FitIntent.NONE
    supports_allowed: bool = True
    preferred_orientation: str = "auto"

class DesignSpec(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    units: Literal["mm"]="mm"
    features: list[Feature] = Field(min_length=1)
    manufacturing: ManufacturingIntent = ManufacturingIntent()
    critical_dimensions: dict[str,float] = {}
    assumptions: list[str] = []
    unresolved_questions: list[str] = []

    @model_validator(mode="after")
    def unique_ids(self):
        ids=[f.primitive.id for f in self.features]
        if len(ids) != len(set(ids)):
            raise ValueError("feature ids must be unique")
        return self
