import asyncio
from pathlib import Path

async def curaengine_slice(stl_path:Path,gcode_path:Path,*,definition_path:str,
                           curaengine_bin="CuraEngine",settings=None,timeout=180):
    if not definition_path:
        return {"ok":False,"status":"NOT_RUN","error":"real Cura definition path required"}
    cmd=[curaengine_bin,"slice","-v","-j",definition_path,"-l",str(stl_path),"-o",str(gcode_path)]
    for k,v in (settings or {}).items(): cmd+=["-s",f"{k}={v}"]
    try:
        p=await asyncio.create_subprocess_exec(*cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
    except FileNotFoundError:
        return {"ok":False,"status":"NOT_RUN","error":f"{curaengine_bin} not installed"}
    try:
        out,err=await asyncio.wait_for(p.communicate(),timeout)
    except asyncio.TimeoutError:
        p.kill(); await p.communicate()
        return {"ok":False,"status":"FAILED","error":"slicer timeout"}
    ok=p.returncode==0 and gcode_path.is_file()
    return {"ok":ok,"status":"PASS" if ok else "FAILED",
            "stdout":out.decode(errors="replace")[-2500:],
            "stderr":err.decode(errors="replace")[-2500:]}
