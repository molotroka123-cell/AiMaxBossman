from dataclasses import dataclass
from .spec import DesignSpec

@dataclass(slots=True)
class RequirementGate:
    ready: bool
    status: str
    questions: list[str]
    warnings: list[str]

def evaluate_requirements(spec: DesignSpec, calibrated_tolerance_mm: float | None = None):
    q=list(spec.unresolved_questions)
    w=[]
    req=spec.manufacturing.required_tolerance_mm
    if req is not None:
        if req <= 0:
            q.append("Required tolerance must be positive.")
        elif calibrated_tolerance_mm is None:
            w.append(f"Tolerance ±{req:g} mm requested but no calibration profile selected.")
        elif req < calibrated_tolerance_mm:
            q.append(
                f"Requested ±{req:g} mm is tighter than calibrated capability "
                f"±{calibrated_tolerance_mm:g} mm."
            )
    if q:
        return RequirementGate(False,"NEEDS_CLARIFICATION_OR_PROCESS_CHANGE",q,w)
    return RequirementGate(True,"READY_FOR_CAD",[],w)
