from __future__ import annotations
import asyncio
from pathlib import Path
from .spec import DesignSpec, Feature

def _vec(v): return "[" + ",".join(f"{float(x):.6g}" for x in v) + "]"

def _primitive(f: Feature):
    p=f.primitive
    if p.kind=="box":
        body=f"cube({_vec(p.size_mm)}, center={'true' if p.center else 'false'});"
    else:
        d,h=p.size_mm
        body=f"cylinder(d={d:.6g}, h={h:.6g}, center={'true' if p.center else 'false'}, $fn=96);"
    if any(abs(x)>1e-12 for x in f.transform.rotate_deg):
        body=f"rotate({_vec(f.transform.rotate_deg)}) {{ {body} }}"
    if any(abs(x)>1e-12 for x in f.transform.translate_mm):
        body=f"translate({_vec(f.transform.translate_mm)}) {{ {body} }}"
    return body

def compile_scad(spec: DesignSpec):
    adds=[_primitive(f) for f in spec.features if f.operation=="add"]
    cuts=[_primitive(f) for f in spec.features if f.operation=="cut"]
    if not adds: raise ValueError("at least one additive body required")
    union="union() {\n" + "\n".join("  "+x for x in adds) + "\n}"
    if cuts:
        body="difference() {\n  " + union.replace("\n","\n  ") + "\n"
        body += "\n".join("  "+x for x in cuts) + "\n}"
    else:
        body=union
    return "// AI 3D Maker deterministic DesignSpec compiler\n// units: mm\n" + body + "\n"

async def export_stl(scad_path: Path, stl_path: Path, openscad_bin="openscad", timeout=60):
    cmd=[openscad_bin,"-o",str(stl_path),str(scad_path)]
    try:
        p=await asyncio.create_subprocess_exec(*cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
    except FileNotFoundError:
        return {"ok":False,"status":"NOT_RUN","error":f"{openscad_bin} not installed"}
    try:
        out,err=await asyncio.wait_for(p.communicate(),timeout)
    except asyncio.TimeoutError:
        p.kill(); await p.communicate()
        return {"ok":False,"status":"FAILED","error":"OpenSCAD timeout"}
    ok=p.returncode==0 and stl_path.is_file()
    return {"ok":ok,"status":"PASS" if ok else "FAILED",
            "stdout":out.decode(errors="replace")[-1500:],
            "stderr":err.decode(errors="replace")[-1500:]}
