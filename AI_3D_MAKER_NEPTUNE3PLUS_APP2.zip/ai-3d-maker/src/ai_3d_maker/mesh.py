from pathlib import Path

def validate_mesh(path):
    p=Path(path)
    try:
        import trimesh
    except Exception:
        return {"status":"NOT_RUN","reason":"trimesh optional dependency unavailable","path":str(p)}
    mesh=trimesh.load_mesh(p,process=False)
    if hasattr(mesh,"geometry"):
        geoms=list(mesh.geometry.values())
        if not geoms: return {"status":"FAILED","reason":"empty scene"}
        mesh=trimesh.util.concatenate(geoms)
    return {
        "status":"PASS" if len(mesh.faces)>0 else "FAILED",
        "vertices":int(len(mesh.vertices)),
        "faces":int(len(mesh.faces)),
        "watertight":bool(mesh.is_watertight),
        "winding_consistent":bool(mesh.is_winding_consistent),
        "volume_mm3":float(mesh.volume) if mesh.is_volume else None,
        "bbox_mm":[float(x) for x in mesh.extents],
        "components":int(len(mesh.split(only_watertight=False)))
    }
