from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json

@dataclass(slots=True)
class PrinterProfile:
    id: str
    model: str
    build_x: float
    build_y: float
    build_z: float
    platform_x: float
    platform_y: float
    nozzle: float
    max_nozzle_temp: int
    max_bed_temp: int
    fit_margin: float = 2.0

    @classmethod
    def load(cls, path: str | Path) -> "PrinterProfile":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        m = data["verified_machine_limits"]
        c = data.get("coordinate_policy", {})
        return cls(
            id=data["id"], model=data["model"],
            build_x=float(m["build_x_mm"]), build_y=float(m["build_y_mm"]),
            build_z=float(m["build_z_mm"]), platform_x=float(m["platform_x_mm"]),
            platform_y=float(m["platform_y_mm"]), nozzle=float(m["stock_nozzle_mm"]),
            max_nozzle_temp=int(m["max_nozzle_temp_c"]),
            max_bed_temp=int(m["max_bed_temp_c"]),
            fit_margin=float(c.get("fit_margin_mm", 2.0)),
        )

    def usable_xyz(self):
        return (
            max(0.0, self.build_x - 2*self.fit_margin),
            max(0.0, self.build_y - 2*self.fit_margin),
            self.build_z,
        )
