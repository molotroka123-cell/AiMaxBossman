import json
from pathlib import Path
from .artifacts import build_manifest,write_report
from .cadquery_engine import available as cq_available,export as cq_export
from .geometry import check_bbox_fit
from .mesh import validate_mesh
from .openscad import compile_scad,export_stl
from .requirements import evaluate_requirements

class PrecisionPipeline:
    def __init__(self,profile,openscad_bin="openscad"):
        self.profile=profile; self.openscad_bin=openscad_bin

    async def build(self,spec,out_dir,calibrated_tolerance_mm=None,prefer_cadquery=True):
        out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
        gate=evaluate_requirements(spec,calibrated_tolerance_mm)
        (out/"design_spec.json").write_text(spec.model_dump_json(indent=2),encoding="utf-8")
        if not gate.ready:
            result={"status":gate.status,"questions":gate.questions,"warnings":gate.warnings}
            (out/"validation.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
            return result

        scad=compile_scad(spec); (out/"model.scad").write_text(scad,encoding="utf-8")
        stl=out/"model.stl"; step=out/"model.step"
        engine="openscad"; cad_result=None
        if prefer_cadquery and cq_available():
            try:
                cad_result=cq_export(spec,step,stl); engine="cadquery"
            except Exception as exc:
                cad_result={"error":f"{type(exc).__name__}: {exc}"}
        if not stl.is_file():
            cad_result=await export_stl(out/"model.scad",stl,self.openscad_bin)

        mesh=validate_mesh(stl) if stl.is_file() else {"status":"NOT_RUN"}
        bbox=tuple(mesh.get("bbox_mm",[])) if len(mesh.get("bbox_mm",[]))==3 else None
        fit=check_bbox_fit(bbox,self.profile) if bbox else None

        status="PASS"; warnings=list(gate.warnings)
        if not stl.is_file():
            status="FAILED"; warnings.append("No STL produced.")
        if mesh.get("status")=="FAILED": status="FAILED"
        if fit and not fit.fits:
            status="FAILED"; warnings.extend(fit.warnings)

        result={"status":status,"engine":engine,"cad":cad_result,"mesh":mesh,
                "fit":None if fit is None else {"fits":fit.fits,
                "orientation_xyz":fit.orientation_xyz,"warnings":fit.warnings},
                "warnings":warnings}
        (out/"validation.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
        write_report(out/"print_report.md",{"status":status,"printer":self.profile.model,
            "bbox_mm":bbox,"fit":None if fit is None else fit.fits,
            "mesh_status":mesh.get("status"),"gcode_status":"NOT_RUN","warnings":warnings})
        (out/"manifest.json").write_text(json.dumps(build_manifest(out),indent=2),encoding="utf-8")
        return result
