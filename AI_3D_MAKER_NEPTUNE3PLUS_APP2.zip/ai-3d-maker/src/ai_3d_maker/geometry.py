from dataclasses import dataclass
from itertools import permutations
from .profile import PrinterProfile

@dataclass(slots=True)
class GeometryCheck:
    fits: bool
    orientation_xyz: tuple[float,float,float] | None
    warnings: list[str]

def check_bbox_fit(bbox_xyz, profile: PrinterProfile, allow_rotate=True):
    if any(v<=0 for v in bbox_xyz):
        return GeometryCheck(False,None,["Non-positive bounding box."])
    usable=profile.usable_xyz()
    candidates=list(set(permutations(bbox_xyz,3))) if allow_rotate else [bbox_xyz]
    for xyz in candidates:
        if all(v<=limit+1e-9 for v,limit in zip(xyz,usable)):
            return GeometryCheck(True,tuple(float(v) for v in xyz),[])
    return GeometryCheck(False,None,[f"Model {bbox_xyz} does not fit usable {usable} mm."])

def minimum_wall_warning(wall_mm, nozzle_mm, minimum_lines=3):
    target=nozzle_mm*minimum_lines
    return [] if wall_mm+1e-9>=target else [
        f"Wall {wall_mm:g} mm below conservative {minimum_lines}-line target {target:g} mm."
    ]
