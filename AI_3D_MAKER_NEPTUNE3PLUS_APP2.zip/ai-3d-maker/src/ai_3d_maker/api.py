import os
from pathlib import Path
from fastapi import FastAPI,HTTPException
from pydantic import BaseModel
from .pipeline import PrecisionPipeline
from .profile import PrinterProfile
from .spec import DesignSpec
from .gcode import scan_gcode

class BuildRequest(BaseModel):
    spec:DesignSpec
    job_id:str="job"
    calibrated_tolerance_mm:float|None=None

def safe_job_id(v):
    cleaned="".join(c for c in v if c.isalnum() or c in "-_")[:80]
    if not cleaned: raise ValueError("invalid job id")
    return cleaned

def build_app():
    profile=PrinterProfile.load(os.getenv("AI3D_PRINTER_PROFILE","./profiles/elegoo_neptune_3_plus.json"))
    data=Path(os.getenv("AI3D_DATA_DIR","./data"))
    pipeline=PrecisionPipeline(profile,os.getenv("AI3D_OPENSCAD_BIN","openscad"))
    app=FastAPI(title="AI 3D Maker",version="0.1.0")

    @app.get("/api/profile")
    async def p():
        return {"id":profile.id,"model":profile.model,
                "build_mm":[profile.build_x,profile.build_y,profile.build_z],
                "nozzle_mm":profile.nozzle,"max_nozzle_temp_c":profile.max_nozzle_temp,
                "max_bed_temp_c":profile.max_bed_temp}

    @app.post("/api/precision/build")
    async def build(req:BuildRequest):
        try: job=safe_job_id(req.job_id)
        except ValueError as exc: raise HTTPException(400,str(exc))
        return await pipeline.build(req.spec,data/"jobs"/job,req.calibrated_tolerance_mm)

    @app.post("/api/gcode/scan")
    async def scan(payload:dict):
        text=payload.get("gcode")
        if not isinstance(text,str): raise HTTPException(400,"gcode string required")
        strict=os.getenv("AI3D_STRICT_GCODE","true").lower() in {"1","true","yes"}
        return scan_gcode(text,profile,strict_unknown=strict)

    return app
