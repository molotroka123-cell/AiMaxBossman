import os,uvicorn
from .api import build_app

def main():
    uvicorn.run(build_app(),host=os.getenv("AI3D_HOST","127.0.0.1"),
                port=int(os.getenv("AI3D_PORT","8890")))

if __name__=="__main__": main()
