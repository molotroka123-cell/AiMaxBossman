from pathlib import Path
import hashlib,json

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def build_manifest(directory):
    root=Path(directory); files=[]
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({"path":p.relative_to(root).as_posix(),
                          "bytes":p.stat().st_size,"sha256":sha256(p)})
    return {"files":files}

def write_report(path,data):
    lines=["# AI 3D Maker — Print Report","",
           f"Status: **{data.get('status','UNKNOWN')}**","",
           "## Printer",f"- {data.get('printer','unknown')}","",
           "## Geometry",f"- bbox: {data.get('bbox_mm')}",
           f"- fit: {data.get('fit')}",f"- mesh: {data.get('mesh_status','NOT_RUN')}","",
           "## G-code",f"- status: {data.get('gcode_status','NOT_RUN')}","",
           "## Warnings"]
    ws=data.get("warnings",[])
    lines += [f"- {w}" for w in ws] if ws else ["- none"]
    Path(path).write_text("\n".join(lines)+"\n",encoding="utf-8")
