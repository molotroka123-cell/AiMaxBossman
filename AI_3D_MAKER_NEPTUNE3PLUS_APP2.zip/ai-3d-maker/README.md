# AI 3D Maker

BOSSMAN App #2: validated CAD/mesh-to-print pipeline.

## Modes
- Precision CAD: deterministic DesignSpec → CAD → validate → slice.
- Generative 3D: generator adapter → repair/validate → slice.

## Install

Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev,mesh]"
cp .env.example .env
ai-3d-maker
```

Optional:
`pip install -e ".[cad]"`

System tools:
- OpenSCAD
- CuraEngine / ELEGOO Cura resources

V1 never starts a physical print automatically.
