from ai_3d_maker.tolerance import scale_from_coupon,suggest_xy_scale
def test_scale(): assert round(scale_from_coupon(20,19.8),6)==round(20/19.8,6)
def test_xy(): assert .99 < suggest_xy_scale(20,19.8,20,20.2) < 1.01
