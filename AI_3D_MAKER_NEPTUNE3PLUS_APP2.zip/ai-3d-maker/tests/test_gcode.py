from ai_3d_maker.gcode import scan_gcode

def test_safe(profile):
    g='G90\nM82\nM104 S205\nM140 S60\nG28\nG1 X20 Y20 Z0.2\nG1 X40 Y20 E1.2'
    assert scan_gcode(g,profile)["status"]=="PASS"
def test_hot_nozzle(profile): assert scan_gcode("M104 S300",profile)["status"]=="FAILED"
def test_hot_bed(profile): assert scan_gcode("M140 S120",profile)["status"]=="FAILED"
def test_xyz(profile): assert scan_gcode("G90\nM82\nG1 X400 Y10 Z0.2 E1",profile)["status"]=="FAILED"
def test_eeprom(profile): assert scan_gcode("M500",profile)["status"]=="FAILED"
