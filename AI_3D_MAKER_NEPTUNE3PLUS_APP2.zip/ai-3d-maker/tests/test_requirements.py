from ai_3d_maker.spec import DesignSpec
from ai_3d_maker.requirements import evaluate_requirements

def mk(tol=None,q=None):
    return DesignSpec.model_validate({"name":"x","features":[
      {"primitive":{"id":"b","kind":"box","size_mm":[10,10,10]},"operation":"add"}],
      "manufacturing":{"required_tolerance_mm":tol},"unresolved_questions":q or []})

def test_question_blocks(): assert not evaluate_requirements(mk(q=["Which fit?"])).ready
def test_tight_blocks(): assert not evaluate_requirements(mk(.05),.2).ready
def test_uncalibrated_warns():
    g=evaluate_requirements(mk(.2),None); assert g.ready and g.warnings
