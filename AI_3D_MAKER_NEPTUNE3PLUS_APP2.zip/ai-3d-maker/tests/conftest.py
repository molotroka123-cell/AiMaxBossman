from pathlib import Path
import pytest
from ai_3d_maker.profile import PrinterProfile

@pytest.fixture
def profile():
    return PrinterProfile.load(Path(__file__).parents[1]/"profiles"/"elegoo_neptune_3_plus.json")
