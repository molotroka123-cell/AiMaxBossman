from ai_3d_maker.spec import DesignSpec
from ai_3d_maker.openscad import compile_scad

def test_compile():
    s=DesignSpec.model_validate({"name":"x","features":[
      {"primitive":{"id":"b","kind":"box","size_mm":[60,30,8]},"operation":"add"},
      {"primitive":{"id":"h","kind":"cylinder","size_mm":[4,8]},"operation":"cut"}]})
    c=compile_scad(s)
    assert "difference()" in c and "cube([60,30,8]" in c and "cylinder(d=4" in c

def test_negative_rejected():
    try:
        DesignSpec.model_validate({"name":"bad","features":[
          {"primitive":{"id":"b","kind":"box","size_mm":[10,-2,3]},"operation":"add"}]})
    except Exception: return
    raise AssertionError("negative dimension accepted")
