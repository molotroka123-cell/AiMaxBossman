from ai_3d_maker.geometry import check_bbox_fit,minimum_wall_warning

def test_fit(profile): assert check_bbox_fit((100,200,50),profile).fits
def test_rotate_fit(profile):
    r=check_bbox_fit((390,200,300),profile); assert r.fits and r.orientation_xyz[2]==390
def test_oversize(profile): assert not check_bbox_fit((500,500,500),profile).fits
def test_wall(profile):
    assert minimum_wall_warning(.8,profile.nozzle,3)
    assert not minimum_wall_warning(1.2,profile.nozzle,3)
