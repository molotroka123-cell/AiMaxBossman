from ai_3d_maker.api import safe_job_id
def test_sanitize(): assert safe_job_id('../../my job!')=='myjob'
def test_empty():
    try: safe_job_id('../')
    except ValueError: return
    raise AssertionError('unsafe empty id accepted')
