def test_limits(profile):
    assert (profile.build_x,profile.build_y,profile.build_z)==(320,320,400)
    assert profile.nozzle==0.4
    assert profile.max_nozzle_temp==260
    assert profile.max_bed_temp==100
