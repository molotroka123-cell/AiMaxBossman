# MASTER PROMPT — AI 3D Maker / ELEGOO Neptune 3 Plus

Build BOSSMAN App #2: **AI 3D Maker**.

The product must create manufacturing-ready artifacts, not just plausible 3D renders.

## Phase boundary

If BOSSMAN V2.2 is not formally CLOSED after final audit, keep this app
standalone/staged. Do not destabilize foundation code.

## Mode A — Precision CAD (P0)

For brackets, holders, clamps, cases, spacers, adapters, mounts, replacement
parts and dimensioned mechanical objects.

Pipeline:

natural language / sketch / dimensions
→ Requirement Normalizer
→ strict DesignSpec
→ ambiguity/tolerance gate
→ deterministic CAD
→ STEP + STL where the engine supports them
→ geometry + printer-fit validation
→ slicer
→ G-code safety scan
→ 3MF/project where the real slicer supports it
→ print report
→ human approval

Do NOT use a generative text-to-3D mesh for dimension-critical parts if a
parametric CAD representation is possible.

## Mode B — Generative 3D (P1)

For figurines, statues, decorative and organic shapes.

text/image
→ generator adapter
→ mesh repair
→ scale
→ manifold/wall/size checks
→ orientation/supports
→ slicer
→ G-code scan

Do not hard-depend on one 3D-generation vendor.

## Printer profile

Seed profile: `profiles/elegoo_neptune_3_plus.json`

Preserve verified limits:
- X 320 mm
- Y 320 mm
- Z 400 mm
- stock nozzle 0.4 mm
- max nozzle 260C
- max bed 100C

Maximum temperature is a hard safety cap, NOT a recommended print temperature.

## AI execution boundary

Normal mode must not run arbitrary model-generated Python on the BOSSMAN host.

Preferred:
model → DesignSpec JSON → schema validation → deterministic compiler.

If advanced free-form CadQuery/FreeCAD code mode is added later, execute it only
inside a sandbox and behind ASK.

## Precision policy

Keep separate:
- nominal CAD dimension;
- expected/calibrated FDM process capability;
- user's required tolerance.

If requested tolerance is tighter than selected calibration profile, return:
`NEEDS_CALIBRATION_OR_DIFFERENT_PROCESS`

Do not fake precision.

Hole/XY compensation is printer/material/process specific.
Default compensation is zero until a measured calibration profile is selected.

## Required V1 components

Reuse/adapt supplied code:
- official printer profile loader
- Pydantic DesignSpec
- requirements gate
- deterministic OpenSCAD compiler
- optional CadQuery exporter
- mesh validator
- bbox/printer-fit checker
- calibration profile
- CuraEngine wrapper
- G-code scanner
- artifact manifest/report
- FastAPI API
- tests

## Slicer

Use actual ELEGOO Cura/CuraEngine resources from the target machine.

Do not fabricate an exact vendor Cura definition file.

The wrapper should accept:
- real CuraEngine executable
- real printer definition path
- controlled setting overrides

Future OrcaSlicer/PrusaSlicer adapters are fine, but keep slicing separate from CAD core.

## G-code safety

Never auto-start the physical printer in V1.

Flow:
slice → scan → report → human approval → transfer

Reject/flag:
- extrusion moves outside profile envelope
- nozzle >260C
- bed >100C
- persistent EEPROM/reset/firmware-style commands
- malformed or suspicious commands in strict mode

Do not invent a network-print interface: official Neptune 3 Plus transfer is
TF card / USB cable.

## Outputs

Target, only when actually produced:
- design_spec.json
- model.scad and/or deterministic CAD source
- model.step (CadQuery/FreeCAD path)
- model.stl
- model.3mf (real supported export path)
- model.gcode
- validation.json
- print_report.md
- manifest.json

Never claim a file exists if it does not.

## Calibration workflow

Before tight precision claims:
1. generate a calibration coupon;
2. print it;
3. measure with calipers after cooling;
4. record material/nozzle/layer/settings;
5. save versioned calibration profile;
6. use compensation only when that profile is explicitly selected.

## Future BOSSMAN integration

After App Runtime exists:
- standalone UI
- Apps button
- `/3d make ...`
- `/3d validate file.stl`
- `/3d slice ...`
- `/3d calibrate`
- natural-language routing
- autonomous CAD→validate→revise loop

Physical print start remains DENY in V1.

## Acceptance gates

Focused tests:
- official machine limits
- spec validation
- ambiguity gate
- OpenSCAD generation
- no arbitrary-code normal path
- fit and rotation-fit checks
- minimum wall warning
- tolerance/calibration gate
- G-code nozzle cap reject
- G-code bed cap reject
- G-code XYZ reject
- EEPROM/reset command reject
- safe G-code pass
- artifact manifest
- API helper sanity

Real evidence separately:
- REAL CAD ENGINE
- REAL STL EXPORT
- REAL STEP EXPORT
- REAL SLICER
- REAL NEPTUNE 3 PLUS PRINT + physical measurement

Create `docs/AI_3D_MAKER_APP2_REPORT.md` and separate:
UNIT PASS / REAL CAD PASS / REAL SLICER PASS / REAL PRINTER PASS / NOT RUN.

Do not return only a plan. Implement, test, measure, and report.
