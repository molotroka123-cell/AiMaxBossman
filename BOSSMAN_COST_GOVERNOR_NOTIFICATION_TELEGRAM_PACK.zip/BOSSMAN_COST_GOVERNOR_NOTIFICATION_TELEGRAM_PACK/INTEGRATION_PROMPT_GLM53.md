# GLM 5.3 MASTER PROMPT — COST GOVERNOR + NOTIFICATIONS/TELEGRAM

Repo:
`molotroka123-cell/AiMaxBossman`

Branch:
`claude/bossman-control-v03-43igbk`

Pack:
`BOSSMAN_COST_GOVERNOR_NOTIFICATION_TELEGRAM_PACK.zip`

ROLE:
You are the implementation owner and independent security reviewer for this integration.

GOAL:
Integrate two production controls without creating parallel architecture:

1. HARD DOLLAR COST GOVERNOR
2. DURABLE NOTIFICATION DISPATCHER + TELEGRAM TRANSPORT

Do not start another large feature while doing this pass.

======================================================================
0. CURRENT HEAD IS SOURCE OF TRUTH
======================================================================

First:

git status
git branch --show-current
git fetch origin
git log -20 --oneline
git rev-parse HEAD
git rev-parse origin/claude/bossman-control-v03-43igbk

Preserve other workers' changes.
No reset --hard over foreign work.
No force push.

Record BASE_HEAD in WORKLOG.

======================================================================
1. STAGE THE ZIP, DO NOT BLIND OVERWRITE
======================================================================

sha256sum BOSSMAN_COST_GOVERNOR_NOTIFICATION_TELEGRAM_PACK.zip
unzip -l BOSSMAN_COST_GOVERNOR_NOTIFICATION_TELEGRAM_PACK.zip

Extract under ignored:
`_staging/cost-notify/`

Run:
`python tools/check_pack.py` from the staged pack.

Read:
README
ARCHITECTURE
SECURITY
BUDGET_POLICY
TELEGRAM_SECURITY
BUG_CHECKLIST
PATCH_MAP
GATEWAY_COST_HOOK
API_TELEGRAM_HOOK

Classify every candidate:
ADOPT / ADAPT / MERGE / SKIP_SUPERSEDED / DOC_ONLY.

Current repo wins when it is newer/safer.

======================================================================
2. DO NOT CREATE SECOND SYSTEMS
======================================================================

Reuse:
- Stage3 Gateway
- bossman.events EventBus
- bossman.approvals
- Stage6 auth/scopes
- existing telegram config/webhook secret
- existing correlation IDs
- existing redaction/obs
- existing lifecycle registry

Do NOT create:
- another LLM router
- another auth DB
- another approval DB
- another EventBus
- another Remote API
- a new cloud-policy mechanism

Subsystem-local SQLite ledgers for budget reservations and notification queue are allowed;
they are durable control state, not replacements for application Postgres.

======================================================================
3. COST GOVERNOR MUST BE BEFORE REAL CLOUD I/O
======================================================================

This is critical.

Do NOT enforce only from `bossman/llm.py`.

Capability alias can route:
local → failure → cloud fallback.

The correct enforcement boundary is Stage3 Gateway immediately before the exact
cloud upstream network request.

For every potentially billable upstream attempt:

EXACT TARGET
→ EXACT PRICE
→ UPPER BOUND COST
→ COST RESERVATION
→ ONLY THEN NETWORK

No reservation ALLOW = no cloud socket.

======================================================================
4. HARD BUDGET SCOPES
======================================================================

Support simultaneously:

run
task
project
daily_global (UTC)

Projected spend is:

committed spent
+ all active in-flight reservations
+ this request's conservative upper bound

Parallel agents must not overspend by race.

Use the pack SQLite `BEGIN IMMEDIATE` ledger or improve it without weakening this property.

Add a concurrency test with separate store/connections:
20 × $0.10 requests under $1 cap
=> at most 10 reservations accepted.

======================================================================
5. MONEY RULES
======================================================================

Use Decimal.
Never float for accounting.

Store exact decimal strings.

No negative/NaN/Infinity.

Preflight estimate MUST be a conservative upper bound from:
- exact selected provider/model
- actual prompt tokens or safe upper bound
- configured max completion tokens
- exact catalog input price
- exact catalog output price
- provider request/image/tool fees where applicable

If any applicable hard budget exists and pricing is unknown:
FAIL CLOSED.

Do not assume $0.
Do not use stale price silently if catalog contract says it is invalid.

Record pricing source/version/model with the call audit if current schema supports it.

======================================================================
6. RESERVATION LIFECYCLE
======================================================================

Before billable call:
reserve.

Success:
commit actual cost.

Failure/cancel before a billable request:
release.

Reservation:
- idempotency key
- TTL
- context fingerprint
- amount
- ACTIVE/COMMITTED/RELEASED/EXPIRED

Restart:
active reservations remain visible.
Janitor expires stale ones and releases held amount.

Duplicate request id cannot double reserve.

`actual > reserved`:
NEVER silently commit.
This means the upper-bound adapter was wrong.
Treat as accounting/security incident and reconcile; future requests should fail safe if
the ledger cannot be trusted.

======================================================================
7. WARNING + HARD ACTION
======================================================================

Default warning fraction can be 0.80.

Warning threshold crossing should notify once per bucket/limit state, not every request.

At hard limit:

STOP:
typed denial before cloud network.

ASK:
existing BOSSMAN approval.

No model can change STOP to ASK.

No model can raise hard_limit_usd.

Budget policy mutation requires existing Stage6 `admin`.

Reading budget status can use `chat`.

======================================================================
8. BOUNDED APPROVED OVERRIDE
======================================================================

ASK is NOT:
"raise project budget".

It is:
one exact request gets one bounded exception.

Flow:
Budget REQUIRE_APPROVAL
→ approvals.create()
→ owner decision
→ single-use override token
→ bound to context fingerprint
→ exact extra amount
→ TTL
→ retry same reservation
→ token consumed atomically

Wrong context:
deny.

Expired:
deny.

Replay:
deny.

Changing persistent policy requires a separate admin operation.

======================================================================
9. CLOUD POLICY REMAINS ABOVE BUDGET
======================================================================

A budget approval does NOT authorize cloud.

If:
cloud_policy=never

then:
no cloud request,
even if owner approved a budget override.

If cloud_policy=ask:
both gates may be required:
cloud approval AND budget approval.

Test this explicitly.

======================================================================
10. NOTIFICATION DISPATCHER
======================================================================

Use existing `bossman.events`.

The pack EventBridge is ONE subscriber on that bus.

Do not modify every subsystem to call Telegram.

Event:
→ EventBridge
→ allowlisted NotificationPolicy
→ durable queue
→ transport.

Phone-worthy defaults:

task.completed
task.failed
approval.created
budget.warning
budget.exceeded
service.degraded
emergency_lock

Adapt exact current event names.

Do not forward arbitrary EventBus payloads.

======================================================================
11. TELEGRAM IS TRANSPORT, NOT AUTHORITY
======================================================================

Current repo has Telegram already.

Do not create Telegram Bot #2.

Replace/adapt the old direct transport with pack compatibility facade so:
- existing `approvals.py -> telegram.ask_approval()` keeps working;
- send is queued;
- approval callback becomes opaque;
- notification bus can also deliver events.

Outgoing approval callback:
`b:<opaque random token>`

NOT:
`approve:<id>`
`reject:<id>`

After integration old raw callback formats must be rejected.

======================================================================
12. TELEGRAM WEBHOOK SECURITY
======================================================================

Require:
- existing TELEGRAM_WEBHOOK_SECRET;
- constant-time comparison;
- configured chat binding;
- optional TELEGRAM_ALLOWED_USER_IDS if configured;
- opaque callback;
- TTL;
- single-use atomic consume;
- target/action binding.

The callback can only act on an already-created BOSSMAN approval.

It cannot:
- create a new approval;
- change budget;
- change cloud_policy;
- acquire admin;
- access arbitrary task;
- execute arbitrary tool.

Approval goes through existing:
`approvals.decide()`.

If approval already decided:
fail closed.

Do not trust Telegram username as identity.

Use numeric chat/user IDs for binding.

======================================================================
13. BOT TOKEN HYGIENE
======================================================================

Telegram Bot API URL contains the token.

HTTP exceptions can accidentally stringify that URL.

Never persist raw httpx exception text from Telegram.

Persist only:
- sanitized error category
- HTTP status
- bounded non-secret diagnostic

Search after tests:

TELEGRAM_BOT_TOKEN value
TELEGRAM_WEBHOOK_SECRET value

must have ZERO matches in:
logs
DB
audit docs
snapshots
test reports.

Do not print secrets to prove they are absent.

Use canary/test credentials in tests.

======================================================================
14. DURABLE DELIVERY
======================================================================

Queue must survive Core restart.

States:
PENDING
SENDING
SENT
DEAD

On startup:
stale SENDING → PENDING.

Retry:
bounded exponential backoff + jitter.

Max attempts bounded.

Telegram outage:
must not make the original Core task fail.

No synchronous `await Telegram network` in a consequential Core transaction.

Approvals themselves still remain correct in Postgres even if Telegram is down.

======================================================================
15. DEDUPE
======================================================================

Prevent duplicate notifications for:
same approval
same budget warning
same terminal task event where possible.

Exactly-once delivery over external HTTP cannot be guaranteed.
Security correctness must not depend on exactly-once Telegram.

Duplicate old approval buttons must still be harmless because:
- callback token single-use;
- `approvals.decide()` updates only pending row.

======================================================================
16. SANITIZATION
======================================================================

Notifications may include only concise selected fields.

Never send:
- full prompt
- model context
- private keys
- API keys
- password
- full source diff
- screenshot
- wallet seed
- full stack dump with secrets

Reuse existing obs/redaction seam first.
Pack regex is defense-in-depth, not replacement.

Adversarial test:
secret-looking canary in event
→ Telegram payload/queue contains [REDACTED], not canary.

======================================================================
17. ROUTES / AUTH
======================================================================

Budget:
GET policies/status -> current appropriate read scope
PUT policy -> admin

Notifications:
status/test -> admin

Do not expose callback-token DB.

Telegram webhook remains transport-authenticated by Telegram webhook secret + binding;
do not add localhost bypass.

Raw Core remains under current perimeter hardening.

======================================================================
18. CURRENT API WEBHOOK MUST CHANGE
======================================================================

Current code parses:
approve:<id>
reject:<id>

Remove that parser.

Use pack:
`telegram.handle_webhook(update, secret_header)`.

On callback failure:
return generic auth/denied error.
No oracle details to caller.
No token in error.

Add tests proving:
old `approve:42` is rejected.

======================================================================
19. GATEWAY PRICING ADAPTER
======================================================================

Inspect current OpenRouter model catalog implementation.

Use the exact cached catalog/pricing fields already present.

Do not hardcode model prices in Cost Governor.

If pricing units are strings USD/token:
use pack pricing helpers.

If current catalog represents per-million:
adapt explicitly and test units.

Must test with known fixture:
input price
output price
prompt tokens
max_tokens
=> expected upper-bound Decimal exactly.

A 1e6 unit mistake is P0.

======================================================================
20. RETRY / FALLBACK COSTS
======================================================================

Each billable attempt gets a unique idempotency key:
request/correlation id + route attempt + provider + exact model.

If cloud attempt A bills then errors and fallback cloud B also bills:
both costs must be represented.

Do not reserve once for a multi-provider chain unless the reservation upper-bound provably
covers every billable attempt.

Prefer per-attempt accounting.

======================================================================
21. TESTS FROM PACK
======================================================================

Copy/adapt tests.

Run at least:

test_cost_governor.py
test_cost_governor_concurrency.py
test_cost_governor_adversarial.py
test_notifications.py
test_telegram_callbacks.py
test_budget_notification_integration.py

Then add integration tests against CURRENT repo for:

- Gateway no-network on STOP
- Gateway ASK waits
- cloud_policy never precedence
- exact OpenRouter price fixture
- reservation release on cancel/timeout
- provider fallback accounting
- API admin/chat scope
- raw Telegram callback rejected
- wrong webhook secret
- wrong chat
- optional wrong user
- callback replay
- approval handler called once
- event → queue → fake Telegram transport
- Telegram transport failure doesn't fail task
- token absent from stored error
- subsystem restart recovers queue
- warning not spammed

======================================================================
22. NO REAL OPENROUTER SPEND NEEDED
======================================================================

Do not spend real money for normal implementation tests.

Use current catalog fixtures/mocks.

If owner explicitly asks for a live cost smoke and key is already legitimately available,
maximum ONE cheapest controlled inference with tiny token cap.

Never search disk/logs for provider keys to reuse them.

Absence of key:
does not block unit/integration budget tests.

======================================================================
23. TELEGRAM LIVE
======================================================================

If valid Telegram bot/webhook credential is explicitly available:
run `docs/LIVE_ACCEPTANCE.md`.

If absent:
BLOCKED_BY_CREDENTIAL for live Telegram only.

Do not turn deterministic tests into skips.

======================================================================
24. FULL REGRESSION
======================================================================

After targeted green:

bossman-core:
full suite

command-center:
full suite

existing:
auth/perimeter
approvals
remote
gateway/OpenRouter mocked
Resource Brain
sandbox
AI Lab
Dev Factory
Stage12
Stage13 if it already exists on CURRENT HEAD

secret scan
compile/import
JS checks where relevant

Do not xfail/skip failures caused by this patch.

======================================================================
25. CI
======================================================================

Commit only after local green.

Push active branch.

Then inspect GitHub Actions on FINAL HEAD.

"queued" is not green.
"in_progress" is not green.
commit message saying "green" is not green.

Required deterministic workflows must conclude:
success.

If red:
read logs
reproduce
fix
test
push
check again.

Continue until green or a genuine external GitHub outage/permission blocker is evidenced.

======================================================================
26. DOCUMENTATION
======================================================================

Only after tests.

Update current project truth files:
WORKLOG / CURRENT_STATE / NEXT / FINAL_HARDENING_STATUS / context-cache
as applicable on CURRENT HEAD.

Add:
`docs/context/COST_GOVERNOR_STATUS.md`
`docs/context/NOTIFICATION_TELEGRAM_STATUS.md`

Use:
IMPLEMENTED
WIRED
UNIT_VERIFIED
ADVERSARIAL_VERIFIED
LOCAL_LIVE_VERIFIED
CI_VERIFIED
BLOCKED_BY_CREDENTIAL

Do not reuse old test counts.

======================================================================
27. STOP CONDITIONS
======================================================================

DO NOT FINISH if any achievable issue remains:

- parallel overspend
- float money
- cloud request opens before reservation
- unknown pricing silently treated as free
- budget approval bypasses cloud_policy
- model can raise budget
- override replay
- reservation leak
- notification can leak a secret
- Telegram token can appear in stored exception
- raw approve:<id> callback still accepted
- forged/wrong-chat callback works
- callback replay works
- Telegram outage breaks Core task
- duplicate approval can execute twice
- deterministic tests fail
- full bossman-core fails due this change
- command-center fails due this change
- secret scan red
- CI red
- fix uncommitted/unpushed

======================================================================
28. FINAL RESPONSE
======================================================================

FINAL HEAD:
PUSHED HEAD:
CI:

COST GOVERNOR
- scopes:
- reserve/commit/release:
- concurrency:
- STOP:
- ASK:
- cloud-policy precedence:
- pricing source:

NOTIFICATIONS
- EventBus bridge:
- durable queue:
- retry:
- redaction:

TELEGRAM
- opaque callback:
- webhook:
- chat binding:
- replay:
- live:

TESTS
- targeted:
- adversarial:
- bossman-core:
- command-center:
- CI:

REAL MONEY SPENT DURING THIS PASS:
$0 unless explicitly authorized live smoke.

OPEN P0:
NONE

OPEN FIXABLE P1:
NONE

BLOCKED:
only genuine external credentials/host capabilities.

Do not begin another feature inside this pass.
