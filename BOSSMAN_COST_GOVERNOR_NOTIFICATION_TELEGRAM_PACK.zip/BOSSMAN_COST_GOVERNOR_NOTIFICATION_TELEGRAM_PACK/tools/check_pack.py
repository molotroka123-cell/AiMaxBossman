from __future__ import annotations
import ast,re,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
errors=[]
py=list((ROOT/"overlay").rglob("*.py"))
for p in py:
    text=p.read_text(encoding="utf-8")
    try:ast.parse(text,filename=str(p))
    except SyntaxError as exc:errors.append(f"{p}: syntax: {exc}")
    for needle in ("create_subprocess_shell(","shell=True","os.system(","os.popen("):
        if needle in text:errors.append(f"{p}: forbidden host-shell pattern {needle}")
    for lineno,line in enumerate(text.splitlines(),1):
        if re.search(r"\bsk-(?:proj-|or-v1-)?[A-Za-z0-9_-]{12,}\b",line) and "ci-secret-scan: allow" not in line:
            errors.append(f"{p}:{lineno}: secret-like test string lacks allow marker")

required=[
 ROOT/"INTEGRATION_PROMPT_GLM53.md",
 ROOT/"docs/BUG_CHECKLIST.md",
 ROOT/"integration/GATEWAY_COST_HOOK.md",
 ROOT/"overlay/bossman-core/bossman/cost_control/store.py",
 ROOT/"overlay/bossman-core/bossman/notifications/telegram_transport.py",
 ROOT/"overlay/bossman-core/bossman/telegram.py",
]
for p in required:
    if not p.exists():errors.append(f"missing {p}")

telegram=(ROOT/"overlay/bossman-core/bossman/notifications/telegram_transport.py").read_text()
if '"approve:"' in telegram or '"reject:"' in telegram:
    errors.append("runtime Telegram transport contains legacy raw approval callback")
if 'callback_data":"b:"' not in telegram.replace(" ",""):
    errors.append("opaque callback prefix not found")

if errors:
    print("FAIL")
    print("\n".join(errors))
    sys.exit(2)
print(f"PASS: {len(py)} Python files parsed; shell scan clean; callback format opaque")
