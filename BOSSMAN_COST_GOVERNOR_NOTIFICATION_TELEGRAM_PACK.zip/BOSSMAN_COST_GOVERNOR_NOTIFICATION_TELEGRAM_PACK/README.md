# BOSSMAN — Cost Governor + Notification/Telegram Integration Pack

Готовый integration pack для двух функций перед Stage 13:

1. **Hard Dollar Cost Governor**
   - лимиты `run / task / project / daily_global`;
   - `Decimal`, а не float;
   - reserve → commit/release;
   - учёт in-flight/reserved денег;
   - атомарность SQLite/WAL;
   - `STOP` или `ASK`;
   - warning threshold;
   - single-use bounded overrides;
   - TTL/restart cleanup;
   - fail-closed на unknown pricing при включённых бюджетах.

2. **Notification Dispatcher + Telegram**
   - подписывается на существующий `bossman.events`;
   - durable queue;
   - dedupe + bounded retry/backoff;
   - Telegram — транспорт, не второй remote API;
   - opaque single-use callback tokens;
   - approval кнопки через существующий `bossman.approvals`;
   - webhook secret + chat binding;
   - Telegram outage не ломает Core;
   - legacy `bossman.telegram` compatibility facade.

## Не создаёт второй
Gateway / EventBus / auth / approval DB / Resource Brain / Remote Client.

Главный файл: `INTEGRATION_PROMPT_GLM53.md`.

`CURRENT HEAD` ветки — source of truth. Blind overwrite запрещён.

Правильная точка budget enforcement — Stage 3 Gateway непосредственно перед
реальным cloud upstream call: capability alias может сначала пробовать local и только
потом fallback в cloud.
