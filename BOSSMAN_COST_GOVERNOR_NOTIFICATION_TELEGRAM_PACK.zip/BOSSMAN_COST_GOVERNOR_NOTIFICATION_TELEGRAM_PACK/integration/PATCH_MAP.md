# Patch Map against current BOSSMAN seams

Observed current seams:
- `bossman/events.py`: `subscribe() / unsubscribe() / emit()`.
- `bossman/approvals.py`: `create/decide/wait`, and currently calls `telegram.ask_approval`.
- `bossman/telegram.py`: direct Telegram HTTP transport with raw `approve:<id>` callbacks.
- `bossman/api.py`: subsystem/router registries and `/telegram/webhook`.
- `bossman/llm.py`: Core calls Stage3 Gateway but capability alias may hide cloud target.

## Files to ADOPT
- `bossman/cost_control/*`
- `bossman/notifications/*`
- tests

## File to ADAPT/replace
- `bossman/telegram.py` -> compatibility facade from overlay.
  This preserves `enabled/notify/ask_approval` so `approvals.py` need not be redesigned.

## api.py changes
1. Register:
   - `bossman.cost_control`
   - `bossman.notifications`
2. Include both routers.
3. Replace raw Telegram callback parsing with:
   `await telegram.handle_webhook(update, secret_header)`.
   Raw `approve:<id>` and `reject:<id>` must cease to be accepted.

## Gateway
Wire budget enforcement at the exact cloud-upstream boundary. See
`GATEWAY_COST_HOOK.md`.

## Do not
- create a second EventBus;
- change Stage6 auth semantics;
- create another approvals table;
- put bot token in DB;
- silently guess provider pricing.
