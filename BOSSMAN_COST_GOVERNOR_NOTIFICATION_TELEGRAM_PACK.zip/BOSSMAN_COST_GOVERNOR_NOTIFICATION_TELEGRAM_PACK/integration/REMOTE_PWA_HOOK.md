# Dashboard / PWA hook

Optional UI after backend is green:
- budget policy/status card;
- spent/reserved/remaining;
- warning threshold;
- hard action STOP/ASK;
- notification queue health;
- Telegram enabled/disabled.

Read budget status: existing `chat` scope.
Mutate budget policy: `admin`.
Approval decisions remain existing `approve` scope.

Do not show bot token or webhook secret.
Do not cache budget/notification API responses in service worker.
