# Existing approvals integration

No new approval database.

Cost ASK flow:
budget decision REQUIRE_APPROVAL
→ `approvals.create("budget_override", sanitized preview, payload=...)`
→ existing UI/remote/Telegram approval
→ `approvals.wait`
→ if approved, issue one-time CostGovernor override
→ repeat exact reservation
→ cloud call only if reserve now ALLOW.

Approval payload must not contain prompt contents or provider secret.

Telegram approval:
existing `approvals.create()` already calls `telegram.ask_approval()`.
The overlay compatibility facade turns that into durable notification queue delivery.
The EventBridge also sees `approval.created`; dedupe key prevents duplicate phone messages.
