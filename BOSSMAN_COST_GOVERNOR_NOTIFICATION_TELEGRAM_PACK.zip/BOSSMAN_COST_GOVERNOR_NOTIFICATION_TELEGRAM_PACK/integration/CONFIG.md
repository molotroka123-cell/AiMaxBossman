# Configuration

Existing:
- TELEGRAM_BOT_TOKEN
- TELEGRAM_CHAT_ID
- TELEGRAM_WEBHOOK_SECRET

Optional new:
- TELEGRAM_ALLOWED_USER_IDS=123,456
- BOSSMAN_NOTIFICATION_DB=<workspace>/_notifications/notifications.db
- BOSSMAN_COST_DB=<workspace>/_cost_control/cost_control.db
- BOSSMAN_BUDGET_RUN_USD=
- BOSSMAN_BUDGET_TASK_USD=
- BOSSMAN_BUDGET_PROJECT_USD=
- BOSSMAN_BUDGET_DAILY_USD=
- BOSSMAN_BUDGET_WARNING_FRACTION=0.80
- BOSSMAN_BUDGET_HARD_ACTION=stop|ask

Empty budget env vars do not invent limits. Admin can configure policies through authenticated API.

Recommended first production values should be chosen by owner, not hard-coded by a model.
