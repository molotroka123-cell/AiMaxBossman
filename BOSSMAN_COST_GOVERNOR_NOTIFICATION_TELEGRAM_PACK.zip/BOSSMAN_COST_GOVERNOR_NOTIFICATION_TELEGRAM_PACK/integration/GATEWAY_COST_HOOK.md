# Stage3 Gateway Cost Hook

## Why Gateway, not only llm.py

`bossman-fast/smart/...` are capability aliases. A request can:
local target -> 5xx/health fallback -> OpenRouter target.

Core `llm.py` cannot always know before routing whether money will be spent.
The Gateway does know the exact target immediately before cloud network I/O.

## Required integration

Immediately before EACH real cloud upstream attempt:

1. Determine exact provider/model.
2. Resolve exact pricing from the current cached provider catalog.
3. Calculate conservative upper bound:
   prompt upper tokens × input price +
   max completion tokens × output price +
   fixed fees.
4. Build BudgetContext from correlation:
   run_id / task_id / project_id / device where available.
5. `BudgetEnforcer.reserve(...)`.
6. Only ALLOW can open the cloud request.
7. On response, compute actual cost from exact usage + same pricing version.
8. `commit(reservation_id, actual)`.
9. On failure before a billable request was accepted: release.
10. If provider semantics may bill failed calls, account according to provider contract.

## Pricing unknown

If an applicable budget policy exists and exact pricing is unavailable:
**deny cloud attempt** with a typed `BudgetPricingUnknown`, emit sanitized event.

Do not use “$0” or “probably cheap”.

## Retry/fallback

Each potentially billable cloud attempt needs its own idempotency key derived from:
request_id + route attempt + exact provider/model.

Retry must not double-reserve the same attempt.
Different billable attempts must not reuse an idempotency key.

## Budget ASK

`BudgetEnforcer` uses existing `approvals.create/wait`.
Budget approval is separate from cloud-policy approval.

Both gates must be satisfied if both apply.
Budget approval can never change `cloud_policy`.
