# Existing seams this pack was designed around

At pack preparation time the branch contained:

- `bossman/events.py` with `subscribe / unsubscribe / emit`.
- `bossman/approvals.py` with `create / decide / wait` and a call to
  `telegram.ask_approval`.
- `bossman/telegram.py` with direct `httpx` send and raw `approve:<id>` /
  `reject:<id>` callback_data.
- `bossman/api.py` with Stage6-scoped Core routes, subsystem/router registries and
  Telegram webhook-secret validation.
- `bossman/llm.py` using the Stage3 Gateway and capability aliases.

Because HEAD is moving, integration MUST re-check these APIs before adoption.
The pack intentionally keeps compatibility functions for the current approvals seam.
