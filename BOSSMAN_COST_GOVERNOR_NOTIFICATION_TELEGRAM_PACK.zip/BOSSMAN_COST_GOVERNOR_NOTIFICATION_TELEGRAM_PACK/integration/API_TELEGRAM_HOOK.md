# Secure Telegram webhook replacement

Current API route directly accepts `approve:<id>` / `reject:<id>` after webhook-secret check.
After this pack, outgoing buttons are opaque `b:<random>` callbacks.

Adapt the existing route to:

```python
from . import telegram
from .notifications.store import CallbackRejected

@app.post("/telegram/webhook")
async def telegram_webhook(update: dict, request: Request):
    got = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    try:
        return await telegram.handle_webhook(update, got)
    except CallbackRejected:
        raise errors.AuthDenied("telegram callback denied")
```

Do not log `got`, callback token, bot token or full update.

Remove/disable the old parser for:
- approve:<id>
- reject:<id>

Existing messages with old buttons may stop working; this is intentional security hardening.
