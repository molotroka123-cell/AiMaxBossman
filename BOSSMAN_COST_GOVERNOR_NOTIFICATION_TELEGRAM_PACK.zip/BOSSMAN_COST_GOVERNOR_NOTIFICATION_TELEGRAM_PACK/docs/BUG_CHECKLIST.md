# Bug / adversarial checklist

## Cost
- [ ] parallel reservations cannot overspend
- [ ] Decimal precision, no float money
- [ ] STOP blocks before cloud socket
- [ ] ASK uses existing approvals
- [ ] cloud_policy=never beats approved budget override
- [ ] model cannot mutate policy
- [ ] chat token cannot mutate policy
- [ ] exact policy overrides wildcard
- [ ] run/task/project/global all applied
- [ ] UTC day rollover works
- [ ] reservation success commits actual
- [ ] exception/cancel releases reservation
- [ ] duplicate request id cannot double reserve
- [ ] stale reservation cleanup releases held amount
- [ ] restart retains spend/reservations
- [ ] override wrong context rejected
- [ ] override expired rejected
- [ ] override replay rejected
- [ ] unknown cloud pricing fails closed when budget enabled
- [ ] actual > reserved is never silently committed

## Notifications
- [ ] EventBus reused
- [ ] dispatcher restart recovers SENDING
- [ ] dedupe prevents duplicate approval messages
- [ ] bounded retries/backoff
- [ ] Telegram outage does not fail task
- [ ] no raw prompt/diff/secret forwarded
- [ ] bot token absent from errors/logs/DB
- [ ] callback data contains no approval id
- [ ] callback wrong chat rejected
- [ ] callback expired rejected
- [ ] callback replay rejected
- [ ] raw legacy approve:<id> rejected
- [ ] wrong webhook secret rejected
- [ ] approval already decided fails closed
- [ ] no callback can create a new approval
- [ ] no callback can change budget policy
- [ ] notification routes use Stage6 scopes

## Full
- [ ] targeted tests green
- [ ] bossman-core full green
- [ ] command-center full green
- [ ] secret scan green
- [ ] CI green on tested HEAD
