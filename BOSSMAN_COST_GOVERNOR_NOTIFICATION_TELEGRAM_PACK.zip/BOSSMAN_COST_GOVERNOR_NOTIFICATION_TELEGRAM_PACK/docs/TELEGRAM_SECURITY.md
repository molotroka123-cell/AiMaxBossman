# Telegram Security

Telegram is transport, not a new authorization model.

Outgoing approval buttons use `b:<opaque random token>`, not `approve:<id>`.
Server stores only SHA-256 of callback token.

Callback is bound to:
- target type/id;
- action;
- configured chat;
- fingerprint;
- expiry;
- single use.

Webhook requires the existing `TELEGRAM_WEBHOOK_SECRET` header and configured chat.
Optional `TELEGRAM_ALLOWED_USER_IDS` further pins Telegram users.

Approval effect calls existing `bossman.approvals.decide()`; it does not modify the
approvals table directly.

Old raw `approve:<id>` / `reject:<id>` callbacks must be rejected after integration.

Bot token must never appear in logs. Transport wraps HTTP exceptions and persists only
exception type/status, not token-bearing Telegram URLs.
