# Live acceptance

Budget:
1. Set tiny test daily limit (e.g. $0.02) on a disposable/test provider path.
2. Mock-priced request below limit executes.
3. Parallel requests cannot reserve above limit.
4. STOP request above limit produces zero provider call.
5. ASK request reaches WAITING approval; reject -> zero provider call.
6. Approve bounded override; only the exact request gets one use.
7. Restore production budget policy.

Telegram (only if credentials available):
1. Send test notification.
2. Trigger fake/test approval.
3. Telegram receives one message with opaque callbacks.
4. Deny works.
5. Replay same callback fails.
6. Trigger another approval, Approve works exactly once.
7. Temporarily simulate Telegram network failure; Core task continues and queue retries.
8. Search logs/state for bot token and webhook secret: zero matches.

If Telegram credentials are absent: tests remain green and live result is
`BLOCKED_BY_CREDENTIAL`, never fake PASS.
