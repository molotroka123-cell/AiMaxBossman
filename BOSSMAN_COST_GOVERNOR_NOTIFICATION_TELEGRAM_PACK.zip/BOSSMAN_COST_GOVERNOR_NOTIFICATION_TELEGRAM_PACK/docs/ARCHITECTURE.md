# Architecture — Cost Governor + Notifications

```text
Stage 3 Gateway
  exact cloud target + pricing
        |
        v
Cost Enforcer
  cloud_policy gate
  reserve upper-bound USD
  run/task/project/day buckets
        |
        +-- STOP -> deny before network
        |
        +-- ASK -> existing approvals -> single-use override
        |
        v
cloud upstream
        |
  usage + exact pricing
        |
  commit actual / release on pre-network failure
        |
existing bossman.events
        |
Notification EventBridge
        |
durable queue
        |
TelegramTransport
        |
phone
```

The budget boundary lives immediately before the real cloud upstream attempt, not
only in `llm.py`, because a capability alias can route local first and cloud second.

Notification delivery is asynchronous. Telegram outage never changes task correctness
or approval correctness.
