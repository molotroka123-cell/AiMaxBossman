# Phone-worthy events

Default mapping:
- task.completed / task.done / run.completed
- task.failed / run.failed / job.failed
- approval.created / approval.required
- budget.warning
- budget.exceeded / budget.approval_required
- service.degraded / service.failed
- emergency_lock / system.emergency_lock / remote.lock_all

Do not forward:
- full prompts;
- raw model messages;
- full diffs;
- screenshots;
- secrets;
- API keys;
- arbitrary EventBus payloads.

NotificationPolicy explicitly allowlists event families and sanitizes selected fields.
