# Security invariants

1. cloud_policy is above money approval. Budget approval never authorizes cloud.
2. Model/tool cannot mutate budget policy. Policy writes are `admin`.
3. `chat` may read budget status but cannot raise limits.
4. In-flight reservations are atomic.
5. Override is exact-context, bounded, expiring and single-use.
6. Telegram callback is opaque, bound, expiring, single-use.
7. Webhook secret and chat binding are both required.
8. Telegram failure cannot block Core or cause auto-approval.
9. Notification messages are allowlisted + redacted.
10. No real OpenRouter spending is required for ordinary tests.
