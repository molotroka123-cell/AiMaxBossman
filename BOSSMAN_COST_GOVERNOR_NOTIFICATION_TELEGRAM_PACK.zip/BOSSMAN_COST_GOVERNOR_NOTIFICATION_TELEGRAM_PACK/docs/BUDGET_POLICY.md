# Budget Policy

Supported scopes:
- run
- task
- project
- daily_global (UTC calendar day)

Policy resolution: exact subject overrides `*`.

Accounting:
`projected = spent + reserved_in_flight + new_upper_bound`.

This prevents N parallel agents from each seeing the same remaining balance.

Hard action:
- STOP: deny before network.
- ASK: create existing BOSSMAN approval; if approved, issue exact-context,
  amount-bounded, TTL, single-use override. Persistent policy is unchanged.

Money uses Decimal strings in SQLite.

The preflight estimate must be a conservative upper bound based on:
- exact chosen provider/model;
- prompt token upper bound;
- max completion tokens;
- exact catalog price units;
- provider fixed/request fees if any.

If pricing is unknown while any applicable budget is enabled: FAIL CLOSED.
Never guess “probably cheap”.

`actual > reserved` is an accounting anomaly: do not silently accept it. It indicates
the preflight pricing/upper-bound adapter is wrong and must block/reconcile.
