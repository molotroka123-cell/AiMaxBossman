# Acceptance Matrix

| Area | Required |
|---|---|
| Budget unit | PASS |
| Parallel overspend | PASS |
| Override adversarial | PASS |
| Cloud-policy precedence | PASS |
| Telegram callback adversarial | PASS |
| Queue retry/dedupe | PASS |
| Existing approvals regression | PASS |
| Gateway cloud enforcement | WIRED + tested |
| bossman-core full | 0 failed |
| command-center full | 0 failed |
| secret scan | PASS |
| Telegram live | PASS or BLOCKED_BY_CREDENTIAL |
| GitHub CI | success on final HEAD |
