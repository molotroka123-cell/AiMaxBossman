"""Compatibility facade: existing approvals.py can keep importing bossman.telegram."""
from __future__ import annotations
from .notifications.runtime import TELEGRAM,enqueue_approval,enqueue_text,handle_telegram_webhook

def enabled()->bool:return TELEGRAM.enabled()
async def notify(text:str)->None:await enqueue_text(text)
async def ask_approval(approval_id:int,preview:str)->None:await enqueue_approval(approval_id,preview)
async def handle_webhook(update:dict,secret_header:str):return await handle_telegram_webhook(update,secret_header)
