# CLAUDE CODE — IMPLEMENT BOSSMAN IMAGES EXACTLY

Use this package as the implementation source.

Do not convert it to React.
Do not redesign the backend extension mechanism.
Do not modify central API files unless a real test demonstrates it is necessary.

## Current repository extension points already verified

Backend feature module:
`command-center/bcc/features/*.py`

Frontend feature page:
`command-center/ui/pages/*.js`

Frontend registry:
`command-center/ui/pages/index.js`

## Step 1 — copy these new files

```text
command-center/bcc/features/images.py
command-center/bcc/v2/images_tables.py
command-center/bcc/v2/images_runtime.py
command-center/tests/test_feat_images.py
command-center/ui/pages/images.js
docs/reference-images/images-panel-reference.png
```

## Step 2 — patch the UI page registry

Edit:

`command-center/ui/pages/index.js`

Add:

```javascript
import ImagesPage from './images.js';
```

and add:

```javascript
ImagesPage,
```

to `FEATURE_PAGES`.

Use `patches/pages_index.patch` as reference.

## Step 3 — run focused tests

```bash
cd command-center
pytest -q tests/test_feat_images.py
```

Then:

```bash
pytest -q
```

## Step 4 — start real Command Center

```bash
bcc
```

Open the new:

`Изображения`

page.

## Step 5 — real UI acceptance

Must work:

1. open Images page
2. type a prompt
3. select model / aspect ratio / count
4. click Generate
5. queued job appears
6. feature tick completes the job
7. generated preview appears in library
8. click preview
9. right inspector shows prompt/model/seed/size
10. click "Повторить промпт" to reuse it
11. click "Вариация" and a new job is created
12. create a folder/collection
13. assign asset to collection
14. mark asset favorite
15. recent jobs panel updates
16. storage stats update

## Important

The included provider is intentionally:

`mock`

It generates deterministic SVG previews locally and has zero network dependency.

Do NOT mark real image-provider support DONE merely because this page works.

The architecture is designed so a real image provider can later replace/extend
`MockImageProvider`.

For this pass, mark:

- Images library: DONE if E2E works
- Image job queue: DONE if DB + tick + events work
- Mock provider: DONE if previews are produced
- Real providers: PARTIAL unless actually connected and tested

## Existing image model data

`GET /api/images/models` exposes:

- a guaranteed local `mock-image` entry
- any BOSSMAN model whose `caps` advertise:
  - `image_generation`
  - `image`
  - `images`
  - `text_to_image`

Do not expose ordinary LLMs as image generators unless their registry capabilities say so.

## Do not add dependencies

This implementation deliberately avoids:
- Pillow
- python-multipart
- React
- npm packages

Keep the first pass dependency-free.

## Final proof

Create:

`docs/IMAGES_FEATURE_REPORT.md`

Include:
- commit
- changed files
- tests
- screenshot
- current limitations
- exact real-provider next step

Do not claim real provider generation unless actually tested.
