# BOSSMAN Images — exact GitHub integration pack

This pack was rewritten specifically for the **current AiMaxBossman repository architecture**.

Target:
- repo: `molotroka123-cell/AiMaxBossman`
- branch audited: `claude/bossman-control-v03-43igbk`
- current Command Center UI is **vanilla ES modules**, NOT React
- V2 backend features auto-load from `command-center/bcc/features/*.py`
- V2 page registry is `command-center/ui/pages/index.js`

The previous generic React scaffold should NOT be used.

## Claude: start here

Read:

1. `CLAUDE_IMPLEMENT_IMAGES_EXACT.md`
2. `docs/REPO_ALIGNMENT.md`
3. supplied source files

Then copy/merge the files.

## New files that can be copied directly

- `command-center/bcc/features/images.py`
- `command-center/bcc/v2/images_tables.py`
- `command-center/bcc/v2/images_runtime.py`
- `command-center/tests/test_feat_images.py`
- `command-center/ui/pages/images.js`

## Existing file with a tiny edit

`command-center/ui/pages/index.js`

Use:

`patches/pages_index.patch`

or manually add the two documented lines.

No changes to:
- `command-center/bcc/api.py`
- `command-center/ui/api.js`
- `command-center/ui/app.js`

are required for the first implementation because the repository already has the exact extension points we need.
