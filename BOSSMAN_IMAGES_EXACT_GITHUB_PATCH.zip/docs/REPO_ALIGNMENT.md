# Why this patch matches the current repository

The current repo already provides the extension mechanisms this feature needs.

## Backend

`Services.__init__()` calls:

```python
self.features = load_features()
```

before `db.create_all()`.

`load_features()` imports every module in:

```text
command-center/bcc/features/
```

and registers each exported:

```python
FEATURE = Feature(...)
```

Therefore `features/images.py` can import `v2/images_tables.py` during feature discovery.
That registers the image SQLAlchemy tables on the canonical `bcc.db.metadata`
**before create_all() executes**.

No central API edit is required.

The main app later mounts each feature router under:

```text
/api
```

with canonical BOSSMAN token authentication.

So the router in this package intentionally uses paths like:

```text
/images/assets
/images/jobs
```

which become:

```text
/api/images/assets
/api/images/jobs
```

at runtime.

## UI

The current UI is vanilla JavaScript:

```text
command-center/ui/
  api.js
  app.js
  components.js
  pages.js
  pages/
```

Feature pages export:

```javascript
{
  id,
  title,
  icon,
  nav,
  render(ctx),
  onEvent(ev)
}
```

The supplied `images.js` follows exactly that contract.

It uses the already-existing:

```javascript
api.raw(...)
getToken()
h(...)
icon(...)
statusBadge(...)
toastOk(...)
toastError(...)
pageHead(...)
errorBanner(...)
emptyPanel(...)
```

No React, TypeScript, Tailwind, bundler or npm build step is introduced.

## Media files

A normal `<img src="/api/...">` cannot add the `X-BCC-Token` header.

Therefore the Images page follows the same pattern as the existing Browser page:

1. `fetch()` the protected image endpoint with `X-BCC-Token`
2. create a browser object URL
3. assign that object URL to `<img>`
4. revoke it when no longer needed

This keeps generated assets authenticated without exposing the image directory publicly.

## Background execution

The feature uses the existing V2 feature tick mechanism.

Normal server:

```text
POST job
→ DB status queued
→ images feature tick claims queued job
→ running
→ mock runtime produces asset
→ completed
→ image.* events
→ page refreshes through normal event flow
```

When tests use `start_workers=False`, the test directly invokes the exported
`process_one()` helper so tests stay deterministic.
