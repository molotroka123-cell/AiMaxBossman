# Acceptance checklist

## Backend
- [ ] `features/images.py` auto-loads with no central API edit
- [ ] image tables exist after startup
- [ ] `/api/images/assets` authenticated
- [ ] `/api/images/models` contains `mock-image`
- [ ] POST job persists queued row
- [ ] feature tick claims queued row
- [ ] completed job creates asset
- [ ] protected file endpoint returns image bytes
- [ ] import endpoint accepts base64 image up to 15 MB
- [ ] favorite / tags / collection patch works
- [ ] real unwired provider fails honestly instead of faking success
- [ ] image events appear on EventBus

## UI
- [ ] Images page appears in sidebar
- [ ] no React/bundler added
- [ ] prompt composer works
- [ ] model dropdown loads API data
- [ ] aspect ratio adjusts dimensions
- [ ] queue updates after generation
- [ ] library cards load protected previews
- [ ] selection opens inspector
- [ ] repeat prompt works
- [ ] variation creates a job
- [ ] favorite works
- [ ] import works
- [ ] collection create works
- [ ] mobile has no horizontal page overflow at 390/430 px

## Honesty
- [ ] Mock provider labeled as mock
- [ ] real provider support remains PARTIAL until actually integrated/tested
