# Opportunity scoring

Score each dimension 0–10.

| Dimension | Weight |
|---|---:|
| Pain severity | 15 |
| Proven willingness to pay | 13 |
| Regulatory/market trigger | 10 |
| Distribution accessibility | 11 |
| Automation advantage | 10 |
| Time to first revenue | 9 |
| Gross-margin potential | 7 |
| Retention/frequency | 7 |
| Competitive whitespace | 6 |
| Data/integration accessibility | 5 |
| Defensibility | 4 |
| Strategic fit | 3 |

Base:
weighted average / 10.

## Confidence multiplier

| Evidence quality | Multiplier |
|---|---:|
| paid evidence + strong primary data | 1.00 |
| interviews + primary + competitor evidence | 0.90 |
| primary data + strong indirect evidence | 0.80 |
| mostly secondary | 0.70 |
| hypothesis-heavy | 0.60 |
| speculation | <=0.50 |

Final score:
`base_score × confidence_multiplier`

## Hard blockers

Independent of score:
- no payer;
- unlawful planned acquisition;
- required licence unavailable;
- core data unavailable;
- structural gross-margin failure;
- disproportionate liability;
- market commoditized below sustainable price;
- product requires custom build for every customer;
- no plausible first-payment path.

## Decision bands

8.0–10.0:
immediate deep validation

7.0–7.99:
validate when capacity exists

6.0–6.99:
improve evidence / monitor

5.0–5.99:
park

<5.0:
reject unless trigger changes.

## Anti-gaming

The agent must display:
- every component score;
- source/evidence behind score;
- confidence;
- blocker state;
- missing evidence.

No single composite number may conceal a score <=3 on payer, legality or access.
