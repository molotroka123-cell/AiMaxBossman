# Venture stage gates

## Gate 0 — evidence scan

Duration:
1–3 days.

Output:
opportunity object + top unknowns.

Pass:
payer identifiable and no hard blocker.

## Gate 1 — problem proof

Target:
10–20 qualified interviews or equivalent first-party evidence.

Default pass:
>=60% independently describe the pain/workaround.

Rules:
- no leading questions;
- record disconfirming evidence;
- segment respondents.

## Gate 2 — payment proof

Preferred:
- paid pilot;
- deposit;
- paid concierge;
- paid beta.

Micro/SMB default:
3 independent paying customers.

Higher-ticket B2B:
one meaningful paid pilot may justify limited build.

“Sounds useful” is not payment proof.

## Gate 3 — repeat-use proof

Identify an activation and retention event.

Pass example:
>=50% of paid pilot customers repeat the core workflow.

## Gate 4 — acquisition proof

At least one channel produces paying customers within acceptable cash payback.

## Gate 5 — scale

Requirements:
- actual gross margin known;
- retention measured;
- support burden measured;
- cash controls;
- legal/compliance path;
- acquisition source.

## Bypass

Any bypass requires:
- owner approval;
- written exception;
- reason;
- maximum capital;
- deadline;
- kill metric.

No permanent “strategic exception”.
