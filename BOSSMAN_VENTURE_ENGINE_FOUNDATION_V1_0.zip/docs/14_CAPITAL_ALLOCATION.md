# Capital allocation policy

## Default limits

Discovery:
<=1,000 CZK/opportunity.

Validation:
<=5,000 CZK/ordinary experiment.

Pre-payment external build:
<=20,000 CZK/venture.

>50,000 CZK cumulative external spend:
mandatory investment review.

## Investment review

Required:
- actual revenue;
- actual collected cash;
- contribution margin;
- acquisition;
- retention;
- support;
- bear/base/bull;
- remaining unknowns;
- runway;
- next milestone;
- kill condition.

## Portfolio capacity

Start:
1 build + 1 research.

Do not fund a third active build because an agent has spare tokens.

## R&D cash multiple

`cumulative contribution margin /
 cumulative external validation+development cash`

Track over time.

## Engineering shadow cost

Internal development is not economically free.

Use configurable shadow CZK/day to compare opportunities.
