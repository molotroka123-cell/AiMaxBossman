# ŽivnoPilot calibration case

Status:
candidate, not selected App #3.

## Thesis

Czech microbusiness owners often operate across fragmented customer messages,
quotes, calendars, jobs, invoices, payments, expenses and accountant handoff.

EET 2.0 can increase attention to transaction administration, but EET alone
should not be the product.

## Wedge

job
→ quote
→ schedule
→ work
→ payment
→ invoice/EET where applicable
→ expense
→ accountant.

## Initial ICP candidates

Do not target “all OSVČ”.

Compare:
- electricians;
- plumbers;
- installation trades;
- cleaners;
- beauty;
- repair/service;
- small auto workshops.

## Pricing hypotheses

Solo:
249 vs 349 CZK.

Pro:
499 vs 699 CZK.

Team:
999 vs 1,490 CZK.

These are experiment cells, not final pricing.

## Activation

First complete job-to-cash flow.

Target time to value:
<15 minutes.

## 90-day management target

Day 30:
15+ qualified interviews;
3+ pilot willingness signals.

Day 60:
first paid pilots.

Day 90:
10 paying accounts OR a clear pivot/kill recommendation.

## Main competitive warning

Czech invoice software is already inexpensive and mature.

Therefore “AI invoice generator” is a weak wedge.

## Regulatory warning

EET technical infrastructure is progressing while legislation has recently
remained in parliamentary process. Recheck before any feature promise.
