# Unit economics

## Required actual metrics

Revenue:
- subscription;
- usage;
- setup;
- services;
- discounts;
- refunds;
- net collected.

Variable cost:
- inference;
- OCR;
- API;
- storage;
- bandwidth;
- e-mail/SMS;
- payment fees;
- customer-specific compute;
- support attributable to account.

Contribution:
`net revenue - variable costs`

Contribution margin:
`contribution / net revenue`

## Target bands

Low-compute SaaS:
>85% mature target.

AI-heavy SaaS:
>70% early;
>80% mature preferred.

Service-assisted:
>50% pilot is acceptable if automation path is credible.

## CAC

Cash CAC:
cash acquisition spend / new paid customers.

Fully loaded CAC:
cash acquisition + attributable sales labor / new paid customers.

Track by channel.

## Payback

Low-ticket SaaS:
<=4 months preferred;
<=6 months acceptable after retention proof;
>9 months requires exceptional retention/expansion economics.

## LTV

Early:
use capped 12-month contribution LTV.

Do not use infinite churn formula on tiny cohorts.

Mature:
show cohort size before using churn-based LTV.

## LTV:CAC

>=3 acceptable;
>=4 strong;
<2 not scalable without correction.

## Time to Revenue

Target for micro/SMB:
<=45 days from validation approval to first external payment.
