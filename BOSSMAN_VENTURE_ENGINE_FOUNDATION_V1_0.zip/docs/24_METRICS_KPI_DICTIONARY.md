# KPI dictionary

## Revenue

MRR:
normalized recurring monthly subscription revenue.

ARR:
12 × current normalized MRR; not collected cash.

Net revenue:
gross billed/collected according to defined accounting view minus discounts,
refunds and taxes excluded from revenue where applicable.

## Contribution

Net revenue minus directly variable product delivery costs.

## ARPA

Average recurring revenue / active paying account.

## CAC

Channel spend / attributable new paying accounts.

Report cash and fully loaded CAC separately.

## Payback

CAC / monthly contribution per new account.

## Activation

First event strongly correlated with receiving product value.

## Retention

Cohort share repeating the defined value event or remaining paid.

## Churn

Logo churn and MRR churn separately.

## Support load

Minutes of human support / active account / period.

## TTR

Approval of validation -> first real external payment.

## Learning efficiency

Experiment spend / high-value uncertainty resolved.

## Metric integrity

Every KPI definition must specify:
- numerator;
- denominator;
- time window;
- exclusions;
- data source.
