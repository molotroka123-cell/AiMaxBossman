# Numerical models

These CSV files are planning aids, not forecasts.

- `customers_needed_by_arpa.csv`: accounts needed for MRR milestones.
- `osvc_penetration_scenarios.csv`: mechanical penetration examples using the
  March-2026 OSVČ base carried in the research draft; revalidate primary dataset
  before external use.
- `cac_payback_matrix.csv`: sensitivity to ARPA/gross margin/CAC.
- `ltv_sensitivity.csv`: demonstrates how dangerous churn-based LTV assumptions
  can be; compare with capped 12-month contribution.
- `experiment_budget_ladder.csv`: frozen V1.0 internal budget policy.

The agent must never present these outputs as market forecasts without a
venture-specific SAM and acquisition model.
