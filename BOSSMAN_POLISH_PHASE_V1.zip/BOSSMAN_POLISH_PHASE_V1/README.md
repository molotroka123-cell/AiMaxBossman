# BOSSMAN POLISH PHASE V1

This pack is designed to be dropped into the next coding-agent run without
losing project context.

Read order:
1. `00_AUDIT_AND_CONTEXT.md`
2. `01_POLISH_BACKLOG.md`
3. `02_MASTER_PROMPT_POLISH.md`
4. `03_EVENING_ACCEPTANCE.md`

The pack deliberately does not contain another framework.
It is a context + execution package for finishing the existing architecture.
