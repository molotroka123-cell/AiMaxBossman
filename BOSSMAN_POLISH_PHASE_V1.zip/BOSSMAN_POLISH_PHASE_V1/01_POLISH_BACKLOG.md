# POLISH BACKLOG — ORDERED

## Wave 1 — Repository + status hygiene
- inventory root;
- dedupe/archive historical MD;
- remove fully integrated transfer ZIPs;
- inspect foreign-model handoff folders before removal;
- keep only canonical current-state docs;
- update README to point at `docs/context/CURRENT_STATE.md`;
- no deletion of unique code/specs.

## Wave 2 — Finish real plugin execution
Priority:
1. GitHub
2. Obsidian
3. Browser
4. Ollama
5. OpenRouter
6. Telegram
7. SQL read
8. MCP
9. n8n
10. Gmail
11. Calendar
12. Drive
13. monitor/http

For each: typed contract, existing authority, real handler, bounded output,
timeouts, idempotency where relevant, redaction, targeted tests, honest live status.

## Wave 3 — Coding workflow polish
Implement/finish:
- CodingSession durable model;
- isolated worktree/session;
- resume/fork;
- changed-file tracking;
- test evidence;
- LSP evidence;
- diff-aware reviewer;
- conflict detection;
- merge preview;
- rollback/cancel.

## Wave 4 — Context + observability
One task trace should correlate:
task/session/agent/model/provider/tools/approvals/retries/cost/files/tests/result.

Checkpoint/compaction must retain:
objective, invariants, decisions, files, evidence, blockers, next action.

## Wave 5 — Command Center UX
Build one coherent operator path:
Task -> Session -> Activity -> Diff -> Diagnostics -> Tests -> Review ->
Approval -> Merge/Action -> Audit.

Add:
- plugin health
- degraded reason
- model/cost/latency
- resume/fork
- approval inbox clarity.

## Wave 6 — Reliability/security
Test:
- provider down
- Ollama down
- browser down
- restart
- duplicate approval
- duplicate external write
- SSRF + redirect
- path/symlink escape
- SQL write
- unknown MCP capability
- secret leakage.

## Wave 7 — benchmark readiness
Use same task/model/repo snapshot.
Do not claim Bossman > OpenCode without measured evidence.

## Wave 8 — freeze
Only P0/P1 fixes after acceptance begins.
