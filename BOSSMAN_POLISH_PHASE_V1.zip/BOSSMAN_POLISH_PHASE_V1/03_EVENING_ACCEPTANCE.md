# EVENING ACCEPTANCE — POLISH EXIT

Mandatory real-host sequence:

1. Clean pull of exact POLISH_FINAL_HEAD.
2. Start required DB/services.
3. Start Ollama and selected local 3–4B 4-bit model.
4. Start Bossman Core + Command Center.
5. Verify health.
6. Set/verify local-only policy.
7. Ask Bossman: `Открой Блокнот`.
8. Verify production chain and fresh observation.
9. Optional type marker `BOSSMAN-POLISH-LIVE`.
10. Attempt unsafe app/shell-like launch -> DENY.
11. Prove cloud calls = 0.
12. FactStore write/read/restart/read.
13. Context resume after restart.
14. Browser read + controlled input.
15. Approval reject -> zero side effect.
16. Approval approve -> exactly one safe side effect.
17. Plugin live matrix for configured services.
18. Cost Governor reserve/commit/release/budget stop.
19. Pythia offline fail-soft; live/recovery if service available.
20. Chaos: stop Ollama/browser/core/Command Center and verify graceful recovery.
21. Full regression + secret scan.
22. CI exact SHA.
23. Only then final V1/V2 freeze decision.

Allowed statuses:
PASS / FAIL / SKIP_HOST / SKIP_EXTERNAL_SERVICE / SKIP_EXTERNAL_CREDENTIAL / NOT_TESTED
