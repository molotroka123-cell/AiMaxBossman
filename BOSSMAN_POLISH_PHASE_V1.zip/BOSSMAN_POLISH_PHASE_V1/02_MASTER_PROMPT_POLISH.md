# BOSSMAN — POLISH MASTER PROMPT

You are working on:
`molotroka123-cell/AiMaxBossman`
branch:
`claude/bossman-control-v03-43igbk`

This is the POLISH phase.

Goal:
finish incomplete implementation, simplify the repository, improve coding UX,
turn adapter stubs into real integrations, strengthen context/observability,
and leave the system READY for the evening real-machine acceptance run.

Do NOT start a new architecture epoch.

## 1. Establish truth
- git fetch
- resolve remote HEAD
- record `POLISH_START_HEAD`
- read every MD in the supplied POLISH pack
- read latest `docs/context/*` reports
- inspect code before trusting historical prose
- create/update `docs/context/POLISH_LIVE_CONTEXT.md`

After every wave append:
HEAD, completed, changed files, tests, decisions, bugs, unresolved P0/P1, next action.

## 2. Preserve architecture
Never introduce duplicate Gateway/policy/approval/secrets/audit/browser/Telegram/MCP/memory authorities.
Use existing seams.

No LLM -> arbitrary shell bypass.

## 3. Clean repository safely
Inventory root and classify:
KEEP / MOVE_TO_DOCS_ARCHIVE / DELETE_INTEGRATED_ARTIFACT / REVIEW_UNIQUE.

Before deleting any ZIP/handoff/report:
prove its useful code/spec has already landed.

Move historical reports to `docs/archive/`.
Remove integrated transfer ZIPs from working tree.
Keep canonical current-state documentation.
Update README/status links.

Write:
`docs/context/REPO_HYGIENE_REPORT.md`.

## 4. Finish plugins for real
Audit every registered plugin capability.

For each produce:
CONTRACT_READY / POLICY_READY / EXECUTION_IMPLEMENTED / UNIT_VERIFIED / LIVE_VERIFIED.

Replace generic ready stubs with real adapters where existing Bossman infrastructure
and credentials make that possible.

Priority:
GitHub, Obsidian, Browser, Ollama, OpenRouter, Telegram, SQL-read, MCP,
n8n, Gmail, Calendar, Drive, monitor/http.

Rules:
- external mutation ASK
- destructive ASK
- unknown DENY
- cloud LLM through Gateway + Cost Governor
- Ollama through Gateway + cloud_policy=never
- browser through existing browser subsystem
- MCP through existing MCP runtime
- Telegram through existing transport
- secrets by reference, never logged
- bounded responses/timeouts
- idempotency/replay safety.

SQL read must actually execute against a read-only connection when configured;
validation-only is not EXECUTION_IMPLEMENTED.

No fake PASS when credential/service is absent.

Write:
`docs/context/PLUGIN_POLISH_REPORT.md`.

## 5. Polish coding experience
Audit existing LSP and code tools first.

Finish the production workflow:
`task -> coding session -> isolated worktree -> repo map/LSP -> edit -> diagnostics ->
tests -> diff -> reviewer -> approval if needed -> merge/rollback -> durable summary`

Reviewer MUST consume:
- acceptance criteria
- actual git diff
- diagnostics
- test output
- changed files
- security-sensitive changes
- TODO/SKIP/blockers

Add negative test:
agent prose says DONE while diff/tests are wrong -> reviewer must reject.

Implement durable resume/fork/worktree semantics using existing storage.

Do not rewrite working code-tool infrastructure.

Write:
`docs/context/CODING_POLISH_REPORT.md`.

## 6. Context polish
Measure, do not guess.

Add a deterministic long-session test:
large history -> compact -> restart/resume -> recover objective, architecture
invariants, decisions, files, test state, blockers and next action.

Do not inject all memory into every prompt.
Use relevance and budget.

## 7. Observability polish
Ensure a task/session correlation id joins:
model/provider, tool calls, approvals, retries, latency, Cost Governor,
changed files, tests, final state.

No secrets.

## 8. Command Center UX polish
Only high-ROI UX:
- coding sessions
- diff/reviewer panel
- diagnostics/tests
- model/cost/latency
- plugin health
- degraded reason
- approval inbox
- resume/fork
- clear final task journal

No aesthetic rewrite.

## 9. Security + reliability
Targeted red team:
SSRF/private IP, redirect SSRF, path traversal, symlink escape, SQL writes,
unknown capability, MCP escalation, secret leakage, approval replay,
duplicate external side effect, arbitrary shell.

Chaos:
provider down, Ollama down, browser down, Pythia down, restart core,
restart Command Center, cancel/retry task.

Fix P0/P1 with:
REPRO -> ROOT CAUSE -> TEST -> MINIMAL FIX -> RETEST.

## 10. Tests
During work: targeted first.

Before finish:
- full bossman-core
- full command-center
- plugins
- LSP/code-intel
- context/memory
- approvals
- Gateway
- Cost Governor
- Stage13
- Pythia
- security
- secret scan
- compileall
- JS syntax

Never hide SKIP.

## 11. Score honestly
Create:
`docs/context/POLISH_SCORECARD.md`

Each category:
BEFORE / AFTER / EVIDENCE / REMAINING GAP.

>=8 requires working feature + regression evidence.
~9 requires E2E/operational evidence or explicit host SKIP.

Do not inflate.

## 12. Prepare evening test
Create:
`docs/context/EVENING_LIVE_ACCEPTANCE.md`

Include exact commands/checklist for:
- Docker/Postgres/Redis if required
- Ollama
- Gateway
- local model
- Windows Notepad
- fresh observation
- cloud calls = 0
- unsafe launch deny
- memory restart
- plugins
- browser
- approvals
- Cost Governor
- Pythia
- chaos/security
- final regression.

## 13. Git discipline
Before push:
full tests, secret scan, diff review, no temp/debug, no unique artifact accidentally removed.

git fetch before push.
No force push.
If remote moved, reconcile normally.

Record `POLISH_FINAL_HEAD`.
Check CI on exact final SHA.

## 14. Required final report
Create:
`docs/context/POLISH_FINAL_REPORT.md`

Must contain:
- POLISH_START_HEAD
- POLISH_FINAL_HEAD
- cleanup
- files changed
- plugin truth matrix
- coding workflow result
- P0/P1/P2
- exact tests
- live/mock/skip distinction
- score before/after
- remaining evening-only gates.

Only declare:
`POLISH_CODE_GATE: PASS`
when P0/P1=0 and regressions are green.

Then STOP. Do not start another feature epoch.
