# BOSSMAN POLISH PHASE — AUDIT + CONTEXT

Repository: `molotroka123-cell/AiMaxBossman`
Branch: `claude/bossman-control-v03-43igbk`
Verified HEAD when this pack was built: `35b04d735c4879f6519d877deba21028acd4eb7a`

## Mission

POLISH is not another architecture epoch. The architecture is already broad.
This phase converts partially implemented/rough surfaces into a coherent,
daily-usable product and closes evidence gaps before the evening live run.

## Confirmed strong areas
- Core typed-action architecture.
- Existing policy/approval authority.
- Stage3 Gateway.
- Cost Governor.
- FactStore/memory foundation.
- Stage13 computer operator architecture.
- Pythia fail-soft/context-only architecture.
- Command Center.
- Plugin capabilities registered through the existing registry rather than a duplicate framework.
- LSP/code-intelligence bridge has been added and tested at code level.

## Important current gaps

### P0 — none known from the reviewed reports
Do not assume none exist: run security/regression.

### P1 product gaps
1. Plugin adapters are structurally integrated, but several handlers are still
   `NOT_TESTED_LIVE` / ready stubs rather than real execution paths.
2. SQL read adapter validates read-only SQL but does not yet execute the query.
3. Coding workflow is behind the rest of Bossman:
   - coding-session lifecycle;
   - worktree isolation;
   - resume/fork;
   - diff-aware reviewer;
   - test/diagnostic evidence attached to review;
   - merge/conflict UX.
4. LSP is code-tested but needs a real LSP host smoke.
5. Windows + Ollama real E2E remains mandatory proof.
6. Context retention needs measurable compaction/resume evidence.
7. UI/UX is functionally rich but needs one coherent operator workflow.
8. Observability needs one correlated task trace.
9. OpenCode comparison infrastructure exists, but real same-task benchmark evidence is missing.
10. Repository hygiene/status docs need consolidation.

## Plugin truth rule

Do not call a connector "implemented" merely because a capability is registered.

Classify each connector separately:
- CONTRACT_READY
- POLICY_READY
- EXECUTION_IMPLEMENTED
- UNIT_VERIFIED
- LIVE_VERIFIED

A plugin reaches PASS only when the appropriate layers are proven.

## Repo cleanup rule

Remove/archive historical transfer artifacts only after proving they contain no
unique requirements/code.

Root should converge toward production directories + a small canonical doc set.
Historical reports should move under `docs/archive/`.
Binary transfer ZIPs that are fully integrated should leave the working tree.

## Architecture invariants
Never create a second:
- Gateway
- policy engine
- approval engine
- secret store
- audit/event bus
- browser authority
- Telegram authority
- MCP authority
- memory authority

Canonical action flow:
`intent -> typed action/capability -> policy/scopes -> approval -> executor -> fresh result -> audit`

Cloud LLM:
`agent -> Gateway -> Cost Governor -> provider`

Local LLM:
`agent -> Gateway -> Ollama`, with `cloud_policy=never`

Pythia:
context/intelligence only; never action authority.

## Polish exit target

Code-level target:
- every major score >=8;
- coding/plugin/UX gaps materially improved;
- P0/P1 = 0;
- full regressions green.

Live target for evening:
- real Windows;
- real Ollama;
- real Notepad;
- fresh observation;
- zero cloud calls;
- plugin live matrix;
- restart/chaos;
- benchmark where possible.
