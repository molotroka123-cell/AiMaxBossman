# REFERENCE GITHUB CROSS-CHECK — POLISH

Purpose: every code change in POLISH should be checked against both:
1. current AiMaxBossman implementation;
2. proven patterns from mature/open implementations;
3. Bossman architecture invariants.

## LSP
Reference patterns reviewed:
- lsp-client/lsp-client — async-first LSP, capability negotiation, typed capability surfaces, explicit local-server configuration, no hidden downloads.
- python-lsp/python-lsp-jsonrpc — mature JSON-RPC framing/process patterns.

Bossman decision:
KEEP the existing lightweight `bcc/lsp_bridge.py` rather than adding a new dependency now.
Polish requirements:
- validate server-advertised capabilities before calling them;
- normalize Location vs LocationLink shapes;
- keep argv-only subprocess;
- workspace confinement;
- timeout + bounded payload;
- graceful shutdown;
- deterministic fake-server tests;
- optional real pyright/gopls smoke.
Do NOT replace the existing registry or add a second LSP framework.

## Worktree/session isolation
Reference patterns reviewed:
- DanHenton/opencode-worktree — one branch/worktree per task, context markers, serialized merge, abort on conflicts, orphan cleanup.
- RedWilly/opencode-agent — persistent worker/session IDs, managed worktrees, wait/status/interrupt/merge/close lifecycle.
- thunderock/forge — parallel agents isolated in worktrees, diff review before merge.
- zsprackett/agent-workspace — persistent session metadata and dirty-worktree state.

Bossman decision:
EXTEND existing tasks/runs/checkpoints/forks instead of building another session engine.
Required semantics:
- task/run remains authority;
- optional coding-worktree metadata attached to run/session;
- source repo is read-only to worker;
- branch/worktree names generated safely;
- merge is explicit and conflict-aware;
- serialize merges;
- no auto-delete before successful merge/explicit discard;
- orphan cleanup;
- durable session state survives restart;
- dirty/uncommitted state visible;
- existing replay/fork remains lineage authority.

## Reviewer
Reference pattern:
modern coding-agent harnesses make the diff the artifact, not the agent's prose.

Bossman reviewer must consume:
- actual `git diff --stat`;
- actual patch/diff;
- changed-file list;
- test results;
- diagnostics;
- acceptance criteria;
- security-sensitive paths;
- unresolved TODO/SKIP.
Negative test required:
agent says DONE while diff/test evidence is wrong -> reject.

## Plugins
Bossman already made the correct architectural choice:
adapters over the existing registry/policy/approval/secret/audit layers.

Polish rule:
never add a connector SDK/framework that bypasses Bossman authority.
A plugin is not PASS just because it is registered.

Truth states:
CONTRACT_READY -> POLICY_READY -> EXECUTION_IMPLEMENTED -> UNIT_VERIFIED -> LIVE_VERIFIED.

## Safe code-insertion rule for Claude
Before pasting any supplied candidate:
1. inspect target file/interfaces on current remote HEAD;
2. adapt imports/types/storage to current Bossman;
3. add/extend targeted regression first or in the same patch;
4. run targeted tests;
5. run full relevant suite;
6. inspect diff;
7. only then commit.

No blind copy from external GitHub.
External repos are pattern references, not drop-in authority.
