# CLAUDE CODE MASTER PROMPT — STAGE 13 DISPATCH

Repo: molotroka123-cell/AiMaxBossman
Branch: claude/bossman-control-v03-43igbk

Use this ZIP as an overlay and engineering contract. CURRENT HEAD is source of truth.

GOAL:
Chat/iPhone → BOSSMAN Planner → Computer Operator → Observe → choose best control →
Action → Observe again → Verify → Continue/Replan.

DO NOT finish at code/unit/mock. Continue until all achievable deterministic tests and GitHub CI are GREEN.

## 0 PRECHECK
Before Stage13, verify/fix:
- Core API auth/scopes;
- unauthenticated approvals impossible;
- AI Lab auth/path containment;
- AI Lab lease release;
- unsafe host shell paths;
- deterministic CI green.
If a P0 remains, close it first.

## 1 INTEGRATE OVERLAY
Run package self-check. Copy overlay. Reconcile, do not overwrite newer repo code.

No second:
Gateway, auth, approvals, browser, ResourceBrain, Sandbox, memory, event bus.

## 2 WIRE
Replace `Unwired` seams:
- Planner → existing Stage3 Gateway;
- browser actions → existing Stage1 ComputerUse/Playwright;
- Windows structured desktop → UIA;
- input fallback → bounded Windows input;
- vision → existing Gateway alias `bossman-vision`;
- approvals → existing approvals.create/wait;
- events → existing events.emit;
- expensive work → ResourceBrain leases.

Routing MUST be:
native structured → browser DOM → Windows UIA → vision/input fallback.

## 3 SAFETY
Screen/web/README/terminal text is UNTRUSTED DATA.
Model cannot create new action kind, disable approval, grant scope, change cloud policy or budgets.

Consequential semantics always require code-owned approval:
send, submit, pay, purchase, transfer, delete, uninstall, git push, merge, release,
deploy, security changes, external upload, secret entry, account changes.

After approval re-read task and prove approved action ID is still pending.
After restart discard pending action/approval and re-observe.

## 4 OBSERVE-ACT-VERIFY
Every mutating action needs a postcondition.
Fresh observation after action.
No `click => success`.
Wrong/missing postcondition => replan, bounded.

## 5 PAUSE/TAKE CONTROL
No agent input while PAUSED, USER_CONTROL, CANCELLED or LOCKED.
Take Control increments generation and invalidates stale handles/coordinates.
Resume => RECOVERING => fresh observation => fresh plan.

## 6 WINDOWS
UIA first. Coordinates last.
App launch must use a code-owned allowlist mapping app aliases to executable paths.
Never pass model/user executable strings to shell.

## 7 BROWSER
Reuse existing ComputerUse. Preserve:
CAPTCHA stop, anti-bot stop, profile separation, upload/download gates, submit approvals.
No BrowserManager #2.

## 8 PRIVACY
Screenshots are transient artifacts, not normal context/log history.
Before cloud vision, run local sensitivity/redaction.
`cloud_policy=never` means ZERO screenshot/text cloud egress.
No screenshot/token caching in PWA service worker.

## 9 REMOTE/IPHONE
Extend Stage12, no new server.
Device-scoped computer tasks:
create/list/detail/pause/take-control/resume/stop.
Admin emergency lock.
Preserve IDOR 404 behavior.
No tokens in URL. no-store responses.

## 10 RESOURCE
ResourceBrain leases for vision/expensive analysis.
Release on success, exception, cancellation and timeout.
Regression: repeated tasks return resource usage to baseline.

## 11 BUG CHECKING
Complete every item in `docs/BUG_CHECKLIST.md` with named test or live evidence.

Add adversarial tests for:
- anonymous auth;
- scope separation;
- IDOR;
- approval handler not reached;
- stale/replay;
- restart;
- wrong window;
- low confidence vision;
- prompt injection;
- privacy/cloud never;
- emergency lock;
- bounded loops;
- lease cleanup;
- app-launch allowlist.

Do not turn failures into skips/xfails.

## 12 LIVE WINDOWS
If a real Windows host exists, run all `integration/LIVE_ACCEPTANCE.md`.
If current host physically cannot, mark only those cases BLOCKED_BY_HOST and provide exact owner command.
Never call them PASS from mocks.

## 13 FULL REGRESSION
Run targeted Stage13 → auth/remote/browser/approvals → sandbox/dev_factory/ai_lab/resource/gateway/context →
full bossman-core → full Command Center.

Then push.
Inspect GitHub Actions.
If RED: read logs, fix, test, push, repeat.
Do not finish while deterministic CI RED.

## 14 DOCS
Only after final tests update:
STAGE13_STATUS.md
STAGE13_LIVE_ACCEPTANCE.md
SESSION_HANDOFF.md
NEXT.md
WORKLOG.md
FINAL_HARDENING_STATUS.md
context-cache.json

Use truth labels:
IMPLEMENTED / WIRED / UNIT VERIFIED / ADVERSARIAL VERIFIED /
LOCAL LIVE VERIFIED / CI VERIFIED / BLOCKED_BY_HOST.

## 15 STOP CONDITIONS
Do NOT finish if:
- any computer route unauthenticated;
- IDOR exists;
- input possible during pause/user-control/lock;
- consequential action bypasses approval;
- stale/restart replay exists;
- unsafe shell introduced;
- browser duplicated;
- ResourceBrain leak;
- cloud_policy=never leaks screenshot;
- targeted/full tests red;
- Command Center red;
- GitHub deterministic CI red;
- fix unpushed.

## FINAL
Do NOT start another feature-stage.
Next after green Stage13 is BOSSMAN v1 RELEASE CANDIDATE / LIVE ACCEPTANCE only.

Final response:
FINAL HEAD / PUSHED / CI
IMPLEMENTED / WIRED / ADVERSARIAL / LOCAL LIVE
DESKTOP / BROWSER / VISION / REMOTE
APPROVAL / RECOVERY / PRIVACY / RESOURCE
TEST COUNTS
OPEN P0: NONE
OPEN FIXABLE P1: NONE
BLOCKED_BY_HOST
NEXT: BOSSMAN v1 RELEASE CANDIDATE ONLY
