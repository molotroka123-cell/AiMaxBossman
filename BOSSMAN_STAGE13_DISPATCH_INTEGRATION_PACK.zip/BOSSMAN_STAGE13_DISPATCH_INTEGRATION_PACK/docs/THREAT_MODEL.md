# Threat model
Protect keyboard/mouse authority, authenticated browser sessions, filesystem, secrets and approvals.

Attack cases: prompt injection on screen; wrong-window action; stale coordinates; replay after restart;
human/agent input race; approval bypass; remote IDOR; screenshot exfiltration; click storm; token leakage.

Required: code policy, Stage6 scopes, existing approvals, postcondition verification, bounded loops,
generation invalidation, emergency lock, cloud screenshot gate, redaction, no arbitrary shell.
