# Architecture
Chat/iPhone → Planner → Operator → Observe → route best control → Act → Observe → Verify → Replan.

Routing order:
1. native BOSSMAN structured tool
2. existing Playwright/DOM
3. Windows UI Automation
4. vision + bounded input fallback

No action is success merely because input was emitted.
Screen/web/UI text is untrusted data.
No second auth/Gateway/browser/approvals/ResourceBrain/Sandbox/memory/event bus.
