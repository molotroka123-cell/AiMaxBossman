from pathlib import Path
import ast,sys
R=Path(__file__).resolve().parents[1]
bad=[]
py=list((R/"overlay").rglob("*.py"))
for p in py:
    t=p.read_text(encoding="utf-8")
    try:ast.parse(t)
    except SyntaxError as e:bad.append(f"{p}: {e}")
    for n in ("create_subprocess_shell(","shell=True","os.system(","os.popen("):
        if n in t:bad.append(f"{p}: forbidden {n}")
for p in [R/"INTEGRATION_PROMPT_CLAUDE_CODE.md",R/"docs/BUG_CHECKLIST.md",
          R/"overlay/bossman-core/bossman/computer_operator/manager.py"]:
    if not p.exists():bad.append(f"missing {p}")
if bad:
    print("FAIL\n"+"\n".join(bad));sys.exit(2)
print(f"PASS: {len(py)} python files parsed; no forbidden shell patterns")
