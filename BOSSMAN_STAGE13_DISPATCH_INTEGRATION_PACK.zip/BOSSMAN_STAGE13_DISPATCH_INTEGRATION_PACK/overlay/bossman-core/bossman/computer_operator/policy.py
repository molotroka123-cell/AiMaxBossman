from __future__ import annotations
from dataclasses import dataclass
from urllib.parse import urlparse
from .models import ActionKind,ComputerAction,TaskMode

CONSEQUENTIAL=frozenset({
 "submit","send","pay","purchase","transfer","delete","uninstall","git_push","merge",
 "release","deploy","security_change","external_upload","secret_entry","account_change"
})
MIN_VISION_CONFIDENCE=.72
MAX_TYPE_CHARS=20000

@dataclass(slots=True,frozen=True)
class PolicyDecision:
    allow:bool; requires_approval:bool=False; reason:str=""; approval_kind:str|None=None

class ComputerPolicy:
    def classify(self,a:ComputerAction,*,mode:TaskMode,locked:bool=False)->PolicyDecision:
        if locked: return PolicyDecision(False,reason="operator locked")
        if mode is TaskMode.OBSERVE_ONLY and a.kind not in {
            ActionKind.NOOP,ActionKind.WAIT,ActionKind.TAKE_SCREENSHOT,ActionKind.COMPLETE,ActionKind.FAIL
        }:
            return PolicyDecision(False,reason="observe-only mode")
        if a.source=="vision" and a.kind in {ActionKind.CLICK,ActionKind.DOUBLE_CLICK,ActionKind.DRAG,ActionKind.UI_INVOKE} and a.confidence<MIN_VISION_CONFIDENCE:
            return PolicyDecision(False,reason="low vision confidence")
        if a.kind is ActionKind.TYPE and len(a.text or "")>MAX_TYPE_CHARS:
            return PolicyDecision(False,reason="typed text too long")
        semantic=str(a.args.get("semantic","")).lower().strip()
        if semantic in CONSEQUENTIAL:
            return PolicyDecision(True,True,f"consequential:{semantic}",f"computer_{semantic}")
        if a.kind is ActionKind.BROWSER and a.args.get("op")=="navigate":
            u=urlparse(str(a.args.get("url","")))
            if u.scheme not in {"http","https"}:
                return PolicyDecision(False,reason="unsupported URL scheme")
        return PolicyDecision(True)
