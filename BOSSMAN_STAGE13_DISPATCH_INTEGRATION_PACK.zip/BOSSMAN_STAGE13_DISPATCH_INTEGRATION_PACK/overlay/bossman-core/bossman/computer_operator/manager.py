from __future__ import annotations
import asyncio,time
from .models import ActionKind,ComputerTask,StepRecord,TaskMode,TaskState
from .policy import ComputerPolicy
from .verifier import Verifier

class ComputerOperatorManager:
    def __init__(self,*,store,planner,observer,action_router,approval_create,approval_wait,event_emit,
                 policy=None,verifier=None):
        self.store=store; self.planner=planner; self.observer=observer; self.action_router=action_router
        self.approval_create=approval_create; self.approval_wait=approval_wait; self.event_emit=event_emit
        self.policy=policy or ComputerPolicy(); self.verifier=verifier or Verifier()
        self.locks={}; self.global_locked=False

    def create_task(self,goal,*,mode=TaskMode.CONTROL,source="local",owner_device_id=None):
        t=ComputerTask.create(goal,mode=mode,source=source,owner_device_id=owner_device_id)
        self._save(t); self._emit(t,"created"); return t

    async def run(self,task_id):
        lock=self.locks.setdefault(task_id,asyncio.Lock())
        async with lock:
            t=self._req(task_id)
            if t.terminal:return t.state
            if t.state in {TaskState.PAUSED,TaskState.USER_CONTROL,TaskState.WAITING_APPROVAL}:return t.state
            last=""
            while not t.terminal:
                if self.global_locked:return self._fail(t,"operator globally locked",TaskState.LOCKED)
                if t.state in {TaskState.PAUSED,TaskState.USER_CONTROL}:return t.state
                if t.steps_used>=t.max_steps:return self._fail(t,"max steps exceeded")
                t.state=TaskState.OBSERVING; self._save(t)
                before=await self.observer.observe(generation=t.generation); t.last_observation=before
                t.state=TaskState.PLANNING; self._save(t)
                try:
                    a=await self.planner.next_action(goal=t.goal,observation_summary=before.summary,
                      foreground=before.foreground,ui_tree=before.ui_tree,last_result=last,
                      remaining_steps=t.max_steps-t.steps_used)
                except Exception as e:
                    t.replans_used+=1; last=f"planner:{type(e).__name__}:{e}"; self._save(t)
                    if t.replans_used>t.max_replans:return self._fail(t,"planner replan budget")
                    continue
                if a.kind is ActionKind.COMPLETE:
                    t.state=TaskState.COMPLETED; t.pending_action=None; self._save(t); self._emit(t,"completed"); return t.state
                if a.kind is ActionKind.FAIL:return self._fail(t,a.text or "planner failed")
                d=self.policy.classify(a,mode=t.mode,locked=self.global_locked)
                if not d.allow:
                    t.replans_used+=1; last=f"policy denied:{d.reason}"; self._save(t)
                    if t.replans_used>t.max_replans:return self._fail(t,"policy/replan budget")
                    continue
                t.pending_action=a; step=StepRecord(action=a,before_observation_id=before.id); t.history.append(step); self._save(t)
                if d.requires_approval:
                    t.state=TaskState.WAITING_APPROVAL
                    aid=await self.approval_create(d.approval_kind or "computer_action",self._preview(t,a,d.reason),
                      tool="computer_operator",payload={"computer_task_id":t.id,"action_id":a.id,
                      "idempotency_key":a.idempotency_key,"kind":a.kind.value})
                    t.waiting_approval_id=aid; step.approval_id=aid; self._save(t); self._emit(t,"waiting_approval",approval_id=aid)
                    result=await self.approval_wait(aid)
                    if result.get("status")!="approved":return self._fail(t,f"approval {result.get('status','unknown')}")
                    fresh=self._req(t.id)
                    if not fresh.pending_action or fresh.pending_action.id!=a.id:
                        return self._fail(fresh,"approved action stale")
                    t=fresh
                if t.state in {TaskState.PAUSED,TaskState.USER_CONTROL,TaskState.CANCELLED,TaskState.LOCKED}:
                    return self._fail(t,"input state changed before action")
                t.state=TaskState.RUNNING; self._save(t)
                try: backend=await self.action_router.execute(a,before)
                except Exception as e:
                    step.error=f"{type(e).__name__}:{e}"; step.finished_at=time.time(); t.pending_action=None
                    t.replans_used+=1; last=f"action failed:{step.error}"; self._save(t)
                    if t.replans_used>t.max_replans:return self._fail(t,"action replan budget")
                    continue
                t.steps_used+=1; t.state=TaskState.OBSERVING; self._save(t)
                after=await self.observer.observe(generation=t.generation); t.last_observation=after
                step.after_observation_id=after.id
                v=self.verifier.verify(a,after); step.verified=v.ok; step.finished_at=time.time()
                t.pending_action=None; t.waiting_approval_id=None; self._save(t)
                if v.ok:
                    last=f"verified via {backend}:{v.reason}"; self._emit(t,"step_verified",action=a.kind.value)
                else:
                    t.replans_used+=1; last=f"verify failed:{v.reason}"; self._save(t)
                    if t.replans_used>t.max_replans:return self._fail(t,"verification budget")
            return t.state

    def pause(self,i): return self._state(i,TaskState.PAUSED,"paused",invalidate=True)
    def take_control(self,i): return self._state(i,TaskState.USER_CONTROL,"user_control",invalidate=True)
    def stop(self,i): return self._state(i,TaskState.CANCELLED,"cancelled",invalidate=True)
    def resume(self,i):
        t=self._req(i)
        if t.state not in {TaskState.PAUSED,TaskState.USER_CONTROL,TaskState.RECOVERING}:raise RuntimeError("invalid resume")
        t.state=TaskState.RECOVERING; t.generation+=1; t.pending_action=None; t.waiting_approval_id=None
        self._save(t); self._emit(t,"recovering"); return t
    def recover_all(self):
        out=[]
        for t in self.store.list():
            if t.terminal:continue
            t.state=TaskState.RECOVERING; t.generation+=1; t.pending_action=None; t.waiting_approval_id=None
            self._save(t); out.append(t)
        return out
    def emergency_lock(self):
        self.global_locked=True
        for t in self.store.list():
            if not t.terminal:self._fail(t,"emergency lock",TaskState.LOCKED)
    def _state(self,i,state,event,invalidate=False):
        t=self._req(i)
        if not t.terminal:
            t.state=state
            if invalidate:t.generation+=1;t.pending_action=None
            self._save(t);self._emit(t,event)
        return t
    def _fail(self,t,reason,state=TaskState.FAILED):
        t.state=state;t.last_error=str(reason)[:3000];t.pending_action=None;self._save(t);self._emit(t,"failed",error=t.last_error);return t.state
    def _req(self,i):
        t=self.store.get(i)
        if not t:raise KeyError(i)
        return t
    def _save(self,t):t.touch();self.store.save(t)
    def _emit(self,t,event,**kw):self.event_emit("computer_operator.task",computer_task_id=t.id,state=t.state.value,event=event,**kw)
    @staticmethod
    def _preview(t,a,reason):return f"Computer task: {t.goal[:500]}\nAction: {a.kind.value} {a.target or ''}\nReason: {reason}"
