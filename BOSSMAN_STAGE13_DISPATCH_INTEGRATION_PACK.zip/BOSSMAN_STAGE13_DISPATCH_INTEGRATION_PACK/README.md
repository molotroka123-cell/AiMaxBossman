# BOSSMAN Stage 13 — Dispatch / Computer Operator Integration Pack

Готовый overlay + ТЗ для интеграции в `molotroka123-cell/AiMaxBossman`.

Цепочка:
Chat / iPhone → BOSSMAN Planner → Computer Operator → Observe → Choose control
method → Action → Observe again → Verify → Continue/Replan.

Внутри:
- `bossman/computer_operator/` production-shaped код;
- state machine и restart recovery;
- policy + approvals boundary;
- Windows UIA/input, browser и vision adapters;
- Observe→Act→Verify loop;
- тесты и adversarial tests;
- JSON schemas;
- bug checklist;
- threat model;
- готовый `INTEGRATION_PROMPT_CLAUDE_CODE.md`.

Пакет НЕ создаёт второй Gateway/auth/approvals/browser/resource manager.
Claude должен связать overlay с текущими seams репозитория.

Перед Stage 13 должны быть закрыты pre-Dispatch P0/P1 и CI.
После Stage 13 — только BOSSMAN v1 Release Candidate / live acceptance.
