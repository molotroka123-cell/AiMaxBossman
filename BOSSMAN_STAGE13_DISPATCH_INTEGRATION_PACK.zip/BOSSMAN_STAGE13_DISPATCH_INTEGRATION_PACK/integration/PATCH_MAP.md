# Patch map
Copy overlay `bossman/computer_operator` into `bossman-core/bossman/`.
Copy Stage13 tests into `bossman-core/tests/`.

Then reconcile CURRENT HEAD:
- `bossman/api.py`: register subsystem/router while preserving Core auth fixes.
- `computer_operator/subsystem.py`: replace fail-closed Unwired seams with existing Gateway, Stage1 browser, Windows backend and ResourceBrain.
- `remote_client/mobile_api.py`: add device-scoped computer task endpoints using current Stage12 auth/IDOR pattern.
- PWA: task status, pause, take control, resume, stop, emergency lock; no API/screenshot SW cache.
- config: only Stage13 enable/limits/model aliases/retention; no duplicate provider settings.
- approvals/events: reuse existing modules.
