# MASTER PROMPT — Ai WebCam Vision App #1

Build the first real-world BOSSMAN application: **Ai WebCam Vision**.

Target camera: **TP-Link Tapo C200**.
Target room: dental treatment room.
Target compute topology: camera in clinic, server at home via private VPN.

## Phase rule

If BOSSMAN V2.2 foundation is not formally closed after audit, keep this app
standalone/staged under `apps/ai-webcam-vision/`. Do not destabilize the foundation.

## Product goal

Convert camera + CRM context into operational facts:

- motion event
- transit-only movement
- staff in room but not clinical work
- preparation
- chair occupied
- clinical work
- turnover/cleanup
- empty/idle room
- procedure episode duration
- productive room/chair hours
- daily utilization
- scheduled vs observed duration
- later per-clinician efficiency

Do not infer employee identity from face. Use CRM/roster/room/shift assignment.

## Motion trigger

Tapo C200 itself detects motion and can notify the user. For machine integration:

1. Prefer an ONVIF motion/event source if the exact firmware exposes a usable event.
2. Or use a clinic edge/NVR bridge.
3. Translate the event to `POST /hooks/motion`.
4. If native events are unavailable, use low-rate frame-difference as fallback.

Do NOT scrape iOS/Android push notifications.

The motion event should wake the heavier frame analysis for a configurable
window (e.g. 60-120 s). New motion extends the window.

## Network

Preferred:

Tapo C200 -> clinic LAN -> Tailscale/WireGuard subnet router ->
home Ai WebCam Vision server.

Never expose RTSP port 554 or ONVIF to the public Internet.

## RTSP

Use a dedicated Tapo Camera Account, not the TP-Link cloud account password.

Expected forms:
- `rtsp://USER:PASSWORD@CAMERA_IP:554/stream1`
- `rtsp://USER:PASSWORD@CAMERA_IP:554/stream2`

V1 default: stream2.

Credentials must never appear in logs/API responses.

## CRM is mandatory in architecture

Add/keep a `CRMAdapter`.

For each observation ask the CRM/schedule layer for:

- room_id
- employee_id / clinician_id
- shift_active
- appointment_id
- appointment_active
- scheduled_start/end
- planned_service
- confirmed_service

Fuse it with visual evidence.

Examples:

motion + no appointment + chair near empty baseline + short interval
=> TRANSIT

shift active + room activity + no active appointment + chair near baseline
=> STAFF_NONCLINICAL

active appointment + persistent chair evidence + work-zone motion
=> CLINICAL_WORK

active appointment + room activity before chair/work evidence
=> PREP

appointment ended + chair becomes empty + room activity continues
=> TURNOVER

## Procedure label

Do not pretend the camera alone knows the procedure.

Precedence:
1. CRM confirmed service -> confirmed label
2. current appointment planned service -> likely label
3. future local VLM -> additional evidence only
4. unknown

Always store provenance/confidence.

## Privacy defaults

DENY:
- face identification
- patient identification from pixels
- audio capture
- raw continuous video retention

Default local-only processing.

## V1 components

- RTSP client / probe / JPEG sampling
- credential redaction
- MotionGate
- baseline + normalized ROI detector
- CRMAdapter + generic HTTP implementation
- OperationalClassifier
- debounced state machine
- SQLite timeline
- daily metrics
- FastAPI dashboard/API
- `/hooks/motion`
- tests

## Future BOSSMAN App Runtime

After foundation closure, App #1 must be invocable by:
- standalone dashboard
- Apps button
- command: `/webcam today`
- natural language: "Сколько реально работал кабинет сегодня?"
- autonomous clinic-hours monitoring
- end-of-day report

Send BOSSMAN structured events/metrics, not frames.

## Acceptance

Create `docs/AI_WEBCAM_VISION_APP1_REPORT.md`.

Report separately:
- LOCAL PASS
- REAL TAPO PASS
- MOCK CRM PASS
- REAL CRM PASS
- NOT RUN

Do not mark real Tapo or CRM integration DONE from mocks.

Minimum tests:
- RTSP URL/redaction
- motion gate
- classifier transit vs clinical
- CRM service provenance
- state hysteresis
- storage metrics
- no secret in returned status
- no face/audio/raw-video feature enabled by default

Do not return only a plan. Implement and test the app seed.
