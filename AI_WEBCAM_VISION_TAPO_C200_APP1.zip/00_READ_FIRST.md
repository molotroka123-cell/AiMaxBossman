# Ai WebCam Vision — App #1

Target: TP-Link Tapo C200 in a dental treatment room, with heavy compute on a home server.

The app is event-first, not video-first:

Tapo motion / ONVIF edge event -> motion gate -> temporary RTSP sampling ->
local vision evidence -> CRM/schedule correlation -> operational state ->
SQLite events/metrics -> later BOSSMAN.

Important:
- Tapo C200 supports motion notifications, RTSP and ONVIF.
- Do not scrape the mobile notification. Prefer ONVIF/edge/NVR event translation
  into our vendor-neutral `/hooks/motion`. If unavailable, use cheap frame-diff fallback.
- Use stream2 for normal continuous/light sampling, stream1 later for detailed bursts.
- No public RTSP port forwarding.
- No face recognition.
- Employee identity comes from CRM/shift/room assignment.
- Patient identity does not come from pixels.
- Raw video is not retained by default.
- Audio is disabled.
- Keep the PTZ camera in a fixed pose while baseline/ROI analysis is active.

Read next: `MASTER_PROMPT_FOR_CLAUDE.md`.
