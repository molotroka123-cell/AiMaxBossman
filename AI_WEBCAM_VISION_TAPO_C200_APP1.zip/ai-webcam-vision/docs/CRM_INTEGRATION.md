# CRM correlation

Generic contract:

`GET /api/bossman/room-context?room_id=dental-1&at=<ISO8601>`

Example:

```json
{
  "source": "clinic-crm",
  "employee_id": "assistant-7",
  "clinician_id": "doctor-2",
  "shift_active": true,
  "appointment_id": "appt-123",
  "appointment_active": true,
  "planned_service": "endodontics-3-channel",
  "confirmed_service": ""
}
```

This is the key to the user's requirement: movement alone is not "work".

Camera evidence says what physically happened in the room. CRM says what should
have been happening and who was assigned.

Later join completed episodes back to CRM billing/service records to compare:
- planned duration;
- observed prep;
- observed clinical work;
- observed turnover;
- billed/confirmed service;
- clinician;
- room utilization.

Do not hard-code a vendor until the actual clinic CRM API/export is selected.
