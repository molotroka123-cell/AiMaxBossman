# Tapo C200 + home server

The C200 can stay in the clinic while the server is at home.

Preferred:

```text
Tapo C200
  -> clinic private LAN
  -> Tailscale/WireGuard subnet router
  -> encrypted tunnel
  -> home server
```

Do not public-forward RTSP 554.

Use a dedicated Camera Account configured in Tapo for RTSP/ONVIF.

Motion:
- Tapo supports motion detection and phone notifications.
- C200 also supports ONVIF/RTSP.
- Whether a convenient ONVIF motion-event subscription works depends on exact
  firmware/integration; verify it on the physical camera.
- The app therefore exposes `/hooks/motion` for a tiny clinic edge bridge/NVR.
- If no usable camera event exists, fall back to cheap frame-difference.

Do not scrape phone notifications.
