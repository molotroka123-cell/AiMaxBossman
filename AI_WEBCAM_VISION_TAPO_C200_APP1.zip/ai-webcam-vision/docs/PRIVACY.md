# Clinic privacy defaults

Engineering defaults:
- no facial recognition;
- no audio;
- no patient identification from pixels;
- no raw continuous video retention;
- private VPN;
- local processing;
- store structured operational events;
- employee/clinician identity from CRM assignment, not biometrics.

Before production, review Czech/EU workplace and patient privacy requirements,
notice/transparency, lawful basis, access and retention.
