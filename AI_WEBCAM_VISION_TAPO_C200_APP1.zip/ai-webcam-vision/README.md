# Ai WebCam Vision

Local-first operational analytics for a Tapo C200.

## Flow

camera motion -> `/hooks/motion` -> high-rate analysis window -> RTSP frame ->
baseline/ROI evidence -> CRM room context -> state -> SQLite -> metrics.

## States

- EMPTY
- TRANSIT
- STAFF_NONCLINICAL
- PREP
- CLINICAL_WORK
- TURNOVER
- IDLE_OCCUPIED

## Install

Requires Python 3.11+, ffmpeg/ffprobe.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
ai-webcam-vision
```

## Important

The C200 is pan/tilt. V1 baseline/ROI analytics assumes a fixed pose. Disable
patrol/tracking during analytics or later add named PTZ presets + per-preset baselines.
