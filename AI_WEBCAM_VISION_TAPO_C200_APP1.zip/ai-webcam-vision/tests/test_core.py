from datetime import datetime, timezone
from ai_webcam_vision.core import RTSP, redact, MotionGate, CRMContext, classify, State

def test_rtsp_redacts():
    r=RTSP("10.0.0.5","user","secret pass","stream2")
    assert "secret" not in r.safe_url()
    assert "***:***@" in r.safe_url()

def test_motion_gate():
    g=MotionGate(30); assert not g.active(); g.trigger("tapo"); assert g.active()

def test_transit_vs_work():
    ev={"ts":datetime.now(timezone.utc),"room":.08,"chair":.01,"work":.03,"motion":True}
    c=classify(ev,CRMContext())
    assert c["state"]==State.TRANSIT.value

    ev2={"ts":datetime.now(timezone.utc),"room":.08,"chair":.10,"work":.03,"motion":True}
    crm=CRMContext(shift_active=True,appointment_active=True,planned_service="filling",source="test")
    c2=classify(ev2,crm)
    assert c2["state"]==State.CLINICAL_WORK.value
    assert c2["procedure"]=="filling"

def test_confirmed_service_wins():
    crm=CRMContext(appointment_active=True,planned_service="planned",confirmed_service="confirmed",source="crm")
    label,conf,src=crm.procedure()
    assert label=="confirmed" and conf==1.0 and "confirmed" in src
