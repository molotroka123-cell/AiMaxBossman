from datetime import timedelta
from fastapi import FastAPI, Request, HTTPException
from .core import Settings, RTSP, MotionGate, CRM, Detector, Store, classify, now

HTML="""<!doctype html><html><body style='font-family:system-ui;background:#111;color:#eee;padding:24px'>
<h1>Ai WebCam Vision</h1>
<button onclick="p('/api/baseline')">Capture empty baseline</button>
<button onclick="p('/hooks/motion')">Motion trigger</button>
<button onclick="p('/api/sample')">Sample</button>
<pre id=x></pre><script>
async function p(u){await fetch(u,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});r()}
async function r(){x.textContent=JSON.stringify(await (await fetch('/api/status')).json(),null,2)}
setInterval(r,3000);r()</script></body></html>"""

def build_app(s=None):
    s=s or Settings()
    rtsp=RTSP(s.camera_host,s.camera_username,s.camera_password,s.camera_stream)
    gate=MotionGate(s.motion_hold_seconds)
    crm=CRM(s.crm_kind,s.crm_base_url,s.crm_token)
    det=Detector(s.baseline_path,s.chair_zone,s.work_zone)
    db=Store(s.db_path)
    app=FastAPI(title="Ai WebCam Vision")

    @app.get("/")
    async def home(): return __import__("fastapi").responses.HTMLResponse(HTML)

    @app.get("/api/status")
    async def status():
        return {"room":s.room_id,"camera":{"host":s.camera_host,"stream":s.camera_stream,
                "rtsp":rtsp.safe_url()},"motion":{"active":gate.active(),"source":gate.source},
                "baseline":s.baseline_path.exists(),"latest":db.latest(s.room_id)}

    @app.post("/hooks/motion")
    async def motion(req:Request):
        try: body=await req.json()
        except Exception: body={}
        gate.trigger(str((body or {}).get("source") or "edge/webhook")[:80])
        return {"ok":True,"active":gate.active(),"source":gate.source}

    @app.post("/api/baseline")
    async def baseline():
        det.save_baseline(await rtsp.jpeg()); return {"ok":True}

    @app.post("/api/sample")
    async def sample():
        try:
            ev=det.analyze(await rtsp.jpeg(),gate.active())
            ctx=await crm.context(s.room_id,ev["ts"])
            cl=classify(ev,ctx); db.add(s.room_id,ev,ctx,cl)
            return cl
        except FileNotFoundError as e: raise HTTPException(409,str(e))
        except Exception as e: raise HTTPException(503,f"{type(e).__name__}: {e}")

    @app.get("/api/metrics/today")
    async def metrics():
        t=now(); start=t.replace(hour=0,minute=0,second=0,microsecond=0)
        return db.metrics(s.room_id,start.isoformat(),(start+timedelta(days=1)).isoformat())

    return app
