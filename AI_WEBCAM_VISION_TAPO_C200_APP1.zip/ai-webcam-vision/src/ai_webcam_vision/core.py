from __future__ import annotations
import asyncio, json, os, re, sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from pathlib import Path
from urllib.parse import quote

import cv2
import httpx
import numpy as np


def now():
    return datetime.now(timezone.utc)


def zone(raw):
    vals = tuple(float(x) for x in raw.split(","))
    if len(vals) != 4 or not all(0 <= x <= 1 for x in vals):
        raise ValueError("zone must be normalized x1,y1,x2,y2")
    return vals


@dataclass
class Settings:
    camera_host: str = os.getenv("AWV_CAMERA_HOST", "192.168.10.50")
    camera_username: str = os.getenv("AWV_CAMERA_USERNAME", "")
    camera_password: str = os.getenv("AWV_CAMERA_PASSWORD", "")
    camera_stream: str = os.getenv("AWV_CAMERA_STREAM", "stream2")
    room_id: str = os.getenv("AWV_ROOM_ID", "dental-1")
    motion_hold_seconds: float = float(os.getenv("AWV_MOTION_HOLD_SECONDS", "90"))
    active_interval: float = float(os.getenv("AWV_ACTIVE_INTERVAL_SECONDS", "1"))
    idle_interval: float = float(os.getenv("AWV_IDLE_INTERVAL_SECONDS", "10"))
    chair_zone: tuple = zone(os.getenv("AWV_CHAIR_ZONE", "0.25,0.25,0.78,0.90"))
    work_zone: tuple = zone(os.getenv("AWV_WORK_ZONE", "0.15,0.10,0.90,0.95"))
    baseline_path: Path = Path(os.getenv("AWV_BASELINE_PATH", "./data/baseline.jpg"))
    db_path: Path = Path(os.getenv("AWV_DB_PATH", "./data/vision.sqlite3"))
    crm_kind: str = os.getenv("AWV_CRM_KIND", "none")
    crm_base_url: str = os.getenv("AWV_CRM_BASE_URL", "")
    crm_token: str = os.getenv("AWV_CRM_TOKEN", "")
    host: str = os.getenv("AWV_HOST", "127.0.0.1")
    port: int = int(os.getenv("AWV_PORT", "8870"))


_CRED = re.compile(r"(rtsp://)([^/@:]+):([^/@]+)@", re.I)
def redact(text): return _CRED.sub(r"\1***:***@", text)


@dataclass
class RTSP:
    host: str
    user: str
    password: str
    stream: str = "stream2"

    def url(self):
        if self.stream not in {"stream1", "stream2"}:
            raise ValueError("bad stream")
        auth = f"{quote(self.user,safe='')}:{quote(self.password,safe='')}@" if self.user or self.password else ""
        return f"rtsp://{auth}{self.host}:554/{self.stream}"

    def safe_url(self): return redact(self.url())

    async def jpeg(self):
        cmd = ["ffmpeg","-hide_banner","-loglevel","error","-rtsp_transport","tcp",
               "-i",self.url(),"-frames:v","1","-f","image2pipe","-vcodec","mjpeg","pipe:1"]
        try:
            p = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE,
                                                     stderr=asyncio.subprocess.PIPE)
        except FileNotFoundError as e:
            raise RuntimeError("ffmpeg not installed") from e
        out, err = await asyncio.wait_for(p.communicate(), 10)
        if p.returncode or not out:
            raise RuntimeError("capture failed: " + redact(err.decode(errors="replace"))[:500])
        return out


class MotionGate:
    def __init__(self, hold=90):
        self.hold = hold
        self.until = None
        self.source = ""

    def trigger(self, source="webhook"):
        self.until = now() + timedelta(seconds=self.hold)
        self.source = source

    def active(self):
        return bool(self.until and now() <= self.until)


class State(StrEnum):
    EMPTY="EMPTY"
    TRANSIT="TRANSIT"
    STAFF_NONCLINICAL="STAFF_NONCLINICAL"
    PREP="PREP"
    CLINICAL_WORK="CLINICAL_WORK"
    TURNOVER="TURNOVER"
    IDLE_OCCUPIED="IDLE_OCCUPIED"


@dataclass
class CRMContext:
    employee_id: str=""
    clinician_id: str=""
    shift_active: bool=False
    appointment_id: str=""
    appointment_active: bool=False
    planned_service: str=""
    confirmed_service: str=""
    source: str="none"

    def procedure(self):
        if self.confirmed_service:
            return self.confirmed_service, 1.0, self.source+":confirmed"
        if self.appointment_active and self.planned_service:
            return self.planned_service, .85, self.source+":planned"
        return "unknown", 0.0, "none"


class CRM:
    def __init__(self, kind="none", base="", token=""):
        self.kind, self.base, self.token = kind, base.rstrip("/"), token

    async def context(self, room_id, ts):
        if self.kind == "none":
            return CRMContext()
        if self.kind != "generic_http":
            raise ValueError("unsupported CRM kind")
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(self.base+"/api/bossman/room-context",
                            params={"room_id":room_id,"at":ts.isoformat()}, headers=headers)
            r.raise_for_status()
            d = r.json()
        fields = CRMContext.__dataclass_fields__
        return CRMContext(**{k:d.get(k, fields[k].default) for k in fields})


def decode(jpeg):
    f = cv2.imdecode(np.frombuffer(jpeg,np.uint8), cv2.IMREAD_COLOR)
    if f is None: raise ValueError("bad jpeg")
    return f


def crop(f,z):
    h,w=f.shape[:2]; x1,y1,x2,y2=z
    return f[int(y1*h):int(y2*h),int(x1*w):int(x2*w)]


def score(a,b):
    def gray(x):
        h,w=x.shape[:2]; x=cv2.resize(x,(320,max(1,int(h*320/max(1,w)))))
        return cv2.cvtColor(x,cv2.COLOR_BGR2GRAY)
    a,b=gray(a),gray(b)
    if a.shape!=b.shape: b=cv2.resize(b,(a.shape[1],a.shape[0]))
    return float(np.mean(cv2.absdiff(a,b)>24))


class Detector:
    def __init__(self, baseline, chair_zone, work_zone):
        self.baseline=Path(baseline); self.chair_zone=chair_zone; self.work_zone=work_zone
        self.prev=None

    def save_baseline(self,jpeg):
        self.baseline.parent.mkdir(parents=True,exist_ok=True)
        cv2.imwrite(str(self.baseline),decode(jpeg))

    def analyze(self,jpeg,motion):
        frame=decode(jpeg); base=cv2.imread(str(self.baseline))
        if base is None: raise FileNotFoundError("capture empty-room baseline first")
        room=score(frame,base); chair=score(crop(frame,self.chair_zone),crop(base,self.chair_zone))
        work=0.0 if self.prev is None else score(crop(frame,self.work_zone),crop(self.prev,self.work_zone))
        self.prev=frame
        return {"ts":now(),"room":room,"chair":chair,"work":work,"motion":motion}


def classify(ev, crm):
    service, pc, ps = crm.procedure()
    room, chair, work = ev["room"]>=.035, ev["chair"]>=.055, ev["work"]>=.012
    if not room and not ev["motion"]: state,conf,why=State.EMPTY,.9,["near baseline"]
    elif crm.appointment_active and chair and work:
        state,conf,why=State.CLINICAL_WORK,.9,["appointment","chair","work motion"]
    elif crm.appointment_active and chair:
        state,conf,why=State.IDLE_OCCUPIED,.74,["appointment","chair","low motion"]
    elif crm.appointment_active and room:
        state,conf,why=State.PREP,.72,["appointment","room activity"]
    elif crm.shift_active and room and not chair:
        state,conf,why=State.STAFF_NONCLINICAL,.68,["shift","room","chair baseline"]
    elif ev["motion"] and not chair:
        state,conf,why=State.TRANSIT,.70,["motion","chair baseline"]
    elif chair:
        state,conf,why=State.IDLE_OCCUPIED,.5,["chair without CRM confirmation"]
    else:
        state,conf,why=State.TRANSIT,.45,["unclassified motion"]
    return {"state":state.value,"confidence":conf,"reasons":why,
            "procedure":service,"procedure_confidence":pc,"procedure_source":ps}


class Store:
    def __init__(self,path): self.path=Path(path); self.init()

    def con(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        c=sqlite3.connect(self.path); c.row_factory=sqlite3.Row; return c

    def init(self):
        with self.con() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS observations(
              id INTEGER PRIMARY KEY, ts TEXT, room_id TEXT, state TEXT, confidence REAL,
              room_change REAL, chair_change REAL, work_motion REAL, motion INTEGER,
              employee_id TEXT, clinician_id TEXT, appointment_id TEXT,
              procedure TEXT, procedure_confidence REAL, procedure_source TEXT,
              reasons TEXT
            );
            CREATE INDEX IF NOT EXISTS ix_obs_room_ts ON observations(room_id,ts);
            """)

    def add(self,room,ev,crm,cl):
        with self.con() as c:
            c.execute("""INSERT INTO observations VALUES(NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (ev["ts"].isoformat(),room,cl["state"],cl["confidence"],ev["room"],ev["chair"],
               ev["work"],int(ev["motion"]),crm.employee_id,crm.clinician_id,crm.appointment_id,
               cl["procedure"],cl["procedure_confidence"],cl["procedure_source"],
               json.dumps(cl["reasons"],ensure_ascii=False)))

    def latest(self,room):
        with self.con() as c:
            r=c.execute("SELECT * FROM observations WHERE room_id=? ORDER BY id DESC LIMIT 1",(room,)).fetchone()
        return dict(r) if r else None

    def metrics(self,room,start,end):
        with self.con() as c:
            rows=c.execute("SELECT ts,state FROM observations WHERE room_id=? AND ts>=? AND ts<? ORDER BY ts",
                           (room,start,end)).fetchall()
        d={}
        for a,b in zip(rows,rows[1:]):
            dt=max(0,min((datetime.fromisoformat(b["ts"])-datetime.fromisoformat(a["ts"])).total_seconds(),120))
            d[a["state"]]=d.get(a["state"],0)+dt
        clinical=d.get(State.CLINICAL_WORK.value,0)
        occupied=sum(d.get(s.value,0) for s in [State.PREP,State.CLINICAL_WORK,State.IDLE_OCCUPIED,State.TURNOVER])
        return {"samples":len(rows),"seconds_by_state":d,"clinical_seconds":clinical,"occupied_seconds":occupied}
