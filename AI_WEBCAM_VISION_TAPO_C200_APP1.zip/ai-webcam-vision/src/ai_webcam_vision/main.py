import uvicorn
from .api import build_app
from .core import Settings

def main():
    s=Settings()
    uvicorn.run(build_app(s),host=s.host,port=s.port)

if __name__=="__main__":
    main()
