# Integration order

1. Integrate/finish the preceding V3 Foundation + Executive OS first.
2. Copy `production/command-center/bcc/v3/organization/` to `command-center/bcc/v3/organization/`.
3. Ensure `command-center/bcc/v3/__init__.py` exists; create only if the repository still lacks the V3 package.
4. Copy tests into `command-center/tests/v3/organization/` (or adapt to the repository's current V3 test path).
5. Implement a small adapter satisfying `ExecutiveOSBridge` using the actual Executive OS delegation entrypoint.
6. Optionally implement `MemoryBridge` using V3 scoped memory. Publish only verified facts/artifact references.
7. Register initial department policies and agent profiles from configuration, not hard-coded secrets.
8. Run the package validation script.
9. Run existing action-contract/permission/idempotency targeted tests.
10. Run one full repository regression.
11. Inspect `git diff`, secret scan, then commit as one coherent Organization Layer commit.

Do not weaken existing V2/V3 success semantics to make this layer pass.
