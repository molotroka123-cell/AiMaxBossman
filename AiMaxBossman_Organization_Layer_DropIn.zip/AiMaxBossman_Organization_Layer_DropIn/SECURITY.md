# Security invariants

1. Textual completion is never sufficient evidence for side effects.
2. A result with missing/unverified required evidence is forced to FAILED.
3. Cross-department exports are allowlisted by kind.
4. Department budgets can block delegation and escalate to the owner.
5. The layer never increases tool permissions; Executive OS/V2 remain authoritative.
6. Durable state contains organization metadata and evidence references, not secrets or hidden chain-of-thought.
7. Completed work returned by `resume()` is loaded from durable result state and is not executed again.
