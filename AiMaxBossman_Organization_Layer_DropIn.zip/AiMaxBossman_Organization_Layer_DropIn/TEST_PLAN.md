# Test plan

Included deterministic tests cover:

- local-first routing;
- department isolation;
- no textual false-success;
- verified evidence acceptance;
- multi-agent consensus primitive;
- budget/evidence governor;
- SQLite durability;
- verified fact publication only after success;
- forced FAILED state on unverified result;
- restart/resume with no duplicate execution;
- KPI false-success accounting.

After integration, add repository-native E2E tests for:

1. Research → Engineering → QA delegation across a single mission.
2. Department budget exhaustion → human escalation.
3. Model escalation local-small → local-strong → cloud only when lower tier is incapable.
4. A failed required child preventing parent mission completion.
5. Cross-project memory isolation through the real V3 memory adapter.
