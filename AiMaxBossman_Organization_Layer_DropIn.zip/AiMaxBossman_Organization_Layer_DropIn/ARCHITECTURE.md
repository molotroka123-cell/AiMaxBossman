# AiMaxBossman Organization Layer

This layer sits **above Executive OS** and below any future Fleet/Distributed layer.

Flow:

`Owner → Organization Layer → Executive OS → V3 Foundation → V2 verified action engine → real tools`

The Organization Layer does not execute side effects itself. It chooses a department/team, issues a delegation contract, lets Executive OS execute, and only accepts results backed by required verified evidence.

Core components:

- `OrganizationRegistry`: agents + department policy.
- `AgentRouter`: capability-first, local-first selection.
- `OrganizationGovernor`: department budget and evidence gates.
- `DelegationContract`: explicit success criteria/evidence contract.
- `OrganizationStore`: durable SQLite organization state.
- `OrganizationOrchestrator`: route → delegate → verify → persist → publish verified facts.
- `KPIReport`: verified-success rate, cost, false-success count.
- `ExecutiveOSBridge`: narrow adapter to the preceding layer.

This drop-in intentionally avoids a new database server, message bus, vector store, or model SDK.
