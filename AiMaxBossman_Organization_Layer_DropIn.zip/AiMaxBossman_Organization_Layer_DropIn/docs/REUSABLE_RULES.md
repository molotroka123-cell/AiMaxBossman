# Reusable rules

1. Delegation must define `success_criteria` and `evidence_required` before execution.
2. Manager agents manage; they do not silently become unrestricted executors.
3. Select the cheapest capable agent, not the cheapest agent regardless of capability.
4. Reviewer/QA consensus is useful only when each result is independently verified.
5. Department scope and project scope are security boundaries, not prompt conventions.
6. Persist state transitions before/after delegation so restart behavior is deterministic.
7. Organization KPIs count verified success, not self-reported success.
