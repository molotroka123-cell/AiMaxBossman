# Failure patterns

- **False success:** executor says "done" without required verified evidence. Resolution: contract validation forces FAILED.
- **Wrong department:** an agent from another department has capabilities but is outside work scope. Resolution: routing is department-scoped.
- **Budget runaway:** child task would exceed department envelope. Resolution: governor blocks and requests human review.
- **Duplicate side effect on restart:** completed work is re-executed. Resolution: `resume()` loads completed result and performs zero new execution.
- **Cross-department leakage:** raw/private state exported to another department. Resolution: export kinds are allowlisted.
