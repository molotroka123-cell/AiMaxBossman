# Implementation decisions

## D1 — Organization delegates; Executive OS executes
OBSERVATION: V2/V3 already own execution truth and permissions.
DECISION: Organization Layer never marks a side effect complete directly.
TEST: unverified executor result is forced FAILED.
REUSABLE_RULE: higher orchestration layers must not bypass lower-layer verification.

## D2 — Local-first routing
OBSERVATION: most coordination work should not require frontier models.
DECISION: route by capability first, then deterministic/local/cloud tier, then load/cost/success.
TEST: local eligible agent beats cloud eligible agent.
REUSABLE_RULE: escalate model cost only for missing capability or demonstrated quality need.

## D3 — SQLite only
OBSERVATION: this layer needs durable organizational state but no distributed consensus yet.
DECISION: use stdlib SQLite and a narrow store class.
REUSABLE_RULE: do not add infrastructure before Fleet Mode requires it.
