from __future__ import annotations

from dataclasses import dataclass
from statistics import mean

from .models import WorkResult


@dataclass(frozen=True)
class KPIReport:
    total: int
    verified_success_rate: float
    average_cost_usd: float
    false_success_count: int


def calculate_kpis(results: list[WorkResult]) -> KPIReport:
    if not results:
        return KPIReport(0, 0.0, 0.0, 0)
    verified = [r for r in results if r.verified]
    false_success = [r for r in results if r.success and not r.verified]
    return KPIReport(
        total=len(results),
        verified_success_rate=len(verified) / len(results),
        average_cost_usd=mean(r.cost.usd for r in results),
        false_success_count=len(false_success),
    )
