from __future__ import annotations

from typing import Protocol

from .models import WorkItem, WorkResult


class ExecutiveOSBridge(Protocol):
    """Adapter expected from the preceding Executive OS layer."""

    def execute_delegated(self, work: WorkItem, agent_id: str) -> WorkResult: ...

    def request_human_review(self, work: WorkItem, reason: str) -> None: ...


class MemoryBridge(Protocol):
    def publish_department_fact(self, department: str, kind: str, payload: dict) -> str: ...
