from __future__ import annotations

from collections import defaultdict

from .models import AgentProfile, Department, DepartmentPolicy


class OrganizationRegistry:
    def __init__(self) -> None:
        self._agents: dict[str, AgentProfile] = {}
        self._policies: dict[Department, DepartmentPolicy] = {}

    def register_agent(self, profile: AgentProfile) -> None:
        if profile.agent_id in self._agents:
            raise ValueError(f"agent already registered: {profile.agent_id}")
        self._agents[profile.agent_id] = profile

    def upsert_policy(self, policy: DepartmentPolicy) -> None:
        self._policies[policy.department] = policy

    def policy(self, department: Department) -> DepartmentPolicy:
        return self._policies.get(department, DepartmentPolicy(department=department))

    def agents(self, department: Department | None = None) -> list[AgentProfile]:
        values = list(self._agents.values())
        if department is not None:
            values = [a for a in values if a.department == department]
        return [a for a in values if a.enabled]

    def by_department(self) -> dict[Department, list[AgentProfile]]:
        grouped: dict[Department, list[AgentProfile]] = defaultdict(list)
        for agent in self.agents():
            grouped[agent.department].append(agent)
        return dict(grouped)
