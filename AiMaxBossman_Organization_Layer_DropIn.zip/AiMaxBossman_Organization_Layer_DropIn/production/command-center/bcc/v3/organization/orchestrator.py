from __future__ import annotations

from collections import defaultdict

from .bridge import ExecutiveOSBridge, MemoryBridge
from .contracts import DelegationContract
from .models import Budget, TaskState, WorkItem, WorkResult
from .policy import OrganizationGovernor
from .registry import OrganizationRegistry
from .router import AgentRouter
from .store import OrganizationStore


class OrganizationOrchestrator:
    """Team/dept layer above Executive OS. It delegates; it does not fake execution."""

    def __init__(
        self,
        *,
        registry: OrganizationRegistry,
        store: OrganizationStore,
        executive: ExecutiveOSBridge,
        memory: MemoryBridge | None = None,
    ) -> None:
        self.registry = registry
        self.store = store
        self.executive = executive
        self.memory = memory
        self.router = AgentRouter(registry)
        self.governor = OrganizationGovernor()
        self._used: dict[str, Budget] = defaultdict(Budget)

    def run(self, work: WorkItem) -> WorkResult | None:
        policy = self.registry.policy(work.department)
        gate = self.governor.preflight(work, policy, self._used[work.department.value])
        if not gate.allowed:
            work.state = TaskState.BLOCKED
            self.store.save_work(work)
            self.executive.request_human_review(work, gate.reason)
            return None

        decision = self.router.route(work)
        if not decision.selected_agents:
            work.state = TaskState.BLOCKED
            self.store.save_work(work)
            self.executive.request_human_review(work, decision.reason)
            return None

        agent_id = decision.selected_agents[0]
        work.assigned_agents = [agent_id]
        work.state = TaskState.EXECUTING
        self.store.save_work(work)

        result = self.executive.execute_delegated(work, agent_id)
        contract = DelegationContract.from_work(work)
        ok, errors = contract.validate(result)
        self._used[work.department.value] = self._used[work.department.value] + result.cost

        if not ok:
            work.state = TaskState.FAILED
            result.success = False
            result.metadata = {**result.metadata, "contract_errors": errors}
        else:
            work.state = TaskState.COMPLETED
            if self.memory is not None:
                for evidence in result.evidence:
                    if evidence.verified:
                        self.memory.publish_department_fact(
                            work.department.value,
                            "verified_fact",
                            {"work_id": work.work_id, "kind": evidence.kind, "value": evidence.value},
                        )
        self.store.save_result(result)
        self.store.save_work(work)
        return result

    def resume(self, work_id: str) -> WorkResult | None:
        work = self.store.load_work(work_id)
        if work is None:
            raise KeyError(work_id)
        if work.state == TaskState.COMPLETED:
            return self.store.load_result(work_id)
        return self.run(work)
