from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class Department(str, Enum):
    ENGINEERING = "engineering"
    RESEARCH = "research"
    BUSINESS = "business"
    FRESH_VIBES = "fresh_vibes"
    TRADING = "trading"
    ADMIN = "admin"


class Role(str, Enum):
    LEAD = "lead"
    EXECUTOR = "executor"
    REVIEWER = "reviewer"
    QA = "qa"
    RESEARCHER = "researcher"
    RISK = "risk"


class TaskState(str, Enum):
    PLANNED = "planned"
    ASSIGNED = "assigned"
    EXECUTING = "executing"
    VERIFYING = "verifying"
    BLOCKED = "blocked"
    FAILED = "failed"
    COMPLETED = "completed"


@dataclass(frozen=True)
class Budget:
    usd: float = 0.0
    tokens: int = 0
    compute_seconds: int = 0

    def fits(self, used: "Budget") -> bool:
        return used.usd <= self.usd and used.tokens <= self.tokens and used.compute_seconds <= self.compute_seconds

    def __add__(self, other: "Budget") -> "Budget":
        return Budget(self.usd + other.usd, self.tokens + other.tokens, self.compute_seconds + other.compute_seconds)


@dataclass(frozen=True)
class Capability:
    name: str
    risk: int = 0
    cost_hint: int = 0


@dataclass
class AgentProfile:
    agent_id: str
    department: Department
    roles: set[Role]
    capabilities: set[str]
    model_tier: str = "local_small"
    enabled: bool = True
    current_load: int = 0
    success_rate: float = 1.0
    avg_cost_usd: float = 0.0


@dataclass
class WorkItem:
    work_id: str
    mission_id: str
    title: str
    department: Department
    required_roles: set[Role]
    required_capabilities: set[str]
    success_criteria: list[str]
    evidence_required: list[str]
    budget: Budget
    payload: dict[str, Any] = field(default_factory=dict)
    state: TaskState = TaskState.PLANNED
    assigned_agents: list[str] = field(default_factory=list)
    parent_id: str | None = None


@dataclass
class Evidence:
    kind: str
    value: str
    verified: bool
    provenance: str = ""


@dataclass
class WorkResult:
    work_id: str
    success: bool
    summary: str
    evidence: list[Evidence]
    cost: Budget = field(default_factory=Budget)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def verified(self) -> bool:
        return self.success and all(e.verified for e in self.evidence)


@dataclass
class DepartmentPolicy:
    department: Department
    max_parallel: int = 4
    require_reviewer: bool = False
    require_risk_review: bool = False
    allowed_cross_department_exports: set[str] = field(default_factory=lambda: {"summary", "verified_fact", "artifact_ref"})
    budget: Budget = field(default_factory=lambda: Budget(usd=10.0, tokens=250_000, compute_seconds=36_000))


@dataclass
class OrganizationDecision:
    mission_id: str
    work_id: str
    selected_department: Department
    selected_agents: list[str]
    reason: str
    estimated_cost_rank: int
    requires_human: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)
