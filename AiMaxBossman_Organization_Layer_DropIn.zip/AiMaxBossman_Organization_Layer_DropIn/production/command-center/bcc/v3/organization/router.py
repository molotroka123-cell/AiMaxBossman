from __future__ import annotations

from .models import AgentProfile, OrganizationDecision, WorkItem
from .registry import OrganizationRegistry


_TIER_RANK = {
    "deterministic": 0,
    "local_small": 1,
    "local_strong": 2,
    "cheap_cloud": 3,
    "frontier": 4,
}


class AgentRouter:
    """Local-first, capability-first routing with cost/load bias."""

    def __init__(self, registry: OrganizationRegistry) -> None:
        self.registry = registry

    def _eligible(self, work: WorkItem) -> list[AgentProfile]:
        agents = self.registry.agents(work.department)
        return [
            a for a in agents
            if work.required_roles.intersection(a.roles)
            and work.required_capabilities.issubset(a.capabilities)
        ]

    @staticmethod
    def _score(agent: AgentProfile) -> tuple[int, int, float, float]:
        return (
            _TIER_RANK.get(agent.model_tier, 99),
            agent.current_load,
            agent.avg_cost_usd,
            -agent.success_rate,
        )

    def route(self, work: WorkItem, *, count: int = 1) -> OrganizationDecision:
        eligible = sorted(self._eligible(work), key=self._score)
        if not eligible:
            return OrganizationDecision(
                mission_id=work.mission_id,
                work_id=work.work_id,
                selected_department=work.department,
                selected_agents=[],
                reason="no eligible agent with required role+capabilities",
                estimated_cost_rank=99,
                requires_human=True,
            )
        selected = eligible[:count]
        return OrganizationDecision(
            mission_id=work.mission_id,
            work_id=work.work_id,
            selected_department=work.department,
            selected_agents=[a.agent_id for a in selected],
            reason="capability match; local-first; then load/cost/success",
            estimated_cost_rank=max(_TIER_RANK.get(a.model_tier, 99) for a in selected),
        )
