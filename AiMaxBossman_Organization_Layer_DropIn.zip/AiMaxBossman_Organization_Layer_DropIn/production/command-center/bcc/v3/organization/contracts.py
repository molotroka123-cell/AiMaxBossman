from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .models import Evidence, WorkItem, WorkResult


@dataclass(frozen=True)
class DelegationContract:
    work_id: str
    success_criteria: tuple[str, ...]
    required_evidence: tuple[str, ...]

    @classmethod
    def from_work(cls, work: WorkItem) -> "DelegationContract":
        return cls(work.work_id, tuple(work.success_criteria), tuple(work.evidence_required))

    def validate(self, result: WorkResult) -> tuple[bool, list[str]]:
        errors: list[str] = []
        if result.work_id != self.work_id:
            errors.append("work_id mismatch")
        by_kind = {e.kind: e for e in result.evidence}
        for kind in self.required_evidence:
            ev = by_kind.get(kind)
            if ev is None:
                errors.append(f"missing evidence:{kind}")
            elif not ev.verified:
                errors.append(f"unverified evidence:{kind}")
        if not result.success:
            errors.append("executor reported failure")
        return not errors, errors


def consensus(results: Iterable[WorkResult], *, minimum_verified: int = 2) -> bool:
    verified = sum(1 for result in results if result.verified)
    return verified >= minimum_verified
