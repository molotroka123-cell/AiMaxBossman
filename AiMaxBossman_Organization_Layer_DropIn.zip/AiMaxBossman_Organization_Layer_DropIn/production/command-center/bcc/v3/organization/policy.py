from __future__ import annotations

from dataclasses import dataclass

from .models import Budget, DepartmentPolicy, WorkItem


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str
    require_human: bool = False


class OrganizationGovernor:
    def preflight(self, work: WorkItem, policy: DepartmentPolicy, used: Budget) -> PolicyDecision:
        projected = used + work.budget
        if not policy.budget.fits(projected):
            return PolicyDecision(False, "department budget exceeded", True)
        if not work.success_criteria:
            return PolicyDecision(False, "missing success criteria", True)
        if not work.evidence_required:
            return PolicyDecision(False, "side-effect work must declare evidence", True)
        return PolicyDecision(True, "allowed")

    def can_export(self, policy: DepartmentPolicy, export_kind: str) -> PolicyDecision:
        if export_kind not in policy.allowed_cross_department_exports:
            return PolicyDecision(False, f"cross-department export blocked:{export_kind}")
        return PolicyDecision(True, "allowed")
