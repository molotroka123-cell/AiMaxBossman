from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from .models import Budget, Department, TaskState, WorkItem, WorkResult, Evidence, Role


class OrganizationStore:
    """Tiny durable store. No external DB/service dependency."""

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        self._init()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def _init(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS org_work (
                  work_id TEXT PRIMARY KEY,
                  mission_id TEXT NOT NULL,
                  payload TEXT NOT NULL,
                  state TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS org_results (
                  work_id TEXT PRIMARY KEY,
                  payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS org_kv (
                  key TEXT PRIMARY KEY,
                  value TEXT NOT NULL
                );
                """
            )

    def save_work(self, work: WorkItem) -> None:
        payload = {
            "work_id": work.work_id,
            "mission_id": work.mission_id,
            "title": work.title,
            "department": work.department.value,
            "required_roles": [r.value for r in work.required_roles],
            "required_capabilities": sorted(work.required_capabilities),
            "success_criteria": work.success_criteria,
            "evidence_required": work.evidence_required,
            "budget": work.budget.__dict__,
            "payload": work.payload,
            "state": work.state.value,
            "assigned_agents": work.assigned_agents,
            "parent_id": work.parent_id,
        }
        with self._connect() as con:
            con.execute(
                "INSERT INTO org_work(work_id, mission_id, payload, state) VALUES(?,?,?,?) "
                "ON CONFLICT(work_id) DO UPDATE SET payload=excluded.payload,state=excluded.state",
                (work.work_id, work.mission_id, json.dumps(payload), work.state.value),
            )

    def load_work(self, work_id: str) -> WorkItem | None:
        with self._connect() as con:
            row = con.execute("SELECT payload FROM org_work WHERE work_id=?", (work_id,)).fetchone()
        if not row:
            return None
        p = json.loads(row["payload"])
        return WorkItem(
            work_id=p["work_id"], mission_id=p["mission_id"], title=p["title"],
            department=Department(p["department"]), required_roles={Role(x) for x in p["required_roles"]},
            required_capabilities=set(p["required_capabilities"]), success_criteria=list(p["success_criteria"]),
            evidence_required=list(p["evidence_required"]), budget=Budget(**p["budget"]), payload=p["payload"],
            state=TaskState(p["state"]), assigned_agents=list(p["assigned_agents"]), parent_id=p.get("parent_id"),
        )

    def save_result(self, result: WorkResult) -> None:
        payload = {
            "work_id": result.work_id,
            "success": result.success,
            "summary": result.summary,
            "evidence": [e.__dict__ for e in result.evidence],
            "cost": result.cost.__dict__,
            "metadata": result.metadata,
        }
        with self._connect() as con:
            con.execute(
                "INSERT INTO org_results(work_id,payload) VALUES(?,?) ON CONFLICT(work_id) DO UPDATE SET payload=excluded.payload",
                (result.work_id, json.dumps(payload)),
            )

    def load_result(self, work_id: str) -> WorkResult | None:
        with self._connect() as con:
            row = con.execute("SELECT payload FROM org_results WHERE work_id=?", (work_id,)).fetchone()
        if not row:
            return None
        p = json.loads(row["payload"])
        return WorkResult(
            work_id=p["work_id"], success=p["success"], summary=p["summary"],
            evidence=[Evidence(**e) for e in p["evidence"]], cost=Budget(**p["cost"]), metadata=p["metadata"],
        )
