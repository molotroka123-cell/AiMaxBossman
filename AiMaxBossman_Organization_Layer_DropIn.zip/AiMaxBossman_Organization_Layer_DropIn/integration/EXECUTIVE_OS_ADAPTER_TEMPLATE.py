"""Template only. Replace imports/calls with the real Executive OS API after it lands."""

from bcc.v3.organization.models import WorkItem, WorkResult


class BossmanExecutiveAdapter:
    def __init__(self, executive):
        self.executive = executive

    def execute_delegated(self, work: WorkItem, agent_id: str) -> WorkResult:
        # Map WorkItem -> the actual Executive OS child-mission/task API.
        # IMPORTANT: convert only VERIFIED Executive OS receipts into Evidence(verified=True).
        raise NotImplementedError("wire to actual Executive OS API")

    def request_human_review(self, work: WorkItem, reason: str) -> None:
        # Wire to existing approval/review gate.
        raise NotImplementedError("wire to actual owner review gate")
