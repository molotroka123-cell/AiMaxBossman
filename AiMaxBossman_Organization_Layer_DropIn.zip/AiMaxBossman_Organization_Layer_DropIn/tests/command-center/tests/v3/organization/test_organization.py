from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[5]
PROD = ROOT / "production" / "command-center"
sys.path.insert(0, str(PROD))

from bcc.v3.organization import (  # noqa: E402
    AgentProfile, Budget, Department, DepartmentPolicy, Evidence,
    OrganizationOrchestrator, OrganizationRegistry, OrganizationStore,
    Role, TaskState, WorkItem, WorkResult,
)
from bcc.v3.organization.contracts import DelegationContract, consensus  # noqa: E402
from bcc.v3.organization.kpi import calculate_kpis  # noqa: E402
from bcc.v3.organization.policy import OrganizationGovernor  # noqa: E402
from bcc.v3.organization.router import AgentRouter  # noqa: E402


def make_work(work_id="w1", department=Department.ENGINEERING):
    return WorkItem(
        work_id=work_id,
        mission_id="m1",
        title="fix bug",
        department=department,
        required_roles={Role.EXECUTOR},
        required_capabilities={"code"},
        success_criteria=["bug fixed"],
        evidence_required=["test"],
        budget=Budget(usd=1, tokens=1000, compute_seconds=60),
    )


def test_router_prefers_local_then_load_cost():
    reg = OrganizationRegistry()
    reg.register_agent(AgentProfile("cloud", Department.ENGINEERING, {Role.EXECUTOR}, {"code"}, model_tier="cheap_cloud"))
    reg.register_agent(AgentProfile("local", Department.ENGINEERING, {Role.EXECUTOR}, {"code"}, model_tier="local_small", current_load=3))
    decision = AgentRouter(reg).route(make_work())
    assert decision.selected_agents == ["local"]


def test_cross_project_department_mismatch_is_not_routed():
    reg = OrganizationRegistry()
    reg.register_agent(AgentProfile("researcher", Department.RESEARCH, {Role.EXECUTOR}, {"code"}))
    decision = AgentRouter(reg).route(make_work())
    assert decision.selected_agents == []
    assert decision.requires_human


def test_contract_rejects_text_success_without_verified_evidence():
    work = make_work()
    result = WorkResult(work.work_id, True, "done", [Evidence("test", "claimed pass", False)])
    ok, errors = DelegationContract.from_work(work).validate(result)
    assert not ok
    assert "unverified evidence:test" in errors


def test_contract_accepts_verified_result():
    work = make_work()
    result = WorkResult(work.work_id, True, "done", [Evidence("test", "pytest passed", True)])
    ok, errors = DelegationContract.from_work(work).validate(result)
    assert ok and not errors


def test_consensus_requires_multiple_verified_results():
    good = WorkResult("w", True, "ok", [Evidence("review", "yes", True)])
    bad = WorkResult("w", True, "claimed", [Evidence("review", "no", False)])
    assert consensus([good, good], minimum_verified=2)
    assert not consensus([good, bad], minimum_verified=2)


def test_governor_blocks_missing_evidence():
    work = make_work()
    work.evidence_required = []
    decision = OrganizationGovernor().preflight(work, DepartmentPolicy(Department.ENGINEERING), Budget())
    assert not decision.allowed


def test_store_roundtrip(tmp_path: Path):
    store = OrganizationStore(tmp_path / "org.sqlite")
    work = make_work()
    work.assigned_agents = ["a"]
    work.state = TaskState.EXECUTING
    store.save_work(work)
    loaded = store.load_work(work.work_id)
    assert loaded is not None
    assert loaded.assigned_agents == ["a"]
    assert loaded.state == TaskState.EXECUTING


class FakeExecutive:
    def __init__(self, result):
        self.result = result
        self.calls = 0
        self.human = []

    def execute_delegated(self, work, agent_id):
        self.calls += 1
        return self.result

    def request_human_review(self, work, reason):
        self.human.append((work.work_id, reason))


class FakeMemory:
    def __init__(self):
        self.rows = []

    def publish_department_fact(self, department, kind, payload):
        self.rows.append((department, kind, payload))
        return "mem-1"


def configured_registry():
    reg = OrganizationRegistry()
    reg.register_agent(AgentProfile("coder", Department.ENGINEERING, {Role.EXECUTOR}, {"code"}, model_tier="local_small"))
    reg.upsert_policy(DepartmentPolicy(Department.ENGINEERING, budget=Budget(usd=5, tokens=10000, compute_seconds=1000)))
    return reg


def test_orchestrator_verified_execution_completes_and_publishes(tmp_path: Path):
    result = WorkResult("w1", True, "ok", [Evidence("test", "pytest passed", True)], Budget(usd=.1, tokens=100, compute_seconds=1))
    executive = FakeExecutive(result)
    memory = FakeMemory()
    store = OrganizationStore(tmp_path / "org.sqlite")
    orch = OrganizationOrchestrator(registry=configured_registry(), store=store, executive=executive, memory=memory)
    out = orch.run(make_work())
    assert out and out.success
    assert store.load_work("w1").state == TaskState.COMPLETED
    assert len(memory.rows) == 1


def test_orchestrator_false_success_is_forced_failed(tmp_path: Path):
    result = WorkResult("w1", True, "I did it", [Evidence("test", "trust me", False)])
    store = OrganizationStore(tmp_path / "org.sqlite")
    orch = OrganizationOrchestrator(registry=configured_registry(), store=store, executive=FakeExecutive(result))
    out = orch.run(make_work())
    assert out is not None and not out.success
    assert store.load_work("w1").state == TaskState.FAILED


def test_resume_completed_does_not_repeat_side_effect(tmp_path: Path):
    result = WorkResult("w1", True, "ok", [Evidence("test", "pass", True)])
    executive = FakeExecutive(result)
    store = OrganizationStore(tmp_path / "org.sqlite")
    orch = OrganizationOrchestrator(registry=configured_registry(), store=store, executive=executive)
    assert orch.run(make_work()).success
    assert executive.calls == 1
    assert orch.resume("w1").success
    assert executive.calls == 1


def test_kpi_counts_false_success():
    rows = [
        WorkResult("a", True, "ok", [Evidence("x", "v", True)], Budget(usd=1)),
        WorkResult("b", True, "claim", [Evidence("x", "v", False)], Budget(usd=3)),
    ]
    report = calculate_kpis(rows)
    assert report.total == 2
    assert report.verified_success_rate == .5
    assert report.average_cost_usd == 2
    assert report.false_success_count == 1
