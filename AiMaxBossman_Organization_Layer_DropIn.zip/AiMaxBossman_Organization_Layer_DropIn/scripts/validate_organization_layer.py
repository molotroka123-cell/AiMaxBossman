from __future__ import annotations

import compileall
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    prod = ROOT / "production" / "command-center" / "bcc" / "v3" / "organization"
    tests = ROOT / "tests" / "command-center" / "tests" / "v3" / "organization"
    print("[1/3] compileall")
    if not compileall.compile_dir(prod, quiet=1):
        print("FAIL: compileall")
        return 1
    print("PASS: compileall")

    print("[2/3] secret-pattern check")
    bad = []
    patterns = ("s"+"k-", "api"+"_key=", "authorization:"+" bearer ")
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".py", ".md", ".json", ".txt"}:
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
            if any(p in text for p in patterns):
                bad.append(str(path.relative_to(ROOT)))
    if bad:
        print("FAIL: suspicious secret patterns", bad)
        return 1
    print("PASS: secret-pattern check")

    print("[3/3] pytest")
    env = os.environ.copy()
    proc = subprocess.run([sys.executable, "-m", "pytest", "-q", str(tests)], cwd=ROOT, env=env)
    if proc.returncode:
        print("FAIL: pytest")
        return proc.returncode
    print("PASS: pytest")
    print("ORGANIZATION_LAYER_VALIDATION=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
