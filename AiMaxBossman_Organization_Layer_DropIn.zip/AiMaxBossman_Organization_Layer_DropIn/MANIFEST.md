# Manifest

| ZIP path | Target path | Type | Purpose |
|---|---|---|---|
| production/command-center/bcc/v3/organization/__init__.py | command-center/bcc/v3/organization/__init__.py | NEW | Public package exports |
| production/command-center/bcc/v3/organization/models.py | command-center/bcc/v3/organization/models.py | NEW | Departments, roles, budgets, work/evidence/result models |
| production/command-center/bcc/v3/organization/registry.py | command-center/bcc/v3/organization/registry.py | NEW | Agent/department registry |
| production/command-center/bcc/v3/organization/router.py | command-center/bcc/v3/organization/router.py | NEW | Capability-first local-first routing |
| production/command-center/bcc/v3/organization/contracts.py | command-center/bcc/v3/organization/contracts.py | NEW | Delegation contracts + consensus primitive |
| production/command-center/bcc/v3/organization/policy.py | command-center/bcc/v3/organization/policy.py | NEW | Budget/evidence/cross-department policy gates |
| production/command-center/bcc/v3/organization/store.py | command-center/bcc/v3/organization/store.py | NEW | Durable SQLite state |
| production/command-center/bcc/v3/organization/kpi.py | command-center/bcc/v3/organization/kpi.py | NEW | Organization KPIs |
| production/command-center/bcc/v3/organization/bridge.py | command-center/bcc/v3/organization/bridge.py | NEW | Executive OS + memory adapter protocols |
| production/command-center/bcc/v3/organization/orchestrator.py | command-center/bcc/v3/organization/orchestrator.py | NEW | Route/delegate/verify/persist orchestration |
| tests/command-center/tests/v3/organization/test_organization.py | command-center/tests/v3/organization/test_organization.py | NEW | Deterministic unit/E2E-style tests |
| integration/EXECUTIVE_OS_ADAPTER_TEMPLATE.py | integration only | TEMPLATE | Wire to the actual Executive OS API after it lands |
| scripts/validate_organization_layer.py | tools/ or run from ZIP | NEW | compile + secret-pattern + pytest validation |
| ARCHITECTURE.md | docs/v3/organization/ARCHITECTURE.md | DOC | Architecture |
| SECURITY.md | docs/v3/organization/SECURITY.md | DOC | Security invariants |
| INTEGRATION_ORDER.md | docs/v3/organization/INTEGRATION_ORDER.md | DOC | Integration steps |
| TEST_PLAN.md | docs/v3/organization/TEST_PLAN.md | DOC | Test plan |
| HANDOFF.md | docs/v3/organization/HANDOFF.md | DOC | Handoff to integrating model |
| docs/IMPLEMENTATION_DECISIONS.md | docs/v3/organization/IMPLEMENTATION_DECISIONS.md | DOC | Structured implementation trace |
| docs/FAILURE_PATTERNS.md | docs/v3/organization/FAILURE_PATTERNS.md | DOC | Known failure patterns |
| docs/REUSABLE_RULES.md | docs/v3/organization/REUSABLE_RULES.md | DOC | Rules for local-model training |

## Dependencies

Production: Python standard library only.
Tests: `pytest`.

## Integration caveat

This package is intentionally adapter-driven because the Executive OS stage is being implemented in parallel. The only expected compatibility work is implementing the actual Executive OS bridge and, optionally, the real V3 memory bridge. Do not rewrite stable V2/V3 execution semantics.
