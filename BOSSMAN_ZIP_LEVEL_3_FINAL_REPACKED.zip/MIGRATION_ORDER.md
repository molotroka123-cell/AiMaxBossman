# EXECUTION ORDER

1. Fresh fetch/re-audit.
2. Isolated worktree for CI-HISTORY-001.
3. Targeted provenance test unchanged.
4. Independent verification + atomic commit.
5. Fresh CI.
6. Confirm/fix Auto-Repair report/ref issues separately.
7. Start LONGHORIZON-FREEZE-001 with durable mission_id.
8. Real Higgsfield case.
9. Real teacher Bug A -> Bug B reuse case.
10. Public business research -> WAIT_APPROVAL case.
11. Populate key-function touch matrix during execution.
12. Let Fable propose runtime-derived improvements.
13. Deliberate safe manager/process restart -> automatic resume same mission.
14. Safe ZIP3 ingest where useful.
15. Existing benchmark/release evidence.
16. Full regression/security gate.
17. Freeze report.
18. FREEZE only with P0_OPEN=0; otherwise NO_GO.
