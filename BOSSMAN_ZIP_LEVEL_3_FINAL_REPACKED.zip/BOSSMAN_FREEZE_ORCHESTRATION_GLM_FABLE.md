# BOSSMAN FREEZE ORCHESTRATION — GLM + FABLE

## ONE-SESSION LOCAL LONG-HORIZON FREEZE ACCEPTANCE

The entire freeze is acceptance `LONGHORIZON-FREEZE-001`.

ONE_SESSION means one owner mission_id from start to FREEZE or NO_GO even when model contexts,
workers or local processes rotate.

Forbidden:
- RunPod
- remote compute/browser/shell/worktrees
- pretending simulated evidence is real

Allowed cloud:
- authorized model API calls only

Required orchestration:
- GLM = persistent local-first manager
- Claude Fable = paid lead engineer only for hard escalations
- narrow/local agents = routine work
- prompt caching + delta-first context
- independent work may batch
- hard cloud budget = $9
- typed fallback sends the same sanitized ProblemBundle to another approved model only when Fable is objectively stuck

Required deliberate restart proof:
- safely stop/restart manager/process once
- resume same mission_id automatically from durable checkpoint
- no owner continuation prompt
- no duplicate LIVE effect

Do not idle merely to increase wall-clock duration. Record real wall time, phase count, and atomic work count.
