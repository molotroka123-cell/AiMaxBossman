# KEY FUNCTION TOUCH MATRIX

| ID | Function/module that must be exercised | Runtime evidence |
|---|---|---|
| KEYFUNC-FABLE-001 | manager / mission queue / checkpoint-resume | mission_id + checkpoint before/after restart |
| KEYFUNC-FABLE-002 | model routing / escalation / fallback | typed routing events + failure fingerprint |
| KEYFUNC-FABLE-003 | prompt cache / $9 cost governor | cache hit/write + atomic cost reservations |
| KEYFUNC-FABLE-004 | WorldState / failure diagnosis | evidence-backed transitions |
| KEYFUNC-FABLE-005 | UCA observe/act/verify/recover | fresh observations + verifier |
| KEYFUNC-FABLE-006 | skill record/select/reuse/promotion | analogous task selects verified skill first |
| KEYFUNC-FABLE-007 | Claude teacher ProblemBundle/patch/verifier | sanitized bundle + independent verifier |
| KEYFUNC-FABLE-008 | durable side effect / owner approval / idempotency | nonce/effect persistence + replay denial |
| KEYFUNC-FABLE-009 | real browser E2E | semantic target + reobserve + final state |
| KEYFUNC-FABLE-010 | ZIP3 ingest | hash/inventory/disposable unpack/worktree |
| KEYFUNC-FABLE-011 | existing benchmark/release evidence | executed SHA/tree binding |
| KEYFUNC-FABLE-012 | CI/release gate | current workflow results + exact blockers |

For every row record:
symbol/path; why exercised; runtime evidence; weakness; Fable recommendation; changed or not;
exact diff/commit; targeted tests; independent verifier; before/after metric where measurable.

If no change is justified, record `NO_CHANGE_JUSTIFIED` with evidence.
