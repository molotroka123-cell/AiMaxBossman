# LONG_HORIZON_ACCEPTANCE

Acceptance ID: LONGHORIZON-FREEZE-001

PASS only if:
1. one owner mission_id is preserved from start to FREEZE/NO_GO;
2. ordinary worker/model/context/test failures recover from durable checkpoint without owner re-prompt;
3. one deliberate safe manager/process restart resumes same mission_id;
4. no duplicate LIVE side effect;
5. CI-HISTORY-001 is fixed without weakening provenance;
6. key-function touch matrix is completed from runtime evidence;
7. real acceptance cases stay separate and truthfully labeled;
8. existing benchmark/release evidence runs against actual executed code;
9. no unresolved P0 remains.

Otherwise end NO_GO with the exact blocker.
