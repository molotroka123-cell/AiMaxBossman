# HANDOFF

Reference branch:
claude/bossman-control-v03-43igbk

Reference HEAD:
0d4d4feee3fb89ee1939814071669c79c348226a

Do not assume it is still current. Fetch and re-audit.

Hard stop rules:
- secret in cloud context -> redact/refuse call
- cloud budget exceeded -> local-only / NO_GO
- unresolved P0 -> NO_GO
- owner approval required -> WAIT_APPROVAL
- remote compute/browser/worktree -> forbidden
