# MASTER IMPLEMENTATION PROMPT

You are finishing AiMaxBossman Autonomy Trainer / V2 freeze on the OWNER MACHINE.

FIRST re-audit:
- fresh remote HEAD
- dirty tree
- current workflows/CI
- durable checkpoint
- affected code paths
Never trust the reference SHA blindly.

Read this package completely.

Immediate P0:
Fix CI-HISTORY-001 by making enough git history available to affected CI jobs.
Preserve run_isolated() ShaMismatch integrity and the historical provenance test unchanged.

Then execute one mission:
LONGHORIZON-FREEZE-001

GLM is persistent local-first manager.
Fable is paid lead engineer only for hard escalations.
Routine tasks go to narrow/local/smaller agents.
Cloud budget hard cap: $9.
Use prompt caching and delta-first context.
Typed fallback may hand the SAME sanitized ProblemBundle to another approved model only when Fable is objectively stuck.

Required separate real cases:
A) Higgsfield workflow learning/reuse
B) Claude/Fable teacher: Bug A -> hermetic teacher -> verified generalized lesson -> analogous Bug B tries skill first
C) public business/Maps research -> real website issue -> demo/proposal -> authenticated WAIT_APPROVAL
Never send unsolicited outreach.

Build KEY_FUNCTION_TOUCH_MATRIX from actual runtime evidence.
Fable MUST inspect the functions touched by the long task and may improve them using its own ideas.
Do not constrain Fable to this runbook's architecture when a demonstrably superior implementation exists.

For every deviation document:
reason, tests, compatibility, security, resource/cloud cost, migration and rollback.

No speculative rewrite.
High-risk Fable changes require independent verifier acceptance.
If already sufficient: NO_CHANGE_JUSTIFIED.

ZIP3 ingest:
- hash
- inventory
- unpack disposable
- compare provenance to current HEAD
- never overwrite newer code blindly
- isolated local worktree
- targeted tests
- independent verifier
- merge only accepted deltas

Required restart:
perform one safe deliberate manager/process restart and resume same mission_id automatically, without owner re-prompt.

Final:
existing benchmark/release gate -> full regression/security -> freeze report.
FREEZE only when P0_OPEN=0. Otherwise NO_GO.
