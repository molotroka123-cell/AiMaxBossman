# BUG / GAP MAP

## P0 — CI-HISTORY-001
Repro: run current Core CI or V2 Auto-Repair.
Actual: historical benchmark SHA cannot be resolved from shallow clone.
Expected: isolated worktree executes the requested historical commit.
Fix: fetch full history or the exact required SHA.
Acceptance: provenance test passes unchanged and unknown SHAs still fail.

## P1 — CI-AUTOREPAIR-REPORT-001
Failure-triggered repair/report flow must never state "all tests pass" when they do not.
Generate report from actual suite outcome.

## P1 — CI-AUTOREPAIR-REF-001
PR validation must test the candidate PR SHA, not accidentally hard-code only the target branch.

## P1 — REAL-E2E-001
Separate real proofs still required:
- Higgsfield
- Claude/Fable teacher Bug A -> Bug B
- public business research -> proposal -> WAIT_APPROVAL

## P1 — LONGHORIZON-001
One mission_id, durable continuation, deliberate restart/resume and no duplicate side effects remain acceptance requirements.

## P1 — KEYFUNC-FABLE-001..N
Fable must inspect functions actually exercised at runtime and either improve them from evidence or record NO_CHANGE_JUSTIFIED.
