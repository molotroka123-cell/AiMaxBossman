# Claude Code handoff — Stages 4–7
This package contains the previous stages plus new implementation seams for:
4 Resource Brain
5 Search Everything
6 Private Remote Client backend
7 Video Factory

Do not treat these modules as production-complete. They are working cores intended for integration into the actual repo.
First inspect current HEAD because Stage 1–3 may have changed since this handoff.
Use multiple review passes: architecture, builder, security, chaos/QA, integration.

Priority:
1. Reconcile Stage 3 ResourceAdvisor with `resource_brain`.
2. Reuse Stage 2.222 retrieval/memory in Search Everything; do not create duplicate vector stores.
3. Persist Stage 6 devices in existing PostgreSQL and connect approvals/events.
4. Put Video Factory workers behind Resource Brain admission and bounded queues.
5. Add API/dashboard endpoints only after auth/security boundaries are clear.
6. Run all existing tests plus `test_stage4_7.py`.
7. Improve/refactor freely when evidence/tests show a better design.
