import os, shutil, time
from .models import ResourceSnapshot
def snapshot()->ResourceSnapshot:
    page=os.sysconf("SC_PAGE_SIZE") if hasattr(os,"sysconf") else 4096
    pages=os.sysconf("SC_PHYS_PAGES") if hasattr(os,"sysconf") else 0
    avail_pages=os.sysconf("SC_AVPHYS_PAGES") if hasattr(os,"sysconf") else pages
    du=shutil.disk_usage("/")
    return ResourceSnapshot(ram_total=page*pages, ram_available=page*avail_pages,
        disk_total=du.total,disk_free=du.free,ts=time.time())
