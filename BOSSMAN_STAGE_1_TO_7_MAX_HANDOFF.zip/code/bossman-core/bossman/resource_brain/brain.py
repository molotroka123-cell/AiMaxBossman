from .models import *
class ResourceBrain:
    def __init__(self, *, max_ram_pressure:float=.88, disk_reserve:int=20*1024**3):
        self.max_ram_pressure=max_ram_pressure; self.disk_reserve=disk_reserve
    def admit(self, snap:ResourceSnapshot, req:WorkloadRequest)->AdmissionDecision:
        projected=1-((snap.ram_available-req.estimated_ram)/snap.ram_total) if snap.ram_total else 0
        if snap.disk_free-req.estimated_disk < self.disk_reserve:
            return AdmissionDecision(False,"disk_reserve",projected)
        if projected > self.max_ram_pressure:
            return AdmissionDecision(False,"ram_pressure",projected)
        return AdmissionDecision(True,"ok",projected,req.model)
    def rank_models(self, snap:ResourceSnapshot, candidates:list[dict])->list[dict]:
        def score(m):
            health=1 if m.get("health","healthy")=="healthy" else 0
            resident=1 if m.get("id") in snap.model_resident else 0
            ram=int(m.get("ram_estimate",0))
            fits=1 if ram <= snap.ram_available else 0
            return (fits,health,resident,-ram,-float(m.get("latency_ms",0)))
        return sorted(candidates,key=score,reverse=True)
