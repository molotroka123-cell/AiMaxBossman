from dataclasses import dataclass, field
from typing import Literal
@dataclass(slots=True)
class ResourceSnapshot:
    ram_total:int; ram_available:int; disk_total:int; disk_free:int
    cpu_percent:float=0.0; gpu_memory_total:int|None=None; gpu_memory_used:int|None=None
    model_resident:tuple[str,...]=(); ts:float=0.0
    @property
    def ram_pressure(self)->float:
        return 0.0 if not self.ram_total else 1-(self.ram_available/self.ram_total)
@dataclass(slots=True)
class WorkloadRequest:
    kind:Literal["llm","embedding","rerank","video","training","sandbox","other"]="other"
    estimated_ram:int=0; estimated_disk:int=0; priority:int=50; model:str|None=None
@dataclass(slots=True)
class AdmissionDecision:
    allowed:bool; reason:str; pressure:float; suggested_model:str|None=None
