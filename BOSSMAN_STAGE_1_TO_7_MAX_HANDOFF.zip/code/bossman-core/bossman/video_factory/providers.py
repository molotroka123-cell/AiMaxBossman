from typing import Protocol
class VideoProvider(Protocol):
    async def generate(self,*,prompt:str,duration_s:float,output_dir:str)->str: ...
class ProviderPolicyError(RuntimeError): pass
def assert_browser_provider_allowed(blocked:bool):
    if blocked: raise ProviderPolicyError("Provider automation blocked by service/access-control policy")
