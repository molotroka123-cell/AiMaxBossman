from dataclasses import dataclass,field
from enum import StrEnum
from pathlib import Path
import json,time,uuid
class JobState(StrEnum):
    PLANNED="planned"; QUEUED="queued"; RUNNING="running"; FAILED="failed"; COMPLETE="complete"; CANCELLED="cancelled"
@dataclass(slots=True)
class Scene:
    id:str; prompt:str; duration_s:float=5.; status:str="planned"; output:str|None=None; attempts:int=0
@dataclass(slots=True)
class VideoJob:
    id:str; title:str; scenes:list[Scene]; state:JobState=JobState.PLANNED; created_at:float=field(default_factory=time.time)
class VideoFactory:
    def __init__(self,root:Path):self.root=root;root.mkdir(parents=True,exist_ok=True)
    def create(self,title,prompts):
        job=VideoJob(uuid.uuid4().hex,title,[Scene(f"s{i+1:03}",p) for i,p in enumerate(prompts)])
        self.save(job);return job
    def save(self,job):
        d=self.root/job.id;d.mkdir(parents=True,exist_ok=True)
        data={"id":job.id,"title":job.title,"state":job.state.value,"created_at":job.created_at,
              "scenes":[{"id":s.id,"prompt":s.prompt,"duration_s":s.duration_s,"status":s.status,"output":s.output,"attempts":s.attempts} for s in job.scenes]}
        tmp=d/"job.json.tmp";tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),"utf-8");tmp.replace(d/"job.json")
    def checkpoint_scene(self,job,scene_id,*,status,output=None):
        s=next(x for x in job.scenes if x.id==scene_id);s.status=status;s.output=output;s.attempts+=1;self.save(job)
