# Stage 6 private client backend
Backend primitives only. The production phone client must connect over a private tunnel/TLS boundary.
Never expose raw model backends publicly. Device secrets are returned only at enrollment and stored hashed.
Integrate persistence with Bossman's PostgreSQL before production use.
