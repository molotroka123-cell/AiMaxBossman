import hashlib,hmac,secrets,time
from dataclasses import dataclass
@dataclass(slots=True)
class Device:
    id:str; name:str; token_hash:str; scopes:frozenset[str]; revoked:bool=False; created_at:float=0
class DeviceRegistry:
    def __init__(self): self._devices={}
    def enroll(self,name,scopes=("chat","events")):
        raw=secrets.token_urlsafe(32); did=secrets.token_hex(8)
        self._devices[did]=Device(did,name,hashlib.sha256(raw.encode()).hexdigest(),frozenset(scopes),False,time.time())
        return did,raw
    def verify(self,did,token,scope=None):
        d=self._devices.get(did)
        if not d or d.revoked:return False
        ok=hmac.compare_digest(d.token_hash,hashlib.sha256(token.encode()).hexdigest())
        return ok and (scope is None or scope in d.scopes)
    def revoke(self,did):
        if did in self._devices:self._devices[did].revoked=True
