import asyncio
class EventBroker:
    def __init__(self,maxsize=256):self.maxsize=maxsize;self._q={}
    def subscribe(self,device_id):
        q=asyncio.Queue(self.maxsize);self._q.setdefault(device_id,set()).add(q);return q
    def unsubscribe(self,device_id,q):self._q.get(device_id,set()).discard(q)
    def publish(self,device_id,event):
        for q in list(self._q.get(device_id,())):
            try:q.put_nowait(event)
            except asyncio.QueueFull:self.unsubscribe(device_id,q)
