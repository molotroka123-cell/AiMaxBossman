from pathlib import Path
from .engine import SearchDocument
TEXT_SUFFIXES={".md",".txt",".py",".js",".ts",".tsx",".json",".yaml",".yml",".toml",".html",".css"}
def filesystem_documents(root:Path, *, project:str|None=None, max_bytes:int=2_000_000):
    root=root.resolve()
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES: continue
        try:
            if p.stat().st_size>max_bytes: continue
            text=p.read_text("utf-8",errors="replace")
            yield SearchDocument(str(p.relative_to(root)),text,"filesystem",project,{"path":str(p)})
        except (OSError,ValueError): continue
