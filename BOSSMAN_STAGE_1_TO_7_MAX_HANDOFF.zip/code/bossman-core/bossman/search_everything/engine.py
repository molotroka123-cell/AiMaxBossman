from dataclasses import dataclass, field
import math, re
from collections import Counter
@dataclass(slots=True)
class SearchDocument:
    id:str; text:str; source:str; project:str|None=None; metadata:dict=field(default_factory=dict)
@dataclass(slots=True)
class SearchHit:
    document:SearchDocument; score:float; reasons:tuple[str,...]=()
def _terms(s): return re.findall(r"[\w.-]+",s.lower(),re.UNICODE)
class SearchEngine:
    """Local lexical core. Vector/reranker adapters can merge into this without replacing provenance."""
    def __init__(self): self.docs={}
    def upsert(self, docs):
        for d in docs:self.docs[d.id]=d
    def search(self,q,*,project=None,limit=10):
        qt=Counter(_terms(q)); out=[]
        for d in self.docs.values():
            if project and d.project!=project: continue
            dt=Counter(_terms(d.text)); overlap=sum(min(v,dt[k]) for k,v in qt.items())
            if not overlap: continue
            score=overlap/(math.sqrt(sum(qt.values())*max(1,sum(dt.values()))))
            out.append(SearchHit(d,score,("lexical",)))
        return sorted(out,key=lambda x:x.score,reverse=True)[:limit]
    @staticmethod
    def fuse(*ranked, limit=10):
        scores={}; hits={}
        for result in ranked:
            for rank,h in enumerate(result,1):
                scores[h.document.id]=scores.get(h.document.id,0)+1/(60+rank)
                hits[h.document.id]=h
        return [SearchHit(hits[k].document,v,("rrf",)) for k,v in sorted(scores.items(),key=lambda x:x[1],reverse=True)[:limit]]
