from pathlib import Path
import shutil
HERE=Path(__file__).resolve().parents[1]
def main(target):
    target=Path(target).resolve()
    src=HERE/"code"/"bossman-core"/"bossman"
    dst=target/"bossman-core"/"bossman"
    for name in ("resource_brain","search_everything","remote_client","video_factory"):
        shutil.copytree(src/name,dst/name,dirs_exist_ok=True)
    print("Stage 4-7 module cores copied. Integrate APIs/config/DB after inspecting current HEAD.")
if __name__=="__main__":
    import sys
    if len(sys.argv)!=2: raise SystemExit("usage: apply_stage_4_7.py /path/to/AiMaxBossman")
    main(sys.argv[1])
