# ЭТАП 6 — Private Remote Client backend
Thin device-auth/event primitives for a future iPhone client.
Production boundary: private tunnel + TLS, device enrollment, revocation, scoped credentials, approvals and emergency lock.
Included registry is deliberately in-memory for tests; Claude must persist devices in PostgreSQL and integrate Bossman approvals/events.
Do not expose Ollama/LM Studio/model backends directly to the internet.
