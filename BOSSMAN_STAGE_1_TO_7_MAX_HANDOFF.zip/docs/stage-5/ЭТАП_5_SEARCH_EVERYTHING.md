# ЭТАП 5 — Search Everything
One provenance-preserving search plane across projects, code, docs, memory and agent history.
Pipeline: connectors -> normalize -> chunk -> lexical/vector candidates -> RRF -> rerank -> dedupe -> context pack.
The included lexical/RRF core is deterministic; wire Stage 2.222 vector/reranker rather than creating a second memory system.
Never silently index secrets; connectors need allow/deny rules and sensitivity metadata.
