# ЭТАП 7 — Video Factory
Project/job/scene state machine with atomic checkpoints and provider interface.
Target pipeline: script -> scene plan -> storyboard -> refs -> generation -> QA/retry -> upscale/interpolate -> FFmpeg -> export.
Providers may be local or approved browser/API adapters. Browser automation must stop at CAPTCHA, anti-bot, rate-limit and access-control blocks.
Before production add bounded worker queue, Resource Brain leases, FFmpeg argument-safe adapter, artifact hashes, cancellation and crash recovery.
