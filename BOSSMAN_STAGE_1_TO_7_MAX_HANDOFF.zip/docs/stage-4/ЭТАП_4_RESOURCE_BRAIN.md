# ЭТАП 4 — Resource Brain
Admission control and future scheduling layer for the 128-GB unified-memory host.
Hard rule: reserve RAM/disk before expensive work; reject/backpressure rather than OOM.
Integrate with Stage 3 through ResourceAdvisor-compatible hooks. Add OS/AMD-specific GPU probes only after runtime detection.
Future: residency manager, eviction scoring, thermal/throughput signals, workload leases, fairness.
