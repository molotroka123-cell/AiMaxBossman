# Intelligence Preservation / Anti-Dumbness

Bossman must not gain autonomy by making the same underlying model worse.

Compare the SAME model on SAME benchmark items in four lanes:

1. RAW
2. SYSTEM
3. CONTEXT
4. FULL BOSSMAN

Required categories:
- reasoning accuracy
- coding correctness
- structured output accuracy
- unknown-task adaptation
- tool selection accuracy
- schema argument accuracy
- long-context accuracy
- memory retrieval accuracy
- computer-use planning
- task completion
- hallucination rate
- latency/tokens/cost as secondary metrics

Current gate policy:
- core intelligence retention >= 98% vs RAW
- FULL tool selection must not regress vs CONTEXT
- FULL schema argument accuracy must not regress vs CONTEXT
- hallucination regression is bounded
- missing measured evidence = `INSUFFICIENT_EVIDENCE`, never PASS

Core intelligence = mean of:
reasoning + coding + structured output + unknown-task adaptation.

Diagnosis:
- SYSTEM regression => instruction collision
- CONTEXT regression => context pollution / retrieval / authority issue
- FULL regression => orchestration harms baseline reasoning
- TOOL regression => tool overload / bad capability selection

Rule:
`MORE_AUTONOMY != MORE_INTELLIGENCE`
