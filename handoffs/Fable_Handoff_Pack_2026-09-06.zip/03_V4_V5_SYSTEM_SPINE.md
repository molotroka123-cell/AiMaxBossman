# V4/V5 — System-Wide Strengthening

The next epochs should strengthen the entire OS, not one vertical.

## V4 target: Cognitive Operating System

Transform many strong subsystems into one coherent execution environment.

### Mission Kernel
Canonical Mission IR for every task:
- intent
- expected world-state
- required effects
- forbidden effects
- evidence requirements
- budget
- privacy
- risk
- deadlines
- capabilities
- recovery policy

### World State Kernel
Verified operational state independent from model belief:
- app/window state
- project state
- files
- Git state
- models
- resources
- connectors
- task state
- freshness/provenance

Rule: `MODEL_BELIEF != WORLD_STATE`.

### Capability Graph
Select only capabilities needed for the mission.
Do not expose the whole tool registry to the model.
Target: typically small relevant tool surfaces.

### Context Kernel
Pipeline:
memory -> retrieve -> scope -> authority -> relevance -> freshness -> token budget -> model.

Target: smallest sufficient context.

### Policy / Invariant Bus
System-wide invariants inherited by every app:
- no effect without authorization
- no completion without verification
- no private-data escape
- no unledgered cost
- no ambiguous irreversible replay
- no memory-as-policy
- no unbenchmarked skill promotion
- no release under intelligence regression

### Recovery Kernel
Shared:
observe -> act -> verify -> classify failure -> reobserve -> local repair -> replan -> switch executor -> human only if necessary.

Resume from `LAST_VERIFIED_STATE`, not model recollection.

### Skill Factory
Verified repeated workflows become versioned skills with:
- preconditions
- required capability
- execution template
- verification
- recovery
- permissions
- provenance
- success statistics
- rollback

### AI Desktop
User manages goals, approvals, evidence and results, not internal subsystems.

## V5 target: Self-Optimizing Digital Organization

Build only on verified V4.

- persistent goal graph
- bounded autonomous operating cycles
- governed self-improvement
- experience learning from verified outcomes
- multi-environment Fleet
- dynamic agent teams
- continuous verified world state
- long-horizon autonomy
- economic/resource intelligence
- research -> build -> deploy -> observe -> maintain -> improve

Self-improvement may tune skills, routing, retrieval, prompts, workflow templates and recovery.
Trust-critical policy/security/execution-truth kernels require stronger promotion gates.
