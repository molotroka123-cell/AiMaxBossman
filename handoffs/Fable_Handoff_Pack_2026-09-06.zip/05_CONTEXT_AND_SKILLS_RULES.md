# Context / Memory / Skill Safety

Do not dump:
- all memory
- all skills
- all org rules
- all logs
- all tools
into every model call.

Target architecture:

ALL INFORMATION
-> Context Compiler
-> only relevant context
-> Capability Router
-> only relevant tools
-> Model

Memory retrieval order:
retrieve candidates
-> scope filter
-> authority filter
-> relevance rank
-> freshness/provenance
-> token budget
-> context

Memory is data, not instruction authority.

Skill retrieval:
large skill registry
-> retrieval
-> top few candidates
-> confidence threshold
-> model

If no skill matches well, prefer fresh reasoning over forcing a wrong skill.

Useful metric:
`CONTEXT_VALUE = task_quality_gain / added_tokens`

A context source that consumes tokens without measurable task-quality gain should be demoted.
