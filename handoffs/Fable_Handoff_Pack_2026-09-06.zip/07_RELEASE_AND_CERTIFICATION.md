# Release Certification

A stage is not closed because code exists.

Required evidence classes:

## Exact-SHA CI
All required release workflows must be final and green on the SAME SHA.
Old green runs do not transfer.

## Golden Missions
Representative real tasks validating actual post-state:
- file edit
- browser interaction
- terminal
- memory
- approval/resume
- denied action
- coding fix
- MCP
- Video export
- Web Designer edit
- multi-app task
- restart recovery
- PRIVATE local-only task

## Crash Matrix
Inject failures:
- before dispatch
- after dispatch
- after external effect
- before journal
- after approval
- during verification

Invariant: no duplicate irreversible effect.

## Chaos / resource tests
- disk pressure
- RAM pressure
- CPU contention
- browser/MCP crash
- network/model timeout
- SQLite lock
- renderer hang

## Intelligence Preservation
RAW / SYSTEM / CONTEXT / FULL benchmark must remain above release thresholds.

## System Multiplier Benchmark
Epoch-level changes should improve multiple independent subsystems:
- success rate
- recovery rate
- tool accuracy
- context tokens
- latency
- cost
- human interventions
- duplicate effects
- intelligence retention

An epoch-level component should ideally improve at least 3–5 independent subsystems.
