# Cross-App Requirements

## Video Studio
Known historic risk areas:
- real FFmpeg CI must execute renderer tests, not skip them
- export artifact may exist but become unrecoverable after verification timeout
- output must remain recoverably downloadable after successful verification
- thumbnails need dedupe/cache/concurrency/resource accounting
- duration semantics must never produce NaN
- owner-visible structured diagnostics are required

## Web Designer
Known historic risk areas:
- whole-document parse/serialize can corrupt unrelated content
- prefer source-preserving/minimal edits
- preview must be isolated from privileged same-origin state
- PRIVATE/LOCAL_ONLY cannot fall back to cloud
- paid AI edits must use canonical Treasury
- canonical edit action needs reread/post-state verification

## Every future app
Must inherit Mission, Context, Policy, Recovery, Verification, Budget and Intelligence Preservation layers automatically.
An app should not invent its own weaker trust model.
