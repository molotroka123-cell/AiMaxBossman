# Fable Independent Workstream

Fable should work independently of Astra.

Recommended lane:
1. fetch latest remote HEAD
2. identify work Astra currently owns
3. choose non-overlapping high-value system-spine defects
4. reproduce before fixing
5. fix repository-local P0/P1 immediately
6. add narrow tests
7. hostile-retetest the fix
8. push small coherent commits
9. re-fetch remote before every push
10. reconcile; never force-push

Best independent targets:
- Execution Truth edge cases
- approval/resume/crash semantics
- stale/cross-run evidence attacks
- context pollution/instruction collision
- capability/tool overload regressions
- Intelligence Preservation measurements and harness
- Golden Missions / Crash Matrix / chaos
- System Multiplier benchmark
- release/exact-SHA certification

Do not duplicate Astra's active feature implementation unless a concrete defect is reproduced.
