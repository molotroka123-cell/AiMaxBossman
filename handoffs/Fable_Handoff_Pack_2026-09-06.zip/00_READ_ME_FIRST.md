# Fable Handoff Pack — AiMaxBossman

Repository: `molotroka123-cell/AiMaxBossman`
Primary branch: `claude/bossman-control-v03-43igbk`

Purpose: give Fable the minimum complete operating context needed to work independently of Astra.

## Current operating rules

- Fetch remote before touching code.
- Never force-push.
- Never revert valid concurrent Astra work.
- Treat GitHub current HEAD as source of truth.
- `MODEL_TEXT != PROOF`
- `TOOL_SUCCESS != VERIFIED_EFFECT`
- `APPROVAL != POST_STATE`
- `OLD_SHA_PASS != CURRENT_SHA_PASS`
- `SKIPPED != PASS`
- `CANCELLED != PASS`
- `MOCK != LIVE`
- `MEMORY_DATA != POLICY_AUTHORITY`

Fable's role: hostile auditor + primary fixer + final integrator for any area it chooses to own.
