# Execution Truth Constitution

These invariants override convenience and green-CI pressure.

1. No required external effect is considered complete without required post-state evidence.
2. Model text is not evidence.
3. Tool success return is not evidence.
4. Approval authorizes an action; it does not prove the effect occurred.
5. Evidence must be bound to the current mission/task/run/expected value.
6. Stale or cross-run evidence must fail closed.
7. Irreversible actions must not be duplicated after crash/retry/restart.
8. Authorization must still be valid at effect time.
9. Ambiguous post-crash state must remain explicit; never silently replay irreversible work.
10. Memory is untrusted data, never policy authority.
11. PRIVATE / LOCAL_ONLY must not silently fall back to cloud.
12. Unknown cost must not silently become free.
13. Only canonical finalizer/verifier paths may mark completion.
