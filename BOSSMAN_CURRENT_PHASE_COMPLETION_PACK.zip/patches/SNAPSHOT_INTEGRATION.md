# Snapshot derived-store integration

Use `bcc.v2.derived_stores` from this pack.

## Imports

```python
from ..v2.derived_stores import copy_into_snapshot, restore_from_snapshot, safety_copy_current
```

## Create snapshot

After DB copy, before manifest write:

```python
derived = await copy_into_snapshot(
    data_dir=Path(svc.settings.data_dir),
    snapshot_base=base,
    per_file_limit=MAX_ARTIFACT_BYTES,
    total_limit=MAX_ARTIFACT_BYTES,
)
```

Add `"derived_stores": derived` to manifest.

For copied entries include copied bytes in total artifact accounting.
Do not silently exceed the existing snapshot cap.

## Restore preview

Show:
- copied derived paths;
- omitted/rebuildable paths;
- expected checksums;
- paths that will be replaced.

## Restore safety copy

Before restore:

```python
derived_entries = manifest.get("derived_stores") or []
safety_derived = await safety_copy_current(
    data_dir=Path(svc.settings.data_dir),
    safety_dir=safety_dir,
    entries=derived_entries,
)
```

## Restore derived stores

After DB replacement is healthy:

```python
derived_restore = await restore_from_snapshot(
    data_dir=Path(svc.settings.data_dir),
    snapshot_base=base,
    entries=derived_entries,
)
```

Put `derived_restore` into the restore event + response.

If an index was omitted due to size, DB restore may still succeed. Report:

```text
restored=false
reason=not copied; rebuild required
```

Then reindex after restore.

Never broaden the allowlist to `data_dir/**`.
