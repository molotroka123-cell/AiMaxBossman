# Integration notes

New feature modules are intended for the existing auto-discovery mechanism in `bcc.features.load_features()`.

Therefore `tools_code.py` and `tools_facts.py` should not need a central API edit unless the repository architecture changed after the audited HEAD.

Use semantic merge notes:
- `MEMORY_INTEGRATION.md`
- `SNAPSHOT_INTEGRATION.md`

Do not replace proven core files wholesale when a small merge is safer.
