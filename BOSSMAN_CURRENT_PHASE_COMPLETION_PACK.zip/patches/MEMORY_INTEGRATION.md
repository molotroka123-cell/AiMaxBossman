# Memory V2.2 integration — semantic patch instructions

Do not apply blindly if current files moved after audited HEAD.

## 1. `tools_memory.py`

Add:

```python
from ..v2.memory.sqlite_index import SQLiteMemoryBackend
```

Recommended backend behavior:

```text
backend=memsearch   -> require real memsearch
backend=local-json  -> legacy LocalMemoryBackend
backend=sqlite      -> SQLiteMemoryBackend
backend=local       -> SQLiteMemoryBackend (compat alias)
backend=auto        -> SQLiteMemoryBackend
```

Why `auto -> sqlite` is safe conceptually:
- no new dependency;
- no daemon;
- vault Markdown remains source of truth;
- derived index can be rebuilt;
- old JSON may stay untouched for rollback.

Suggested construction:

```python
index_dir = Path(svc.settings.data_dir) / "memory"
fp = _fingerprint({"root": str(vault.root)})
backend = SQLiteMemoryBackend(
    index_path=index_dir / f"index-{fp}.sqlite3",
    vault_root=vault.root,
    excluded_dirs=set(vault.excluded_dirs),
)
```

## 2. `service.py`

Current `remember()` rescans the write root:

```python
await self.backend.index([self.vault.write_root], force=False)
```

Prefer:

```python
index_one = getattr(self.backend, "index_one", None)
if callable(index_one):
    await index_one(path, force=False)
else:
    await self.backend.index([self.vault.write_root], force=False)
```

This is the critical measured write-path fix.

## 3. `local_index.py`

Keep legacy JSON fallback, but make its splitting safe too.

Add:

```python
from .chunking_v22 import split_long_markdown
```

Replace `_split_long(content)` body with:

```python
return split_long_markdown(
    content,
    max_chars=MAX_CHUNK_CHARS,
    overlap=CHUNK_OVERLAP_CHARS,
    max_atomic_chars=MAX_SECTION_CHARS,
)
```

## 4. Existing data

Do not migrate truth from JSON to SQLite.
Truth is Markdown.

After backend switch, run normal `memory.index` to rebuild derived SQLite from vault.

Do not delete old JSON until:
- full index succeeds;
- search parity fixtures pass;
- expand works;
- at least one `memory.write` immediately becomes searchable.
