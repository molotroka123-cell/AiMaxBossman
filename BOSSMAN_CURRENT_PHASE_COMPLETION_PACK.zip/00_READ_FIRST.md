# BOSSMAN CURRENT PHASE COMPLETION PACK

Target repo: `molotroka123-cell/AiMaxBossman`

Audited branch: `claude/bossman-control-v03-43igbk`

Audited HEAD for this pack: `c13eea5bbbb31c3f09cc5b4a8faa952be20bef50`

This pack exists to FINISH the current V2.2 / research-memory-code-search wave before the next large implementation phase.

It deliberately does **not** implement the OpenClaw bridge yet.

## Current unfinished areas this pack addresses

1. `bcc/v2/code_index.py` exists, but canonical `code.*` tools are not fully wired.
2. the `facts` table exists, but temporal fact runtime/tools are incomplete.
3. the legacy JSON memory index still has expensive write/cold-start scaling.
4. markdown chunking still needs fence/table-safe splitting.
5. snapshot currently needs a complete story for derived memory/code indexes.
6. browser-use research still needs final measured closeout.
7. OpenClaw research still needs final measured closeout.
8. `_MASTER_PLAN.md` must be reconciled after those reports.
9. GitHub CI still needs an independent quality gate.
10. README/test counts need one final synchronization after the merge.

## Use order

1. `CLAUDE_SORT_MERGE_AND_FINISH.md`
2. supplied source candidates
3. `docs/CURRENT_PHASE_GATES.md`
4. `99_BEFORE_CLAUDE_TESTS.md`

The supplied code is a merge kit, not a blind overwrite. Claude must compare it to the then-current repo first.
