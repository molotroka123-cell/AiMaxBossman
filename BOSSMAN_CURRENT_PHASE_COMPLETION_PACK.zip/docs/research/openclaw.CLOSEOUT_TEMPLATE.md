# OpenClaw — FINAL research closeout BEFORE bridge implementation

STATUS: RESEARCH ONLY. DO NOT BUILD THE BRIDGE IN THIS PHASE.

## 1. Exact target

Record official repo, exact commit/release, LICENSE, supported OS/runtime, install footprint, default processes and default listeners.

## 2. Product boundary to verify

Candidate boundary:

BOSSMAN owns:
- Missions;
- Governor;
- permissions/approvals;
- Resource Brain;
- model/provider registry;
- durable Memory source of truth;
- Skill Library source of truth;
- audit/evidence.

OpenClaw may own:
- communication channels;
- conversational sessions;
- personal-assistant experience;
- device/node communication;
- channel-specific routing.

Research must prove whether this boundary is technically enforceable.

## 3. Gateway/API surface

Find and test where possible:
- health;
- agents list;
- sessions list/create/send/abort;
- channels list/status;
- nodes/devices list/status;
- event stream/websocket;
- auth;
- bind/Tailscale implications.

Do not propose GUI scraping if supported API exists.

## 4. Local LLM compatibility

Test where possible:
- OpenAI-compatible local server;
- Ollama native endpoint if supported;
- llama.cpp/LM Studio;
- tool calling;
- streaming;
- long session;
- several agents sharing one inference server.

Record tokens/s, malformed tool-call rate, retry behavior and OpenClaw RSS excluding model weights.

## 5. Shared model topology

Validate:

```text
BOSSMAN Resource Brain
      ↓
shared local inference server
 ↙        ↓        ↘
BOSSMAN OpenClaw OpenCode
```

Avoid duplicate model loads.

## 6. Skills

Inspect skill discovery/format/session loading and whether `.agents/skills` can be shared or synced without putting all skills into every prompt.
BOSSMAN should remain canonical/versioned source.

## 7. Memory

Inspect OpenClaw native memory: persistence, context injection, embeddings/providers and external calls.
Target is a narrow BOSSMAN memory adapter, not an incompatible second durable truth layer.

## 8. Permissions/security

Can BOSSMAN remain final authority over:
- send message;
- login;
- upload/download;
- terminal;
- filesystem;
- MCP;
- account changes;
- purchase/payment.

If OpenClaw tools can bypass BOSSMAN approval, specify containment before any bridge implementation.

Inspect channel credentials, logs, plugins, shell access, remote exposure, telemetry and duplicate-send risk.

## 9. Nodes/devices

Inspect registration/auth/capabilities/offline behavior and whether a second laptop can be a constrained worker without becoming another control plane.

## 10. Resource measurements

Measure OpenClaw WITHOUT model weights:
- idle RSS;
- active one session RSS;
- 5 sessions RSS;
- idle CPU;
- disk footprint;
- process count.

## 11. Failure injection

Test/inspect Gateway restart, channel disconnect, local model unavailable, malformed tool call, node offline and send timeout. Check idempotency/duplicate messages.

## 12. Integration choice

Choose one:
A. execution engine under BOSSMAN
B. channel gateway only
C. node/device layer only
D. do not integrate

If A/B/C specify only the minimal NEXT-phase V1 bridge contract:

```text
health
agents
sessions
send
abort
channels
nodes
events
```

Also specify auth, timeout, idempotency key and BOSSMAN mission/run IDs.

## 13. Final verdict

Use exactly one:
- ВНЕДРЯТЬ
- ВНЕДРЯТЬ ПОЗЖЕ
- ВЗЯТЬ ИДЕЮ
- НЕ ВНЕДРЯТЬ

Then write:

`OPENCLAW NEXT PHASE ALLOWED: YES/NO`
