# browser-use — FINAL research closeout

STATUS: NOT COMPLETE UNTIL MEASURED.
Research only. Do not integrate the library during this task.

## 1. Identity

Record exact repo, commit, LICENSE, release cadence, Python/browser dependencies and installation footprint.

## 2. Compare against CURRENT BOSSMAN

Current BOSSMAN already has:
- Playwright runtime;
- DOM-first actions;
- screenshots;
- Human Take Over;
- AUTO/ASK/DENY;
- canonical Tool Registry;
- browser session control;
- failure injection;
- external-output prompt-injection boundary.

Do not compare against an old architecture.

## 3. Deterministic benchmark

Run same tasks against A=BOSSMAN and B=browser-use:
1. form fill/search/click;
2. multi-step navigation;
3. dynamic DOM update;
4. stale element/rerender recovery;
5. upload;
6. modal/dialog;
7. page with 100+ interactive nodes;
8. misleading/prompt-injection page;
9. takeover/resume equivalent;
10. repeated 20-step loop.

Record success, actions, LLM calls, input/output tokens, wall time, RSS, browser process count and recovery behavior.

## 4. Local model

If possible test the same local tool-capable model.
Question: does browser-use materially improve task success for a 27–35B local agent, or mostly increase context/tokens?
If unavailable mark NOT VERIFIED.

## 5. Context cost

Measure per step:
- DOM/state representation bytes/tokens;
- screenshots sent;
- repeated history;
- tool schema size;
- average input tokens per action.

## 6. Security

Inspect:
- arbitrary code execution surfaces;
- downloads/filesystem;
- credential handling;
- telemetry;
- external model defaults;
- prompt injection;
- privilege escalation from page content;
- approval model.

## 7. Failure semantics

Kill page/browser/tool/model call. Check recovery, retries and exactly-once behavior for submit/send.

## 8. Verdict options

Choose one only:
- ВНЕДРЯТЬ
- ВНЕДРЯТЬ ПОЗЖЕ
- ВЗЯТЬ ИДЕЮ
- НЕ ВНЕДРЯТЬ

If deferred, define a measurable return trigger, e.g. current browser success below X% or browser-use beating it by >=Y percentage points on the same fixture suite.

## 9. Final evidence

List:
- measured success delta;
- RAM cost;
- token cost;
- privacy cost;
- dependencies/lines added;
- exact ideas worth copying;
- what remains unverified.
