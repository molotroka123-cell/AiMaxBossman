# Claude Code — Sort, merge and finish CURRENT BOSSMAN phase

Do not begin the next product phase until this wave is closed.

## Read first

1. `00_READ_FIRST.md`
2. current `docs/research/_MASTER_PLAN.md`
3. current HEAD diff from `c13eea5...` to your working HEAD
4. all source files in this pack
5. `docs/CURRENT_PHASE_GATES.md`
6. `99_BEFORE_CLAUDE_TESTS.md`

Do not recursively reread the whole repository unless a focused search requires it.

## Lane A — canonical code search

Finish:

```text
bcc/v2/code_index.py
   ↓
code.search
code.expand
code.index
code.status
```

Use `command-center/bcc/features/tools_code.py` as the implementation candidate.

Requirements:
- project/workspace roots only;
- no whole-computer indexing;
- compact results with source + symbol + real line range;
- output cap;
- background explicit indexing;
- search can bootstrap an empty index;
- canonical Tool Registry only.

## Lane B — temporal facts

Finish the already-created `facts` table with:

```text
FactStore
memory.fact.add
memory.fact.search
memory.fact.at_time
memory.fact.history
```

Use:
- `command-center/bcc/v2/memory/facts.py`
- `command-center/bcc/features/tools_facts.py`

Critical semantic rule:

**No automatic contradiction detection by LLM.**

`append` never invalidates anything.
`replace-current` deterministically closes current facts with the same `(subject,predicate)` only when the caller explicitly requests replacement.

Old world interval must close at `new.valid_at`, not at "now".
Knowledge interval closes when BOSSMAN learns the replacement.

## Lane C — memory scale / write path

Use:
- `command-center/bcc/v2/memory/sqlite_index.py`
- `command-center/bcc/v2/memory/chunking_v22.py`
- `patches/MEMORY_INTEGRATION.md`

Goal:
- Markdown/Obsidian stays source of truth;
- derived index uses stdlib SQLite, no service;
- one new memory note can update only that note;
- no full JSON rewrite on every `memory.write`;
- no giant JSON deserialize on cold start;
- legacy JSON backend remains a temporary rollback/fallback.

## Lane D — snapshots

Use:
- `command-center/bcc/v2/derived_stores.py`
- `patches/SNAPSHOT_INTEGRATION.md`

Snapshot derived stores must be allowlisted only:
- memory SQLite indexes;
- legacy memory JSON indexes;
- code-index JSON files.

Never recursively snapshot arbitrary `data_dir`.
Do not copy secrets, model weights, browser profiles or logs.

## Lane E — independent CI

Use:
- `.github/workflows/command-center-ci.yml`
- `tools/ci_secret_scan.py`

CI minimum:
- Python compile;
- full pytest;
- JS syntax;
- secret-pattern scan.

A YAML file existing is not CI PASS. Record the actual Actions run status.

## Lane F — close the remaining research

Use templates:
- `docs/research/browser-use.CLOSEOUT_TEMPLATE.md`
- `docs/research/openclaw.CLOSEOUT_TEMPLATE.md`

Research only. DO NOT implement the OpenClaw bridge in this phase.

The OpenClaw report must define the next-phase boundary:

```text
BOSSMAN = Mission/Governor/Permissions/Resources/Memory/Skills/Audit
OpenClaw = channels/sessions/personal-agent/device execution where safe
```

and prove whether this split is actually technically enforceable.

## Lane G — documentation cleanup

After research closes:
- fix `_MASTER_PLAN.md` count;
- separate original 8-project wave from later OpenClaw addition;
- list exactly what was implemented vs only researched;
- update README test count;
- remove stale status contradictions.

## Before full tests

STOP and fill `99_BEFORE_CLAUDE_TESTS.md`.

It must contain:
- current branch/commit;
- exact changed files;
- supplied code used/adapted/rejected;
- known risks;
- exact focused/full/browser/CI commands.

Only then start the final test run.

## Test order

Focused first:

```bash
cd command-center
pytest -q \
  tests/test_v22_code_tools.py \
  tests/test_v22_facts.py \
  tests/test_v22_sqlite_memory.py \
  tests/test_v22_chunking.py \
  tests/test_v22_snapshot_derived.py
```

Then full:

```bash
pytest -q
```

Then JS:

```bash
find ui -name '*.js' -print0 | xargs -0 -n1 node --check
```

Then relevant real Chromium/dashboard acceptance.
Then GitHub Actions.

## Honest status rules

- `code_index.py` exists but model never called `code.search` → PARTIAL.
- facts schema exists but temporal queries not proven → PARTIAL.
- SQLite backend exists but write path still rescans/re-writes whole corpus → PARTIAL.
- snapshot manifest mentions index but cannot verify/restore it → PARTIAL.
- OpenClaw report is README-only with no resource/security/API measurement → PARTIAL.
- workflow YAML exists but Actions never ran → PARTIAL.

## Final artifact

Create:

`docs/V2_2_CURRENT_PHASE_FINAL_REPORT.md`

It must clearly distinguish:
- LOCAL REAL PASS
- REAL EXTERNAL PASS
- MOCK/FAKE PASS
- NOT RUN

After this report the repo may enter the next implementation phase.
