"""Bi-temporal fact store for BOSSMAN.

Useful Graphiti idea without graph DB and without per-episode LLM calls.
World time: valid_at / invalid_at.
Knowledge time: created_at / expired_at.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import sqlalchemy as sa

from ...db import facts as facts_t, rows_dicts, utcnow


def _naive_utc(value: datetime | None = None) -> datetime:
    value = value or utcnow()
    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def parse_time(value: Any, *, default: datetime | None = None) -> datetime:
    if value in (None, ""):
        return _naive_utc(default)
    if isinstance(value, datetime):
        return _naive_utc(value)
    raw = str(value).strip()
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    try:
        return _naive_utc(datetime.fromisoformat(raw))
    except ValueError as exc:
        raise ValueError(f"неверное ISO-время: {value}") from exc


def public_fact(row: dict) -> dict:
    out = dict(row)
    for key in ("valid_at", "invalid_at", "created_at", "expired_at"):
        value = out.get(key)
        if isinstance(value, datetime):
            out[key] = value.isoformat()
    out["meta"] = dict(out.get("meta") or {})
    return out


@dataclass
class FactStore:
    svc: Any

    async def get(self, fact_id: int) -> dict | None:
        async with self.svc.db.session() as s:
            row = (await s.execute(sa.select(facts_t).where(facts_t.c.id == fact_id))).first()
        return dict(row._mapping) if row else None

    async def add(
        self, *, subject: str, predicate: str, statement: str,
        object_value: str = "", valid_at: datetime | None = None,
        mode: str = "append", source_kind: str = "human",
        source_run_id: int | None = None, source_note: str = "",
        confidence: float = 1.0, meta: dict | None = None,
    ) -> dict:
        """Insert a fact.

        append: no invalidation.
        replace-current: explicitly close current facts with same subject/predicate.
        Natural-language contradiction is NEVER guessed here.
        """
        subject = subject.strip()
        predicate = predicate.strip()
        statement = statement.strip()
        if not subject or not predicate or not statement:
            raise ValueError("subject, predicate и statement обязательны")
        if mode not in ("append", "replace-current"):
            raise ValueError("mode должен быть append или replace-current")

        world_time = _naive_utc(valid_at)
        knowledge_time = _naive_utc()
        confidence = max(0.0, min(float(confidence), 1.0))

        async with self.svc.db.session() as s:
            dup = (await s.execute(sa.select(facts_t).where(
                facts_t.c.subject == subject,
                facts_t.c.predicate == predicate,
                facts_t.c.statement == statement,
                facts_t.c.invalid_at.is_(None),
                facts_t.c.expired_at.is_(None),
            ).order_by(facts_t.c.id.desc()).limit(1))).first()
            if dup:
                return dict(dup._mapping)

            res = await s.execute(sa.insert(facts_t).values(
                subject=subject, predicate=predicate, object=object_value,
                statement=statement, valid_at=world_time, invalid_at=None,
                created_at=knowledge_time, expired_at=None, superseded_by=None,
                source_kind=(source_kind[:16] or "human"), source_run_id=source_run_id,
                source_note=source_note[:500], confidence=confidence, meta=dict(meta or {}),
            ))
            new_id = int(res.inserted_primary_key[0])

            if mode == "replace-current":
                # Allowed temporal closure operation. World invalidation uses the
                # NEW fact's world-valid time; knowledge expiration uses learning time.
                await s.execute(sa.update(facts_t).where(
                    facts_t.c.subject == subject,
                    facts_t.c.predicate == predicate,
                    facts_t.c.id != new_id,
                    facts_t.c.invalid_at.is_(None),
                    facts_t.c.expired_at.is_(None),
                ).values(
                    invalid_at=world_time,
                    expired_at=knowledge_time,
                    superseded_by=new_id,
                ))
            await s.commit()

        row = await self.get(new_id)
        assert row is not None
        return row

    async def search(self, *, query: str = "", subject: str = "",
                     predicate: str = "", current_only: bool = True,
                     limit: int = 50) -> list[dict]:
        stmt = sa.select(facts_t)
        if current_only:
            stmt = stmt.where(facts_t.c.invalid_at.is_(None), facts_t.c.expired_at.is_(None))
        if subject:
            stmt = stmt.where(sa.func.lower(facts_t.c.subject).like(f"%{subject.lower()}%"))
        if predicate:
            stmt = stmt.where(sa.func.lower(facts_t.c.predicate).like(f"%{predicate.lower()}%"))
        if query:
            q = f"%{query.lower()}%"
            stmt = stmt.where(sa.or_(
                sa.func.lower(facts_t.c.statement).like(q),
                sa.func.lower(facts_t.c.subject).like(q),
                sa.func.lower(facts_t.c.predicate).like(q),
                sa.func.lower(facts_t.c.object).like(q),
            ))
        stmt = stmt.order_by(facts_t.c.valid_at.desc(), facts_t.c.created_at.desc(),
                             facts_t.c.id.desc()).limit(max(1, min(int(limit), 200)))
        async with self.svc.db.session() as s:
            return rows_dicts((await s.execute(stmt)).fetchall())

    async def as_of(self, *, world_at: datetime, known_at: datetime | None = None,
                    subject: str = "", predicate: str = "", query: str = "",
                    limit: int = 50) -> list[dict]:
        world_at = _naive_utc(world_at)
        known_at = _naive_utc(known_at) if known_at else _naive_utc()
        stmt = sa.select(facts_t).where(
            facts_t.c.valid_at <= world_at,
            sa.or_(facts_t.c.invalid_at.is_(None), facts_t.c.invalid_at > world_at),
            facts_t.c.created_at <= known_at,
            sa.or_(facts_t.c.expired_at.is_(None), facts_t.c.expired_at > known_at),
        )
        if subject:
            stmt = stmt.where(sa.func.lower(facts_t.c.subject).like(f"%{subject.lower()}%"))
        if predicate:
            stmt = stmt.where(sa.func.lower(facts_t.c.predicate).like(f"%{predicate.lower()}%"))
        if query:
            q = f"%{query.lower()}%"
            stmt = stmt.where(sa.or_(
                sa.func.lower(facts_t.c.statement).like(q),
                sa.func.lower(facts_t.c.subject).like(q),
                sa.func.lower(facts_t.c.predicate).like(q),
                sa.func.lower(facts_t.c.object).like(q),
            ))
        stmt = stmt.order_by(facts_t.c.valid_at.desc(), facts_t.c.created_at.desc(),
                             facts_t.c.id.desc()).limit(max(1, min(int(limit), 200)))
        async with self.svc.db.session() as s:
            return rows_dicts((await s.execute(stmt)).fetchall())

    async def history(self, *, subject: str, predicate: str = "",
                      limit: int = 100) -> list[dict]:
        if not subject.strip():
            raise ValueError("history требует subject")
        stmt = sa.select(facts_t).where(
            sa.func.lower(facts_t.c.subject).like(f"%{subject.lower()}%")
        )
        if predicate:
            stmt = stmt.where(sa.func.lower(facts_t.c.predicate).like(f"%{predicate.lower()}%"))
        stmt = stmt.order_by(facts_t.c.valid_at.asc(), facts_t.c.created_at.asc(),
                             facts_t.c.id.asc()).limit(max(1, min(int(limit), 500)))
        async with self.svc.db.session() as s:
            return rows_dicts((await s.execute(stmt)).fetchall())
