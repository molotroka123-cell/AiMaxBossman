# BOSSMAN Memory + Obsidian + Local Retrieval Add-on

Purpose:

- use an Obsidian vault as human-readable long-term memory / knowledge source
- index markdown locally
- retrieve only relevant context instead of stuffing whole history into the LLM
- support progressive disclosure
- keep source citations
- keep memory portable across BOSSMAN, OpenCode and Claude Code
- use proven open-source retrieval where possible

Start with:

`docs/CLAUDE_MEMORY_HANDOFF.md`

Primary recommended backend:

**zilliztech/memsearch**

because it already provides:
- markdown source-of-truth
- incremental hashing
- local ONNX BGE-M3 embedding
- hybrid dense + BM25 retrieval
- reciprocal-rank fusion
- progressive disclosure search → expand → transcript
- plugins for Claude/OpenCode/Codex

BOSSMAN should wrap it instead of reimplementing a worse RAG engine.

The code in this add-on adds:
- Obsidian vault policy/writeback
- MemSearch bridge
- local reranker
- context assembly
- memory capture service
- safe repository intake manifest
