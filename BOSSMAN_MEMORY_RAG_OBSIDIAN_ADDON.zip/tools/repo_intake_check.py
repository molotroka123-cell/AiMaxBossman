"""Static pre-install intake check for a cloned third-party repository.

This is not malware detection. It catches common high-risk install patterns so
BOSSMAN does not blindly execute a popular repo.

Usage:
    python tools/repo_intake_check.py /path/to/cloned/repo
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

PATTERNS = [
    ("download-and-execute", re.compile(r"(?i)(curl|wget).{0,200}\|\s*(bash|sh|powershell)")),
    ("powershell-download-exec", re.compile(r"(?i)(Invoke-WebRequest|iwr).{0,200}(iex|Invoke-Expression)")),
    ("credential-path", re.compile(r"(?i)(\.ssh|wallet|keychain|credential|Login Data)")),
    ("sudo-install", re.compile(r"(?i)\bsudo\b")),
]
FILES = {
    "package.json", "pyproject.toml", "setup.py", "setup.cfg",
    "install.sh", "install.ps1", "Makefile", "Dockerfile",
}

def main(root: Path) -> int:
    root = root.resolve()
    hits = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if p.name not in FILES and p.suffix not in {".sh", ".ps1"}:
            continue
        if p.stat().st_size > 2_000_000:
            continue
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        for name, pattern in PATTERNS:
            for m in pattern.finditer(text):
                hits.append({
                    "risk": name,
                    "file": str(p.relative_to(root)),
                    "snippet": text[max(0,m.start()-100):m.end()+100].replace("\n"," ")[:500],
                })

    package = root/"package.json"
    if package.exists():
        try:
            data = json.loads(package.read_text())
            scripts = data.get("scripts") or {}
            for k in ("preinstall","install","postinstall","prepare"):
                if k in scripts:
                    hits.append({"risk": "npm-lifecycle-script", "file": "package.json",
                                 "snippet": f"{k}: {scripts[k]}"})
        except Exception:
            pass

    print(json.dumps({"root": str(root), "findings": hits}, indent=2, ensure_ascii=False))
    return 2 if hits else 0

if __name__ == "__main__":
    raise SystemExit(main(Path(sys.argv[1])))
