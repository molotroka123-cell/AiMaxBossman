# Claude Code Handoff — Memory / Obsidian / Local Context

## Locked architecture

Do not build a vector database from scratch.

Use:

```text
Obsidian vault / BOSSMAN markdown memory
                ↓
             memsearch
                ↓
local BGE-M3 embeddings
                ↓
hybrid dense + BM25 + RRF
                ↓
optional local cross-encoder reranker
                ↓
progressive disclosure
                ↓
small, high-quality context pack
                ↓
local/cloud LLM
```

Markdown is the source of truth.

The vector index is disposable/rebuildable.

## Why

The main model should NOT receive:
- the entire Obsidian vault
- complete old conversations
- the whole repository
- every search hit

The retrieval agent should:
1. search broadly
2. rerank
3. expand only top results
4. deduplicate
5. fit a context budget
6. return citations + compact evidence

This increases effective usable context without wasting context-window tokens.

## Obsidian

User selects an explicit vault path in BOSSMAN Settings.

Never auto-discover every vault on the machine.

Index selectable folders.

Default excludes:
- `.obsidian/**`
- `.trash/**`
- `.git/**`
- attachments/binaries
- user configured private paths

AI writeback is restricted to a dedicated folder by default:

`BOSSMAN Memory/`

Do not let agents rewrite arbitrary notes automatically.

## Recommended local config

For the user's Strix Halo machine:

Embedding:
- memsearch ONNX BGE-M3 int8

Memory search:
- local Milvus via WSL2 or Milvus Docker

Optional reranker:
- BAAI/bge-reranker-v2-m3 via sentence-transformers / compatible local runtime

Because the user works across Russian/Czech/English, prefer multilingual embeddings/reranking.

## Windows note

Milvus Lite does not provide native Windows binaries.

Use one of:
1. WSL2 for memsearch + local Milvus Lite
2. Milvus standalone in Docker
3. future BOSSMAN LanceDB backend if native-Windows embedded storage is desired

Do not silently fall back to cloud.

## Agent tools to expose

```text
memory.search
memory.expand
memory.write
memory.index
memory.stats
memory.reindex
```

Permissions:

AUTO:
- search
- expand
- stats

ASK:
- write
- full reindex if expensive

DENY:
- delete arbitrary Obsidian notes
- modify notes outside configured writeback roots

## Skill Forge integration

Repeated successful workflows may become Skills.

Memory can store:
- decisions
- lessons
- project conventions
- useful user preferences
- completed-session summaries

Do NOT turn raw private conversation dumps into Skills.

## Night missions

At the end of every significant autonomous run:

1. write a concise project memory summary
2. index it
3. persist `NIGHT_HANDOFF.md`
4. future agents retrieve relevant summaries instead of re-reading entire history

## Acceptance

1. User configures vault path.
2. BOSSMAN indexes selected markdown folders.
3. Search returns relevant Obsidian chunks with source path/heading.
4. Search is local.
5. Local embedding works with no cloud key.
6. Optional rerank improves ordering.
7. Context assembler respects budget.
8. BOSSMAN can write a new memory note only into allowed memory folder.
9. New note becomes searchable.
10. OpenCode/Claude can access same memory through Skill/MCP/CLI bridge.
