# Recommended external repositories for BOSSMAN

No public repository can be guaranteed "virus-free" forever.

For BOSSMAN:
- pin a commit/tag
- inspect install scripts
- do not run `curl | bash`
- use dependency scanning
- install in isolated environment
- keep GitHub provenance in the dashboard

## Tier A — strongly recommended

### zilliztech/memsearch

Role: primary local markdown memory/search backend.

Why:
- Markdown source of truth
- local ONNX BGE-M3 embedding
- hybrid dense + BM25 + RRF
- progressive disclosure
- dedup/content hashing
- file watcher
- Claude/OpenCode/Codex support
- MIT

BOSSMAN integration:
- wrap CLI/Python API
- point it to Obsidian and BOSSMAN Memory
- expose search/expand/index/stats as tools

### mem0ai/mem0

Role: higher-level adaptive/user-agent memory layer.

Use later for:
- extracting durable user/session/agent memories
- automatic memory CRUD/personalization

Do not replace human-readable Obsidian memory with opaque memory only.

License: Apache-2.0.

### getzep/graphiti

Role: temporal relationship memory / knowledge graph.

Use when BOSSMAN needs to understand:
- fact changed over time
- entity relationships
- "what was true before"
- provenance

Useful for business/project state rather than every chat message.

Apache-2.0.

### lancedb/lancedb

Role: embedded local retrieval backend option.

Why:
- local OSS
- vector + full-text + SQL
- no separate vector server required
- good fallback for a future native-Windows BOSSMAN memory engine

Apache-2.0.

### qdrant/qdrant

Role: heavier production vector/hybrid retrieval service.

Use if:
- many projects/agents
- large indexes
- stronger filtering/service isolation is needed

For a single machine, memsearch/Milvus or LanceDB may be simpler.

Apache-2.0.

## Tier B — useful modules / inspiration

### zilliztech/claude-context

Role: semantic code search MCP.

Why:
- hybrid code search
- injects relevant code instead of entire repo
- saves context tokens
- supports Ollama embeddings and Milvus/Zilliz

BOSSMAN can either:
- use its MCP server
- or copy the retrieval pattern into a canonical `code.search` tool

### browser-use/browser-use

Role: mature browser-agent stack.

Very popular and useful as:
- optional browser execution backend
- fallback/reference to our Playwright Browser Agent
- skill source

Do not replace BOSSMAN permissions/governor with Browser Use's own policy layer.

### infiniflow/ragflow

Role: advanced RAG/context engine reference or optional service.

Excellent for:
- complex PDFs/docs
- citations
- multi-stage retrieval
- fused reranking

But it is a much larger stack and overlaps with BOSSMAN.
Do not integrate by default tonight.

### danielmiessler/Fabric

Role: large library of reusable AI Patterns.

Use as:
- Skill Forge inspiration
- curated import source

Do not import every pattern into every agent context.

## Practical stack recommendation

Start:

```text
Obsidian Markdown
      ↓
memsearch
      ↓
local BGE-M3
      ↓
hybrid dense + BM25 + RRF
      ↓
optional BGE reranker
      ↓
BOSSMAN memory.search
```

Add later:

```text
Graphiti → temporal facts/relationships
Mem0     → adaptive extracted memories
LanceDB  → embedded native storage option
```

For code:

```text
Git repository
      ↓
claude-context style semantic code search
      ↓
top relevant symbols/chunks
      ↓
OpenCode/Coder
```
