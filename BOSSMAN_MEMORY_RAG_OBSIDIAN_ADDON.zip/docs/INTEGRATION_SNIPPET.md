# Minimal integration into BOSSMAN services

Pseudo-integration:

```python
from pathlib import Path
from .v2.memory import (
    ObsidianVault,
    MemSearchBridge,
    ObsidianMemoryService,
    LocalCrossEncoderReranker,
)

vault = ObsidianVault(
    Path(config.obsidian_vault),
    index_folders=config.memory_index_folders,
    write_folder="BOSSMAN Memory",
)

backend = MemSearchBridge(
    provider="onnx",
    collection="bossman_obsidian",
    milvus_uri=config.milvus_uri,
)

memory = ObsidianMemoryService(
    vault=vault,
    backend=backend,
    reranker=LocalCrossEncoderReranker()
        if config.memory_reranker_enabled else None,
)
```

Expose tools:

```text
memory.search(query, max_context_tokens)
memory.expand(chunk_hash)
memory.write(title, content, kind, project, tags)
memory.index(force=false)
memory.stats()
```

Agent prompt injection rule:

Do not automatically inject memory into every model call.

Call memory retrieval when:
- user references prior work
- task is attached to an existing project
- manager plans a long mission
- agent sees uncertainty about a past decision
- reviewer needs project conventions

Maximum memory context should be budgeted separately from active task context.
