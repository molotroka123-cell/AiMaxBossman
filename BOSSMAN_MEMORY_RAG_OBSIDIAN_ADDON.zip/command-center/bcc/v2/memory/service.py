from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .context_pack import ContextPack, build_context_pack
from .memsearch_bridge import MemSearchBridge, MemoryHit
from .obsidian import ObsidianVault
from .reranker import LocalCrossEncoderReranker, RerankerUnavailable

@dataclass
class ObsidianMemoryService:
    vault: ObsidianVault
    backend: MemSearchBridge
    reranker: LocalCrossEncoderReranker | None = None

    async def index(self, *, force: bool = False) -> str:
        return await self.backend.index(self.vault.markdown_roots(), force=force)

    async def search(
        self,
        query: str,
        *,
        candidate_k: int = 16,
        rerank_k: int = 8,
        context_tokens: int = 7000,
    ) -> ContextPack:
        hits = await self.backend.search(query, top_k=candidate_k)
        if self.reranker is not None and hits:
            try:
                hits = self.reranker.rerank(query, hits, top_k=rerank_k)
            except RerankerUnavailable:
                hits = hits[:rerank_k]
        else:
            hits = hits[:rerank_k]

        # Progressive disclosure:
        # expand only the highest-ranked chunks that have an anchor.
        expanded: list[MemoryHit] = []
        for hit in hits[:4]:
            if not hit.chunk_hash:
                expanded.append(hit)
                continue
            try:
                detail = await self.backend.expand(hit.chunk_hash)
                content = str(
                    detail.get("content")
                    or detail.get("section")
                    or detail.get("text")
                    or hit.content
                )
                expanded.append(MemoryHit(
                    content=content,
                    source=str(detail.get("source") or hit.source),
                    heading=str(detail.get("heading") or hit.heading),
                    score=hit.score,
                    chunk_hash=hit.chunk_hash,
                    metadata=detail,
                ))
            except Exception:
                expanded.append(hit)

        expanded.extend(hits[4:])
        return build_context_pack(query, expanded, max_tokens=context_tokens)

    async def remember(
        self,
        *,
        title: str,
        content: str,
        kind: str = "note",
        project: str = "",
        tags: list[str] | None = None,
        source_run_id: str | int | None = None,
    ) -> Path:
        path = self.vault.write_memory(
            title=title,
            content=content,
            kind=kind,  # type: ignore[arg-type]
            project=project,
            tags=tags,
            source_run_id=source_run_id,
        )
        # Incremental index is preferred. If the installed memsearch CLI lacks
        # a stable single-file API in this environment, indexing the write root
        # still hashes and skips unchanged content.
        await self.backend.index([self.vault.write_root], force=False)
        return path
