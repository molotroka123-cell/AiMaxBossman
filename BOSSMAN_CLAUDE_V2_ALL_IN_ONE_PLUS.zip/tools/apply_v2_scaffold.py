"""Safely copy the prepared V2 scaffold into an AiMaxBossman checkout.

Dry-run by default.
Examples:

    python tools/apply_v2_scaffold.py --repo /path/to/AiMaxBossman
    python tools/apply_v2_scaffold.py --repo /path/to/AiMaxBossman --apply

Rules:
- never overwrites an existing destination file
- never changes git branches
- never commits/pushes
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

PACK_ROOT = Path(__file__).resolve().parents[1]

COPY_ROOTS = [
    (PACK_ROOT / ".agents" / "skills", Path(".agents/skills")),
    (PACK_ROOT / "command-center" / "bcc" / "v2", Path("command-center/bcc/v2")),
    (PACK_ROOT / "command-center" / "tests" / "v2", Path("command-center/tests/v2")),
    (PACK_ROOT / "docs", Path("docs/v2-prepared")),
]

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, type=Path)
    ap.add_argument("--apply", action="store_true")
    args = ap.parse_args()
    repo = args.repo.resolve()
    if not (repo / ".git").exists():
        raise SystemExit(f"not a git checkout: {repo}")

    plan: list[tuple[Path, Path]] = []
    conflicts: list[Path] = []
    for src_root, rel_dest in COPY_ROOTS:
        if not src_root.exists():
            continue
        for src in src_root.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(src_root)
            dest = repo / rel_dest / rel
            if dest.exists():
                conflicts.append(dest)
            else:
                plan.append((src, dest))

    print(f"new files: {len(plan)}")
    print(f"existing/conflicts: {len(conflicts)}")
    for p in conflicts[:30]:
        print("SKIP existing:", p.relative_to(repo))

    if not args.apply:
        print("\nDRY RUN. Re-run with --apply to copy only NEW files.")
        return 0

    for src, dest in plan:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        print("COPY", dest.relative_to(repo))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
