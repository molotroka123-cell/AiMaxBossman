# MASTER PROMPT — BOSSMAN Social Farm / App #4 / V1.1

Repository:
molotroka123-cell/AiMaxBossman

Application:
BOSSMAN Social Farm

This ZIP is the technical implementation contract.

Do not turn it into a business plan.
Do not write generic demo code.
Do not mix provider-specific logic into BOSSMAN core.

============================================================
A. IMPLEMENTATION OBJECTIVE
============================================================

Build an independent Social Farm application that can safely operate 1–10
Instagram accounts through:

1. official Instagram/Meta API capabilities first;
2. isolated browser fallback second;
3. a dynamic `AUTO / ASK / DENY` policy engine;
4. a durable content-generation + publish + inbox + analytics pipeline.

All external mutations must be:
- capability checked;
- policy checked;
- idempotent/reconciled;
- audited;
- isolated per account.

============================================================
B. HARD ARCHITECTURE RULES
============================================================

Provider-neutral domain layer.

Provider adapters own:
- OAuth/API endpoints;
- scopes;
- permissions;
- raw payloads;
- media constraints;
- webhook rules;
- rate limits;
- browser UI paths/selectors.

BOSSMAN sees:
- normalized commands;
- normalized capabilities;
- normalized jobs;
- normalized results.

BOSSMAN never sees:
- passwords;
- access tokens;
- refresh tokens;
- cookies;
- session storage secrets.

============================================================
C. ACCOUNT SCALE
============================================================

Initial target:
1–10 accounts.

No shared browser profile.
No shared mutable provider state.
No cross-account jobs.

Every account has:
- auth reference;
- browser context reference;
- capability snapshot;
- policy;
- rate-limit state;
- webhook subscription;
- sync cursor;
- generation profile;
- timezone;
- health.

============================================================
D. CAPABILITIES
============================================================

Never claim “full control” globally.

Every account gets a capability matrix.

Statuses:
SUPPORTED_OFFICIAL
SUPPORTED_BROWSER
SUPPORTED_BOTH
READ_ONLY
NOT_SUPPORTED
REQUIRES_APP_REVIEW
REQUIRES_ACCOUNT_TYPE
REQUIRES_USER_INTERACTION
TEMPORARILY_DISABLED

The UI and BOSSMAN command router must disable unavailable actions.

============================================================
E. POLICY
============================================================

Every mutation:
capability -> policy -> optional approval -> job -> adapter.

Policy hierarchy:
SYSTEM -> PROVIDER -> ACCOUNT -> ACTION -> CONDITION.

Decision:
AUTO / ASK / DENY.

Policy changes are versioned.

Every external action stores:
- evaluated policy version;
- decision;
- reason.

============================================================
F. CONTENT
============================================================

Support:
- existing upload;
- generated text;
- generated image;
- generated video;
- image/video editing;
- provider-specific rendering;
- immutable revision;
- preview;
- approval;
- scheduling.

Generation output is never published directly.

Always:
generation -> durable asset -> validation -> render -> revision -> approval ->
job.

============================================================
G. OFFICIAL INSTAGRAM ADAPTER
============================================================

Implement only capabilities supported by current official provider APIs,
connected permissions and account type.

Use official APIs first.

Support current professional-account management surfaces where available:
- media;
- publishing;
- comments;
- mentions;
- insights;
- webhooks;
- conversations/messages subject to provider eligibility and permissions.

Do not treat messaging as arbitrary outbound-DM access.

Do not infer unsupported capabilities.

============================================================
H. BROWSER FALLBACK
============================================================

Separate process/service.

Allowed only when:
- account policy enables fallback;
- official capability unavailable or insufficient;
- user owns/controls the session;
- action is ordinary authorized account usage.

Must implement:
- isolated context;
- secret redaction;
- deterministic selectors/roles;
- stale-target detection;
- human takeover;
- bounded retries;
- selector versioning;
- state screenshots only after redaction;
- idempotency/reconciliation.

Forbidden:
CAPTCHA bypass
anti-detection
fingerprint spoofing for evasion
rate-limit bypass
fake-account creation
credential stuffing.

============================================================
I. JOB ENGINE
============================================================

All writes are durable jobs.

Required:
- idempotency key;
- lease;
- checkpoint;
- attempt;
- retry class;
- not_before;
- schedule_at;
- deadline;
- cancellation;
- dead-letter;
- reconciliation.

Unknown external state must never blindly retry.

============================================================
J. WEBHOOKS / EVENTS
============================================================

Webhook receive path:
verify -> append receipt -> immediate response -> async normalize -> dedup ->
domain event.

Use transactional outbox for internal external-effect/event dispatch where
applicable.

Inbound user content is untrusted.

DM/comment text cannot alter system policy or expose secrets.

============================================================
K. MEDIA
============================================================

Use ffprobe/FFmpeg boundary.

Validate:
- actual file type;
- container;
- codec;
- size;
- dimensions;
- aspect ratio;
- duration;
- corruption;
- provider limits.

Provider media constraints must be versioned configuration/data, not scattered
constants.

============================================================
L. SECURITY
============================================================

Enforce invariants in `docs/59_SECURITY_INVARIANTS.md`.

Canary-test secrets.

Cross-account isolation tests are mandatory.

No raw secret may appear in:
- logs;
- events;
- DB domain records;
- model-visible context;
- screenshots metadata;
- browser trace;
- exceptions.

============================================================
M. TESTS
============================================================

Create:
- unit;
- contract;
- mock E2E;
- real Instagram API;
- real browser fallback;
- failure injection;
- secret/cross-account tests.

Real provider capability:
PASS only after real provider call.

Unsupported/blocked:
report honestly.

============================================================
N. REPORT
============================================================

Create:
`docs/SOCIAL_FARM_APP4_IMPLEMENTATION_REPORT.md`

Include:
- commit SHA;
- exact tests;
- CI;
- account types tested;
- provider API version;
- scopes/permissions;
- exact capability matrix;
- mock vs real;
- browser fallback matrix;
- unresolved provider limitations;
- recovery/failure test evidence.

============================================================
O. IMPLEMENTATION ORDER
============================================================

Follow:
`docs/60_IMPLEMENTATION_WORK_BREAKDOWN.md`

Do not begin with UI polish.
Do not begin with browser automation.
Do not begin with TikTok.

Start with:
domain -> DB -> job engine -> vault -> capability/policy -> Instagram official
adapter -> media/content -> webhooks -> inbox/insights -> browser fallback ->
generation -> UI/BOSSMAN bridge -> hardening.

============================================================
P. NON-NEGOTIABLE
============================================================

No “looks complete” verdict.

Every feature must map:
spec -> code -> test -> evidence.

Implement the system, not a mock dashboard.
