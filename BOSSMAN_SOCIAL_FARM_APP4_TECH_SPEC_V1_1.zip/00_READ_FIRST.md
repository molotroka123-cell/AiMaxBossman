# BOSSMAN Social Farm — App #4 — Technical Specification V1.1

This ZIP is a **technical implementation specification only**.

It intentionally excludes:
- business purpose;
- monetization;
- growth strategy;
- marketing goals;
- commercial KPIs.

## Frozen requirements

Primary platform:
**Instagram**

Initial scale:
**1–10 connected accounts**

Integration order:
1. official Meta/Instagram APIs;
2. isolated browser fallback where explicitly enabled and technically/legal-policy allowed.

Content input:
- manual upload;
- text generation;
- image generation;
- video generation;
- edit/transform existing media;
- future local/BOSSMAN/cloud model providers.

Control model:
- dynamic;
- account-specific;
- action-specific;
- runtime editable;
- `AUTO / ASK / DENY`.

Future providers:
- TikTok
- YouTube
- Facebook Pages
- Threads
- X
- LinkedIn

They are **adapter-ready / coming soon**, not fake implementations.

## V1.1 additions

This revision adds deeper implementation detail for:
- OAuth/token lifecycle;
- capability refresh logic;
- SQL/domain data model;
- outbox/inbox event processing;
- webhook verification;
- job leasing/checkpointing;
- provider error translation;
- browser selector registry;
- browser state machine;
- safe secret handling;
- generation-provider contracts;
- content versioning and approval invalidation;
- media probe/transcode rules;
- multi-account concurrency;
- storage layout;
- audit immutability;
- exact implementation work breakdown;
- CI/test matrix;
- migration/versioning strategy;
- operational runbooks;
- manual recovery procedures;
- hard failure/unknown-state rules.

## Core architecture rule

BOSSMAN core must not know Instagram-specific endpoints, scopes, selectors or
payloads.

All provider-specific implementation remains behind adapters.

## Safety boundary

Do not implement:
- CAPTCHA bypass;
- anti-bot stealth/fingerprinting evasion;
- rate-limit circumvention;
- credential theft;
- fake-account registration;
- unsolicited mass messaging/commenting engines.

Browser fallback is a user-authorized compatibility adapter, not an evasion
framework.

## Read order

1. `MASTER_PROMPT_FOR_CLAUDE.md`
2. `docs/01_SYSTEM_ARCHITECTURE.md`
3. `docs/02_CAPABILITY_MODEL.md`
4. `docs/05_POLICY_ENGINE.md`
5. `docs/51_DATABASE_MODEL.md`
6. `docs/52_OAUTH_TOKEN_LIFECYCLE.md`
7. `docs/53_EVENT_OUTBOX_INBOX.md`
8. `docs/54_JOB_LEASES_CHECKPOINTS.md`
9. `docs/55_BROWSER_STATE_MACHINE.md`
10. `docs/56_PROVIDER_ERROR_TRANSLATION.md`
11. `docs/57_CONTENT_PIPELINE_DETAILED.md`
12. `docs/58_MEDIA_RULE_ENGINE.md`
13. `docs/59_SECURITY_INVARIANTS.md`
14. `docs/60_IMPLEMENTATION_WORK_BREAKDOWN.md`
15. `docs/40_ACCEPTANCE_GATES.md`
16. `docs/61_DEFINITION_OF_READY.md`

## Definition of the target

The target is not one boolean “full control”.

The target is:
**maximum safe, auditable control exposed by the connected account’s real
capabilities, provider rules and configured policy.**
