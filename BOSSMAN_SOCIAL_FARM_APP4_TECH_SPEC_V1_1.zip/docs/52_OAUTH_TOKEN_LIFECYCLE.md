# OAuth and token lifecycle

## Connect

1. create pending SocialAccount;
2. generate CSRF/state nonce;
3. redirect to provider authorization;
4. validate callback state;
5. exchange authorization code in backend;
6. store token only in secret vault;
7. resolve account identity;
8. store auth_ref;
9. fetch capabilities;
10. subscribe webhooks where supported;
11. mark CONNECTED.

## Refresh

Token lifecycle must not assume all providers use the same refresh model.

Adapter returns:
- token expiry;
- refreshable yes/no;
- refresh-after;
- reauth-required.

Scheduler creates AUTH_REFRESH before expiry.

## Scope drift

After reconnect or provider change:
- refetch granted permissions;
- recompute capabilities;
- demote unsupported actions immediately.

## Token invalidation

On provider auth error:
- classify;
- attempt allowed refresh only if safe;
- otherwise account -> AUTH_EXPIRED;
- stop future mutations;
- allow read-only local history.

## Reconnect

Reconnection must not create duplicate account if provider identity matches.

## Security

OAuth state nonce:
single use.

Callback:
HTTPS in production.

Never put access token in redirect URL logs or frontend storage if backend
session can hold reference.

Browser login credentials are not a substitute for API OAuth.
