# Proposed repository layout

apps/
  social-farm/
    README.md
    pyproject.toml / package manifests
    app.manifest.yaml
    src/
      social_farm/
        api/
        domain/
        accounts/
        capabilities/
        policies/
        approvals/
        content/
        media/
        generation/
        jobs/
        inbox/
        insights/
        audit/
        providers/
          base/
          instagram/
            official/
            browser/
          tiktok/
          youtube/
          facebook/
          x/
          threads/
          linkedin/
        browser/
        bossman_bridge/
        security/
        observability/
    web/
    tests/
      unit/
      contract/
      e2e/
      real/
    docs/

Do not unpack this spec into BOSSMAN core package.
