# Deployment

Recommended:
Docker Compose initially.

Services:
social-api
social-worker
social-browser-worker
social-media-worker
db
redis/queue
object-storage-compatible backend optional
reverse proxy.

Local model bridge:
separate endpoint.

Production:
no public DB/Redis/browser debugging.

Webhook endpoint:
public HTTPS only route needed for official provider integration.

Backups:
DB + content metadata + policies + media inventory.
Secrets backup separately encrypted.
