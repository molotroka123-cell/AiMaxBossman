# Provider fixture strategy

Maintain versioned sanitized fixtures for:
- account/profile response;
- media list;
- publish container creation;
- publish status;
- comment event;
- messaging event;
- insight response;
- permission error;
- rate limit;
- auth expiry;
- provider rejection.

Fixtures store:
- provider version;
- observed date;
- source test;
- redaction status.

Contract parsers must tolerate unknown extra fields.

Breaking provider payload changes fail contract tests before deployment.
