# Browser security requirements

Must inherit BOSSMAN browser hardening:
- password-field redaction;
- secret-reference login;
- stable target identity;
- stale element error;
- human takeover.

Additional:
- account-specific context;
- downloads sandbox;
- uploaded file allowlist;
- no browser extension installation;
- no clipboard secret leakage;
- no cross-account tab;
- no persistent debug port exposed publicly.

Browser trace must redact:
- passwords;
- access tokens;
- cookies;
- session/local-storage secret values;
- recovery codes.
