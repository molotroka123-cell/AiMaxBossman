# Detailed content pipeline

## 1. Project

Create ContentProject.

## 2. Inputs

Attach:
- uploaded assets;
- text;
- references;
- generation instructions.

## 3. Generate

Text/image/video jobs create immutable source assets or text variants.

## 4. Select

User/agent selects:
- caption;
- media;
- target accounts;
- content type.

## 5. Render plan

For each target account/provider:
resolve capability + media profile.

Create target-specific render plan.

## 6. Transform

FFmpeg/image transform creates derived assets.

## 7. Validate

Run provider media validation.

## 8. Revision

Create immutable ContentRevision containing:
- final caption;
- asset ids;
- target list;
- schedule;
- hash.

## 9. Approval

Approval tied to revision hash.

Any edit:
new revision -> previous approval invalid.

## 10. Schedule

Create one child SocialJob per account.

## 11. Publish

Policy evaluated again at execution time.

Reason:
policy/capability may have changed since scheduling.

## 12. Reconcile

Persist provider object id.

## 13. Analytics

Link PublishedMedia to revision.

## 14. Reuse

Republishing same project requires new target revision/job, not mutating
historical record.
