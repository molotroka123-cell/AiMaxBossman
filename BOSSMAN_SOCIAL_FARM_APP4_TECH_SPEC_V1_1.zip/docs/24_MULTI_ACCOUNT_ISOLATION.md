# Multi-account isolation

Target 1–10 accounts.

Isolation:
- secrets;
- browser context;
- account policy;
- provider cursor;
- rate-limit state;
- content targeting;
- audit.

Jobs may target multiple accounts only by creating one child job per account.

A batch is orchestration, not one shared provider mutation.

One failed child does not roll back already published content on another
account.

UI must display partial batch outcomes clearly.
