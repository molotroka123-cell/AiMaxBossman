# Insights

Normalized metric dimensions:
- provider;
- account;
- media;
- period;
- metric;
- value;
- source;
- collected_at;
- provider freshness.

Raw provider metrics can change/deprecate.

Do not hard-code one permanent metric vocabulary.

Store metric registry with provider mapping/version.

Views:
- account snapshot;
- media snapshot;
- publishing history;
- operational adapter health.

Technical system metrics remain separate from social analytics.
