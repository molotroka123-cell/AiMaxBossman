# Manual recovery runbook

## Token expired

1. freeze mutation jobs for account;
2. mark AUTH_EXPIRED;
3. reconnect/refresh through official flow;
4. recompute capabilities;
5. resume only safe queued jobs.

## Unknown publish state

1. do not retry;
2. query provider container/media status;
3. inspect external id;
4. reconcile;
5. if confirmed absent, allow explicit retry.

## Browser broken UI

1. disable affected browser capability;
2. keep official adapter active;
3. require selector-pack update;
4. test on non-destructive action;
5. re-enable.

## Wrong account identity in browser

1. stop context;
2. revoke session ref;
3. human reauth;
4. verify provider account id;
5. audit incident.

## Duplicate webhook

Dedup and ignore domain duplicate.

## Object-store loss

Jobs referencing missing asset:
FAIL_MEDIA_MISSING.
Do not regenerate silently if revision was approved.

## Account disconnect

Stop new jobs.
Resolve/reconcile active external effects.
Revoke tokens/session after confirmed disconnect.
