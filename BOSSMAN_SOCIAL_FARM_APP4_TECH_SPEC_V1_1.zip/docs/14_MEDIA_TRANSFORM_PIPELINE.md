# Media transform pipeline

Use ffprobe/FFmpeg abstraction.

Stages:
probe
→ validate integrity
→ normalize rotation/color metadata
→ provider render profile
→ resize/crop/pad
→ transcode
→ audio normalize if configured
→ subtitle burn/embed if requested
→ thumbnail
→ probe final
→ checksum.

Never silently stretch aspect ratio.

Render profile belongs to provider/version/content type.

Original remains untouched.
