# Storage and retention

Database:
metadata/state.

Object storage:
media/raw payload archives/screenshots.

Encrypted secret store:
tokens/browser session secrets.

Retention classes:
- permanent config;
- account history;
- media library;
- transient raw webhook;
- browser trace;
- logs.

Configurable deletion.

Audit events for destructive actions should survive normal content cleanup.

Raw messages/comments may require different retention from aggregated metrics.

Do not retain browser screenshots containing sensitive information unless
redacted and needed.
