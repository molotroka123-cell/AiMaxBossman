# Real Instagram test-account plan

Use a dedicated authorized Instagram Professional test account where possible.

Do not use production account first.

Validate progressively:

1. connect/OAuth;
2. profile read;
3. capability snapshot;
4. media read;
5. insights read;
6. publish controlled image;
7. publish controlled reel if permitted;
8. comments read/reply;
9. webhook;
10. messaging only if provider eligibility is satisfied;
11. delete/archive only after explicit test approval;
12. browser fallback separately.

Record:
- account type;
- API version;
- scopes;
- app review state;
- capability result;
- provider object ids;
- timestamps.

Never call an untested capability PASS.
