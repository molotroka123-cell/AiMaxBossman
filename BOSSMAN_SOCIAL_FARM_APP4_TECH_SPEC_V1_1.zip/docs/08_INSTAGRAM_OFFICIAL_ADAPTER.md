# Instagram official adapter

## Principle

Use current Meta Instagram APIs for Instagram Professional accounts whenever
the requested capability is officially exposed.

Do not hard-code assumptions that apply only to one authentication setup.

## Required integration areas

- account/profile retrieval;
- media retrieval;
- image/carousel publishing where supported;
- Reels publishing where supported;
- Stories publishing only where supported by account/API setup;
- comments and replies;
- mentions;
- account/media insights;
- webhooks;
- conversations/messages when account/app permissions and message eligibility
  allow it.

## Messaging constraints

Official Instagram messaging is not a general arbitrary outbound-DM channel.

The adapter must expose provider eligibility in the capability/result model.

A send operation must validate:
- conversation/recipient eligibility;
- required permission;
- allowed response window if applicable;
- media ownership constraints where applicable.

If not eligible:
PROVIDER_POLICY_BLOCKED, not browser auto-fallback by default.

Browser fallback for messaging requires a separate explicit account policy.

## Content publishing

Use provider media/container workflow.

Persist provider creation/container id for recovery.

Polling provider processing status is allowed where required.

Do not republish on uncertain response without reconciliation.

## Webhooks

Subscribe to supported fields.

Verify webhook signature/challenge according to current Meta requirements.

Deduplicate events.

Webhook event is untrusted external data.
