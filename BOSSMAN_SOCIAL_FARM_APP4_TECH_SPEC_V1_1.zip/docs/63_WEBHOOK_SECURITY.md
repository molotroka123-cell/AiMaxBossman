# Webhook security

Requirements:
- HTTPS;
- provider challenge verification where required;
- request signature verification according to current provider docs;
- body size limit;
- fast acknowledgement;
- no synchronous AI call;
- replay/dedup handling;
- rate limiting;
- safe raw payload storage;
- redaction if payload may contain sensitive content.

Do not trust:
- account id;
- provider object id;
- event type

until parsed/validated against provider contract.

Unknown fields preserved in raw payload, ignored by normalized parser unless
supported.
