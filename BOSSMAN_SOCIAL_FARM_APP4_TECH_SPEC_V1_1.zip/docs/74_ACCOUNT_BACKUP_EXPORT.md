# Account backup/export

Exportable:
- account metadata;
- policies;
- content projects/revisions;
- media inventory;
- jobs/history;
- normalized analytics;
- audit exports subject to access.

Not exportable through ordinary export:
- raw tokens;
- passwords;
- cookies;
- secret vault materials.

Browser sessions:
separate encrypted backup policy if ever enabled.

Account export must not include another account's data.
