# Required UI screens

## Dashboard

Cards:
- connected accounts;
- queue;
- scheduled jobs;
- auth warnings;
- provider degradation;
- approvals.

## Accounts

Each account:
- connection;
- account type;
- official/browser adapters;
- capability matrix;
- policy;
- health.

## Content Studio

- project;
- source assets;
- text variants;
- image/video generation;
- preview;
- target accounts;
- schedule.

## Calendar

Per account/multi-account schedule.

## Inbox

Messages/comments/mentions.

## Approvals

External mutations waiting ASK.

## Insights

Normalized analytics.

## Jobs

Durable state/attempt/retry.

## Settings

Providers, generation models, storage, browser fallback, policy templates.

No UI action should appear enabled if capability says NOT_SUPPORTED.
