# Security threat model

Threats:
- stolen provider token;
- browser cookie exfiltration;
- malicious inbound DM/comment prompt injection;
- webhook spoofing;
- cross-account data leak;
- accidental destructive action;
- duplicate publish;
- generated-content file attack;
- malicious URL/media;
- leaked logs;
- compromised generation provider.

Controls:
- vault refs;
- encryption;
- least privilege;
- webhook verification;
- account scoping;
- policy engine;
- approvals;
- idempotency;
- MIME/probe;
- URL allow/validation;
- egress control where feasible;
- redaction;
- dependency sandboxing.

Untrusted external text never enters system instructions.
