# Health model

Per account:

OFFICIAL_API:
HEALTHY / DEGRADED / AUTH_EXPIRED / PERMISSION_MISSING.

WEBHOOK:
HEALTHY / LAGGING / UNSUBSCRIBED.

BROWSER:
HEALTHY / REAUTH / TAKEOVER / BROKEN_SELECTOR / DISABLED.

CONTENT:
storage/generation/render.

SCHEDULER:
last due job, lateness.

Overall account state is derived, not manually set except disabled.

Dashboard shows cause.
