# Instagram browser fallback

Dedicated worker.

Not part of official adapter.

## Use cases

Only when:
- official API capability unavailable;
- account policy enables browser fallback;
- action is ordinary user-authorized account operation;
- provider/UI is reachable.

## Browser context

One isolated persistent context per account.

No context reuse across accounts.

Worker receives:
- account id;
- normalized action;
- secret references where needed;
- policy approval reference;
- idempotency key.

It never receives another account's session.

## Interaction model

Prefer:
- accessibility/semantic roles;
- visible labels;
- deterministic DOM signals.

Fallback selectors must be versioned.

Use stale-target verification:
target fingerprint before click/action.

If DOM changed:
STALE_TARGET -> refresh state.

Do not click "nearest" alternative silently.

## Human Take Over

Required for:
- login challenge;
- unexpected security checkpoint;
- ambiguous destructive UI;
- unknown provider modal.

No CAPTCHA solving/bypass.

## Audit

Record:
- action type;
- target semantic identity;
- before/after URL;
- screenshot reference if allowed;
- result;
- DOM fingerprint.

Redact sensitive data before persistence.
