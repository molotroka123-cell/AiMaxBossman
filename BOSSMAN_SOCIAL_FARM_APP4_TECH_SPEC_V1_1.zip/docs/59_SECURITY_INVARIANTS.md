# Security invariants

These are testable invariants.

## Secret invariants

S1:
No raw provider token in domain DB.

S2:
No password/token/cookie in model-visible tool result.

S3:
No password value in browser DOM snapshot.

S4:
No raw session storage/local storage secret in browser trace.

S5:
No secret in structured logs.

## Account isolation

A1:
Account A job cannot resolve Account B secret ref.

A2:
Account A browser context cannot open with Account B profile.

A3:
Provider event account id must be verified before domain association.

A4:
Batch job creates scoped child jobs.

## External mutation

M1:
Mutation requires capability.

M2:
Mutation requires policy.

M3:
ASK requires valid approval.

M4:
External effect has idempotency key.

M5:
Unknown external state cannot blind retry.

## Content

C1:
Approved revision immutable.

C2:
Approval invalid after revision change.

C3:
Generated asset validated before publish.

## Inbound

I1:
DM/comment text is untrusted.

I2:
Inbound text cannot change policy.

I3:
Inbound text cannot request secret resolution.

## Browser

B1:
No CAPTCHA bypass.

B2:
No anti-detection evasion.

B3:
Stale target must fail safe.

B4:
Account identity verified after takeover/relogin.

Every invariant needs at least one automated test where technically possible.
