# Definition of Done

The application is technically usable when a real authorized Instagram
Professional account can be connected and the system can:

- show exact capabilities;
- store secrets outside model context;
- create/upload/generate content;
- create immutable revision;
- validate/render media;
- schedule a job;
- apply dynamic policy;
- request approval when needed;
- publish through official adapter where supported;
- reconcile result;
- process supported webhooks;
- read/reply to supported comments/messages within provider constraints;
- read supported insights;
- recover from restart;
- show full audit;
- optionally execute a verified browser fallback action where explicitly
  enabled;
- keep accounts isolated.

“Full control” is not Definition of Done.
Exact capability evidence is.
