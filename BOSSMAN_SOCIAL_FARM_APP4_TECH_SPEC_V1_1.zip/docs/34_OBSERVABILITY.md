# Observability

Structured log fields:
timestamp
service
trace_id
job_id
account_id
provider
adapter
capability
policy_decision
attempt
duration
result_class.

Operational metrics:
queue depth
job age
scheduled lateness
publish success
publish unknown state
webhook lag
token expiry horizon
rate-limit cooldown
browser crash
browser takeover
generation latency
generation failure
storage usage.

Health:
API
DB
queue
storage
provider official
browser worker
generation provider.

Secrets redacted before sink.
