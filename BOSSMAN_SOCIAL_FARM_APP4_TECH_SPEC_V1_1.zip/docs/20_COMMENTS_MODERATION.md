# Comments and moderation

Normalized actions where provider supports:
READ
REPLY
HIDE
UNHIDE
DELETE
LIKE.

Moderation classifier outputs:
- category;
- confidence;
- toxicity/spam flags if used;
- recommended action;
- evidence text.

Automatic destructive moderation requires explicit policy.

Default:
delete/hide = ASK unless account policy says otherwise.

Store original comment event before moderation action subject to retention.
