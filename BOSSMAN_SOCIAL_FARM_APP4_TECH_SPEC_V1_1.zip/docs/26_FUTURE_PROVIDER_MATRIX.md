# Future provider matrix

Reserved adapters:

TikTok
YouTube
Facebook Pages
Threads
X
LinkedIn.

Each provider starts as:
NOT_INSTALLED.

Core UI may show “Coming soon” based on adapter registry metadata.

Provider installation registers:
- adapter id;
- version;
- auth schemes;
- capabilities;
- configuration schema;
- webhook routes;
- media profiles.

No conditional spaghetti:
`if provider == instagram` throughout core domain is forbidden.
