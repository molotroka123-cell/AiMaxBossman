# Browser selector registry

Browser automation must not contain ad-hoc selectors throughout action code.

## SelectorPack

Fields:
- provider;
- browser_adapter_version;
- ui_revision;
- locale;
- action;
- semantic_target;
- primary strategy;
- fallback strategies;
- expected preconditions;
- expected postcondition;
- verified_at.

## Strategies

Preferred:
- role/name;
- label;
- accessible name;
- stable data attribute if provider exposes one.

Avoid:
- brittle nth-child;
- absolute XPath;
- viewport coordinates.

Destructive actions require:
- target fingerprint;
- confirmation text match;
- postcondition.

A selector pack can be disabled independently after breakage.

Repeated deterministic failure should demote browser capability.
