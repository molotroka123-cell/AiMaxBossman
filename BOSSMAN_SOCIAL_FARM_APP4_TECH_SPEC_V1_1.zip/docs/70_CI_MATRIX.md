# CI matrix

Recommended jobs:

## static
- Python compile/lint/type if used;
- JS/TS typecheck/build;
- schema validation;
- migration validation;
- secret scan.

## unit
- domain/policy/capability;
- security invariants;
- job state.

## contract
- adapter fixtures;
- provider payload parsers;
- vault interface;
- FFmpeg wrapper.

## e2e-mock
- content -> schedule -> publish -> webhook -> reply.

## browser
- local deterministic browser fixture;
- redaction;
- stale target;
- takeover boundary.

## integration-services
- Postgres;
- Redis/queue;
- object storage test backend.

Real Meta/TikTok credentials must NOT be required for normal PR CI.

Real provider tests:
separate protected/manual workflow with authorized test account/secrets.
