# Storage layout

Suggested logical object keys:

media/original/{asset_id}/{checksum}
media/derived/{asset_id}/{checksum}
media/previews/{revision_id}/...
provider/raw/{provider}/{date}/{receipt_id}.json
browser/screenshots/{account_id}/{trace_id}.png
audit/export/{date}/...

Raw provider and browser artifacts may require shorter retention.

Never store:
- plaintext password files;
- token JSON exports;
- raw cookie jars

in ordinary media/object namespace.

Secret artifacts use vault backend only.
