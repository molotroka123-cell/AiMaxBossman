# Event outbox / inbox pattern

## Problem

Jobs, audit events, webhooks and downstream processing must survive process
crashes without duplicate external effects.

## Inbox

Every external webhook/event gets:
- durable receipt;
- dedup key;
- raw payload ref;
- processed marker.

Processing is idempotent.

## Outbox

When a DB transaction changes domain state and needs async work:
write an outbox row in the same transaction.

Dispatcher:
- leases row;
- emits queue task;
- marks dispatched.

Consumer:
idempotent.

## Examples

Content approved:
transaction writes:
- revision approved;
- audit event;
- outbox `CONTENT_APPROVED`.

Scheduler:
consumes event and creates publish child jobs.

## Rule

Do not:
commit DB -> call queue -> hope both succeeded.

Use transactionally coupled outbox or equivalent durable mechanism.
