# Provider governor

Do not model rate limits as a global fixed number.

Maintain per:
- provider;
- account;
- token/app if applicable;
- endpoint/capability.

Inputs:
- provider response headers;
- documented limits;
- local sliding windows;
- retry-after;
- error codes.

States:
OPEN
THROTTLED
COOLDOWN
BLOCKED_AUTH
BLOCKED_POLICY.

Queue scheduler respects governor.

429:
never busy-loop.

No proxy/session rotation to circumvent provider limits.

Browser adapter also has a conservative action budget independent from API
limits.
