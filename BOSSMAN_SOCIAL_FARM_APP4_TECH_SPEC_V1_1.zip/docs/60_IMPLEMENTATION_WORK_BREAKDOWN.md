# Implementation work breakdown

## Workstream 0 — repository placement

- create `apps/social-farm`;
- add app manifest;
- add isolated dependency config;
- add docs/tests directories;
- do not modify BOSSMAN core except bridge/registry integration.

## Workstream 1 — domain

Implement:
- account;
- capability;
- policy;
- approval;
- content;
- media;
- job;
- event;
- inbox;
- insight;
- audit objects.

Tests first for invariants.

## Workstream 2 — persistence

- Postgres schema;
- migrations;
- repositories;
- transaction boundaries;
- outbox/inbox;
- append-only audit.

## Workstream 3 — secret vault

- secret reference interface;
- encrypted local dev backend;
- production-pluggable backend;
- token lifecycle.

## Workstream 4 — job runtime

- durable queue;
- lease;
- checkpoint;
- retry;
- schedule;
- reconciliation;
- dead letter;
- cancellation.

## Workstream 5 — policy/capability

- hierarchy;
- condition evaluator;
- versioning;
- account capability snapshot;
- UI/command enforcement.

## Workstream 6 — Instagram official adapter

- OAuth connect;
- account identity;
- capability fetch;
- media read;
- image publish;
- carousel/reel/story where supported;
- comments;
- mentions;
- insights;
- webhooks;
- messaging eligibility.

Real test account required for REAL PASS.

## Workstream 7 — media/content

- object storage;
- checksums;
- ffprobe;
- transform;
- content revision;
- approval hash;
- provider render profile.

## Workstream 8 — inbound events

- webhook receive;
- signature;
- dedup;
- normalize;
- comments/messages/mentions;
- prompt-injection boundary.

## Workstream 9 — browser fallback

Only now:
- browser service;
- account context;
- session vault;
- selector registry;
- stale target;
- takeover;
- verified browser capabilities.

## Workstream 10 — generation

- text adapter;
- image adapter;
- video adapter;
- local/cloud/BOSSMAN provider registry;
- durable generation jobs;
- cost/latency health.

## Workstream 11 — UI

- dashboard;
- account management;
- content studio;
- calendar;
- inbox;
- approvals;
- jobs;
- insights;
- settings/policy.

## Workstream 12 — BOSSMAN bridge

- normalized commands;
- no secrets;
- job/approval surface.

## Workstream 13 — hardening

- failure injection;
- cross-account tests;
- secret canary;
- rate limit;
- restart recovery;
- CI;
- implementation report.

## Completion

No workstream marked DONE from docs alone.
Each needs tests/evidence.
