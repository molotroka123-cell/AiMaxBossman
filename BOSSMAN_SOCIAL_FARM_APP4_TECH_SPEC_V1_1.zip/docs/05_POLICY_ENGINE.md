# Dynamic policy engine

Policy is runtime data.

Hierarchy:
SYSTEM
→ PROVIDER
→ ACCOUNT
→ CAPABILITY
→ CONDITION.

Decision:
AUTO
ASK
DENY.

Most specific valid rule wins, with DENY able to override if configured as
hard policy.

## Conditions

Possible:
- schedule vs manual;
- content type;
- destination account;
- time/day;
- confidence;
- moderation category;
- generated vs uploaded asset;
- job origin;
- BOSSMAN mission id;
- human-authored vs agent-authored;
- browser fallback required;
- destructive action;
- new external recipient;
- daily action budget.

## Example

Instagram account A:

media.publish.image:
AUTO if schedule=true AND content.approved=true.

comments.reply:
AUTO if moderation_class=FAQ
AND confidence >=0.95
AND no external link
ELSE ASK.

messages.reply:
ASK.

media.delete:
ASK.

account.profile.update:
ASK.

relationships.follow:
DENY unless account rule explicitly enables it.

## Versioning

Every policy update:
- version;
- actor;
- diff;
- created_at;
- effective_at.

Every job stores evaluated policy version and result.
