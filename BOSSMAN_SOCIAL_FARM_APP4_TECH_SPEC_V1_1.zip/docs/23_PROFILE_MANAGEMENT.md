# Profile management

Potential normalized mutations:
- bio;
- link/website;
- avatar;
- display metadata where provider permits.

Capability detection mandatory.

Profile/security mutations default ASK.

Never change:
- account password;
- MFA;
- recovery email/phone;
- ownership/admin permissions

through generic profile.update.

Security settings are out of scope for automated Social Farm action unless a
future dedicated security workflow is explicitly designed.
