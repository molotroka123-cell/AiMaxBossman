# Destructive action guards

Actions:
media.delete
media.archive
comments.delete
profile.update
disconnect
session.revoke.

Default:
ASK.

Approval preview includes:
- exact account;
- exact object;
- current object snapshot;
- action;
- reversibility;
- fallback adapter if used.

Destructive browser action:
requires fresh target fingerprint immediately before click.

No destructive batch without explicit item list.

Provider delete success must be reconciled before local history removal.
