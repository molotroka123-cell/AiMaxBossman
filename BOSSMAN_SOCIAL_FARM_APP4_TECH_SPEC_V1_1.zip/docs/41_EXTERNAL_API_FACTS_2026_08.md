# External provider facts frozen for design review
Observed: 2026-08-28

These facts are for architecture only and must be revalidated during
implementation against current provider docs/API versions.

## Instagram / Meta

Current Meta documentation exposes Instagram APIs for Professional accounts
(Business/Creator) for presence-management functions such as media publishing,
comments, insights and profile/media data.

Meta's official Instagram documentation notes that consumer/personal accounts
do not have the same Graph API access.

Official messaging requires appropriate permissions and is constrained by
conversation eligibility; it is not an unrestricted arbitrary outbound-DM API.

Meta Webhooks provide event delivery for supported Instagram fields such as
messages/comments in applicable integrations.

## TikTok

TikTok's official Content Posting API currently supports:
- Direct Post;
- Upload/draft flow;
- video;
- photo.

Direct posting requires a registered app, relevant approved scope and user
authorization. TikTok documentation also describes audit/review behavior for
clients.

TikTok status can be checked through API and posting webhooks.

## Design consequence

Capability detection and adapter versioning are mandatory.
Do not hard-code one provider's assumptions into Social Farm core.
