# Timezone and scheduling

Each account has IANA timezone.

Schedule stores UTC instant + original local intent.

DST changes must not silently shift recurring schedules.

Recurring schedules:
store rule + timezone.

Provider publishing queue uses UTC.

UI displays account timezone.

If publishing misses deadline due outage:
policy decides:
PUBLISH_LATE
SKIP
ASK.
