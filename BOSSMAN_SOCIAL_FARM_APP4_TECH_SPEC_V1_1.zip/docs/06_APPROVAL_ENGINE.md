# Approval engine

ASK does not block worker resources.

Job transitions:
WAITING_APPROVAL.

Approval object:
- approval_id;
- action;
- account;
- provider;
- preview;
- content artifact;
- external recipient if any;
- risk;
- requested_at;
- expires_at;
- policy reason;
- approve/reject actor.

Approve resumes via idempotent checkpoint.

Reject terminates external-effect step but keeps draft/job history.

Bulk approval:
allowed only for explicitly selected jobs and same policy class.

No approval token in URL with reusable authority.
