# Implementation order

M0:
domain models + capability + policy + jobs.

M1:
account registry + vault + Instagram official auth/capabilities.

M2:
content/media library + image publishing.

M3:
scheduler/idempotency/reconciliation.

M4:
Reels/carousels/stories as capabilities permit.

M5:
webhooks/comments/insights.

M6:
messaging with provider eligibility.

M7:
browser fallback worker.

M8:
AI text/image/video generation providers.

M9:
BOSSMAN bridge + UI refinement.

M10:
failure injection + real capability report.

Do not start browser fallback before official adapter core works.
