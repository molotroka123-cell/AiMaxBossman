# Content render profiles

A content project may target multiple accounts/providers.

Each target resolves a render profile.

RenderProfile:
- provider;
- content type;
- account type;
- locale;
- max caption length if provider exposes one;
- media rule profile;
- cover/thumbnail rule;
- subtitle rule;
- hashtag/metadata mapping;
- verified_at;
- provider version.

Derived assets are target-specific.

The same original video may yield:
- Instagram Reel render;
- future TikTok render;
- future YouTube Shorts render.

No destructive overwrite of original.
