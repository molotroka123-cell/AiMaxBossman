# Data model

Core entities:

SocialAccount
AuthReference
CapabilitySnapshot
PolicyProfile
PolicyRule
ApprovalRequest

ContentProject
ContentRevision
MediaAsset
MediaTransform
GenerationJob

SocialJob
JobAttempt
ExternalEffect

ProviderEvent
WebhookReceipt
SyncCursor

PublishedMedia
Comment
Conversation
Message
Mention

InsightMetric
InsightSnapshot

BrowserSession
BrowserActionTrace

AuditEvent
HealthSnapshot.

Use internal UUID/ULID keys.

Provider ids are alternate unique keys, never primary DB identities.

Raw external payloads should be separately stored with retention/redaction.
