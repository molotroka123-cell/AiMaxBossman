# Test plan

## Unit

- policy inheritance;
- conditional policy;
- capability routing;
- secret redaction;
- account scoping;
- idempotency;
- job recovery;
- media validation;
- error mapping;
- webhook dedup;
- inbound prompt-injection isolation.

## Contract

Official Instagram mocked endpoint fixtures.
Browser worker interface.
FFmpeg.
Text/image/video generation adapters.

## E2E mock

1. connect mock account
2. create content
3. generate image
4. render
5. schedule
6. AUTO policy publish
7. provider result
8. webhook
9. comment reply ASK
10. approve
11. reply.

## Real Instagram

Use authorized professional test account.

Evidence per capability.

## Browser

User-authorized account/test surface.
No rate-limit/anti-bot bypass.

## Failure

429
401/token expired
500
network timeout
duplicate webhook
lost worker
browser crash
unknown publish response
corrupt video
object storage down
DB restart.

## Security

secret canary search over logs/events/tool outputs.
cross-account access tests.
webhook forged signature.
malicious inbound prompt.
