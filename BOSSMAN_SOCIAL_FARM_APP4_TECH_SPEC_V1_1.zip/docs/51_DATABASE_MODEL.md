# Database model

Recommended relational core:
PostgreSQL.

SQLite acceptable only for local development tests if abstractions preserve
production semantics.

## Tables

### social_accounts
- id UUID/ULID PK
- provider
- provider_account_id
- handle
- account_type
- auth_ref
- browser_session_ref
- timezone
- locale
- status
- policy_profile_id
- generation_profile_id
- capability_snapshot_version
- health_state
- created_at
- updated_at
- disabled_at

Unique:
(provider, provider_account_id)

### capability_snapshots
- id
- account_id
- version
- provider_api_version
- adapter_version
- observed_at
- expires_at
- raw_ref

### capabilities
- snapshot_id
- name
- status
- source
- reason
- permission_requirements_json
- metadata_json

Unique:
(snapshot_id, name)

### policy_profiles
- id
- name
- version
- active
- created_by
- created_at
- effective_at

### policy_rules
- id
- profile_id
- scope
- provider
- account_id
- capability
- decision
- condition_json
- hard_deny
- priority
- created_at

### approvals
- id
- job_id
- status
- preview_ref
- requested_at
- expires_at
- decided_at
- actor_id
- decision_note

### content_projects
- id
- title
- brief
- status
- current_revision_id
- created_by
- created_at
- updated_at

### content_revisions
- id
- project_id
- revision_no
- caption
- metadata_json
- content_hash
- approved_at
- approved_by
- supersedes_revision_id
- created_at

Unique:
(project_id, revision_no)

### media_assets
- id
- project_id
- parent_asset_id
- type
- mime
- checksum_sha256
- byte_size
- width
- height
- duration_ms
- codec_json
- source_type
- source_provider
- storage_ref
- immutable
- created_at

### generation_jobs
- id
- project_id
- kind
- provider
- model
- state
- input_ref
- output_ref
- cost_json
- attempts
- started_at
- finished_at

### social_jobs
- id
- account_id
- capability
- state
- adapter_preference
- payload_ref
- idempotency_key
- policy_profile_id
- policy_version
- approval_id
- schedule_at
- not_before
- deadline
- lease_owner
- lease_expires_at
- checkpoint
- attempts
- external_state
- created_at
- updated_at
- terminal_at

Unique:
(account_id, idempotency_key)

### job_attempts
- id
- job_id
- attempt_no
- adapter
- started_at
- finished_at
- result_class
- retry_class
- provider_request_id
- redacted_error_ref

### external_effects
- id
- job_id
- provider
- effect_type
- provider_object_id
- idempotency_key
- state
- observed_at

### webhook_receipts
- id
- provider
- received_at
- signature_valid
- provider_event_id
- dedup_key
- payload_ref
- processed_at

Unique where possible:
(provider, provider_event_id)

### provider_events
- id
- account_id
- provider
- event_type
- provider_event_id
- dedup_key
- event_time
- payload_ref
- normalized_json
- created_at

### conversations
- id
- account_id
- provider_conversation_id
- state
- last_message_at
- eligibility_json

### messages
- id
- conversation_id
- provider_message_id
- direction
- sender_ref
- body_ref
- media_json
- received_at
- sent_at
- status

### comments
- id
- account_id
- media_provider_id
- provider_comment_id
- parent_comment_id
- author_ref
- body_ref
- status
- created_at
- updated_at

### insights
- id
- account_id
- media_ref
- metric
- period
- start_at
- end_at
- value_json
- provider_api_version
- collected_at

### browser_sessions
- id
- account_id
- session_ref
- state
- selector_pack_version
- last_verified_at
- last_takeover_at

### browser_action_traces
- id
- account_id
- job_id
- action
- selector_pack_version
- target_fingerprint
- before_url
- after_url
- screenshot_ref
- result
- created_at

### audit_events
Append-only:
- id
- actor_type
- actor_id
- trace_id
- account_id
- job_id
- event_type
- capability
- policy_version
- policy_decision
- object_ref
- redacted_detail_json
- created_at

## Constraints

- account_id FK scoping everywhere;
- no raw secret columns;
- no browser cookies in domain DB;
- content revision hash immutable;
- audit rows not updated;
- published revision cannot be silently mutated.
