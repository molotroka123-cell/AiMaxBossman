# Authentication and secret vault

## Official API

Store:
- token reference;
- token type;
- scopes;
- issued_at;
- expires_at;
- refresh state;
- provider app id reference.

Do not store access token in normal Account row.

## Browser

Store encrypted:
- browser storage/session artifact reference;
- encrypted credential reference only when strictly required;
- last verified login;
- re-auth required state.

Passwords never appear in:
- DOM snapshot to model;
- screenshots metadata;
- logs;
- audit detail;
- tool arguments visible to LLM.

## Rotation

Token expiry triggers:
AUTH_REFRESH job.

Failure:
account -> AUTH_EXPIRED.

No silent browser password re-entry if policy requires human reauthentication.

## Secret API

Allowed operations:
resolve_for_adapter(secret_ref)
rotate(secret_ref)
revoke(secret_ref)
health(secret_ref)

Never:
get_plaintext_for_model().
