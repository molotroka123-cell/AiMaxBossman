# Provider/API versioning

Store:
- adapter version;
- provider API version;
- capability schema version;
- media profile version.

Provider upgrade:
- run contract tests;
- recompute capabilities;
- do not migrate all accounts blindly if permission model changed.

Deprecation:
capability becomes TEMPORARILY_DISABLED / REQUIRES_REVIEW.

Raw provider payload parsers are versioned fixtures.
