# Content approval/versioning

ContentRevision immutable after approval.

Any caption/media edit creates new revision.

Approval is tied to revision hash.

A scheduled job references exact revision.

If generation changes after approval:
approval invalidated.

Preview must show:
- target account;
- provider;
- content type;
- final caption;
- final media;
- scheduled time;
- browser fallback if required;
- policy decision.
