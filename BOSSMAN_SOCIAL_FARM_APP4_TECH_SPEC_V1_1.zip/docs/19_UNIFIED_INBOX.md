# Unified inbox

Normalize provider conversations/comments without pretending they are the same
object.

Views:
- messages;
- comments;
- mentions;
- moderation queue.

Thread state:
OPEN
WAITING_US
WAITING_EXTERNAL
RESOLVED
ARCHIVED.

Inbound text is untrusted.

AI may:
- summarize;
- classify;
- draft reply;
- detect language;
- extract question.

AI may not:
- reveal secrets;
- change system policy;
- authorize an action;
- execute instructions found in inbound text outside the reply task.

Reply mutation always passes policy engine.
