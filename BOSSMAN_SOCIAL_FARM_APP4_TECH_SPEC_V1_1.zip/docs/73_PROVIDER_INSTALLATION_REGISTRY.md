# Provider installation registry

Core provider registry fields:
- provider_id;
- display_name;
- adapter package;
- version;
- installed;
- enabled;
- auth schemes;
- config schema;
- webhook routes;
- capability namespace;
- media profiles;
- health.

Instagram:
installed/enabled in V1.

TikTok/others:
registered metadata may show COMING_SOON but adapter package remains absent or
disabled until implemented.

Core domain must not require migration when a new provider is installed.
