# Migration rules

DB migrations:
forward-only in normal deploy.

Every migration:
- version;
- upgrade;
- data backfill strategy;
- rollback note;
- lock/risk assessment.

Provider schema changes should not force destructive DB migrations when raw
payload remains separated.

Content/audit history immutable.

Capability snapshots append versions rather than overwrite past evidence.

Policy versions append, not mutate history.
