# Social Provider Adapter Contract

Each adapter implements normalized operations.

Required methods conceptually:

connect()
disconnect()
refresh_auth()
capabilities()
health()

list_media()
get_media()
create_publish_job()
publish()
get_publish_status()
delete_media()
archive_media()

list_comments()
reply_comment()
moderate_comment()

list_threads()
list_messages()
reply_message()

get_account_insights()
get_media_insights()

subscribe_webhooks()
reconcile(cursor)

Adapter result:
- provider request id;
- normalized result;
- raw reference;
- retry class;
- rate-limit metadata;
- capability error;
- policy-independent provider error.

Adapter does not decide AUTO/ASK/DENY.
