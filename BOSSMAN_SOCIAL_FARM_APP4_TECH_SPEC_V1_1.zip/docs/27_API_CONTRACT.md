# Application API contract

Suggested version prefix:
/api/social/v1

## Accounts

GET /accounts
POST /accounts/connect
GET /accounts/{id}
GET /accounts/{id}/capabilities
GET /accounts/{id}/health
PUT /accounts/{id}/policy
POST /accounts/{id}/disconnect

## Content

POST /content/projects
GET /content/projects/{id}
POST /content/projects/{id}/generate/text
POST /content/projects/{id}/generate/image
POST /content/projects/{id}/generate/video
POST /content/projects/{id}/render
POST /content/projects/{id}/approve

## Jobs

POST /jobs
GET /jobs/{id}
POST /jobs/{id}/cancel
POST /jobs/{id}/approve
POST /jobs/{id}/reject

## Inbox

GET /accounts/{id}/comments
GET /accounts/{id}/conversations
GET /conversations/{id}/messages
POST /comments/{id}/reply
POST /conversations/{id}/reply

## Insights

GET /accounts/{id}/insights
GET /media/{id}/insights

## Browser

POST /accounts/{id}/browser/session/verify
POST /accounts/{id}/browser/takeover

Do not return secret values.
