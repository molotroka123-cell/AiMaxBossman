# System architecture

```text
                         BOSSMAN
                            |
                     Social Farm Bridge
                            |
                    Application API/WS
                            |
       +--------------------+--------------------+
       |                    |                    |
 Account Registry      Content Studio       Unified Inbox
       |                    |                    |
 Policy Engine         Media Pipeline       Moderation/Drafts
       |                    |                    |
 Capability Engine ---- Job Orchestrator --------+
       |                    |
       |              Durable Scheduler
       |                    |
 Provider Router -----------+
       |
 +-----+-----------------------------+
 |                                   |
Official Adapters                Browser Fallback
 |                                   |
Instagram API                    Isolated Browser Worker
 |
future adapters:
TikTok / YouTube / Facebook / X / Threads / LinkedIn
```

## Boundaries

Core domain knows:
- accounts;
- capabilities;
- content;
- jobs;
- messages/comments;
- policies;
- insights.

Core domain does not know:
- Graph API URLs;
- CSS selectors;
- TikTok OAuth details;
- provider-specific token format.

Adapters own those details.

## Deployment

Recommended components:
- API service;
- worker service;
- browser worker;
- DB;
- queue;
- object/media storage;
- optional generation worker;
- optional local-model bridge.

Single-host deployment is acceptable initially if processes are isolated.
