# Messaging

Messaging is provider-constrained.

Do not represent it as arbitrary outbound chat.

Message send request includes:
- account;
- conversation;
- recipient provider id;
- eligibility;
- reply context;
- content;
- attachment;
- policy;
- provider window state.

If provider requires recipient-originated conversation:
enforce it.

If provider response window is closed:
return structured block.

Browser fallback does not automatically override official provider messaging
restrictions; it needs explicit action policy and ordinary user-level
eligibility.

External replies are irreversible, so preview/audit is required.
