# Media rule engine

Provider constraints change over time.

Do not scatter constants across code.

## ProviderMediaProfile

Keys:
- provider;
- adapter version;
- API version;
- content_type;
- account_type constraints;
- mime allowlist;
- container allowlist;
- codec allowlist;
- min/max width;
- min/max height;
- aspect ratio rules;
- duration min/max;
- size max;
- audio constraints;
- thumbnail constraints;
- URL requirements;
- published_at;
- source reference;
- verified_at.

## Validation output

PASS
PASS_WITH_TRANSFORM
FAIL_UNSUPPORTED
FAIL_CORRUPT
FAIL_TOO_LARGE
FAIL_DURATION
FAIL_CODEC
FAIL_ASPECT
FAIL_PROVIDER_RULE_UNKNOWN.

If provider rule is unknown:
do not invent a value.
Block automatic publish or defer to provider validation.
