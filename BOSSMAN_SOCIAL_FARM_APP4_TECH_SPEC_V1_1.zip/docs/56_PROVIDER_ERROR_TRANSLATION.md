# Provider error translation

Adapters translate raw provider errors to stable domain classes.

## Auth

401 / invalid token:
AUTH_EXPIRED or AUTH_REQUIRED.

## Permission

permission/scope missing:
PERMISSION_MISSING.

Do not retry automatically.

## Capability

unsupported media/action:
CAPABILITY_UNAVAILABLE.

## Policy

provider disallows send/action:
PROVIDER_POLICY_BLOCKED.

## Rate limit

429 / provider equivalent:
RATE_LIMITED
with retry_after if available.

## Transient

5xx / timeout before known external effect:
TRANSIENT_PROVIDER.

## Unknown external state

timeout after mutation may have reached provider:
UNKNOWN_EXTERNAL_STATE.

Must reconcile.

## Content

provider rejects media/content:
CONTENT_REJECTED / MEDIA_INVALID.

## Error payload

Persist:
- normalized code;
- provider code;
- provider request id;
- safe detail.

Never persist token-bearing raw body directly.
