# Browser worker state machine

Per account browser state:

DISABLED
STARTING
LOGIN_REQUIRED
AUTHENTICATED
READY
BUSY
REAUTH_REQUIRED
TAKEOVER_REQUIRED
BROKEN_UI
COOLDOWN
STOPPED.

## Startup

- start isolated context;
- load encrypted session;
- navigate safe landing;
- verify account identity;
- ensure no cross-account identity mismatch;
- READY.

If identity mismatch:
STOP and require human review.

## Action

READY
-> BUSY
-> verify semantic target
-> verify policy/approval
-> perform action
-> verify result
-> READY.

## Login challenge

No automated CAPTCHA bypass.

Set:
TAKEOVER_REQUIRED.

Human completes challenge.

Worker then:
verify correct account
-> save encrypted session
-> READY.

## Broken selector

If expected semantic target absent:
- refresh once;
- versioned fallback selector set;
- if still ambiguous: BROKEN_UI.

Never click based on position alone for destructive/write actions.

## Cooldown

Repeated provider warnings/security dialogs:
COOLDOWN.

Do not rotate identity/proxy to continue.
