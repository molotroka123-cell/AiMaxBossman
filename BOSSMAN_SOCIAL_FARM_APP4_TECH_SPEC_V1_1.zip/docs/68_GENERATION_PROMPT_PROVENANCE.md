# Generation prompt provenance

For every generated asset store safe metadata:
- provider;
- model;
- prompt hash;
- prompt/config reference;
- source asset ids;
- seed if provider returns one;
- generation timestamp;
- safety/moderation result;
- cost metadata;
- output checksum.

Do not expose private account credentials in prompts.

If a prompt contains user-private content:
respect content retention and access controls.

Prompt provenance helps reproduce/trace assets without coupling to one model.
