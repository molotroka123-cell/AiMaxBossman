# Scheduler and job engine

All external mutations use durable jobs.

Job fields:
- id;
- account;
- capability;
- adapter preference;
- payload ref;
- idempotency_key;
- schedule_at;
- not_before;
- deadline;
- policy snapshot;
- approval;
- attempts;
- checkpoint;
- external ids;
- result.

States:
DRAFT
QUEUED
WAITING_APPROVAL
READY
RUNNING
WAITING_PROVIDER
RETRY_WAIT
RECONCILING
SUCCEEDED
FAILED
CANCELLED
DEAD_LETTER.

Restart recovery:
RUNNING older than lease -> RECONCILING, not automatically rerun.

Publish uncertainty:
query provider status first.
