# Capability model

Every account exposes a live CapabilitySnapshot.

## Namespaces

### Account/profile
account.read
account.profile.read
account.profile.update
account.avatar.update
account.bio.update

### Media
media.list
media.read
media.publish.image
media.publish.carousel
media.publish.reel
media.publish.story
media.edit.caption
media.archive
media.delete

### Comments
comments.read
comments.reply
comments.hide
comments.unhide
comments.delete
comments.like

### Mentions
mentions.read

### Messaging
messages.threads.read
messages.read
messages.reply
messages.attachment.send
messages.reaction.send

### Insights
insights.account.read
insights.media.read
insights.story.read

### Relationship/engagement
relationships.read
relationships.follow
relationships.unfollow
engagement.like
engagement.unlike

## Capability status

SUPPORTED_OFFICIAL
SUPPORTED_BROWSER
SUPPORTED_BOTH
READ_ONLY
NOT_SUPPORTED
REQUIRES_APP_REVIEW
REQUIRES_ACCOUNT_TYPE
REQUIRES_USER_INTERACTION
TEMPORARILY_DISABLED

## Capability snapshot source

Each status has:
- source;
- adapter version;
- provider API version;
- permissions/scopes;
- observed_at;
- expires_at;
- reason.

The UI and BOSSMAN command router use the snapshot.

Never infer capability from account name/type alone.
