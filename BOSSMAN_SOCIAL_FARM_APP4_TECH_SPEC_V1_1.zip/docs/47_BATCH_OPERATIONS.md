# Batch operations

A batch creates independent child jobs.

Examples:
same content revision rendered separately for 5 accounts.

Each child:
- capability check;
- policy;
- media render;
- provider job;
- result.

Batch summary:
SUCCEEDED
PARTIAL
FAILED.

Do not roll back already public content automatically.

Destructive bulk operations default ASK with explicit item list.
