# Content Studio

Content Studio is provider-neutral.

## ContentProject

Contains:
- brief;
- source text/assets;
- generated variants;
- selected caption;
- selected assets;
- target providers/accounts;
- status;
- approval.

## Inputs

- manual text;
- uploaded image/video;
- URL/reference import when permitted;
- BOSSMAN task output;
- local file;
- generated content.

## Text

Provider abstraction:
generate_caption()
rewrite()
translate()
hashtags_or_metadata()
alt_text()

## Image

Provider abstraction:
generate_image()
edit_image()
expand_crop()
variant()
remove_background where supported.

## Video

Provider abstraction:
generate_video()
extend()
edit()
transcode()
caption/subtitle()
cover_frame().

Do not couple to one generation vendor.

Store prompts/config provenance with asset metadata when allowed.

## Durable artifacts

Generation result is stored before publishing.

No ephemeral model URL is the only copy of a scheduled asset.
