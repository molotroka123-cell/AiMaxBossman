# Moderation policy

Moderation output must separate:
- classifier judgment;
- policy decision;
- external action.

Classifier may label:
SPAM
ABUSE
QUESTION
PRAISE
COMPLAINT
UNKNOWN.

Suggested action:
NONE
DRAFT_REPLY
HIDE
DELETE
ESCALATE.

Policy then decides:
AUTO / ASK / DENY.

Default destructive moderation:
ASK.

Low-confidence:
ASK/ESCALATE.

Inbound moderation text remains untrusted.
