# Browser fallback capability discovery

Do not automatically mark every UI control as an automation capability.

A browser capability is promoted only after:
- deterministic navigation path;
- target identity;
- successful test;
- failure behavior;
- policy classification;
- account-type compatibility;
- real browser evidence.

States:
EXPERIMENTAL
VERIFIED_BROWSER
BROKEN_UI_VERSION
DISABLED.

Provider UI changes can automatically demote a capability after repeated
deterministic failure.

No heuristic clicking to preserve a false “full control” status.
