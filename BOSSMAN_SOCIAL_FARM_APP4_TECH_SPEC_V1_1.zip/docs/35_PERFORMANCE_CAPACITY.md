# Performance / capacity

Initial:
1–10 accounts.

Design target:
hundreds of scheduled/content jobs per day without changing domain schema.

Do not optimize for thousands of accounts prematurely.

Capacity boundaries:
- generation jobs separate from publish jobs;
- video generation/transcode CPU/GPU heavy;
- browser worker concurrency low and bounded;
- API webhooks lightweight;
- provider calls governed.

Backpressure:
queue depth and resource reservation.

Media file size limits configurable.
