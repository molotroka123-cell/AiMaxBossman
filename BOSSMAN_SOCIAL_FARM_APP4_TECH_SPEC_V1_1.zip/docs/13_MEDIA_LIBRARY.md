# Media library

Object-store backed.

Asset fields:
- asset_id;
- content_project_id;
- type;
- MIME;
- byte_size;
- checksum;
- width/height;
- duration;
- codec;
- source;
- generation provider;
- parent asset;
- version;
- storage ref;
- created_at.

Immutable originals.

Transform creates child asset.

Deletion uses retention policy and reference checks.

Scheduled/published assets cannot disappear before job terminal state.

Deduplicate by checksum where safe.
