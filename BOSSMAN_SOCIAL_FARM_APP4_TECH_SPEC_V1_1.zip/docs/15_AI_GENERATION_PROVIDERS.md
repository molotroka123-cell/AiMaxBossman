# AI generation provider contract

Provider categories:
TEXT
IMAGE
VIDEO.

Provider may be:
LOCAL
CLOUD
BOSSMAN_INTERNAL.

Capabilities:
- models;
- max input;
- supported edit modes;
- async/sync;
- expected output;
- cost estimate if available;
- health.

GenerationJob:
QUEUED
RUNNING
WAITING_PROVIDER
SUCCESS
FAILED
CANCELLED.

Provider outputs never publish directly.

ContentArtifact must pass media validation and policy first.

Local hardware adapters must expose resource reservation/health.
