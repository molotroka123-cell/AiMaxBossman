# Account registry

Scale target:
1–10 accounts.

Account fields:
- internal account_id;
- provider;
- provider_account_id;
- display handle;
- professional/business/creator/personal classification if known;
- auth_ref;
- browser_session_ref;
- timezone;
- locale;
- status;
- capability_snapshot;
- policy_profile_id;
- content_generation_profile_id;
- media_profile_id;
- rate_limit_bucket_id;
- webhook subscription state;
- last sync;
- health.

States:
PENDING_CONNECT
CONNECTED
DEGRADED
AUTH_EXPIRED
REQUIRES_REVIEW
BROWSER_ONLY
DISABLED
DISCONNECTED.

Account deletion:
must detach secrets and sessions using a separate confirmed destructive action.
