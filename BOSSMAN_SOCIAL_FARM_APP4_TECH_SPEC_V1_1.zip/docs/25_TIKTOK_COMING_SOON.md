# TikTok adapter — COMING SOON

No production TikTok implementation is required in Instagram V1.

Design the adapter boundary now.

Current official TikTok Content Posting APIs support, subject to app approval
and user authorization:
- Direct Post;
- draft/upload workflow;
- video;
- photo posting.

The official workflow includes provider scopes and app review/audit
requirements.

Future adapter responsibilities:
- OAuth/token;
- creator info;
- video/photo post;
- upload;
- publish status;
- webhooks;
- media constraints;
- rate limits.

Do not add browser-based TikTok automation in the Instagram V1 just because
the interface exists.
