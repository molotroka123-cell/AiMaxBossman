# Configuration

Config layers:
- environment/system;
- provider;
- account;
- generation provider;
- media;
- policy.

Environment examples:
DATABASE_URL
QUEUE_URL
MEDIA_STORE
PUBLIC_WEBHOOK_BASE_URL
SECRET_VAULT_BACKEND
BROWSER_WORKER_URL
FFMPEG_BIN.

Provider credentials use secret refs.

Do not make policy decisions environment-only; they need runtime versioned DB
configuration.
