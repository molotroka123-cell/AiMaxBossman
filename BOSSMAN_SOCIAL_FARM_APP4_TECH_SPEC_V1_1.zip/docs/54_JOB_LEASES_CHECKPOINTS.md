# Job leases, checkpoints and recovery

## Lease

Worker claims job by:
- lease_owner;
- lease_expires_at.

Lease renewed for long operations.

Another worker may reclaim only after expiry.

## Checkpoints

Examples:
VALIDATED
POLICY_EVALUATED
APPROVED
MEDIA_RENDERED
PROVIDER_CONTAINER_CREATED
UPLOAD_COMPLETE
PUBLISH_REQUEST_ACCEPTED
PUBLISH_STATUS_KNOWN
AUDIT_WRITTEN.

## Restart

If process dies:
- inspect checkpoint;
- inspect external ids;
- reconcile before replaying mutation.

## Unknown provider response

Example:
HTTP connection dies after publish request body sent.

Do NOT:
retry immediately.

Set:
UNKNOWN_EXTERNAL_STATE.

Then:
query provider using stored container/object/request id where possible.

Only if reconciliation proves no external effect may retry.

## Lease test

Test:
worker A dies after external effect but before DB final state.
Worker B must reconcile and not duplicate publish.
