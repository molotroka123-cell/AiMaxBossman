# Idempotency and external effects

Database transactions cannot guarantee exactly-once on external social
providers.

Use:
- deterministic idempotency keys;
- external provider ids;
- checkpoints;
- reconciliation;
- duplicate detection.

Example publish key:
account_id + content_revision_id + provider + scheduled_slot.

If network fails after provider accepted request:
do not immediately resend.

Mark UNKNOWN_EXTERNAL_STATE and reconcile.

A human retry creates a new explicit revision if desired.
