# Acceptance gates

App #4 implementation is not DONE unless:

1. provider-neutral core exists;
2. Instagram official adapter exists;
3. official capability detection exists;
4. 1–10 accounts isolated;
5. dynamic AUTO/ASK/DENY policy works;
6. policy version is audited;
7. secret vault boundary exists;
8. tokens/passwords absent from model-visible context;
9. durable jobs exist;
10. restart recovery exists;
11. external-effect idempotency/reconciliation exists;
12. scheduler exists;
13. content project/revision exists;
14. media asset library exists;
15. ffprobe/validation exists;
16. text generation adapter exists;
17. image generation adapter exists;
18. video generation adapter exists;
19. provider render profiles exist;
20. publish pipeline exists;
21. comments normalized;
22. messaging eligibility enforced;
23. webhooks verified/deduped;
24. insights normalized;
25. browser fallback isolated;
26. browser secret redaction works;
27. browser stale-target protection works;
28. human takeover exists;
29. no CAPTCHA/anti-detection/rate-limit bypass exists;
30. audit log exists;
31. health/observability exists;
32. mock E2E passes;
33. real API tests report exact capabilities;
34. unsupported capabilities are not presented as working;
35. failure injection passes;
36. BOSSMAN bridge works without provider secrets;
37. TikTok/future providers use registry/adapter contract;
38. docs implementation report distinguishes mock vs real;
39. CI passes;
40. no one-bit “full control” claim replaces capability matrix.
