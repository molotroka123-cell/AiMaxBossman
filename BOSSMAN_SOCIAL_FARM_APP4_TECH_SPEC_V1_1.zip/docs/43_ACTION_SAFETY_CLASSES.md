# Action safety classes

READ:
normally AUTO if account connected.

REVERSIBLE_WRITE:
e.g. scheduled draft update.
Policy configurable.

PUBLIC_PUBLISH:
AUTO/ASK configurable.

DIRECT_COMMUNICATION:
default ASK; account policy may change where provider/user flow permits.

MODERATION:
default ASK for destructive action.

DESTRUCTIVE:
delete/archive/profile mutation default ASK.

SECURITY:
password/MFA/ownership out of generic automation scope.

RELATIONSHIP/ENGAGEMENT:
capability and policy gated; no bulk/rate-limit evasion automation.

Each normalized capability declares safety class.
