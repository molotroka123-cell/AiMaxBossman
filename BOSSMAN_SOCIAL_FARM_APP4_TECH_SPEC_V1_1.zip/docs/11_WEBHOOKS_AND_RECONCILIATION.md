# Webhooks and reconciliation

Webhooks are preferred for inbound events where provider supports them.

Pipeline:
HTTP receive
→ signature verification
→ minimal durable append
→ immediate 2xx
→ async normalize
→ dedup
→ domain event.

Dedup key:
provider event id where available,
otherwise deterministic event fingerprint + time bucket.

Reconciliation periodically verifies:
- missed comments/messages;
- publish status;
- webhook subscription;
- insight freshness.

Webhooks and reconciliation may produce the same logical event.
Domain layer must merge idempotently.
