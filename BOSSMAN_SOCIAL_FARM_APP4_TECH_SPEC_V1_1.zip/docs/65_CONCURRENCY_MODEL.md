# Concurrency model

Initial 1–10 accounts.

## API

High concurrency for read routes/webhooks.

## Official provider workers

Per-account mutation concurrency:
default 1 for actions that can conflict.

Read operations may be parallel within provider governor.

## Browser worker

Default:
one active action per account context.

Global browser concurrency:
small bounded pool.

## Generation

Separate queue/pool due high CPU/GPU latency.

## Media transform

Separate resource class.

## Scheduler

Creates due jobs, does not execute provider calls inline.

## Locking

Use:
- job lease;
- account mutation semaphore;
- provider governor.

Do not use a single global lock.
