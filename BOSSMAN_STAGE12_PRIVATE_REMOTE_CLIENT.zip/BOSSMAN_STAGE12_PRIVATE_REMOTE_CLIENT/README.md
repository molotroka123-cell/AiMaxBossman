# BOSSMAN Stage 12 — Private Remote Client

Integration-ready Stage 12 package targeting the current `AiMaxBossman` Stage 6 remote backend.

What is included:
- scoped `/remote/tasks`, approvals-list, read-only agent catalog, session logout;
- installable same-origin iPhone PWA with authenticated SSE, tasks, approvals and emergency lock UI;
- local first-device bootstrap script using the existing Postgres device store;
- dependency-free Swift `BossmanRemoteKit` with portable tests;
- SwiftUI native client source using iOS Keychain;
- Stage 10 Claude prompt and Stage 11 GLM prompt so all three workstreams can run in parallel without overlapping ownership;
- security/install/API docs and bug-check script.

This package deliberately does NOT expose cloud-policy mutation, provider keys, tool/scope elevation, public model endpoints, git merge/push, or any bypass of existing approvals.
