# GLM 5.3 — Stage 11 AI Lab / Fine-Tuning App

Repo: `molotroka123-cell/AiMaxBossman`. Work ONLY on Stage 11. Claude owns Stage 10; another worker owns Stage 12. Do not refactor their modules.

Use the EXISTING Stage 8 trajectory + DatasetGate. Do not build another memory, dataset store, gateway, scheduler, or sandbox.

Goal: a local-first AI Lab application that lets the owner inspect trajectories, build sanitized dataset candidates, run deterministic eval sets, compare model outputs, approve/reject samples, and export training-ready SFT/DPO files. Actual GPU fine-tuning is an optional adapter, OFF by default.

P0 requirements:
- raw trajectory can NEVER become training data directly;
- sanitize secrets/PII-like identifiers before candidate creation;
- explicit human approval before export/training;
- provenance on every sample: source trajectory/run, sanitizer version, validator result, approval identity/time;
- immutable raw source; edits create a derived candidate, never mutate raw logs;
- reject poisoned/empty/failed trajectories by default;
- bounded local eval runner via existing Gateway/Resource Brain; no mass paid API calls;
- UI/API for Trajectories, Candidates, Evals, Exports, Runs; no cloud-policy mutation;
- export JSONL for SFT and preference-pair JSONL for DPO only after gate;
- all training launch buttons disabled unless an explicit local adapter is configured and owner approves.

Cost control: mocks/fakes for tests; zero real paid model calls. Read only Stage 8 dataset/trajectory code + direct dependencies. Add `docs/context/STAGE11_STATUS.md`, concise WORKLOG, tests for raw->training bypass, secret redaction, provenance loss, duplicate candidate, approval revocation, malicious sample, export schema, and resource denial. Stop after the app/API and safe export pipeline work; do not start Stage 12/13.
