#!/usr/bin/env python3
from __future__ import annotations
import ast, json, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parent
errors=[]
for p in ROOT.rglob("*.py"):
    try: ast.parse(p.read_text(encoding="utf-8-sig"), filename=str(p))
    except Exception as e: errors.append(f"PY {p}: {e}")
for p in ROOT.rglob("*.json"):
    try: json.loads(p.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"JSON {p}: {e}")
for p in ROOT.rglob("*.webmanifest"):
    try: json.loads(p.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"MANIFEST {p}: {e}")
for p in [ROOT/'backend_patch/remote-app/app.js', ROOT/'backend_patch/remote-app/remote-core.mjs', ROOT/'backend_patch/remote-app/sw.js']:
    cp=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if cp.returncode: errors.append(f"JS {p}: {cp.stderr}")
# Security invariants by static assertion.
mobile=(ROOT/'backend_patch/bossman/remote_client/mobile_api.py').read_text(encoding='utf-8')
for forbidden in ['cloud_policy', 'api_key', 'set_cloud_policy']:
    if forbidden in mobile and forbidden != 'cloud_policy': errors.append(f"forbidden backend symbol present: {forbidden}")
if 'payload' in mobile and 'allowed = {"id", "agent", "kind", "preview"' not in mobile:
    errors.append('approval payload allowlist invariant not obvious')
print("BUG_CHECK: PASS" if not errors else "BUG_CHECK: FAIL")
for e in errors: print(e)
sys.exit(1 if errors else 0)
