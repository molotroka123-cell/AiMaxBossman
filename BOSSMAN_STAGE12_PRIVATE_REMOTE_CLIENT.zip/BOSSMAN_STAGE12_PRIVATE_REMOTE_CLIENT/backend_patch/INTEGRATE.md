# Backend integration (current HEAD compatible)

1. Copy `bossman/remote_client/mobile_api.py` to `bossman-core/bossman/remote_client/mobile_api.py`.
2. Copy `remote-app/` to `bossman-core/remote-app/`.
3. Copy tests to `bossman-core/tests/test_stage12_mobile_api.py`.
4. In `bossman-core/bossman/remote_client/__init__.py`, immediately after `from .router import router`, add:

```python
from .mobile_api import router as _mobile_router
router.include_router(_mobile_router)
```

No changes to `bossman/api.py` are required: it already includes the Stage 6 `remote_client.router`.

Run:

```bash
cd bossman-core
python -m pytest tests/test_stage12_mobile_api.py tests/test_remote_client*.py -q
```

Bootstrap first owner device locally:

```bash
python ../backend_patch/scripts/bootstrap_remote_device.py --name owner-iphone
```

Then expose Core **only** through private HTTPS/Tailscale and open:

`https://<private-host>/remote/app`

On iPhone Safari: Share → Add to Home Screen.
