# Stage 12 security model

- Deploy only behind private HTTPS (Tailscale Serve / WireGuard reverse proxy). Do not publish Bossman Core or model backends directly to the public internet.
- Stage 6 scope checks remain authoritative on every data/action route.
- The PWA never persists the device token. It exchanges it for a revocable session token and keeps that token in `sessionStorage`. The native iOS client stores only the session token in Keychain with `WhenUnlockedThisDeviceOnly`.
- Static PWA shell has a restrictive CSP and no external scripts, fonts, analytics, or CDNs. Service Worker caches only `/remote/app*`; authenticated `/remote/*` API traffic is never cached.
- Approval listing omits raw `payload` and redacts secret-like preview content.
- Chat-only devices cannot approve, administer, elevate scopes, or mutate cloud policy.
- Emergency `lock all` remains Stage 6 admin-gated and fail-closed.
- Native client rejects non-HTTPS except the portable API kit can explicitly allow localhost for development.

Remaining deployment gate: the host/private tunnel configuration itself must be audited. This package cannot prove the operator's Tailscale/WireGuard ACLs from an offline build environment.
