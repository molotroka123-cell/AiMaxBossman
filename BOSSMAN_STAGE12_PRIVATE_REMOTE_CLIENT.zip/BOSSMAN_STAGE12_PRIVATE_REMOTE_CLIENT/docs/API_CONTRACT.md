# Stage 12 API contract

Reuses Stage 6 bearer device/session authentication and scopes.

Existing endpoints used:
- `POST /remote/auth` — device token -> one-time session token
- `GET /remote/whoami`
- `GET /remote/events` — authenticated SSE
- `POST /remote/approvals/{id}` — approve scope
- `POST /remote/lock` — admin scope

Stage 12 additions:
- `POST /remote/tasks` — chat; creates a task with source `remote:<device_id>`
- `GET /remote/tasks` — chat; non-admin sees own device tasks, admin sees all
- `GET /remote/tasks/{id}` — same ownership rule
- `GET /remote/approvals` — approve; sanitized preview only, never raw payload
- `GET /remote/agents` — chat; read-only name/title/model
- `POST /remote/session/logout` — revokes current session
- `GET /remote/app` + allowlisted static assets — installable PWA shell

There is intentionally no route for cloud_policy, tool grants, provider keys, scope elevation, model backend configuration, git merge/push, or sandbox policy weakening.
