#!/usr/bin/env python3
"""Idempotent Stage 12 installer into an AiMaxBossman checkout.

Usage: python install_stage12.py /path/to/AiMaxBossman
It only adds Stage 12 files and a two-line include in remote_client/__init__.py.
Existing Stage 12 files are refused unless --force is supplied.
"""
from __future__ import annotations
import argparse, pathlib, shutil, sys

HERE = pathlib.Path(__file__).resolve().parent
MARKER = "from .mobile_api import router as _mobile_router\nrouter.include_router(_mobile_router)\n"


def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument("repo", type=pathlib.Path); ap.add_argument("--force", action="store_true"); args=ap.parse_args()
    repo=args.repo.resolve(); core=repo/"bossman-core"; pkg=core/"bossman"/"remote_client"; init=pkg/"__init__.py"
    if not init.is_file(): print(f"ERROR: not an AiMaxBossman checkout: {init} missing", file=sys.stderr); return 2
    targets=[
        (HERE/"backend_patch/bossman/remote_client/mobile_api.py", pkg/"mobile_api.py"),
        (HERE/"backend_patch/tests/test_stage12_mobile_api.py", core/"tests"/"test_stage12_mobile_api.py"),
        (HERE/"backend_patch/scripts/bootstrap_remote_device.py", core/"scripts"/"bootstrap_remote_device.py"),
    ]
    for src,dst in targets:
        if dst.exists() and not args.force:
            print(f"ERROR: {dst} already exists (use --force only after reviewing diff)", file=sys.stderr); return 3
    appdst=core/"remote-app"
    if appdst.exists() and any(appdst.iterdir()) and not args.force:
        print(f"ERROR: {appdst} already contains files", file=sys.stderr); return 3
    for src,dst in targets:
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src,dst)
    appdst.mkdir(parents=True, exist_ok=True)
    for src in (HERE/"backend_patch/remote-app").iterdir(): shutil.copy2(src, appdst/src.name)
    text=init.read_text(encoding="utf-8-sig")
    if "from .mobile_api import router as _mobile_router" not in text:
        needle="from .router import router\n"
        if needle not in text: print("ERROR: expected remote_client router import not found; current HEAD changed", file=sys.stderr); return 4
        text=text.replace(needle, needle+MARKER, 1)
        init.write_text(text, encoding="utf-8")
    print("Stage 12 files installed. Review `git diff` before committing.")
    print("Run: cd bossman-core && python -m pytest tests/test_stage12_mobile_api.py tests/test_remote_client*.py -q")
    return 0

if __name__ == "__main__": raise SystemExit(main())
