# AiMaxBossman Fleet OS Foundation Drop-In

This package is the **foundation** for the stage after Organization Layer.

Core rule:

**Organization chooses WHO. Fleet chooses WHERE.**

It intentionally does not implement remote process transport, distributed consensus,
or a full multi-node agent runtime. Those should be integrated against the actual
AiMaxBossman repository and current Executive/Organization APIs.

Included foundations:
1. Fleet Control Plane
2. Node Registry
3. Capability/Resource Scheduler
4. Reservations & Leasing
5. Heartbeat / Watchdog
6. Distributed Resume primitives
7. Credential Broker authorization model
8. Privacy / Locality Router
9. Durable Work-Stealing queue primitive
10. Fleet Digital Twin

Preserve all V2/V3 action-truthfulness, permission and idempotency invariants.


## Complete foundation expansion

The package now includes the base 10 Fleet foundations plus a second wave of production primitives:
node transport contract, bounded retry/dead-letter handling, artifact verification, model residency,
resource admission, topology awareness, durable event journal, explainable placement and metrics.

Read:
- `docs/FLEET_STAGE_COMPLETE_SPEC.md`
- `docs/FLEET_10_INNOVATIONS.md`

This remains a repository-safe drop-in foundation: it does not fabricate remote execution that cannot
be validated without the live AiMaxBossman integration.
