# Fleet OS — 10 foundations

1. **Fleet Control Plane** — authoritative node/task/resource state.
2. **Node Agent contract** — small runtime adapter on each machine; actual transport is an integration task.
3. **Resource Scheduler** — place work by capabilities, RAM/GPU, load, locality and privacy.
4. **Reservations & Leasing** — prevent multiple missions from consuming the same constrained resource.
5. **Heartbeat / Watchdog** — detect stale/offline nodes and stop scheduling onto them.
6. **Distributed Mission Resume** — resume only safe unfinished steps; never repeat verified side effects.
7. **Credential Broker** — grants authorization without persisting secret values in Fleet memory.
8. **Privacy / Locality Router** — private work stays local; cloud gets minimized context only when policy allows.
9. **Work Stealing / Load Balancing** — idle nodes may claim durable eligible work.
10. **Fleet Digital Twin** — truthful snapshot of nodes, leases, load and active work for future control-plane UI.

These are foundations, not ceilings. The integration agent may improve or replace implementation details
when the live repository contains better primitives.
