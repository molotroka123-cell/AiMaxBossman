# Fleet OS — unified stage specification

## Purpose
Organization decides **who** should perform work. Fleet decides **where** it should run.

## Included in this package
- durable node registry and heartbeats
- capability/resource placement
- reservations and exclusive leasing
- safe restart/resume primitives
- privacy/locality policy
- credential authorization boundary
- durable work queue
- Fleet Digital Twin
- node transport protocol
- bounded retry classification/backoff
- dead-letter/quarantine persistence
- artifact identity/hash verification
- local model runtime/warmness primitives
- resource-budget admission primitives
- trusted topology/data-locality primitives
- deduplicated operational event journal
- explainable placement
- Fleet metrics foundation

## Deliberately not faked
Full remote execution transport, PKI, multi-machine artifact streaming, control-plane HA,
actual distributed consensus, cloud autoscaling and real model lifecycle drivers require integration
against the current AiMaxBossman repository and runtime environment.

## Definition of truth
Placement, lease, heartbeat, model readiness, manager approval and event records are **not**
real-world execution proof. Only the lower verified action contract may mark side effects complete.
