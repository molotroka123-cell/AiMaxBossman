# Future boundaries

Not fully implemented in this foundation:

- authenticated encrypted node transport
- remote process executor
- multi-node artifact transfer
- distributed consensus
- remote model lifecycle manager
- advanced work stealing eligibility
- high availability control-plane replication
- internet/cloud worker autoscaling

These require current repository/runtime knowledge. Do not fake them in a drop-in.
