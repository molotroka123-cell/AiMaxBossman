"""Template only.

Adapt this to the actual Organization Layer contract present in AiMaxBossman.
"""

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class OrganizationWorkRequest:
    task_id: str
    mission_id: str
    owner: str
    capability: Mapping[str, Any]
    priority: int = 50


def to_fleet_task(request: OrganizationWorkRequest):
    # Delayed import keeps this file usable as a template.
    from bcc.v5.fleet.models import FleetTask, requirement_from_mapping
    return FleetTask(
        task_id=request.task_id,
        mission_id=request.mission_id,
        organization_owner=request.owner,
        capability=requirement_from_mapping(request.capability),
        priority=request.priority,
    )
