# Manifest

| ZIP path | Target | Purpose |
|---|---|---|
| production/command-center/bcc/v5/fleet/models.py | command-center/bcc/v5/fleet/models.py | Fleet types |
| production/command-center/bcc/v5/fleet/store.py | command-center/bcc/v5/fleet/store.py | SQLite durable state |
| production/command-center/bcc/v5/fleet/registry.py | command-center/bcc/v5/fleet/registry.py | Node registry/heartbeat |
| production/command-center/bcc/v5/fleet/scheduler.py | command-center/bcc/v5/fleet/scheduler.py | Capability scheduler |
| production/command-center/bcc/v5/fleet/leases.py | command-center/bcc/v5/fleet/leases.py | Resource reservations |
| production/command-center/bcc/v5/fleet/health.py | command-center/bcc/v5/fleet/health.py | Watchdog foundation |
| production/command-center/bcc/v5/fleet/resume.py | command-center/bcc/v5/fleet/resume.py | Resume/idempotency |
| production/command-center/bcc/v5/fleet/privacy.py | command-center/bcc/v5/fleet/privacy.py | Locality/privacy policy |
| production/command-center/bcc/v5/fleet/credentials.py | command-center/bcc/v5/fleet/credentials.py | Credential authorization broker |
| production/command-center/bcc/v5/fleet/work_stealing.py | command-center/bcc/v5/fleet/work_stealing.py | Durable pull queue |
| production/command-center/bcc/v5/fleet/digital_twin.py | command-center/bcc/v5/fleet/digital_twin.py | Fleet state snapshot |
| production/command-center/bcc/v5/fleet/control_plane.py | command-center/bcc/v5/fleet/control_plane.py | Composition root |
| production/command-center/bcc/v5/fleet/bridge.py | command-center/bcc/v5/fleet/bridge.py | Organization/Fleet port |
| production/command-center/bcc/v5/fleet/events.py | command-center/bcc/v5/fleet/events.py | Event types |
| tests/command-center/tests/v5/fleet/test_fleet_foundation.py | command-center/tests/v5/fleet/test_fleet_foundation.py | Foundation tests |
| integration/organization_fleet_adapter.py | adapt manually | Integration template |
| scripts/validate_fleet_foundation.py | standalone | Drop-in validation |
| production/command-center/bcc/v5/fleet/node_agent.py | command-center/bcc/v5/fleet/node_agent.py | Remote node transport contract |
| production/command-center/bcc/v5/fleet/retry.py | command-center/bcc/v5/fleet/retry.py | Bounded retries/backoff |
| production/command-center/bcc/v5/fleet/dead_letter.py | command-center/bcc/v5/fleet/dead_letter.py | Durable failed-task quarantine |
| production/command-center/bcc/v5/fleet/artifacts.py | command-center/bcc/v5/fleet/artifacts.py | Artifact identity/hash verification |
| production/command-center/bcc/v5/fleet/model_runtime.py | command-center/bcc/v5/fleet/model_runtime.py | Local model residency primitives |
| production/command-center/bcc/v5/fleet/resource_accounting.py | command-center/bcc/v5/fleet/resource_accounting.py | Resource-budget admission |
| production/command-center/bcc/v5/fleet/topology.py | command-center/bcc/v5/fleet/topology.py | Trusted network/data locality |
| production/command-center/bcc/v5/fleet/event_journal.py | command-center/bcc/v5/fleet/event_journal.py | Durable event journal |
| production/command-center/bcc/v5/fleet/metrics.py | command-center/bcc/v5/fleet/metrics.py | Fleet observability counters |
| production/command-center/bcc/v5/fleet/placement_explain.py | command-center/bcc/v5/fleet/placement_explain.py | Explainable scheduling |
| tests/command-center/tests/v5/fleet/test_fleet_complete_extensions.py | command-center/tests/v5/fleet/test_fleet_complete_extensions.py | Expanded deterministic tests |
| docs/FLEET_10_INNOVATIONS.md | docs/FLEET_10_INNOVATIONS.md | Ten next-wave Fleet innovations |
| docs/FLEET_STAGE_COMPLETE_SPEC.md | docs/FLEET_STAGE_COMPLETE_SPEC.md | Unified stage specification |
