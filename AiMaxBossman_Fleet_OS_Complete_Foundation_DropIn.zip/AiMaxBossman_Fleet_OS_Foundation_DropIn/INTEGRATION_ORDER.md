# Integration order

1. Inspect current repository HEAD and current Executive/Organization Layer APIs.
2. Copy `production/command-center/bcc/v5/fleet/` into the corresponding source tree.
3. Copy/adapt the tests under `tests/.../v5/fleet/`.
4. Run targeted Fleet tests.
5. Adapt `integration/organization_fleet_adapter.py` to actual Organization Layer contracts.
6. Map existing V3 durable task-state receipts into `ExecutionCheckpoint` or replace this adapter with the repository-native type.
7. Connect actual node runtime/transport. Do not fake remote execution.
8. Add authenticated heartbeat ingestion and node registration.
9. Connect existing permission/governor/secret systems.
10. Run restart/idempotency E2E.
11. Run broader regression once targeted tests are green.
12. Secret scan and diff review.
13. Commit in coherent slices and push without force.

If the repository already has equivalent primitives, prefer adapters/refactors instead of duplicate subsystems.
