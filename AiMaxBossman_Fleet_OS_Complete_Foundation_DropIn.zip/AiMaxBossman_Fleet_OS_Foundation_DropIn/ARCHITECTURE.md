# Architecture

```text
USER
  ↓
CEO / Organization Layer
  ↓
Executive OS
  ↓
Organization chooses WHO
  ↓
Fleet Control Plane chooses WHERE
  ├─ Node Registry
  ├─ Scheduler
  ├─ Leases
  ├─ Health/Heartbeat
  ├─ Resume Planner
  ├─ Privacy Router
  ├─ Credential Broker
  ├─ Work Queue
  └─ Fleet Digital Twin
  ↓
Node Agent / Executor transport   [integration target]
  ↓
V3 durable task state
  ↓
V2 verified action engine
```

## Invariants

Fleet placement is not execution proof.

`PLACED != EXECUTED != VERIFIED`

The lower execution layer remains authoritative:

`SIDE_EFFECT_REQUIRED && VERIFIED_SIDE_EFFECT == FALSE -> TASK_SUCCESS == FALSE`

and:

`ANY_REQUIRED_CHILD_UNVERIFIED_OR_FAILED -> PARENT_SUCCESS == FALSE`
