# Test plan

Mandatory integration tests:

- capable node selected; incapable node rejected
- local/private routing honored
- expired/offline nodes not selected
- exclusive lease prevents double booking
- lease expiry permits future reuse
- restart preserves node/lease/checkpoint state
- verified side effect is not repeated after restart
- work item is claimed by at most one node
- credential grant does not persist secret material
- Digital Twin reflects durable truth
- lower V2/V3 verifier remains final authority
- node loss causes reassignment only for safe/resumable pending steps
- `DUPLICATE_SIDE_EFFECT_COUNT=0`


## Expanded foundation tests
- retry backoff is bounded and permission failures are non-retryable
- dead-letter queue persists across process restart
- event journal deduplicates repeated event IDs
- artifact hashes detect mutation/corruption
- warm model placement preference remains capability-gated
- resource budget blocks overage
- untrusted topology links are rejected for transfer scoring
- placement explanations expose deterministic rejection reasons
