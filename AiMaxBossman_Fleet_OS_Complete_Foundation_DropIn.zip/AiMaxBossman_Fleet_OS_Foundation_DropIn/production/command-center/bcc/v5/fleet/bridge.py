from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Any, Protocol

from .models import FleetTask, NodeState


class OrganizationFleetPort(Protocol):
    """Narrow integration port.

    Organization decides WHO should do the work.
    Fleet decides WHERE it should execute.
    """

    def schedule(self, task: FleetTask, now: float) -> "PlacementResult": ...


@dataclass(frozen=True)
class PlacementResult:
    task_id: str
    node_id: str | None
    status: str
    reason: str
    metadata: Mapping[str, Any]
