from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class SecretProvider(Protocol):
    def resolve(self, secret_id: str) -> str: ...


@dataclass(frozen=True)
class CredentialGrant:
    secret_id: str
    node_id: str
    capability: str
    expires_ts: float


class CredentialBroker:
    """Authorization-only broker.

    It deliberately does not persist secret material in Fleet state.
    Runtime integration should inject credentials directly into the approved
    executor environment or use an existing secret manager.
    """

    def __init__(self):
        self._grants: dict[tuple[str, str, str], CredentialGrant] = {}

    def grant(
        self,
        *,
        secret_id: str,
        node_id: str,
        capability: str,
        expires_ts: float,
    ) -> CredentialGrant:
        grant = CredentialGrant(secret_id, node_id, capability, expires_ts)
        self._grants[(secret_id, node_id, capability)] = grant
        return grant

    def authorized(
        self,
        *,
        secret_id: str,
        node_id: str,
        capability: str,
        now: float,
    ) -> bool:
        grant = self._grants.get((secret_id, node_id, capability))
        return bool(grant and grant.expires_ts > now)
