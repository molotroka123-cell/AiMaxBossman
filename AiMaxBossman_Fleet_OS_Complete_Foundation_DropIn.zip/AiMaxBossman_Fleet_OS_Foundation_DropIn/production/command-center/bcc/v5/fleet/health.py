from __future__ import annotations

from dataclasses import dataclass
from .registry import NodeRegistry


@dataclass(frozen=True)
class HealthResult:
    newly_offline: tuple[str, ...]


class HealthMonitor:
    def __init__(self, registry: NodeRegistry, heartbeat_timeout_seconds: float = 90.0):
        self.registry = registry
        self.heartbeat_timeout_seconds = heartbeat_timeout_seconds

    def evaluate(self, now: float) -> HealthResult:
        cutoff = now - self.heartbeat_timeout_seconds
        return HealthResult(tuple(self.registry.mark_offline_older_than(cutoff)))
