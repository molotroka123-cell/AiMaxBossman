from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class PrivacyDecision:
    allowed: bool
    reason: str
    context_policy: str


class PrivacyRouter:
    """Policy boundary before data leaves a node or local trust zone."""

    def decide(
        self,
        *,
        requested_privacy: str,
        target_privacy_level: str,
        contains_secrets: bool,
        allow_cloud_minimized_context: bool = False,
    ) -> PrivacyDecision:
        if contains_secrets and target_privacy_level not in {"PRIVATE", "LOCAL_ONLY"}:
            return PrivacyDecision(False, "secrets_must_stay_local", "NONE")
        if requested_privacy == "PRIVATE" and target_privacy_level not in {"PRIVATE", "LOCAL_ONLY"}:
            if allow_cloud_minimized_context and not contains_secrets:
                return PrivacyDecision(True, "cloud_allowed_with_minimized_context", "MINIMIZED")
            return PrivacyDecision(False, "private_task_requires_local_node", "NONE")
        return PrivacyDecision(True, "policy_allows_target", "FULL")
