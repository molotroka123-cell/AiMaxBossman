from __future__ import annotations

from dataclasses import replace
from .models import Heartbeat, NodeState, NodeStatus
from .store import FleetStore


class NodeRegistry:
    def __init__(self, store: FleetStore):
        self.store = store

    def register(self, node: NodeState) -> None:
        self.store.upsert_node(node)

    def heartbeat(self, hb: Heartbeat) -> NodeState:
        current = self.store.get_node(hb.node_id)
        if current is None:
            raise KeyError(f"unknown node: {hb.node_id}")
        updated = replace(
            current,
            load=max(0.0, min(1.0, hb.load)),
            status=hb.status,
            last_heartbeat_ts=hb.timestamp,
        )
        self.store.upsert_node(updated)
        return updated

    def mark_offline_older_than(self, cutoff_ts: float) -> list[str]:
        changed: list[str] = []
        for node in self.store.list_nodes():
            if node.last_heartbeat_ts < cutoff_ts and node.status != NodeStatus.OFFLINE:
                self.store.upsert_node(replace(node, status=NodeStatus.OFFLINE))
                changed.append(node.node_id)
        return changed
