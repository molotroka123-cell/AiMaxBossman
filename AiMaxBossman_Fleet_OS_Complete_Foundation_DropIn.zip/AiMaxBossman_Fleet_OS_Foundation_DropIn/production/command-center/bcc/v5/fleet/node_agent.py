from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol


@dataclass(frozen=True)
class NodeExecutionRequest:
    task_id: str
    mission_id: str
    capability: str
    idempotency_key: str
    payload_ref: str | None
    timeout_seconds: float
    metadata: Mapping[str, Any]


@dataclass(frozen=True)
class NodeExecutionResult:
    task_id: str
    node_id: str
    accepted: bool
    status: str
    execution_receipt_ref: str | None = None
    error: str | None = None


class NodeTransport(Protocol):
    """Transport abstraction only.

    Implementations must authenticate peers, encrypt transport, and return
    only execution receipts that lower V2/V3 verification can validate.
    """

    def dispatch(self, node_id: str, request: NodeExecutionRequest) -> NodeExecutionResult: ...

    def cancel(self, node_id: str, task_id: str) -> bool: ...

    def probe(self, node_id: str) -> bool: ...
