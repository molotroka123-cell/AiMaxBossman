from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Any


class FleetEventType(str, Enum):
    NODE_REGISTERED = "NODE_REGISTERED"
    NODE_OFFLINE = "NODE_OFFLINE"
    TASK_ASSIGNED = "TASK_ASSIGNED"
    TASK_BLOCKED = "TASK_BLOCKED"
    TASK_VERIFIED = "TASK_VERIFIED"
    LEASE_ACQUIRED = "LEASE_ACQUIRED"
    LEASE_RELEASED = "LEASE_RELEASED"


@dataclass(frozen=True)
class FleetEvent:
    event_id: str
    type: FleetEventType
    timestamp: float
    payload: Mapping[str, Any]
