from __future__ import annotations

from dataclasses import dataclass
from .models import FleetTask, NodeState
from .scheduler import FleetScheduler


@dataclass(frozen=True)
class PlacementExplanation:
    node_id: str
    eligible: bool
    score: float | None
    reasons: tuple[str, ...]


def explain_nodes(nodes: list[NodeState], task: FleetTask) -> list[PlacementExplanation]:
    out = []
    for node in nodes:
        ok, reasons = FleetScheduler.eligible(node, task.capability)
        out.append(
            PlacementExplanation(
                node_id=node.node_id,
                eligible=ok,
                score=FleetScheduler.score(node, task.capability) if ok else None,
                reasons=reasons,
            )
        )
    return sorted(out, key=lambda x: (not x.eligible, -(x.score or -10**9), x.node_id))
