from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FleetMetrics:
    placements: int = 0
    placement_failures: int = 0
    lease_conflicts: int = 0
    node_timeouts: int = 0
    resumed_tasks: int = 0
    duplicate_side_effect_preventions: int = 0

    def snapshot(self) -> dict[str, int]:
        return {
            "placements": self.placements,
            "placement_failures": self.placement_failures,
            "lease_conflicts": self.lease_conflicts,
            "node_timeouts": self.node_timeouts,
            "resumed_tasks": self.resumed_tasks,
            "duplicate_side_effect_preventions": self.duplicate_side_effect_preventions,
        }
