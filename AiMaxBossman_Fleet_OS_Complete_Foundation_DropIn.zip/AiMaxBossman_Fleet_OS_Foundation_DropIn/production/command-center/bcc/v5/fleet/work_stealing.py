from __future__ import annotations

from .store import FleetStore


class WorkStealingQueue:
    """Tiny durable pull queue foundation.

    Actual task eligibility MUST still be checked by scheduler/privacy/
    permission layers before execution.
    """

    def __init__(self, store: FleetStore):
        self.store = store

    def enqueue(self, task_id: str, priority: int, payload: dict) -> None:
        self.store.enqueue_work(task_id, priority, payload)

    def claim(self, node_id: str, now: float) -> dict | None:
        return self.store.claim_next_work(node_id, now)
