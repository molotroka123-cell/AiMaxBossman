from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True)
class DeadLetter:
    task_id: str
    mission_id: str
    reason: str
    attempts: int
    payload: Mapping[str, Any]
    created_ts: float


class DeadLetterStore:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS fleet_dead_letter (
                    task_id TEXT PRIMARY KEY,
                    mission_id TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    attempts INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    created_ts REAL NOT NULL
                )
                """
            )

    def put(self, item: DeadLetter) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO fleet_dead_letter VALUES(?,?,?,?,?,?)",
                (
                    item.task_id, item.mission_id, item.reason, item.attempts,
                    json.dumps(dict(item.payload), sort_keys=True), item.created_ts,
                ),
            )

    def list(self) -> list[DeadLetter]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT task_id,mission_id,reason,attempts,payload,created_ts "
                "FROM fleet_dead_letter ORDER BY created_ts"
            ).fetchall()
        return [
            DeadLetter(r[0], r[1], r[2], int(r[3]), json.loads(r[4]), float(r[5]))
            for r in rows
        ]
