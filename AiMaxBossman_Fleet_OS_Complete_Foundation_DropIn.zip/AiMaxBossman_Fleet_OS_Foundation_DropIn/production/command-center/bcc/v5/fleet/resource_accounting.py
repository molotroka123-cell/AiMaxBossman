from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class ResourceBudget:
    max_wall_seconds: float | None = None
    max_gpu_seconds: float | None = None
    max_cpu_seconds: float | None = None
    max_network_bytes: int | None = None
    max_cloud_cost_usd: float | None = None


@dataclass(frozen=True)
class ResourceUsage:
    wall_seconds: float = 0.0
    gpu_seconds: float = 0.0
    cpu_seconds: float = 0.0
    network_bytes: int = 0
    cloud_cost_usd: float = 0.0


@dataclass(frozen=True)
class BudgetDecision:
    allowed: bool
    exceeded: tuple[str, ...]


def check_budget(budget: ResourceBudget, usage: ResourceUsage) -> BudgetDecision:
    exceeded: list[str] = []
    if budget.max_wall_seconds is not None and usage.wall_seconds > budget.max_wall_seconds:
        exceeded.append("wall_seconds")
    if budget.max_gpu_seconds is not None and usage.gpu_seconds > budget.max_gpu_seconds:
        exceeded.append("gpu_seconds")
    if budget.max_cpu_seconds is not None and usage.cpu_seconds > budget.max_cpu_seconds:
        exceeded.append("cpu_seconds")
    if budget.max_network_bytes is not None and usage.network_bytes > budget.max_network_bytes:
        exceeded.append("network_bytes")
    if budget.max_cloud_cost_usd is not None and usage.cloud_cost_usd > budget.max_cloud_cost_usd:
        exceeded.append("cloud_cost_usd")
    return BudgetDecision(not exceeded, tuple(exceeded))
