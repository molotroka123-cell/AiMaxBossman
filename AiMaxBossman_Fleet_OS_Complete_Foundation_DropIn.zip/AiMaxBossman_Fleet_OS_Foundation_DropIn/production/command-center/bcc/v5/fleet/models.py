from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Mapping, Sequence


class VerificationState(str, Enum):
    UNVERIFIED = "UNVERIFIED"
    VERIFIED = "VERIFIED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"


class NodeStatus(str, Enum):
    ONLINE = "ONLINE"
    DEGRADED = "DEGRADED"
    OFFLINE = "OFFLINE"
    DRAINING = "DRAINING"


@dataclass(frozen=True)
class NodeState:
    node_id: str
    hostname: str
    os_name: str
    ram_gb: float
    gpu_memory_gb: float = 0.0
    gpu_name: str | None = None
    capabilities: tuple[str, ...] = ()
    models: tuple[str, ...] = ()
    labels: Mapping[str, str] = field(default_factory=dict)
    privacy_level: str = "PRIVATE"
    status: NodeStatus = NodeStatus.ONLINE
    load: float = 0.0
    last_heartbeat_ts: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["status"] = self.status.value
        out["labels"] = dict(self.labels)
        return out


@dataclass(frozen=True)
class CapabilityRequirement:
    capabilities: tuple[str, ...] = ()
    min_ram_gb: float = 0.0
    min_gpu_memory_gb: float = 0.0
    required_models: tuple[str, ...] = ()
    allowed_os: tuple[str, ...] = ()
    privacy: str = "PRIVATE"
    prefer_local: bool = True
    max_load: float = 1.0


@dataclass(frozen=True)
class FleetTask:
    task_id: str
    mission_id: str
    organization_owner: str
    capability: CapabilityRequirement
    priority: int = 50
    payload_ref: str | None = None
    verified_children: tuple[str, ...] = ()
    side_effect_required: bool = False


@dataclass(frozen=True)
class Lease:
    lease_id: str
    node_id: str
    task_id: str
    acquired_ts: float
    expires_ts: float
    resource_class: str
    exclusive: bool = True


@dataclass(frozen=True)
class Heartbeat:
    node_id: str
    timestamp: float
    load: float
    ram_used_gb: float = 0.0
    gpu_memory_used_gb: float = 0.0
    status: NodeStatus = NodeStatus.ONLINE


@dataclass(frozen=True)
class ExecutionCheckpoint:
    mission_id: str
    task_id: str
    step_id: str
    node_id: str | None
    verification: VerificationState
    idempotency_key: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    updated_ts: float = 0.0


def requirement_from_mapping(data: Mapping[str, Any]) -> CapabilityRequirement:
    return CapabilityRequirement(
        capabilities=tuple(data.get("capabilities", ())),
        min_ram_gb=float(data.get("min_ram_gb", 0.0)),
        min_gpu_memory_gb=float(data.get("min_gpu_memory_gb", 0.0)),
        required_models=tuple(data.get("required_models", ())),
        allowed_os=tuple(data.get("allowed_os", ())),
        privacy=str(data.get("privacy", "PRIVATE")),
        prefer_local=bool(data.get("prefer_local", True)),
        max_load=float(data.get("max_load", 1.0)),
    )
