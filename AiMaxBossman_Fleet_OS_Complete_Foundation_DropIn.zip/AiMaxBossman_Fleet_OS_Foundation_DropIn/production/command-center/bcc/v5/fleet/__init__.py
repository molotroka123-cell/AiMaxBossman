"""AiMaxBossman Fleet OS foundation.

Organization decides WHO should do work.
Fleet decides WHERE it should run.
"""

from .models import (
    NodeState,
    CapabilityRequirement,
    FleetTask,
    Lease,
    Heartbeat,
    VerificationState,
)
from .store import FleetStore
from .registry import NodeRegistry
from .scheduler import FleetScheduler
from .leases import LeaseManager
from .health import HealthMonitor
from .resume import ResumePlanner
from .privacy import PrivacyRouter
from .credentials import CredentialBroker
from .control_plane import FleetControlPlane

__all__ = [
    "NodeState",
    "CapabilityRequirement",
    "FleetTask",
    "Lease",
    "Heartbeat",
    "VerificationState",
    "FleetStore",
    "NodeRegistry",
    "FleetScheduler",
    "LeaseManager",
    "HealthMonitor",
    "ResumePlanner",
    "PrivacyRouter",
    "CredentialBroker",
    "FleetControlPlane",
]


from .node_agent import NodeExecutionRequest, NodeExecutionResult, NodeTransport
from .retry import RetryClass, RetryPolicy, classify_failure
from .dead_letter import DeadLetter, DeadLetterStore
from .artifacts import ArtifactDescriptor, describe_file, verify_file
from .model_runtime import ModelRuntime, ModelState, ModelPlacementPolicy
from .resource_accounting import ResourceBudget, ResourceUsage, BudgetDecision, check_budget
from .topology import NodeLink, Topology
from .event_journal import EventJournal
from .metrics import FleetMetrics
from .placement_explain import PlacementExplanation, explain_nodes
