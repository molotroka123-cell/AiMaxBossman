from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class RetryClass(str, Enum):
    NEVER = "NEVER"
    TRANSIENT = "TRANSIENT"
    BACKOFF = "BACKOFF"
    HUMAN_REQUIRED = "HUMAN_REQUIRED"


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 3
    base_delay_seconds: float = 2.0
    max_delay_seconds: float = 60.0

    def delay_for(self, attempt: int) -> float:
        if attempt <= 0:
            return 0.0
        return min(self.max_delay_seconds, self.base_delay_seconds * (2 ** (attempt - 1)))


def classify_failure(code: str) -> RetryClass:
    code = code.upper()
    if code in {"PERMISSION_DENIED", "INVALID_INPUT", "UNSAFE_ACTION"}:
        return RetryClass.NEVER
    if code in {"NODE_OFFLINE", "TIMEOUT", "TEMPORARY_UNAVAILABLE"}:
        return RetryClass.BACKOFF
    if code in {"APPROVAL_REQUIRED", "AMBIGUOUS_TARGET"}:
        return RetryClass.HUMAN_REQUIRED
    return RetryClass.TRANSIENT
