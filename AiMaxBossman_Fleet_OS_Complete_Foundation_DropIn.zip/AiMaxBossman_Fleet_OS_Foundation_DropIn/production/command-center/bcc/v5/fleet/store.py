from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .models import (
    ExecutionCheckpoint,
    Lease,
    NodeState,
    NodeStatus,
    VerificationState,
)


class FleetStore:
    """Minimal durable SQLite store for Fleet control-plane state."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS leases (
                    lease_id TEXT PRIMARY KEY,
                    node_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    acquired_ts REAL NOT NULL,
                    expires_ts REAL NOT NULL,
                    resource_class TEXT NOT NULL,
                    exclusive INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_leases_node ON leases(node_id);
                CREATE INDEX IF NOT EXISTS idx_leases_task ON leases(task_id);

                CREATE TABLE IF NOT EXISTS checkpoints (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mission_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    step_id TEXT NOT NULL,
                    node_id TEXT,
                    verification TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    payload TEXT NOT NULL,
                    updated_ts REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_cp_mission ON checkpoints(mission_id, task_id);

                CREATE TABLE IF NOT EXISTS work_queue (
                    task_id TEXT PRIMARY KEY,
                    priority INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    claimed_by TEXT,
                    claimed_ts REAL
                );
                """
            )

    def upsert_node(self, node: NodeState) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO nodes(node_id,payload) VALUES(?,?) "
                "ON CONFLICT(node_id) DO UPDATE SET payload=excluded.payload",
                (node.node_id, json.dumps(node.to_dict(), sort_keys=True)),
            )

    def list_nodes(self) -> list[NodeState]:
        with self._connect() as conn:
            rows = conn.execute("SELECT payload FROM nodes ORDER BY node_id").fetchall()
        out: list[NodeState] = []
        for row in rows:
            data = json.loads(row["payload"])
            out.append(
                NodeState(
                    node_id=data["node_id"],
                    hostname=data["hostname"],
                    os_name=data["os_name"],
                    ram_gb=float(data["ram_gb"]),
                    gpu_memory_gb=float(data.get("gpu_memory_gb", 0.0)),
                    gpu_name=data.get("gpu_name"),
                    capabilities=tuple(data.get("capabilities", ())),
                    models=tuple(data.get("models", ())),
                    labels=data.get("labels", {}),
                    privacy_level=data.get("privacy_level", "PRIVATE"),
                    status=NodeStatus(data.get("status", NodeStatus.ONLINE.value)),
                    load=float(data.get("load", 0.0)),
                    last_heartbeat_ts=float(data.get("last_heartbeat_ts", 0.0)),
                )
            )
        return out

    def get_node(self, node_id: str) -> NodeState | None:
        return next((n for n in self.list_nodes() if n.node_id == node_id), None)

    def save_lease(self, lease: Lease) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO leases VALUES(?,?,?,?,?,?,?)",
                (
                    lease.lease_id,
                    lease.node_id,
                    lease.task_id,
                    lease.acquired_ts,
                    lease.expires_ts,
                    lease.resource_class,
                    1 if lease.exclusive else 0,
                ),
            )

    def delete_lease(self, lease_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM leases WHERE lease_id=?", (lease_id,))

    def list_leases(self, node_id: str | None = None) -> list[Lease]:
        q = "SELECT * FROM leases"
        args: tuple[Any, ...] = ()
        if node_id is not None:
            q += " WHERE node_id=?"
            args = (node_id,)
        q += " ORDER BY acquired_ts"
        with self._connect() as conn:
            rows = conn.execute(q, args).fetchall()
        return [
            Lease(
                lease_id=r["lease_id"],
                node_id=r["node_id"],
                task_id=r["task_id"],
                acquired_ts=float(r["acquired_ts"]),
                expires_ts=float(r["expires_ts"]),
                resource_class=r["resource_class"],
                exclusive=bool(r["exclusive"]),
            )
            for r in rows
        ]

    def remove_expired_leases(self, now: float) -> int:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM leases WHERE expires_ts<=?", (now,))
            return int(cur.rowcount)

    def save_checkpoint(self, cp: ExecutionCheckpoint) -> bool:
        """Insert once by idempotency key. Returns False if already recorded."""
        with self._connect() as conn:
            try:
                conn.execute(
                    """
                    INSERT INTO checkpoints(
                        mission_id,task_id,step_id,node_id,verification,
                        idempotency_key,payload,updated_ts
                    ) VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (
                        cp.mission_id, cp.task_id, cp.step_id, cp.node_id,
                        cp.verification.value, cp.idempotency_key,
                        json.dumps(dict(cp.payload), sort_keys=True),
                        cp.updated_ts,
                    ),
                )
            except sqlite3.IntegrityError:
                return False
        return True

    def list_checkpoints(self, mission_id: str, task_id: str) -> list[ExecutionCheckpoint]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM checkpoints WHERE mission_id=? AND task_id=? ORDER BY id",
                (mission_id, task_id),
            ).fetchall()
        return [
            ExecutionCheckpoint(
                mission_id=r["mission_id"],
                task_id=r["task_id"],
                step_id=r["step_id"],
                node_id=r["node_id"],
                verification=VerificationState(r["verification"]),
                idempotency_key=r["idempotency_key"],
                payload=json.loads(r["payload"]),
                updated_ts=float(r["updated_ts"]),
            )
            for r in rows
        ]

    def enqueue_work(self, task_id: str, priority: int, payload: dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO work_queue(task_id,priority,payload,claimed_by,claimed_ts) "
                "VALUES(?,?,?,?,?)",
                (task_id, priority, json.dumps(payload, sort_keys=True), None, None),
            )

    def claim_next_work(self, node_id: str, now: float) -> dict[str, Any] | None:
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT task_id,payload FROM work_queue "
                "WHERE claimed_by IS NULL ORDER BY priority DESC, task_id LIMIT 1"
            ).fetchone()
            if row is None:
                conn.commit()
                return None
            conn.execute(
                "UPDATE work_queue SET claimed_by=?, claimed_ts=? WHERE task_id=?",
                (node_id, now, row["task_id"]),
            )
            conn.commit()
            return {"task_id": row["task_id"], "payload": json.loads(row["payload"])}
