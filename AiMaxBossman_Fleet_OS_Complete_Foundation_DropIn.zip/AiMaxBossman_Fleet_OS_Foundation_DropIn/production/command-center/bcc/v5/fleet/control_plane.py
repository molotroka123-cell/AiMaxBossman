from __future__ import annotations

from dataclasses import replace

from .bridge import PlacementResult
from .credentials import CredentialBroker
from .digital_twin import FleetDigitalTwin
from .health import HealthMonitor
from .leases import LeaseConflict, LeaseManager
from .models import FleetTask, NodeState
from .privacy import PrivacyRouter
from .registry import NodeRegistry
from .resume import ResumePlanner
from .scheduler import FleetScheduler
from .store import FleetStore
from .work_stealing import WorkStealingQueue


class FleetControlPlane:
    """Composes Fleet foundation primitives.

    This class only places/reserves work. It does not claim that a real-world
    side effect occurred; lower V2/V3 execution verification remains authoritative.
    """

    def __init__(self, db_path):
        self.store = FleetStore(db_path)
        self.registry = NodeRegistry(self.store)
        self.scheduler = FleetScheduler(self.store)
        self.leases = LeaseManager(self.store)
        self.health = HealthMonitor(self.registry)
        self.resume = ResumePlanner(self.store)
        self.privacy = PrivacyRouter()
        self.credentials = CredentialBroker()
        self.work = WorkStealingQueue(self.store)
        self.twin = FleetDigitalTwin(self.store)

    def register_node(self, node: NodeState) -> None:
        self.registry.register(node)

    def schedule(
        self,
        task: FleetTask,
        now: float,
        *,
        lease_ttl_seconds: float = 120.0,
        resource_class: str = "default",
    ) -> PlacementResult:
        node = self.scheduler.choose_node(task)
        if node is None:
            return PlacementResult(
                task_id=task.task_id,
                node_id=None,
                status="CAPABILITY_UNAVAILABLE",
                reason="no_eligible_node",
                metadata={},
            )

        privacy = self.privacy.decide(
            requested_privacy=task.capability.privacy,
            target_privacy_level=node.privacy_level,
            contains_secrets=False,
        )
        if not privacy.allowed:
            return PlacementResult(
                task_id=task.task_id,
                node_id=None,
                status="BLOCKED",
                reason=privacy.reason,
                metadata={"candidate_node": node.node_id},
            )

        try:
            lease = self.leases.acquire(
                node_id=node.node_id,
                task_id=task.task_id,
                now=now,
                ttl_seconds=lease_ttl_seconds,
                resource_class=resource_class,
                exclusive=True,
            )
        except LeaseConflict:
            return PlacementResult(
                task_id=task.task_id,
                node_id=None,
                status="BLOCKED",
                reason="resource_leased",
                metadata={"candidate_node": node.node_id},
            )

        return PlacementResult(
            task_id=task.task_id,
            node_id=node.node_id,
            status="PLACED",
            reason="eligible_node_reserved",
            metadata={
                "lease_id": lease.lease_id,
                "lease_expires_ts": lease.expires_ts,
                "context_policy": privacy.context_policy,
            },
        )
