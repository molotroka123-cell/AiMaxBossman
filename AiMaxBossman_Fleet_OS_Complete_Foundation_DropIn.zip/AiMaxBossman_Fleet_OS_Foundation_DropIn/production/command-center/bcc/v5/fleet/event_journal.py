from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Iterable

from .events import FleetEvent, FleetEventType


class EventJournal:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS fleet_events (
                    event_id TEXT PRIMARY KEY,
                    type TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    payload TEXT NOT NULL
                )
                """
            )

    def append(self, event: FleetEvent) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            try:
                conn.execute(
                    "INSERT INTO fleet_events(event_id,type,timestamp,payload) VALUES(?,?,?,?)",
                    (
                        event.event_id, event.type.value, event.timestamp,
                        json.dumps(dict(event.payload), sort_keys=True),
                    ),
                )
            except sqlite3.IntegrityError:
                return False
        return True

    def list(self) -> list[FleetEvent]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT event_id,type,timestamp,payload FROM fleet_events ORDER BY timestamp,event_id"
            ).fetchall()
        return [
            FleetEvent(r[0], FleetEventType(r[1]), float(r[2]), json.loads(r[3]))
            for r in rows
        ]
