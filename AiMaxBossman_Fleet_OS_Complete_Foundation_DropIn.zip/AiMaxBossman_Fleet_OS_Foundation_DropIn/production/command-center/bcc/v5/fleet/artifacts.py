from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class ArtifactDescriptor:
    artifact_id: str
    sha256: str
    size_bytes: int
    media_type: str
    privacy: str = "PRIVATE"


def describe_file(path: str | Path, *, artifact_id: str, media_type: str) -> ArtifactDescriptor:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return ArtifactDescriptor(
        artifact_id=artifact_id,
        sha256=h.hexdigest(),
        size_bytes=p.stat().st_size,
        media_type=media_type,
    )


def verify_file(path: str | Path, expected_sha256: str) -> bool:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest() == expected_sha256
