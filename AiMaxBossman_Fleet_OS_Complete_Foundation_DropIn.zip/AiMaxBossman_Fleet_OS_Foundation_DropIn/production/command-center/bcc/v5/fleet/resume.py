from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .models import ExecutionCheckpoint, VerificationState
from .store import FleetStore


@dataclass(frozen=True)
class MissionStep:
    step_id: str
    idempotency_key: str
    safe_to_resume: bool = True


class ResumePlanner:
    """Find first incomplete safe step without replaying verified side effects."""

    def __init__(self, store: FleetStore):
        self.store = store

    def next_step(
        self,
        *,
        mission_id: str,
        task_id: str,
        steps: Iterable[MissionStep],
    ) -> MissionStep | None:
        checkpoints = self.store.list_checkpoints(mission_id, task_id)
        verified_keys = {
            cp.idempotency_key
            for cp in checkpoints
            if cp.verification == VerificationState.VERIFIED
        }
        for step in steps:
            if step.idempotency_key in verified_keys:
                continue
            if not step.safe_to_resume:
                return None
            return step
        return None
