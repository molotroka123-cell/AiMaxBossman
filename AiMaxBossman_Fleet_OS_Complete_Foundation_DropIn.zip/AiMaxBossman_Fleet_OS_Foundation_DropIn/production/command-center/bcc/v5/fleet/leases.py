from __future__ import annotations

import uuid
from .models import Lease
from .store import FleetStore


class LeaseConflict(RuntimeError):
    pass


class LeaseManager:
    def __init__(self, store: FleetStore):
        self.store = store

    def acquire(
        self,
        *,
        node_id: str,
        task_id: str,
        now: float,
        ttl_seconds: float,
        resource_class: str = "default",
        exclusive: bool = True,
    ) -> Lease:
        self.store.remove_expired_leases(now)
        active = self.store.list_leases(node_id)
        if exclusive and any(l.exclusive and l.resource_class == resource_class for l in active):
            raise LeaseConflict(f"resource already leased on {node_id}: {resource_class}")
        lease = Lease(
            lease_id=str(uuid.uuid4()),
            node_id=node_id,
            task_id=task_id,
            acquired_ts=now,
            expires_ts=now + ttl_seconds,
            resource_class=resource_class,
            exclusive=exclusive,
        )
        self.store.save_lease(lease)
        return lease

    def release(self, lease_id: str) -> None:
        self.store.delete_lease(lease_id)
