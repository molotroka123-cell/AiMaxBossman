from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ModelState(str, Enum):
    UNAVAILABLE = "UNAVAILABLE"
    COLD = "COLD"
    LOADING = "LOADING"
    READY = "READY"
    BUSY = "BUSY"
    ERROR = "ERROR"


@dataclass(frozen=True)
class ModelRuntime:
    node_id: str
    model_id: str
    state: ModelState
    memory_gb: float
    context_limit: int | None = None
    capabilities: tuple[str, ...] = ()
    last_used_ts: float = 0.0


class ModelPlacementPolicy:
    """Simple deterministic preference for already-warm compatible models."""

    @staticmethod
    def score(runtime: ModelRuntime, required_capability: str) -> float:
        if required_capability not in runtime.capabilities:
            return float("-inf")
        state_bonus = {
            ModelState.READY: 100.0,
            ModelState.BUSY: 20.0,
            ModelState.COLD: 5.0,
            ModelState.LOADING: 0.0,
            ModelState.ERROR: -1000.0,
            ModelState.UNAVAILABLE: -1000.0,
        }[runtime.state]
        return state_bonus - runtime.memory_gb * 0.05
