from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class NodeLink:
    source_node: str
    target_node: str
    latency_ms: float
    bandwidth_mbps: float
    trusted: bool = False


class Topology:
    def __init__(self):
        self._links: dict[tuple[str, str], NodeLink] = {}

    def upsert(self, link: NodeLink) -> None:
        self._links[(link.source_node, link.target_node)] = link

    def get(self, source: str, target: str) -> NodeLink | None:
        return self._links.get((source, target))

    def transfer_score(self, source: str, target: str, bytes_to_move: int) -> float:
        if source == target:
            return 1000.0
        link = self.get(source, target)
        if link is None or not link.trusted:
            return float("-inf")
        size_mb = bytes_to_move / (1024 * 1024)
        transfer_ms = (size_mb * 8 / max(link.bandwidth_mbps, 0.001)) * 1000
        return -(link.latency_ms + transfer_ms)
