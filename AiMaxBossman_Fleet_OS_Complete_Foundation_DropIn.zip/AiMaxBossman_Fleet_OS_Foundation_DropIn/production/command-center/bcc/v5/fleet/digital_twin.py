from __future__ import annotations

from dataclasses import asdict
from .store import FleetStore


class FleetDigitalTwin:
    def __init__(self, store: FleetStore):
        self.store = store

    def snapshot(self, now: float) -> dict:
        nodes = [n.to_dict() for n in self.store.list_nodes()]
        leases = [asdict(l) for l in self.store.list_leases()]
        return {
            "timestamp": now,
            "nodes": nodes,
            "leases": leases,
            "node_count": len(nodes),
            "online_nodes": sum(1 for n in nodes if n["status"] == "ONLINE"),
            "active_leases": len(leases),
        }
