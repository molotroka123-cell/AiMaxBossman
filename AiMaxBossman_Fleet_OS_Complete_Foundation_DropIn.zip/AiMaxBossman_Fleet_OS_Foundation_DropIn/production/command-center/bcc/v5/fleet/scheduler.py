from __future__ import annotations

from dataclasses import dataclass

from .models import CapabilityRequirement, FleetTask, NodeState, NodeStatus
from .store import FleetStore


@dataclass(frozen=True)
class NodeScore:
    node: NodeState
    score: float
    reasons: tuple[str, ...]


class FleetScheduler:
    """Deterministic capability/resource scheduler.

    Organization chooses WHO. Fleet chooses WHERE.
    """

    def __init__(self, store: FleetStore):
        self.store = store

    @staticmethod
    def eligible(node: NodeState, req: CapabilityRequirement) -> tuple[bool, tuple[str, ...]]:
        reasons: list[str] = []
        if node.status != NodeStatus.ONLINE:
            reasons.append("node_not_online")
        if node.ram_gb < req.min_ram_gb:
            reasons.append("insufficient_ram")
        if node.gpu_memory_gb < req.min_gpu_memory_gb:
            reasons.append("insufficient_gpu_memory")
        if req.allowed_os and node.os_name not in req.allowed_os:
            reasons.append("os_not_allowed")
        if any(c not in node.capabilities for c in req.capabilities):
            reasons.append("missing_capability")
        if any(m not in node.models for m in req.required_models):
            reasons.append("missing_model")
        if node.load > req.max_load:
            reasons.append("overloaded")
        if req.privacy == "PRIVATE" and node.privacy_level not in {"PRIVATE", "LOCAL_ONLY"}:
            reasons.append("privacy_mismatch")
        return (not reasons, tuple(reasons))

    @staticmethod
    def score(node: NodeState, req: CapabilityRequirement) -> float:
        # Favor low load, headroom and locality. Deterministic and transparent.
        ram_headroom = max(0.0, node.ram_gb - req.min_ram_gb)
        gpu_headroom = max(0.0, node.gpu_memory_gb - req.min_gpu_memory_gb)
        local_bonus = 20.0 if node.privacy_level in {"PRIVATE", "LOCAL_ONLY"} else 0.0
        model_bonus = 5.0 * len(set(req.required_models).intersection(node.models))
        return (
            (1.0 - node.load) * 100.0
            + min(ram_headroom, 128.0) * 0.25
            + min(gpu_headroom, 128.0) * 0.5
            + local_bonus
            + model_bonus
        )

    def candidates(self, task: FleetTask) -> list[NodeScore]:
        result: list[NodeScore] = []
        for node in self.store.list_nodes():
            ok, reasons = self.eligible(node, task.capability)
            if ok:
                result.append(NodeScore(node, self.score(node, task.capability), reasons))
        result.sort(key=lambda x: (-x.score, x.node.node_id))
        return result

    def choose_node(self, task: FleetTask) -> NodeState | None:
        candidates = self.candidates(task)
        return candidates[0].node if candidates else None
