from pathlib import Path
import sys

HERE = Path(__file__).resolve()
DROPIN = HERE.parents[5]
PROD = DROPIN / "production" / "command-center"
sys.path.insert(0, str(PROD))

from bcc.v5.fleet.artifacts import describe_file, verify_file
from bcc.v5.fleet.dead_letter import DeadLetter, DeadLetterStore
from bcc.v5.fleet.event_journal import EventJournal
from bcc.v5.fleet.events import FleetEvent, FleetEventType
from bcc.v5.fleet.model_runtime import ModelPlacementPolicy, ModelRuntime, ModelState
from bcc.v5.fleet.placement_explain import explain_nodes
from bcc.v5.fleet.resource_accounting import ResourceBudget, ResourceUsage, check_budget
from bcc.v5.fleet.retry import RetryClass, RetryPolicy, classify_failure
from bcc.v5.fleet.topology import NodeLink, Topology
from bcc.v5.fleet.models import CapabilityRequirement, FleetTask, NodeState


def test_retry_policy_is_bounded():
    p = RetryPolicy(max_attempts=3, base_delay_seconds=2, max_delay_seconds=5)
    assert p.delay_for(1) == 2
    assert p.delay_for(10) == 5
    assert classify_failure("PERMISSION_DENIED") == RetryClass.NEVER
    assert classify_failure("NODE_OFFLINE") == RetryClass.BACKOFF


def test_dead_letter_is_durable(tmp_path):
    db = tmp_path / "fleet.sqlite3"
    s = DeadLetterStore(db)
    s.put(DeadLetter("t1", "m1", "exhausted", 3, {"x": 1}, 10.0))
    again = DeadLetterStore(db)
    items = again.list()
    assert len(items) == 1
    assert items[0].task_id == "t1"
    assert items[0].attempts == 3


def test_event_journal_deduplicates(tmp_path):
    db = tmp_path / "fleet.sqlite3"
    j = EventJournal(db)
    ev = FleetEvent("e1", FleetEventType.NODE_REGISTERED, 1.0, {"node_id": "n1"})
    assert j.append(ev) is True
    assert j.append(ev) is False
    assert len(j.list()) == 1


def test_artifact_hash_verification(tmp_path):
    f = tmp_path / "x.bin"
    f.write_bytes(b"hello")
    d = describe_file(f, artifact_id="a1", media_type="application/octet-stream")
    assert d.size_bytes == 5
    assert verify_file(f, d.sha256)
    f.write_bytes(b"changed")
    assert not verify_file(f, d.sha256)


def test_model_policy_prefers_warm_ready():
    ready = ModelRuntime("n1", "m", ModelState.READY, 20, capabilities=("reasoning",))
    cold = ModelRuntime("n2", "m", ModelState.COLD, 20, capabilities=("reasoning",))
    assert ModelPlacementPolicy.score(ready, "reasoning") > ModelPlacementPolicy.score(cold, "reasoning")
    assert ModelPlacementPolicy.score(ready, "vision") == float("-inf")


def test_resource_budget_blocks_overage():
    b = ResourceBudget(max_gpu_seconds=100, max_cloud_cost_usd=2)
    u = ResourceUsage(gpu_seconds=101, cloud_cost_usd=1)
    d = check_budget(b, u)
    assert not d.allowed
    assert d.exceeded == ("gpu_seconds",)


def test_topology_rejects_untrusted_link():
    topo = Topology()
    topo.upsert(NodeLink("a", "b", latency_ms=2, bandwidth_mbps=1000, trusted=False))
    assert topo.transfer_score("a", "b", 100) == float("-inf")
    topo.upsert(NodeLink("a", "b", latency_ms=2, bandwidth_mbps=1000, trusted=True))
    assert topo.transfer_score("a", "b", 100) < 0


def test_placement_explanation_is_truthful():
    nodes = [
        NodeState("good", "good", "Linux", 128, 64, capabilities=("vision",), privacy_level="PRIVATE", load=0.1),
        NodeState("bad", "bad", "Linux", 8, 0, capabilities=("terminal",), privacy_level="PRIVATE", load=0.1),
    ]
    task = FleetTask(
        "t", "m", "Research",
        CapabilityRequirement(capabilities=("vision",), min_ram_gb=32, min_gpu_memory_gb=16)
    )
    result = explain_nodes(nodes, task)
    assert result[0].node_id == "good"
    assert result[0].eligible
    bad = [x for x in result if x.node_id == "bad"][0]
    assert not bad.eligible
    assert "missing_capability" in bad.reasons
