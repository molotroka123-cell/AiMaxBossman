from pathlib import Path
import sys
import tempfile

HERE = Path(__file__).resolve()
DROPIN = HERE.parents[5]
PROD = DROPIN / "production" / "command-center"
sys.path.insert(0, str(PROD))

from bcc.v5.fleet.control_plane import FleetControlPlane
from bcc.v5.fleet.models import (
    CapabilityRequirement,
    ExecutionCheckpoint,
    FleetTask,
    Heartbeat,
    NodeState,
    NodeStatus,
    VerificationState,
)
from bcc.v5.fleet.resume import MissionStep


def make_plane(tmp_path):
    return FleetControlPlane(tmp_path / "fleet.sqlite3")


def test_scheduler_prefers_capable_low_load_local_node(tmp_path):
    cp = make_plane(tmp_path)
    cp.register_node(NodeState(
        node_id="local-ai-max",
        hostname="aimax",
        os_name="Windows",
        ram_gb=128,
        gpu_memory_gb=96,
        capabilities=("llm", "vision"),
        models=("local-strong",),
        privacy_level="LOCAL_ONLY",
        load=0.2,
    ))
    cp.register_node(NodeState(
        node_id="busy-node",
        hostname="busy",
        os_name="Linux",
        ram_gb=128,
        gpu_memory_gb=96,
        capabilities=("llm", "vision"),
        models=("local-strong",),
        privacy_level="PRIVATE",
        load=0.9,
    ))
    task = FleetTask(
        task_id="t1",
        mission_id="m1",
        organization_owner="Engineering",
        capability=CapabilityRequirement(
            capabilities=("vision",),
            min_ram_gb=64,
            min_gpu_memory_gb=32,
            required_models=("local-strong",),
            privacy="PRIVATE",
        ),
    )
    result = cp.schedule(task, now=100.0)
    assert result.status == "PLACED"
    assert result.node_id == "local-ai-max"


def test_capability_unavailable_is_truthful(tmp_path):
    cp = make_plane(tmp_path)
    cp.register_node(NodeState(
        node_id="small",
        hostname="small",
        os_name="Windows",
        ram_gb=16,
        capabilities=("terminal",),
        privacy_level="LOCAL_ONLY",
    ))
    task = FleetTask(
        task_id="t2",
        mission_id="m2",
        organization_owner="Research",
        capability=CapabilityRequirement(capabilities=("vision",), min_ram_gb=64),
    )
    result = cp.schedule(task, now=1.0)
    assert result.status == "CAPABILITY_UNAVAILABLE"
    assert result.node_id is None


def test_exclusive_lease_blocks_double_booking(tmp_path):
    cp = make_plane(tmp_path)
    cp.register_node(NodeState(
        node_id="n1", hostname="n1", os_name="Linux", ram_gb=128,
        capabilities=("llm",), privacy_level="PRIVATE", load=0.0,
    ))
    req = CapabilityRequirement(capabilities=("llm",))
    t1 = FleetTask("t1", "m1", "Engineering", req)
    t2 = FleetTask("t2", "m1", "Research", req)
    assert cp.schedule(t1, now=0.0, resource_class="gpu").status == "PLACED"
    result = cp.schedule(t2, now=1.0, resource_class="gpu")
    assert result.status == "BLOCKED"
    assert result.reason == "resource_leased"


def test_heartbeat_timeout_marks_node_offline(tmp_path):
    cp = make_plane(tmp_path)
    cp.register_node(NodeState(
        node_id="n1", hostname="n1", os_name="Linux", ram_gb=32,
        privacy_level="PRIVATE", last_heartbeat_ts=0.0,
    ))
    result = cp.health.evaluate(now=200.0)
    assert "n1" in result.newly_offline
    assert cp.store.get_node("n1").status == NodeStatus.OFFLINE


def test_resume_skips_verified_side_effect(tmp_path):
    cp = make_plane(tmp_path)
    checkpoint = ExecutionCheckpoint(
        mission_id="m1",
        task_id="t1",
        step_id="edit",
        node_id="n1",
        verification=VerificationState.VERIFIED,
        idempotency_key="edit:file:x",
        payload={"proof": "hash"},
        updated_ts=1.0,
    )
    assert cp.store.save_checkpoint(checkpoint) is True
    assert cp.store.save_checkpoint(checkpoint) is False  # durable dedup
    steps = [
        MissionStep("edit", "edit:file:x"),
        MissionStep("test", "test:unit:x"),
        MissionStep("commit", "git:commit:x"),
    ]
    next_step = cp.resume.next_step(mission_id="m1", task_id="t1", steps=steps)
    assert next_step.step_id == "test"


def test_private_task_rejects_cloud_node(tmp_path):
    cp = make_plane(tmp_path)
    cp.register_node(NodeState(
        node_id="cloud", hostname="cloud", os_name="Linux", ram_gb=128,
        capabilities=("llm",), privacy_level="CLOUD", load=0.0,
    ))
    task = FleetTask(
        task_id="t", mission_id="m", organization_owner="Business",
        capability=CapabilityRequirement(capabilities=("llm",), privacy="PRIVATE"),
    )
    assert cp.schedule(task, now=0.0).status == "CAPABILITY_UNAVAILABLE"


def test_secret_grant_does_not_persist_secret_value(tmp_path):
    cp = make_plane(tmp_path)
    cp.credentials.grant(
        secret_id="github-token",
        node_id="n1",
        capability="github.push",
        expires_ts=100.0,
    )
    assert cp.credentials.authorized(
        secret_id="github-token",
        node_id="n1",
        capability="github.push",
        now=10.0,
    )
    raw_db = (tmp_path / "fleet.sqlite3").read_bytes()
    assert b"super-secret-value" not in raw_db


def test_work_queue_claim_is_single_owner(tmp_path):
    cp = make_plane(tmp_path)
    cp.work.enqueue("task-a", 100, {"kind": "research"})
    first = cp.work.claim("n1", now=1.0)
    second = cp.work.claim("n2", now=2.0)
    assert first["task_id"] == "task-a"
    assert second is None


def test_digital_twin_reports_truthful_state(tmp_path):
    cp = make_plane(tmp_path)
    cp.register_node(NodeState(
        node_id="n1", hostname="n1", os_name="Linux", ram_gb=64,
        privacy_level="PRIVATE",
    ))
    snap = cp.twin.snapshot(now=5.0)
    assert snap["node_count"] == 1
    assert snap["online_nodes"] == 1
    assert snap["active_leases"] == 0


def test_restart_uses_same_sqlite_state_and_no_duplicate_side_effect(tmp_path):
    db = tmp_path / "fleet.sqlite3"
    first = FleetControlPlane(db)
    cp = ExecutionCheckpoint(
        mission_id="m",
        task_id="t",
        step_id="mutate",
        node_id="n",
        verification=VerificationState.VERIFIED,
        idempotency_key="side-effect-001",
        payload={"side_effect_count": 1},
        updated_ts=1.0,
    )
    assert first.store.save_checkpoint(cp)

    # Simulated restart: new control plane, same durable DB.
    second = FleetControlPlane(db)
    steps = [
        MissionStep("mutate", "side-effect-001"),
        MissionStep("verify-next", "verification-002"),
    ]
    step = second.resume.next_step(mission_id="m", task_id="t", steps=steps)
    assert step.step_id == "verify-next"

    # Replaying same receipt is rejected by unique idempotency key.
    assert second.store.save_checkpoint(cp) is False
    stored = second.store.list_checkpoints("m", "t")
    assert len(stored) == 1
    assert stored[0].payload["side_effect_count"] == 1
