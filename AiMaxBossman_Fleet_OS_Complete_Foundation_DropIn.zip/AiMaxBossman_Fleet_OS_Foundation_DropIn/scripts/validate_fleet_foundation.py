from __future__ import annotations

import compileall
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

print("[1/3] compileall")
ok = compileall.compile_dir(ROOT / "production", quiet=1)
if not ok:
    raise SystemExit("FAIL: compileall")
print("PASS: compileall")

print("[2/3] secret-pattern check")
suspicious = []
secret_re = re.compile(r"(sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})")
for p in ROOT.rglob("*"):
    if p.is_file() and p.suffix in {".py", ".md", ".json", ".txt"}:
        text = p.read_text(encoding="utf-8", errors="ignore")
        if secret_re.search(text):
            suspicious.append(str(p.relative_to(ROOT)))
if suspicious:
    raise SystemExit(f"FAIL: suspicious secrets in {suspicious}")
print("PASS: secret-pattern check")

print("[3/3] pytest")
test_file = ROOT / "tests/command-center/tests/v5/fleet/test_fleet_foundation.py"
proc = subprocess.run([sys.executable, "-m", "pytest", "-q", str(test_file)], cwd=ROOT)
if proc.returncode != 0:
    raise SystemExit("FAIL: pytest")
print("PASS: pytest")
print("FLEET_FOUNDATION_VALIDATION=PASS")
