# Handoff

This package is deliberately a foundation, not a claim of complete distributed execution.

Integration agent should:
- inspect actual current repo APIs;
- reuse existing V3 storage/types when superior;
- preserve V2 execution truthfulness;
- add a real authenticated Node Agent transport only against repository truth;
- improve/refactor this drop-in freely where justified;
- avoid Kafka/Kubernetes/Redis unless demonstrated necessary.

Fable/Claude/GLM may improve this stage on their own engineering judgment.
Do not ask for approval for normal Fleet-stage improvements.
