# Security

- Fleet state must never persist raw API keys/tokens.
- CredentialBroker stores authorization grants only.
- Secret material should be injected by the existing trusted secret/runtime layer.
- Private tasks stay on PRIVATE/LOCAL_ONLY nodes unless explicit minimized-cloud policy exists.
- Organization managers do not bypass lower-level permission gates.
- A node being online does not imply it is authorized for every capability.
- Remote transport must authenticate node identity and encrypt traffic.
- Never treat heartbeat, placement, lease, or manager approval as execution evidence.
