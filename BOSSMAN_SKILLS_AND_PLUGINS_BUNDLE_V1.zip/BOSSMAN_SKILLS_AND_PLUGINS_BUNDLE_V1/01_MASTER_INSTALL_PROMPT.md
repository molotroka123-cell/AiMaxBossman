# MASTER INSTALL PROMPT — SKILLS + PLUGINS

Repository:
`molotroka123-cell/AiMaxBossman`

Branch:
`claude/bossman-control-v03-43igbk`

## MODE

`FEATURE FREEZE -> INTEGRATE -> VERIFY -> FIX P0/P1 -> FINAL BUG CHECK`

## SOURCE OF TRUTH

- fetch latest remote HEAD before work
- do not trust stale SHA from docs
- no force push
- if remote HEAD moves, fetch/rebase/merge safely before final push

## TASK

Integrate both folders from this bundle:
- `skills_pack/`
- `plugins_pack/`

Use their README, INTEGRATION_GUIDE, BUG_CHECK_PLAN and CLAUDE_INSTALL_PROMPT files as detailed sub-specs.

## ABSOLUTE ARCHITECTURE RULES

Do not create duplicate:
- Gateway
- approval engine
- policy engine
- event bus
- secret store
- Telegram transport
- browser subsystem
- Cost Governor

All integrations must reuse existing Bossman authorities.

## SECURITY

Unknown capability -> DENY.
Arbitrary shell -> DENY.
Reads -> ALLOW only with proper scopes.
Writes -> ASK.
Destructive actions -> ASK.
Secrets -> references only.
No raw credential values in logs, frontend, DB snapshots, test fixtures or audit events.
Ollama must go through existing Stage3 Gateway with `cloud_policy=never`.
OpenRouter/cloud must go through existing Stage3 Gateway + Cost Governor.

## REQUIRED REPORTS

Create:
- `docs/context/SKILLS_PACK_V1_INTEGRATION_REPORT.md`
- `docs/context/PLUGINS_PACK_V1_INTEGRATION_REPORT.md`
- `docs/context/SKILLS_PLUGINS_FINAL_BUG_CHECK.md`

## FINAL BUG CHECK

Must cover:
- contract mismatches
- UI/API/service parameter drift
- approval bypass
- duplicate execution/replay
- plugin disabled mid-flight
- stale credentials
- SSRF
- path traversal
- SQL write attempts
- MCP escalation
- browser unsafe actions
- n8n unsafe targets
- credential leakage
- local/cloud routing
- Cost Governor stop-before-network
- memory/restart
- Stage13 Windows
- Pythia fail-soft
- full tests
- secret scan
- CI

Use only:
PASS
FAIL
SKIP_HOST
SKIP_EXTERNAL_SERVICE
SKIP_EXTERNAL_CREDENTIAL
NOT_TESTED

Never turn SKIP into PASS.

## RELEASE CONDITION

Do not mark this bundle integrated unless:
- no P0
- no unresolved P1
- no secret leakage
- no approval bypass
- no Gateway bypass
- local Ollama path is honest
- cloud path is governed
- regression suite is green
- final remote HEAD is verified

At the end print:
`SKILLS_PLUGINS_GATE: PASS`
only if evidence supports it.
