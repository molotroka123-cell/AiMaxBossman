# BOSSMAN SKILLS + PLUGINS BUNDLE V1

Единый пакет расширения AiMaxBossman для следующего этапа после закрытия текущего RC.

## Что внутри

Пакет объединяет два слоя:

1. **Skills Pack V1** — прикладные способности агента:
   - web research
   - files/docs
   - knowledge/RAG
   - GitHub
   - Gmail
   - Google Calendar
   - Google Drive
   - n8n
   - monitoring
   - read-only SQLite/SQL
   - media/ffmpeg
   - registry
   - policy ALLOW/ASK/DENY
   - audit/redaction
   - path confinement
   - SSRF protection

2. **Plugins Pack V1** — внешний connector/plugin layer:
   - GitHub
   - Gmail
   - Google Calendar
   - Google Drive
   - Telegram
   - n8n
   - Obsidian
   - Browser/Playwright bridge
   - RSS/HTTP monitor
   - read-only SQL
   - Ollama
   - OpenRouter
   - MCP bridge
   - PluginManager
   - capability/scopes manifests
   - credential references
   - health/degraded state
   - bounded retry
   - audit/redaction
   - Plugin Manager UI spec

## Ключевой архитектурный принцип

Пакет НЕ должен создавать второй Bossman.

Нельзя дублировать:
- Stage 3 Gateway
- approval engine
- policy engine
- event bus
- Telegram transport
- browser subsystem
- secret store
- Cost Governor

Правильный путь:

`intent -> typed capability -> policy/scopes -> approval -> existing Bossman authority -> adapter -> audit -> result`

Для локальной модели:

`plugin/skill -> existing Stage3 Gateway -> Ollama`

с `cloud_policy=never`.

Для облачной модели:

`plugin/skill -> existing Stage3 Gateway -> Cost Governor -> OpenRouter/provider`

## Безопасность по умолчанию

- unknown capability -> DENY
- read -> ALLOW только при допустимом scope
- writes -> ASK
- destructive writes -> ASK
- arbitrary shell -> DENY
- raw secrets не хранятся в manifests/logs/UI
- credentials только через ссылки на существующий secret broker
- file access confined
- SSRF protection
- read-only SQL
- audit redaction
- disabled plugin не может выполнять действия

## Тесты пакетов

Skills Pack содержит собственный bug-check.
Plugins Pack содержит unit/security tests и отдельный финальный cross-check.

После интеграции обоих пакетов обязательно выполнить общий финальный bug-check всего Bossman:
- Skills
- Plugins
- Gateway
- Cost Governor
- Stage13 Windows
- Browser
- Memory
- Approvals
- Credentials
- Restart/replay
- Pythia
- Command Center
- Secret scan
- CI

Static/unit tests не считаются live proof.
SKIP не считается PASS.

## Рекомендуемый порядок

1. Закрыть текущий RC.
2. Интегрировать Skills Pack.
3. Интегрировать Plugins Pack.
4. Не добавлять новых фич в процессе интеграции.
5. Провести общий bug-check.
6. Исправить только реальные P0/P1.
7. После зелёного gate зафиксировать этап и перейти дальше.
