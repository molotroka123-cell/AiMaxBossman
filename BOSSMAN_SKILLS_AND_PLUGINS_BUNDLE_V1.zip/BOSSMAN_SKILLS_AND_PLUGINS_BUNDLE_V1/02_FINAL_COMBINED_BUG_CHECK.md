# FINAL COMBINED BUG CHECK — BOSSMAN SKILLS + PLUGINS

Этот чек запускается ПОСЛЕ интеграции обоих пакетов в актуальный remote HEAD.

## Проверить обязательно

### Архитектура
- нет второго Gateway
- нет второго approval engine
- нет второго policy engine
- нет второго secret store
- нет второго Telegram/browser stack
- OpenRouter идёт через Cost Governor
- Ollama идёт через Stage3 Gateway

### Контракты
- UI -> endpoint -> schema -> handler -> service -> adapter
- одинаковые имена параметров
- одинаковые scope/capability names
- exact request/response semantics
- нет аналогов старых `title/name`, `object/object_value`, `known_at/known_as_of`

### Security
- unknown capability DENY
- arbitrary shell DENY
- path traversal DENY
- SSRF DENY
- private IP access DENY unless explicitly local-approved
- raw secrets never logged
- audit redaction
- approval reject causes zero side effects
- duplicate callback/replay is idempotent or denied
- plugin disable immediately blocks execution
- SQL write denied
- MCP scope escalation denied
- unsafe browser form action ASK/DENY
- unsafe n8n target denied
- unsafe GitHub merge without approval denied

### Reliability
- timeout
- bounded retry
- provider unavailable
- plugin degraded
- token expired
- restart
- no duplicate execution after restart
- stale task/action not replayed

### Local AI
- local model through Bossman Gateway
- `cloud_policy=never`
- CLOUD_CALLS=0
- no direct Ollama bypass

### Cloud AI
- OpenRouter through Gateway
- Cost Governor active
- budget exhausted -> stop before network
- unknown price + active budget -> fail closed

### Skills
- web
- files
- RAG
- docs
- GitHub
- Gmail
- Calendar
- Drive
- n8n
- monitoring
- SQL
- media

### Plugins
- registry
- enable/disable
- health
- scopes
- credential status
- approvals
- audit
- reconnect/degraded

### Existing Bossman regressions
- Memory/FactStore
- Approvals
- Command Center
- Stage13
- Windows Notepad flow
- Browser
- Pythia fail-soft
- Telegram
- full regression
- compile
- secret scan
- CI

## Output matrix

For each:
`TEST | STATUS | EVIDENCE | FIX_COMMIT | NOTES`

Allowed status:
PASS / FAIL / SKIP_HOST / SKIP_EXTERNAL_SERVICE / SKIP_EXTERNAL_CREDENTIAL / NOT_TESTED

## Gate

No P0.
No unresolved P1.
No architecture bypass.
No fake PASS.
No SKIP promoted to PASS.

Only then:
`SKILLS_PLUGINS_GATE: PASS`
