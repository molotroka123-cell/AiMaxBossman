import asyncio, sqlite3, pytest
from bossman_skills_pack.skills.sqlite import SQLiteSkill
from bossman_skills_pack.models import SkillAction

def run(c): return asyncio.run(c)
def test_readonly(tmp_path):
 db=tmp_path/"x.db"; c=sqlite3.connect(db); c.execute("create table t(x int)"); c.execute("insert into t values(7)"); c.commit(); c.close()
 s=SQLiteSkill(tmp_path); r=run(s.execute(SkillAction("sqlite","query",{"db":"x.db","sql":"select * from t"})))
 assert r.data==[{"x":7}]
 with pytest.raises(ValueError): run(s.execute(SkillAction("sqlite","query",{"db":"x.db","sql":"delete from t"})))
