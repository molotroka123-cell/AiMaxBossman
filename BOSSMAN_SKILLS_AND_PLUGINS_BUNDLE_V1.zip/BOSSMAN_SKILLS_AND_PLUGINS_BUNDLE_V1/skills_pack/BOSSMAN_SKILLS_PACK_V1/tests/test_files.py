import asyncio
from bossman_skills_pack.skills.files import FileSkill
from bossman_skills_pack.models import SkillAction

def run(c): return asyncio.run(c)
def test_write_read(tmp_path):
 s=FileSkill(tmp_path)
 assert run(s.execute(SkillAction("files","write",{"path":"x.txt","text":"hello"}))).ok
 r=run(s.execute(SkillAction("files","read",{"path":"x.txt"})))
 assert r.data["text"]=="hello"
