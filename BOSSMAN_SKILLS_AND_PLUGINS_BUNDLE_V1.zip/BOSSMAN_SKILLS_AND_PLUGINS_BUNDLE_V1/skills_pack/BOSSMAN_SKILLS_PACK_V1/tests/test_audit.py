import json
from bossman_skills_pack.audit import JsonlAuditSink
def test_redacts(tmp_path):
 p=tmp_path/"a.jsonl"; JsonlAuditSink(p).emit({"token":"abc","nested":{"api_key":"x"},"ok":1})
 d=json.loads(p.read_text()); assert d["token"]=="<redacted>" and d["nested"]["api_key"]=="<redacted>"
