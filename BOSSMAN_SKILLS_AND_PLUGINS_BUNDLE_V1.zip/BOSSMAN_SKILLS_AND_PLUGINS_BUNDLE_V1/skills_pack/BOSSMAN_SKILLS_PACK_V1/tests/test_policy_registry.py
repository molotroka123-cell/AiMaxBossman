import asyncio
from bossman_skills_pack.models import SkillAction, SkillResult, Decision
from bossman_skills_pack.policy import SkillPolicy
from bossman_skills_pack.registry import SkillRegistry
class S:
 name="x"; operations={"read","write"}
 async def execute(self,a): return SkillResult(True,"x",a.operation,{"done":True},correlation_id=a.correlation_id)
class A:
 def __init__(self,v): self.v=v; self.calls=0
 async def require(self,a,reason): self.calls+=1; return self.v

def run(c): return asyncio.run(c)
def test_default_deny():
 r=SkillRegistry(policy=SkillPolicy(),approvals=A(True)); r.register(S())
 assert run(r.execute(SkillAction("x","read"))).error=="denied_by_policy"
def test_ask_reject_prevents_execute():
 p=SkillPolicy({("x","write"):Decision.ASK}); a=A(False); r=SkillRegistry(policy=p,approvals=a); r.register(S())
 res=run(r.execute(SkillAction("x","write"))); assert not res.ok and res.error=="approval_rejected" and a.calls==1
