from pathlib import Path
import pytest
from bossman_skills_pack.security import confined_path, safe_http_url, SecurityError

def test_confined(tmp_path):
 assert confined_path(tmp_path,"a/b.txt").is_relative_to(tmp_path.resolve())
 with pytest.raises(SecurityError): confined_path(tmp_path,"../escape")

def test_url_blocks_local():
 for u in ["http://127.0.0.1/x","http://localhost/x","file:///etc/passwd","http://169.254.169.254/"]:
  with pytest.raises(SecurityError): safe_http_url(u)

def test_allowlist():
 assert safe_http_url("https://api.github.com/x",allowed_domains={"github.com"})
 with pytest.raises(SecurityError): safe_http_url("https://evilgithub.com/x",allowed_domains={"github.com"})
