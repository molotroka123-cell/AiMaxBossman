# Integration guide for AiMaxBossman

## Preserve current architecture

Do not create a parallel tool router. The pack must sit behind Bossman's existing authenticated API / agent tool execution layer and must reuse the existing approval service and audit/event infrastructure where possible.

Recommended host placement:

`bossman-core/bossman/skills_pack/`

The supplied package can first be copied as-is, then imports renamed from `bossman_skills_pack` to `bossman.skills_pack` in one mechanical pass if desired.

## Required host adapter

Create a tiny adapter implementing:

```python
class BossmanApprovalAdapter:
    async def require(self, action, reason) -> bool:
        # create approval using EXISTING approvals subsystem
        # wait/resolve through EXISTING approval boundary
        ...
```

Use the existing secret store instead of `EnvSecretResolver` when available.

## API suggestion

Expose only typed endpoints under the current auth/scopes, for example:

- `GET /skills`
- `POST /skills/execute`

`POST /skills/execute` accepts `{skill, operation, args}`. The server constructs actor/correlation metadata from authenticated context; do not trust actor/correlation IDs supplied by the client.

## Command Center

One Skills page is enough for V1:

- installed skill
- health/credential readiness
- operations
- risk level
- default policy
- last execution
- test button for read-only health checks

Do not expose raw tokens.

## External credentials

Suggested secret names:

- `GITHUB_TOKEN`
- `GOOGLE_ACCESS_TOKEN`
- `N8N_API_KEY`

Google OAuth refresh should be implemented by Bossman's existing connector/credential layer. This pack deliberately does not invent a second refresh-token store.

## Security invariants

1. No arbitrary shell.
2. No user-supplied executable path.
3. File paths confined to configured workspace roots.
4. Web/monitor outbound requests block private/literal local addresses and optionally require domain allowlists.
5. For strongest SSRF resistance, run HTTP adapters through Bossman's egress proxy and re-check resolved IP at connection time; DNS can change after preflight.
6. Write/external/destructive actions go through approval according to policy.
7. Secret values never enter audit events.
8. GitHub repositories and n8n workflows are allowlisted.
9. SQLite is read-only.
10. Connector write endpoints must use existing Bossman auth scopes.

## Known intentional host-integration TODOs

These are not fake PASS items:

- Google OAuth token refresh: reuse existing Bossman connector secret broker.
- Google Drive binary upload: wire through existing file/connector boundary.
- Media merge: create a safe concat manifest within the host workspace and call ffmpeg argv-only.
- n8n execution: use an explicitly configured webhook per workflow; there is no universal public API execution endpoint across all n8n deployments.
- Browser/Playwright: Bossman already has Browser/Command Center capability; expose it to the skill registry rather than introducing a second browser runtime.
- Telegram: reuse the existing durable Telegram subsystem already integrated in Bossman.

## Acceptance scenarios

- `files.read` auto, path traversal denied.
- `files.write` requires approval; rejected write creates no file.
- `github.contents` auto for allowlisted repo; other repo denied.
- `github.create_issue` approval required.
- `gmail.search` auto; `gmail.send` approval required.
- `calendar.list` auto; create/delete approval required.
- `sqlite.query SELECT` works; DELETE/ATTACH denied.
- `web.fetch` to private/localhost blocked.
- secrets redacted from audit.
- restart keeps policy/config via host configuration and does not duplicate executions.
