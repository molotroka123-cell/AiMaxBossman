# Post-integration bug-check plan

After the pack is integrated into current remote HEAD, do not immediately declare PASS. Run a dedicated bug check.

## P0/P1 checks

- Approval rejection must produce zero side effects.
- Duplicate/replayed approval callback must not execute twice.
- Path traversal with `../`, absolute paths, symlink/junction escapes.
- Windows case-insensitive path behavior and junction/reparse points.
- SSRF: localhost, RFC1918, link-local metadata IP, IPv6 loopback, DNS rebinding through the host egress layer.
- GitHub allowlist exactness (`owner/repo`, no prefix tricks).
- n8n allowlist + webhook path traversal.
- Gmail recipient/subject/header injection.
- Calendar deletion/update requires approval.
- Secret leakage in errors, logs, audit events and UI.
- SQL comments/CTEs/PRAGMA edge cases; no ATTACH or writable pragma.
- ffmpeg input/output workspace confinement and no arbitrary protocol URLs.
- cancellation/timeouts cannot leave duplicate external actions.
- connector 401/403/429/5xx handling is honest and bounded.
- no retry of non-idempotent external write unless an idempotency key is supported and persisted.

## Regression

Run current bossman-core full suite, command-center full suite, this pack's pytest, secret scan, compile/import smoke, and Windows-host E2E for filesystem/media paths.
