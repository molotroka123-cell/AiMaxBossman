from __future__ import annotations
from pathlib import Path
from urllib.parse import urlparse
import ipaddress, socket

class SecurityError(ValueError): pass

def confined_path(root: Path, supplied: str, *, must_exist: bool=False) -> Path:
    root = root.resolve()
    candidate = (root / supplied).resolve()
    if candidate != root and root not in candidate.parents:
        raise SecurityError("path escapes workspace")
    if must_exist and not candidate.exists(): raise FileNotFoundError(candidate)
    return candidate

def safe_http_url(url: str, *, allowed_domains: set[str] | None=None) -> str:
    u = urlparse(url)
    if u.scheme not in {"http", "https"} or not u.hostname or u.username or u.password:
        raise SecurityError("invalid URL")
    host = u.hostname.lower().rstrip('.')
    if allowed_domains and not any(host == d or host.endswith('.'+d) for d in allowed_domains):
        raise SecurityError("domain not allowlisted")
    # Block literal private/loopback/link-local/multicast addresses.
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None and not ip.is_global:
        raise SecurityError("non-global IP blocked")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise SecurityError("local hostname blocked")
    return url

def assert_public_resolved_host(host: str) -> None:
    for fam, _, _, _, sockaddr in socket.getaddrinfo(host, None):
        ip = ipaddress.ip_address(sockaddr[0])
        if not ip.is_global:
            raise SecurityError(f"resolved non-global address blocked: {ip}")
