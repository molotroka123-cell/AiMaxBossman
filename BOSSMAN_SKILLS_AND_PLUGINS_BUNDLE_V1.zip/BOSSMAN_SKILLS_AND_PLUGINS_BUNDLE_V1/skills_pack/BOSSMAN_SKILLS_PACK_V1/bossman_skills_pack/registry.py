from __future__ import annotations
from .models import SkillAction, SkillResult, Decision
from .policy import SkillPolicy
from .contracts import ApprovalProvider, AuditSink, Skill

class SkillRegistry:
    def __init__(self, *, policy: SkillPolicy, approvals: ApprovalProvider | None = None, audit: AuditSink | None = None):
        self.policy, self.approvals, self.audit = policy, approvals, audit
        self._skills: dict[str, Skill] = {}

    def register(self, skill: Skill) -> None:
        if not skill.name or skill.name in self._skills:
            raise ValueError(f"duplicate/invalid skill: {skill.name!r}")
        self._skills[skill.name] = skill

    def list(self) -> list[dict]:
        return [{"name": s.name, "operations": sorted(s.operations)} for s in self._skills.values()]

    async def execute(self, action: SkillAction) -> SkillResult:
        decision = self.policy.decide(action)
        self._audit("skill.decision", action, {"decision": decision.value})
        if decision is Decision.DENY:
            return SkillResult(False, action.skill, action.operation, error="denied_by_policy", correlation_id=action.correlation_id)
        if decision is Decision.ASK:
            if self.approvals is None:
                return SkillResult(False, action.skill, action.operation, error="approval_provider_unavailable", correlation_id=action.correlation_id)
            if not await self.approvals.require(action, f"{action.skill}.{action.operation}"):
                return SkillResult(False, action.skill, action.operation, error="approval_rejected", correlation_id=action.correlation_id)
        skill = self._skills.get(action.skill)
        if skill is None or action.operation not in skill.operations:
            return SkillResult(False, action.skill, action.operation, error="unknown_skill_or_operation", correlation_id=action.correlation_id)
        try:
            result = await skill.execute(action)
        except Exception as e:
            result = SkillResult(False, action.skill, action.operation, error=f"skill_error:{type(e).__name__}", correlation_id=action.correlation_id)
        self._audit("skill.result", action, {"ok": result.ok, "error": result.error})
        return result

    def _audit(self, kind, action, extra):
        if self.audit:
            self.audit.emit({"kind": kind, "skill": action.skill, "operation": action.operation,
                             "correlation_id": action.correlation_id, "actor": action.actor, **extra})
