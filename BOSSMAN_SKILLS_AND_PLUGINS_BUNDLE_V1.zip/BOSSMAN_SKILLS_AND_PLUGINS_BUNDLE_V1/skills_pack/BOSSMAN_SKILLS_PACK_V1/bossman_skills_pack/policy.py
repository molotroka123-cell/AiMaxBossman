from __future__ import annotations
from dataclasses import dataclass, field
from .models import Decision, SkillAction

@dataclass
class SkillPolicy:
    rules: dict[tuple[str, str], Decision] = field(default_factory=dict)
    default: Decision = Decision.DENY

    @classmethod
    def safe_defaults(cls) -> "SkillPolicy":
        p = cls()
        auto = {
            ("web", "fetch"), ("files", "read"), ("files", "list"),
            ("knowledge", "search"), ("knowledge", "index"),
            ("github", "repo"), ("github", "contents"), ("github", "issues"), ("github", "pulls"),
            ("gmail", "search"), ("gmail", "read"),
            ("calendar", "list"), ("drive", "search"), ("drive", "metadata"),
            ("monitor", "check"), ("sqlite", "query"),
            ("media", "probe"), ("n8n", "list"),
        }
        ask = {
            ("files", "write"), ("files", "delete"),
            ("github", "create_issue"), ("github", "comment"),
            ("gmail", "draft"), ("gmail", "send"),
            ("calendar", "create"), ("calendar", "update"), ("calendar", "delete"),
            ("drive", "upload"), ("n8n", "trigger"),
            ("media", "transcode"), ("media", "merge"),
        }
        for k in auto: p.rules[k] = Decision.ALLOW
        for k in ask: p.rules[k] = Decision.ASK
        return p

    def decide(self, action: SkillAction) -> Decision:
        return self.rules.get((action.skill, action.operation), self.default)
