from __future__ import annotations
import os

class EnvSecretResolver:
    """Minimal default resolver. Production Bossman should wrap its existing secret broker instead."""
    def __init__(self, prefix: str = "BOSSMAN_SECRET_"):
        self.prefix = prefix
    def get(self, name: str) -> str | None:
        if not name or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" for c in name.upper()):
            return None
        return os.getenv(self.prefix + name.upper())
