from __future__ import annotations
from pathlib import Path
from .registry import SkillRegistry
from .policy import SkillPolicy
from .audit import JsonlAuditSink
from .skills import *

def build_default_registry(*, workspace, approvals, secrets, config:dict):
    root=Path(workspace); reg=SkillRegistry(policy=SkillPolicy.safe_defaults(),approvals=approvals,audit=JsonlAuditSink(root/".bossman-state"/"skills-audit.jsonl"))
    reg.register(FileSkill(root)); reg.register(KnowledgeSkill(root)); reg.register(SQLiteSkill(root)); reg.register(MediaSkill(root))
    reg.register(WebSkill(set(config.get("web_allowed_domains",[])) or None)); reg.register(MonitorSkill(set(config.get("monitor_allowed_domains",[])) or None))
    repos=set(config.get("github_allowed_repos",[])); reg.register(GitHubSkill(lambda:secrets.get("GITHUB_TOKEN"),repos))
    reg.register(GmailSkill(lambda:secrets.get("GOOGLE_ACCESS_TOKEN"))); reg.register(CalendarSkill(lambda:secrets.get("GOOGLE_ACCESS_TOKEN"))); reg.register(DriveSkill(lambda:secrets.get("GOOGLE_ACCESS_TOKEN")))
    if config.get("n8n_base_url"):
        reg.register(N8nSkill(config["n8n_base_url"],lambda:secrets.get("N8N_API_KEY"),set(config.get("n8n_allowed_workflows",[]))))
    return reg
