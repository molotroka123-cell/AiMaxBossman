from __future__ import annotations
from pathlib import Path
import json, re, hashlib
from collections import Counter
from ..models import SkillResult
from ..security import confined_path

WORD=re.compile(r"[A-Za-zА-Яа-яЁё0-9_]{2,}")
class KnowledgeSkill:
    name="knowledge"; operations={"index","search"}
    def __init__(self, workspace, index_file=".bossman-knowledge.json"):
        self.root=Path(workspace); self.index=confined_path(self.root,index_file)
    def _tokens(self,s): return [x.lower() for x in WORD.findall(s)]
    async def execute(self,a):
        if a.operation=="index":
            rels=a.args.get("paths",[]); docs=[]
            for rel in rels:
                p=confined_path(self.root,str(rel),must_exist=True)
                if not p.is_file() or p.stat().st_size>2_000_000: continue
                text=p.read_text("utf-8",errors="replace"); docs.append({"path":str(p.relative_to(self.root.resolve())),"sha256":hashlib.sha256(text.encode()).hexdigest(),"tokens":Counter(self._tokens(text)),"preview":text[:500]})
            serial=[{**d,"tokens":dict(d["tokens"])} for d in docs]; self.index.write_text(json.dumps(serial,ensure_ascii=False),encoding="utf-8")
            return SkillResult(True,self.name,a.operation,{"indexed":len(serial)},correlation_id=a.correlation_id)
        q=self._tokens(str(a.args.get("query",""))); docs=json.loads(self.index.read_text("utf-8")) if self.index.exists() else []
        scored=[]
        for d in docs:
            score=sum(d["tokens"].get(t,0) for t in q)
            if score: scored.append((score,d))
        scored.sort(key=lambda x:x[0],reverse=True)
        return SkillResult(True,self.name,a.operation,[{"score":s,"path":d["path"],"preview":d["preview"]} for s,d in scored[:int(a.args.get("limit",8))]],correlation_id=a.correlation_id)
