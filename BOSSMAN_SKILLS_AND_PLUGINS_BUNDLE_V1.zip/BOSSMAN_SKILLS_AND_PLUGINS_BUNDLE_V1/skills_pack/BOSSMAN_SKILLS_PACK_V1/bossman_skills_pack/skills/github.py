from __future__ import annotations
import httpx
from ..models import SkillResult

class GitHubSkill:
    name="github"; operations={"repo","contents","issues","pulls","create_issue","comment"}
    def __init__(self, token_getter, allowed_repos:set[str]): self.token_getter=token_getter; self.allowed_repos=allowed_repos
    def _repo(self,a):
        repo=str(a.args.get("repo",""))
        if repo not in self.allowed_repos: raise ValueError("repo not allowlisted")
        return repo
    async def _req(self,m,path,**kw):
        tok=self.token_getter(); h={"Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28"}
        if tok: h["Authorization"]=f"Bearer {tok}"
        async with httpx.AsyncClient(base_url="https://api.github.com",timeout=20,follow_redirects=False) as c:
            r=await c.request(m,path,headers=h,**kw); r.raise_for_status(); return r.json() if r.content else None
    async def execute(self,a):
        repo=self._repo(a); op=a.operation
        if op=="repo": data=await self._req("GET",f"/repos/{repo}")
        elif op=="contents": data=await self._req("GET",f"/repos/{repo}/contents/{str(a.args.get('path','')).lstrip('/')}",params={"ref":a.args.get("ref")} if a.args.get("ref") else None)
        elif op=="issues": data=await self._req("GET",f"/repos/{repo}/issues",params={"state":a.args.get("state","open"),"per_page":min(int(a.args.get("limit",20)),100)})
        elif op=="pulls": data=await self._req("GET",f"/repos/{repo}/pulls",params={"state":a.args.get("state","open"),"per_page":min(int(a.args.get("limit",20)),100)})
        elif op=="create_issue": data=await self._req("POST",f"/repos/{repo}/issues",json={"title":str(a.args["title"])[:256],"body":str(a.args.get("body",""))[:20000]})
        elif op=="comment":
            n=int(a.args["issue_number"]); data=await self._req("POST",f"/repos/{repo}/issues/{n}/comments",json={"body":str(a.args["body"])[:20000]})
        else: raise ValueError("unsupported")
        return SkillResult(True,self.name,op,data,correlation_id=a.correlation_id)
