from __future__ import annotations
from pathlib import Path
import sqlite3, re
from ..models import SkillResult
from ..security import confined_path
READ_PREFIX=re.compile(r"^\s*(select|pragma|explain)\b",re.I)
FORBIDDEN=re.compile(r"\b(attach|detach|vacuum|reindex|insert|update|delete|drop|alter|create|replace)\b",re.I)
class SQLiteSkill:
    name="sqlite"; operations={"query"}
    def __init__(self, workspace): self.root=Path(workspace)
    async def execute(self,a):
        db=confined_path(self.root,str(a.args["db"]),must_exist=True); sql=str(a.args["sql"]).strip()
        if not READ_PREFIX.search(sql) or FORBIDDEN.search(sql) or ";" in sql.rstrip(';'):
            raise ValueError("read-only single-statement SQL required")
        uri=f"file:{db.as_posix()}?mode=ro"
        con=sqlite3.connect(uri,uri=True); con.row_factory=sqlite3.Row
        try:
            cur=con.execute(sql,tuple(a.args.get("params",[]))); rows=[dict(r) for r in cur.fetchmany(min(int(a.args.get("limit",500)),5000))]
        finally: con.close()
        return SkillResult(True,self.name,a.operation,rows,correlation_id=a.correlation_id)
