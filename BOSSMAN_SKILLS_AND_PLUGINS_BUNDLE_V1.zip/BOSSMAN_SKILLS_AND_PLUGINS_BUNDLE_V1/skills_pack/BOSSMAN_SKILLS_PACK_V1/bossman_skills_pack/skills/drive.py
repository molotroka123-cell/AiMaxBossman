from __future__ import annotations
from urllib.parse import quote
from .rest_base import BearerRest
from ..models import SkillResult
class DriveSkill:
    name="drive"; operations={"search","metadata","upload"}
    def __init__(self, token_getter): self.api=BearerRest(token_getter,"https://www.googleapis.com/drive/v3")
    async def execute(self,a):
        op=a.operation
        if op=="search": data=await self.api.req("GET","/files",params={"q":str(a.args.get("q","trashed=false")),"pageSize":min(int(a.args.get("limit",50)),100),"fields":"files(id,name,mimeType,modifiedTime,size,webViewLink)"})
        elif op=="metadata": data=await self.api.req("GET","/files/"+quote(str(a.args["file_id"]),safe=""),params={"fields":"id,name,mimeType,modifiedTime,size,webViewLink,owners"})
        elif op=="upload": raise NotImplementedError("binary upload must be wired through Bossman's existing connector/file layer to avoid secret/file duplication")
        else: raise ValueError("unsupported")
        return SkillResult(True,self.name,op,data,correlation_id=a.correlation_id)
