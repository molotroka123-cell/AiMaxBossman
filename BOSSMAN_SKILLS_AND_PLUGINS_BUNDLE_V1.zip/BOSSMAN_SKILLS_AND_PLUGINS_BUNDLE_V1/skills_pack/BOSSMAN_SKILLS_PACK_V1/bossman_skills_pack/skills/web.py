from __future__ import annotations
import httpx
from urllib.parse import urlparse
from ..models import SkillAction, SkillResult
from ..security import safe_http_url, assert_public_resolved_host

class WebSkill:
    name="web"; operations={"fetch"}
    def __init__(self, allowed_domains: set[str] | None=None, max_bytes: int=1_000_000, timeout: float=15.0):
        self.allowed_domains=allowed_domains; self.max_bytes=max_bytes; self.timeout=timeout
    async def execute(self,a):
        url=safe_http_url(str(a.args["url"]),allowed_domains=self.allowed_domains)
        host=urlparse(url).hostname; assert_public_resolved_host(host)
        headers={"User-Agent":"BossmanSkills/1.0"}
        async with httpx.AsyncClient(timeout=self.timeout,follow_redirects=False) as c:
            r=await c.get(url,headers=headers)
            if r.is_redirect: raise ValueError("redirects disabled; validate destination explicitly")
            r.raise_for_status()
            raw=r.content[:self.max_bytes]
            return SkillResult(True,self.name,a.operation,{"status":r.status_code,"content_type":r.headers.get("content-type"),"text":raw.decode("utf-8","replace"),"truncated":len(r.content)>self.max_bytes},correlation_id=a.correlation_id)
