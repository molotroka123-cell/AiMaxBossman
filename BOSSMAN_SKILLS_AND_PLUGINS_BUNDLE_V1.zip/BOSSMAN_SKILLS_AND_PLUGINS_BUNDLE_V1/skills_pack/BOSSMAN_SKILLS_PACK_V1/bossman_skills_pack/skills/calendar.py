from __future__ import annotations
from urllib.parse import quote
from .rest_base import BearerRest
from ..models import SkillResult
class CalendarSkill:
    name="calendar"; operations={"list","create","update","delete"}
    def __init__(self, token_getter, calendar_id="primary"): self.api=BearerRest(token_getter,"https://www.googleapis.com/calendar/v3"); self.cid=calendar_id
    async def execute(self,a):
        cid=quote(str(a.args.get("calendar_id",self.cid)),safe=""); base=f"/calendars/{cid}/events"; op=a.operation
        if op=="list": data=await self.api.req("GET",base,params={"timeMin":a.args.get("time_min"),"timeMax":a.args.get("time_max"),"singleEvents":"true","orderBy":"startTime","maxResults":min(int(a.args.get("limit",50)),250)})
        elif op=="create": data=await self.api.req("POST",base,json=a.args["event"])
        elif op=="update": data=await self.api.req("PATCH",base+"/"+quote(str(a.args["event_id"]),safe=""),json=a.args["patch"])
        elif op=="delete": data=await self.api.req("DELETE",base+"/"+quote(str(a.args["event_id"]),safe=""))
        else: raise ValueError("unsupported")
        return SkillResult(True,self.name,op,data,correlation_id=a.correlation_id)
