from __future__ import annotations
import hashlib, json, httpx
from urllib.parse import urlparse
from ..models import SkillResult
from ..security import safe_http_url, assert_public_resolved_host
class MonitorSkill:
    name="monitor"; operations={"check"}
    def __init__(self, allowed_domains:set[str]|None=None): self.allowed=allowed_domains
    async def execute(self,a):
        url=safe_http_url(str(a.args["url"]),allowed_domains=self.allowed); assert_public_resolved_host(urlparse(url).hostname)
        async with httpx.AsyncClient(timeout=15,follow_redirects=False) as c: r=await c.get(url,headers={"User-Agent":"BossmanMonitor/1.0"})
        raw=r.content[:2_000_000]; fp=hashlib.sha256(raw).hexdigest(); prev=a.args.get("previous_fingerprint")
        return SkillResult(True,self.name,a.operation,{"status":r.status_code,"fingerprint":fp,"changed":prev is not None and prev!=fp,"bytes":len(raw)},correlation_id=a.correlation_id)
