from __future__ import annotations
from pathlib import Path
import os, tempfile
from ..models import SkillAction, SkillResult
from ..security import confined_path

class FileSkill:
    name = "files"
    operations = {"read", "list", "write", "delete"}
    def __init__(self, workspace: str | Path, max_read_bytes: int=2_000_000):
        self.root=Path(workspace); self.root.mkdir(parents=True, exist_ok=True); self.max_read_bytes=max_read_bytes
    async def execute(self, a: SkillAction) -> SkillResult:
        op=a.operation
        if op=="list":
            p=confined_path(self.root, str(a.args.get("path",".")), must_exist=True)
            return SkillResult(True,self.name,op,[{"name":x.name,"dir":x.is_dir(),"size":x.stat().st_size if x.is_file() else None} for x in sorted(p.iterdir())],correlation_id=a.correlation_id)
        p=confined_path(self.root, str(a.args.get("path","")), must_exist=op in {"read","delete"})
        if op=="read":
            if p.stat().st_size > self.max_read_bytes: raise ValueError("file too large")
            return SkillResult(True,self.name,op,{"text":p.read_text(encoding="utf-8",errors="replace")},correlation_id=a.correlation_id)
        if op=="write":
            text=str(a.args.get("text","")); p.parent.mkdir(parents=True,exist_ok=True)
            fd,tmp=tempfile.mkstemp(dir=p.parent,prefix=".bossman-",text=True)
            try:
                with os.fdopen(fd,"w",encoding="utf-8",newline="") as f: f.write(text)
                os.replace(tmp,p)
            finally:
                if os.path.exists(tmp): os.unlink(tmp)
            return SkillResult(True,self.name,op,{"bytes":len(text.encode())},correlation_id=a.correlation_id)
        if op=="delete":
            if p.is_dir(): raise ValueError("directory deletion disabled")
            p.unlink(); return SkillResult(True,self.name,op,{"deleted":True},correlation_id=a.correlation_id)
        raise ValueError("unsupported")
