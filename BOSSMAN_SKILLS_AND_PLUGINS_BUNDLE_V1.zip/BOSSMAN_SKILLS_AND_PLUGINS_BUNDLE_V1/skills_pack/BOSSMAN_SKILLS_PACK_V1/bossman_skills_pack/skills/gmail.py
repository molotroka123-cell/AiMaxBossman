from __future__ import annotations
import base64
from email.message import EmailMessage
from .rest_base import BearerRest
from ..models import SkillResult

class GmailSkill:
    name="gmail"; operations={"search","read","draft","send"}
    def __init__(self, token_getter): self.api=BearerRest(token_getter,"https://gmail.googleapis.com/gmail/v1")
    async def execute(self,a):
        op=a.operation
        if op=="search": data=await self.api.req("GET","/users/me/messages",params={"q":str(a.args.get("q","")),"maxResults":min(int(a.args.get("limit",20)),100)})
        elif op=="read": data=await self.api.req("GET",f"/users/me/messages/{a.args['id']}",params={"format":"metadata"})
        elif op in {"draft","send"}:
            msg=EmailMessage(); msg["To"]=str(a.args["to"]); msg["Subject"]=str(a.args.get("subject",""))[:998]; msg.set_content(str(a.args.get("body","")))
            raw=base64.urlsafe_b64encode(msg.as_bytes()).rstrip(b"=").decode()
            if op=="draft": data=await self.api.req("POST","/users/me/drafts",json={"message":{"raw":raw}})
            else: data=await self.api.req("POST","/users/me/messages/send",json={"raw":raw})
        else: raise ValueError("unsupported")
        return SkillResult(True,self.name,op,data,correlation_id=a.correlation_id)
