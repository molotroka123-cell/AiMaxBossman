from __future__ import annotations
import httpx
from urllib.parse import urlparse
from ..models import SkillResult
class N8nSkill:
    name="n8n"; operations={"list","trigger"}
    def __init__(self, base_url:str, api_key_getter, allowed_workflows:set[str]):
        u=urlparse(base_url); 
        if u.scheme not in {"http","https"} or not u.hostname: raise ValueError("invalid n8n base_url")
        self.base=base_url.rstrip('/'); self.key=api_key_getter; self.allowed=allowed_workflows
    async def execute(self,a):
        key=self.key(); h={"X-N8N-API-KEY":key} if key else {}
        async with httpx.AsyncClient(timeout=20,follow_redirects=False) as c:
            if a.operation=="list": r=await c.get(self.base+"/api/v1/workflows",headers=h)
            else:
                wid=str(a.args["workflow_id"])
                if wid not in self.allowed: raise ValueError("workflow not allowlisted")
                # n8n public API does not provide a universal execute endpoint across deployments.
                # Use an explicitly configured webhook path instead.
                hook=str(a.args.get("webhook_path","")).strip('/')
                if not hook or ".." in hook: raise ValueError("webhook_path required")
                r=await c.post(self.base+"/webhook/"+hook,json=a.args.get("payload",{}),headers=h)
            r.raise_for_status(); data=r.json() if "json" in r.headers.get("content-type","") else r.text
        return SkillResult(True,self.name,a.operation,data,correlation_id=a.correlation_id)
