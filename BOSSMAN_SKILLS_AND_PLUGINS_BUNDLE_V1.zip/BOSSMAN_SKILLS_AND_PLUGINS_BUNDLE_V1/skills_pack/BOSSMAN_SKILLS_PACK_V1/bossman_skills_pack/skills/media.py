from __future__ import annotations
from pathlib import Path
import asyncio, shutil
from ..models import SkillResult
from ..security import confined_path
class MediaSkill:
    name="media"; operations={"probe","transcode","merge"}
    def __init__(self,workspace,ffmpeg="ffmpeg",ffprobe="ffprobe"):
        self.root=Path(workspace); self.ffmpeg=ffmpeg; self.ffprobe=ffprobe
    async def _run(self,argv):
        exe=shutil.which(argv[0]);
        if not exe: raise RuntimeError(f"binary unavailable: {argv[0]}")
        p=await asyncio.create_subprocess_exec(exe,*argv[1:],stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        out,err=await asyncio.wait_for(p.communicate(),timeout=120)
        if p.returncode!=0: raise RuntimeError(err.decode("utf-8","replace")[-2000:])
        return out.decode("utf-8","replace")
    async def execute(self,a):
        op=a.operation
        if op=="probe":
            inp=confined_path(self.root,str(a.args["input"]),must_exist=True); out=await self._run([self.ffprobe,"-v","error","-show_format","-show_streams","-of","json",str(inp)])
            return SkillResult(True,self.name,op,{"json":out},correlation_id=a.correlation_id)
        if op=="transcode":
            inp=confined_path(self.root,str(a.args["input"]),must_exist=True); outp=confined_path(self.root,str(a.args["output"])); codec=str(a.args.get("codec","libx264"))
            if codec not in {"libx264","libx265","copy"}: raise ValueError("codec not allowlisted")
            await self._run([self.ffmpeg,"-y","-i",str(inp),"-c:v",codec,"-c:a","aac",str(outp)])
            return SkillResult(True,self.name,op,{"output":str(outp.relative_to(self.root.resolve()))},correlation_id=a.correlation_id)
        if op=="merge":
            raise NotImplementedError("merge intentionally requires host integration to create a safe concat manifest atomically")
        raise ValueError("unsupported")
