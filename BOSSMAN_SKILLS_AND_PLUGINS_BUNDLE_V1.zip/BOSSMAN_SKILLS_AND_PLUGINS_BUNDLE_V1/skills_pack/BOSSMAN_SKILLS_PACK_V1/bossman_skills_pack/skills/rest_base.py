from __future__ import annotations
import httpx

class BearerRest:
    def __init__(self, token_getter, base_url, timeout=20): self.token_getter=token_getter; self.base=base_url.rstrip('/'); self.timeout=timeout
    async def req(self, method, path, *, params=None, json=None, data=None, headers=None):
        token=self.token_getter()
        if not token: raise RuntimeError("credential unavailable")
        h={"Authorization":f"Bearer {token}","Accept":"application/json"}; h.update(headers or {})
        async with httpx.AsyncClient(timeout=self.timeout,follow_redirects=False) as c:
            r=await c.request(method,self.base+path,params=params,json=json,data=data,headers=h)
            r.raise_for_status()
            if not r.content: return None
            ct=r.headers.get("content-type","")
            return r.json() if "json" in ct else r.text
