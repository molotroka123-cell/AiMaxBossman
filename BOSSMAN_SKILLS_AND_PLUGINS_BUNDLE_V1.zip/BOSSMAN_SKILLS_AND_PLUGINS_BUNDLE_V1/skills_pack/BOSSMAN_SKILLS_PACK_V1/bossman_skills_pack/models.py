from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
import time, uuid

class RiskLevel(str, Enum):
    READ = "read"
    WRITE = "write"
    EXTERNAL_SIDE_EFFECT = "external_side_effect"
    DESTRUCTIVE = "destructive"

class Decision(str, Enum):
    ALLOW = "allow"
    ASK = "ask"
    DENY = "deny"

@dataclass(frozen=True)
class SkillAction:
    skill: str
    operation: str
    args: dict[str, Any] = field(default_factory=dict)
    actor: str = "owner"
    correlation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: float = field(default_factory=time.time)

@dataclass
class SkillResult:
    ok: bool
    skill: str
    operation: str
    data: Any = None
    error: str | None = None
    correlation_id: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)
