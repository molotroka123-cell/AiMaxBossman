from __future__ import annotations
from typing import Protocol, Any
from .models import SkillAction, SkillResult

class ApprovalProvider(Protocol):
    async def require(self, action: SkillAction, reason: str) -> bool: ...

class SecretResolver(Protocol):
    def get(self, name: str) -> str | None: ...

class AuditSink(Protocol):
    def emit(self, event: dict[str, Any]) -> None: ...

class Skill(Protocol):
    name: str
    operations: set[str]
    async def execute(self, action: SkillAction) -> SkillResult: ...
