from __future__ import annotations
from pathlib import Path
import json, threading, time
from typing import Any

class JsonlAuditSink:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def emit(self, event: dict[str, Any]) -> None:
        redacted = _redact(event)
        redacted.setdefault("ts", time.time())
        line = json.dumps(redacted, ensure_ascii=False, sort_keys=True)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")

def _redact(value: Any):
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if any(x in k.lower() for x in ("token", "secret", "password", "authorization", "api_key", "apikey")):
                out[k] = "<redacted>"
            else:
                out[k] = _redact(v)
        return out
    if isinstance(value, list): return [_redact(v) for v in value]
    return value
