# MASTER INSTALL PROMPT — BOSSMAN SKILLS PACK V1

You are integrating `BOSSMAN_SKILLS_PACK_V1.zip` into the current remote HEAD of `molotroka123-cell/AiMaxBossman`, branch `claude/bossman-control-v03-43igbk`.

## First

`git fetch` and identify exact remote HEAD. The repository is changing during RC; do not assume the SHA from any previous report.

Read the ZIP README, `INTEGRATION_GUIDE.md`, `BUG_CHECK_PLAN.md`, manifests and tests before changing code.

## Non-negotiable architecture

Do NOT create a second LLM gateway, tool router, approval engine, auth system, event bus, browser runtime, Telegram subsystem, secret store, memory store or Cost Governor.

Reuse current Bossman:
- Stage3 Gateway
- existing approvals
- auth/scopes
- events/audit
- FactStore/context
- existing Browser
- Telegram durable notifications
- Cost Governor
- Stage13
- Pythia intelligence-only boundary

## Work

1. Integrate the supplied skills implementation under bossman-core using current project conventions.
2. Wire the registry through existing subsystem registration and shutdown lifecycle.
3. Replace EnvSecretResolver with the existing Bossman secret/credential abstraction if present.
4. Implement a BossmanApprovalAdapter against the existing approval service.
5. Add authenticated API endpoints for list/execute using existing scopes.
6. Add a Command Center Skills page using current frontend patterns; no second UI framework.
7. Preserve safe defaults: read auto; writes/external side effects ASK; unknown operations DENY.
8. Do not implement arbitrary shell.
9. Do not weaken Stage13 or existing app allowlists.
10. Complete intentional host TODOs only when current architecture has the correct existing primitive. Otherwise mark honest SKIP/KNOWN_LIMITATION; never invent a parallel subsystem.

## Mandatory tests

Add regression tests for policy, approval reject=zero side effect, traversal, SSRF, secret redaction, repo/workflow allowlists, Gmail header safety, Calendar approval, SQLite read-only, ffmpeg argv-only, auth scopes and duplicate/replay behavior.

Run:
- pack tests
- bossman-core full suite
- command-center full suite
- secret scan
- compile/import smoke
- Windows-specific tests where available

## Bug hunt after integration

Follow `BUG_CHECK_PLAN.md`. Fix P0/P1 only. No unrelated refactor.

## Output

Create `docs/context/SKILLS_PACK_V1_INTEGRATION_REPORT.md` containing:
START_HEAD, FINAL_HEAD, FILES_CHANGED, SKILLS, API, UI, APPROVALS, SECURITY, TESTS, SKIPS, P0, P1, KNOWN_LIMITATIONS, REMOTE_HEAD_VERIFIED.

Commit/push normally, no force push. Fetch before final push to avoid overwriting parallel auditors.
