# BOSSMAN Skills Pack V1

Production-oriented capability pack for AiMaxBossman. It adds useful day-to-day skills **without creating a second orchestrator, approval engine, event bus, or LLM gateway**.

## Core rule

Every external side effect follows:

`intent -> typed skill action -> registry -> policy -> approval (if required) -> adapter -> result -> audit`

The pack intentionally does **not** provide arbitrary shell execution. Paths are workspace-confined, URLs are scheme/domain checked, subprocess usage is argv-only and limited to an explicit binary allowlist, SQL defaults to read-only, and credential material stays behind a secret resolver interface.

## Included skills

1. Web research / HTTP fetch with SSRF protections and domain allowlist.
2. Files / local workspace read-write with path confinement and atomic writes.
3. Knowledge / lightweight local indexing and relevance retrieval.
4. GitHub REST integration (read operations auto; write operations ASK by default).
5. Gmail REST integration (read/draft; send ASK by default).
6. Google Calendar REST integration (read auto; create/update/delete ASK).
7. Google Drive REST integration (search/read metadata/download text-ish files; uploads ASK).
8. n8n integration (list/trigger allowed workflows; trigger ASK by default).
9. Monitoring skill for HTTP/JSON/RSS-style checks and change fingerprints.
10. SQLite database skill (read-only SELECT/PRAGMA/EXPLAIN by default; writes DENY unless separately enabled and approved).
11. Media/ffmpeg skill with fixed typed operations and argv-only process launch.
12. App/connector capability manifests and a central registry.

## What this ZIP is

This is a **drop-in implementation pack** plus tests and an integration guide. It is designed to be copied into `bossman-core/bossman/skills_pack/` and wired into the existing Bossman subsystem registration, auth scopes, approvals, events and Command Center. The exact final wiring points must be adapted to the current remote HEAD because AiMaxBossman is actively changing during RC.

Do not replace existing Stage3 Gateway, Cost Governor, Stage13, FactStore, Pythia or Telegram subsystems.

See `INTEGRATION_GUIDE.md` and `CLAUDE_INSTALL_PROMPT.md`.
