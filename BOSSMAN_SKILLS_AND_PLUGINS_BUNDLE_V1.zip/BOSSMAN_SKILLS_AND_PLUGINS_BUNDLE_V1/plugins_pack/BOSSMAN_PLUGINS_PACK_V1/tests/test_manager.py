import pytest
from bossman_plugins.manager import PluginManager
from bossman_plugins.registry import PluginRegistry
from bossman_plugins.types import PluginManifest, Capability, RiskLevel
from bossman_plugins.base import Plugin

class P(Plugin):
    manifest=PluginManifest("p","P","1",(Capability("read",default_risk=RiskLevel.ALLOW),Capability("write",default_risk=RiskLevel.ASK)))
    def __init__(self): self.calls=0
    async def execute(self,capability,args,context):
        self.calls+=1
        return {"ok":True}

@pytest.mark.asyncio
async def test_allow_executes():
    p=P(); m=PluginManager(PluginRegistry()); m.attach(p)
    out=await m.call("p","read",{})
    assert out["ok"] and p.calls==1

@pytest.mark.asyncio
async def test_reject_does_not_execute():
    p=P(); m=PluginManager(PluginRegistry()); m.attach(p)
    async def no(*a): return False
    with pytest.raises(PermissionError): await m.call("p","write",{},approval=no)
    assert p.calls==0

@pytest.mark.asyncio
async def test_disable_blocks():
    p=P(); m=PluginManager(PluginRegistry()); m.attach(p); m.disable("p")
    with pytest.raises(RuntimeError): await m.call("p","read",{})
