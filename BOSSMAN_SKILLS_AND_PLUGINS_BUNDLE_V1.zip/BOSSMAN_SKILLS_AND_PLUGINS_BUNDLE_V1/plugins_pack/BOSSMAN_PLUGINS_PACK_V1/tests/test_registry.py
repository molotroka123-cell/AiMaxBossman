import pytest
from bossman_plugins.registry import PluginRegistry
from bossman_plugins.manifests import MANIFESTS
def test_register_and_resolve():
    r=PluginRegistry(); r.register(MANIFESTS["github"])
    assert r.resolve("github","repo.read").name=="repo.read"
def test_duplicate_rejected():
    r=PluginRegistry(); r.register(MANIFESTS["github"])
    with pytest.raises(ValueError): r.register(MANIFESTS["github"])
