import pytest
from bossman_plugins.plugins.ollama import OllamaPlugin
class G:
    def __init__(self): self.kw=None
    async def list_local_models(self,provider): return ["x"]
    async def chat(self,**kw): self.kw=kw; return {"ok":1}
@pytest.mark.asyncio
async def test_ollama_forces_never_cloud():
    g=G(); p=OllamaPlugin(g)
    await p.execute("chat",{"model":"x","messages":[]},{})
    assert g.kw["provider"]=="ollama"
    assert g.kw["cloud_policy"]=="never"
