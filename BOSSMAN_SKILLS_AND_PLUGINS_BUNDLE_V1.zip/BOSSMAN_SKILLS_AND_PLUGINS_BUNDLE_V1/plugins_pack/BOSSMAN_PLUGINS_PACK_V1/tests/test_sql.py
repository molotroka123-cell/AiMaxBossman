import pytest
from bossman_plugins.plugins.sql import ReadOnlySQLPlugin

@pytest.mark.asyncio
async def test_sql_read_only():
    seen=[]
    async def q(sql,params): seen.append(sql); return [1]
    p=ReadOnlySQLPlugin(q)
    assert await p.execute("query.read",{"sql":"SELECT 1"},{}) == [1]
    for bad in ["DELETE FROM x","DROP TABLE x","SELECT 1; DROP TABLE x","UPDATE x SET a=1"]:
        with pytest.raises(PermissionError): await p.execute("query.read",{"sql":bad},{})
