import pytest
from pathlib import Path
from bossman_plugins.security import validate_http_url, confine_path, redact

def test_ssrf_private_denied():
    for u in ["http://127.0.0.1/x","http://10.0.0.1/x","http://localhost/x","http://169.254.1.1/x"]:
        with pytest.raises(ValueError): validate_http_url(u)

def test_path_confinement(tmp_path):
    assert confine_path(tmp_path,"a/b.txt").is_relative_to(tmp_path.resolve())
    with pytest.raises(ValueError): confine_path(tmp_path,"../escape.txt")

def test_redaction():
    d=redact({"token":"abc","nested":{"api_key":"def","ok":1}})
    assert d["token"]=="***REDACTED***"
    assert d["nested"]["api_key"]=="***REDACTED***"
    assert d["nested"]["ok"]==1
