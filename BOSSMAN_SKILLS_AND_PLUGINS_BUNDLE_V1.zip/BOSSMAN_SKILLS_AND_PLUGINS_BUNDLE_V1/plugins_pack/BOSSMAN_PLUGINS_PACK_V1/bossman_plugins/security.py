from __future__ import annotations
import ipaddress
import re
from urllib.parse import urlparse

TOKEN_KEYS = re.compile(r"(token|secret|password|authorization|api[_-]?key|cookie)", re.I)

def redact(value):
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            out[k] = "***REDACTED***" if TOKEN_KEYS.search(str(k)) else redact(v)
        return out
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, tuple):
        return tuple(redact(v) for v in value)
    return value

def validate_http_url(url: str, allowed_hosts: set[str] | None = None, allow_private: bool = False) -> str:
    p = urlparse(url)
    if p.scheme not in {"http", "https"}:
        raise ValueError("unsupported URL scheme")
    if not p.hostname:
        raise ValueError("missing hostname")
    host = p.hostname.rstrip(".").lower()
    if allowed_hosts is not None and host not in {h.lower() for h in allowed_hosts}:
        raise ValueError("host not allowlisted")
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip and not allow_private:
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            raise ValueError("private or unsafe IP target")
    if host in {"localhost"} and not allow_private:
        raise ValueError("localhost not allowed")
    return url

def confine_path(base, candidate):
    from pathlib import Path
    b = Path(base).resolve()
    c = (b / candidate).resolve() if not Path(candidate).is_absolute() else Path(candidate).resolve()
    try:
        c.relative_to(b)
    except ValueError:
        raise ValueError("path escapes configured root")
    return c
