from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Awaitable
from .types import PluginState, RiskLevel
from .registry import PluginRegistry
from .audit import AuditSink

ApprovalFn = Callable[[str, str, dict], Awaitable[bool]]
PolicyFn = Callable[[str, str, dict], RiskLevel]

@dataclass
class RuntimePlugin:
    plugin: object
    state: PluginState = PluginState.ENABLED
    last_error: str | None = None

class PluginManager:
    def __init__(self, registry: PluginRegistry, audit: AuditSink | None = None):
        self.registry = registry
        self.audit = audit or AuditSink()
        self.runtime: dict[str, RuntimePlugin] = {}

    def attach(self, plugin):
        self.registry.register(plugin.manifest)
        self.runtime[plugin.manifest.plugin_id] = RuntimePlugin(plugin=plugin)

    def enable(self, plugin_id: str):
        self.runtime[plugin_id].state = PluginState.ENABLED

    def disable(self, plugin_id: str):
        self.runtime[plugin_id].state = PluginState.DISABLED

    async def call(self, plugin_id: str, capability: str, args: dict[str, Any], *,
                   context: dict[str, Any] | None = None,
                   policy: PolicyFn | None = None,
                   approval: ApprovalFn | None = None):
        rt = self.runtime[plugin_id]
        if rt.state != PluginState.ENABLED:
            raise RuntimeError(f"plugin not enabled: {plugin_id}")
        cap = self.registry.resolve(plugin_id, capability)
        risk = policy(plugin_id, capability, args) if policy else cap.default_risk
        if risk == RiskLevel.DENY:
            self.audit.emit(plugin_id, capability, "DENY", {"args": args})
            raise PermissionError("capability denied")
        if risk == RiskLevel.ASK:
            if approval is None or not await approval(plugin_id, capability, args):
                self.audit.emit(plugin_id, capability, "REJECTED", {"args": args})
                raise PermissionError("approval required or rejected")
        try:
            out = await rt.plugin.execute(capability, args, context or {})
            self.audit.emit(plugin_id, capability, "OK", {"args": args})
            return out
        except Exception as e:
            rt.last_error = f"{type(e).__name__}: {e}"
            rt.state = PluginState.DEGRADED
            self.audit.emit(plugin_id, capability, "ERROR", {"error": rt.last_error})
            raise
