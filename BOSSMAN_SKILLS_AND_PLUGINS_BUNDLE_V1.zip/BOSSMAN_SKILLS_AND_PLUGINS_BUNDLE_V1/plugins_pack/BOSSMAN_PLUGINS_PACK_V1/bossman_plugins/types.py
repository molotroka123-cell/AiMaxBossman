from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Sequence

class RiskLevel(str, Enum):
    ALLOW = "ALLOW"
    ASK = "ASK"
    DENY = "DENY"

class PluginState(str, Enum):
    ENABLED = "enabled"
    DISABLED = "disabled"
    DEGRADED = "degraded"
    ERROR = "error"

@dataclass(frozen=True)
class Capability:
    name: str
    scopes: tuple[str, ...] = ()
    default_risk: RiskLevel = RiskLevel.ASK
    description: str = ""
    destructive: bool = False

@dataclass(frozen=True)
class PluginManifest:
    plugin_id: str
    name: str
    version: str
    capabilities: tuple[Capability, ...]
    credential_refs: tuple[str, ...] = ()
    network_hosts: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def capability(self, name: str) -> Capability:
        for cap in self.capabilities:
            if cap.name == name:
                return cap
        raise KeyError(name)
