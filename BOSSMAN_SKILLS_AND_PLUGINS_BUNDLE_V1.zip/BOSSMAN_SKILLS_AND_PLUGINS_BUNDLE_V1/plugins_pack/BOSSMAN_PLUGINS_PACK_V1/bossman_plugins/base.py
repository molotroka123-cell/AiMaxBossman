from __future__ import annotations
from typing import Any
from .types import PluginManifest

class Plugin:
    manifest: PluginManifest

    async def health(self) -> dict[str, Any]:
        return {"ok": True}

    async def execute(self, capability: str, args: dict[str, Any], context: dict[str, Any]) -> Any:
        raise NotImplementedError
