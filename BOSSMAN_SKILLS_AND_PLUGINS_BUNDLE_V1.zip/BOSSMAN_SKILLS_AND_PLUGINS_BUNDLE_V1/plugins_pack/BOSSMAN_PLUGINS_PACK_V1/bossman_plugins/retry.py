from __future__ import annotations
import asyncio, random

async def bounded_retry(fn, *, attempts=3, base_delay=0.05, max_delay=0.5, retry_on=(TimeoutError,)):
    last = None
    for idx in range(attempts):
        try:
            return await fn()
        except retry_on as e:
            last = e
            if idx == attempts - 1:
                raise
            delay = min(max_delay, base_delay * (2 ** idx))
            delay += random.random() * min(delay, 0.05)
            await asyncio.sleep(delay)
    raise last
