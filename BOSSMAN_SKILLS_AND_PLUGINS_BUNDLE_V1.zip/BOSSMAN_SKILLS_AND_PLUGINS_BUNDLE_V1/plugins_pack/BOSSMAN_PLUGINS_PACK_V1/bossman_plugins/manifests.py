from .types import PluginManifest, Capability, RiskLevel

def _c(name, scopes=(), risk=RiskLevel.ASK, desc="", destructive=False):
    return Capability(name=name, scopes=tuple(scopes), default_risk=risk, description=desc, destructive=destructive)

MANIFESTS = {
"github": PluginManifest("github","GitHub","1.0",(
    _c("repo.read",("repo:read",),RiskLevel.ALLOW),
    _c("issue.create",("issues:write",),RiskLevel.ASK),
    _c("pr.create",("pull_requests:write",),RiskLevel.ASK),
    _c("pr.merge",("pull_requests:merge",),RiskLevel.ASK, destructive=True),
),("github.token",),("api.github.com",)),
"gmail": PluginManifest("gmail","Gmail","1.0",(
    _c("mail.search",("gmail.readonly",),RiskLevel.ALLOW),
    _c("mail.read",("gmail.readonly",),RiskLevel.ALLOW),
    _c("mail.draft",("gmail.compose",),RiskLevel.ALLOW),
    _c("mail.send",("gmail.send",),RiskLevel.ASK, destructive=True),
),("google.oauth",),("gmail.googleapis.com",)),
"calendar": PluginManifest("calendar","Google Calendar","1.0",(
    _c("event.search",("calendar.readonly",),RiskLevel.ALLOW),
    _c("event.create",("calendar.events",),RiskLevel.ASK),
    _c("event.update",("calendar.events",),RiskLevel.ASK),
    _c("event.delete",("calendar.events",),RiskLevel.ASK, destructive=True),
),("google.oauth",),("www.googleapis.com",)),
"drive": PluginManifest("drive","Google Drive","1.0",(
    _c("file.search",("drive.metadata.readonly",),RiskLevel.ALLOW),
    _c("file.read",("drive.readonly",),RiskLevel.ALLOW),
    _c("file.create",("drive.file",),RiskLevel.ASK),
    _c("file.update",("drive.file",),RiskLevel.ASK),
),("google.oauth",),("www.googleapis.com",)),
"telegram": PluginManifest("telegram","Telegram","1.0",(
    _c("message.send",("telegram.send",),RiskLevel.ASK),
    _c("status.read",("telegram.read",),RiskLevel.ALLOW),
),("telegram.bot_token",),("api.telegram.org",)),
"n8n": PluginManifest("n8n","n8n","1.0",(
    _c("workflow.list",("n8n.read",),RiskLevel.ALLOW),
    _c("workflow.run",("n8n.execute",),RiskLevel.ASK),
    _c("execution.read",("n8n.read",),RiskLevel.ALLOW),
),("n8n.api_key",),()),
"obsidian": PluginManifest("obsidian","Obsidian Vault","1.0",(
    _c("note.search",("vault.read",),RiskLevel.ALLOW),
    _c("note.read",("vault.read",),RiskLevel.ALLOW),
    _c("note.write",("vault.write",),RiskLevel.ASK),
),(),()),
"browser": PluginManifest("browser","Browser Bridge","1.0",(
    _c("page.open",("browser.navigate",),RiskLevel.ALLOW),
    _c("page.read",("browser.read",),RiskLevel.ALLOW),
    _c("form.fill",("browser.input",),RiskLevel.ASK),
    _c("download",("browser.download",),RiskLevel.ASK),
),(),()),
"monitor": PluginManifest("monitor","RSS/HTTP Monitor","1.0",(
    _c("feed.read",("network.read",),RiskLevel.ALLOW),
    _c("http.get",("network.read",),RiskLevel.ALLOW),
),(),()),
"sql": PluginManifest("sql","Read-only SQL","1.0",(
    _c("query.read",("db.read",),RiskLevel.ALLOW),
),("database.dsn",),()),
"ollama": PluginManifest("ollama","Ollama","1.0",(
    _c("models.list",("llm.local",),RiskLevel.ALLOW),
    _c("chat",("llm.local",),RiskLevel.ALLOW),
),(),("127.0.0.1",)),
"openrouter": PluginManifest("openrouter","OpenRouter","1.0",(
    _c("models.list",("llm.cloud.read",),RiskLevel.ALLOW),
    _c("chat",("llm.cloud.use",),RiskLevel.ASK),
),("openrouter.api_key",),("openrouter.ai",)),
"mcp": PluginManifest("mcp","MCP Bridge","1.0",(
    _c("server.list",("mcp.read",),RiskLevel.ALLOW),
    _c("tool.list",("mcp.read",),RiskLevel.ALLOW),
    _c("tool.call",("mcp.execute",),RiskLevel.ASK),
),(),()),
}
