from ..base import Plugin
from ..manifests import MANIFESTS
from ..security import confine_path
class ObsidianPlugin(Plugin):
    manifest=MANIFESTS["obsidian"]
    def __init__(self, vault_root): self.vault_root=vault_root
    async def execute(self,capability,args,context):
        from pathlib import Path
        root=Path(self.vault_root)
        if capability=="note.read":
            p=confine_path(root,args["path"])
            return p.read_text(encoding="utf-8")
        if capability=="note.write":
            p=confine_path(root,args["path"]); p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(args["content"],encoding="utf-8"); return {"path":str(p)}
        if capability=="note.search":
            q=args["query"].lower(); out=[]
            for p in root.rglob("*.md"):
                try: txt=p.read_text(encoding="utf-8")
                except Exception: continue
                if q in txt.lower() or q in p.name.lower():
                    out.append(str(p.relative_to(root)))
            return out[:int(args.get("limit",50))]
        raise KeyError(capability)
