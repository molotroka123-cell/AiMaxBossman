from ..base import Plugin
from ..manifests import MANIFESTS
class OpenRouterPlugin(Plugin):
    manifest=MANIFESTS["openrouter"]
    def __init__(self, gateway_adapter): self.gateway=gateway_adapter
    async def execute(self,capability,args,context):
        # Existing Gateway + Cost Governor remains authority for cloud calls.
        if capability=="models.list": return await self.gateway.list_cloud_models(provider="openrouter")
        if capability=="chat": return await self.gateway.chat(provider="openrouter", **args)
        raise KeyError(capability)
