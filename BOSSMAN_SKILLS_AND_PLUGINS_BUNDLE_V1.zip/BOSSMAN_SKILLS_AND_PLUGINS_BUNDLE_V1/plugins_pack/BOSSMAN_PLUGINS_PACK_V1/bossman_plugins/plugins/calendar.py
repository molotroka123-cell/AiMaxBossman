from ..base import Plugin
from ..manifests import MANIFESTS
class CalendarPlugin(Plugin):
    manifest = MANIFESTS["calendar"]
    def __init__(self, client): self.client=client
    async def execute(self, capability,args,context):
        mapping={"event.search":"search","event.create":"create","event.update":"update","event.delete":"delete"}
        return await getattr(self.client,mapping[capability])(**args)
