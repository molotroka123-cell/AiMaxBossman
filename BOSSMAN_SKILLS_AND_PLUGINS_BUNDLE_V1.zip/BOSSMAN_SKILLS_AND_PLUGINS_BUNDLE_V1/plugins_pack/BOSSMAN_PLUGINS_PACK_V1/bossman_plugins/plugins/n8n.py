from ..base import Plugin
from ..manifests import MANIFESTS
from ..security import validate_http_url
class N8nPlugin(Plugin):
    manifest=MANIFESTS["n8n"]
    def __init__(self, client, base_url, allow_private=True):
        self.client=client
        self.base_url=validate_http_url(base_url, allow_private=allow_private)
    async def execute(self,capability,args,context):
        mapping={"workflow.list":"list_workflows","workflow.run":"run_workflow","execution.read":"read_execution"}
        return await getattr(self.client,mapping[capability])(**args)
