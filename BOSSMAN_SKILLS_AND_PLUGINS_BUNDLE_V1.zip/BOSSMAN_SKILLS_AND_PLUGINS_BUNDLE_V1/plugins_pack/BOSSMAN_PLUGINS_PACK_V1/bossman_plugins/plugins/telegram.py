from ..base import Plugin
from ..manifests import MANIFESTS
class TelegramPlugin(Plugin):
    manifest=MANIFESTS["telegram"]
    def __init__(self, client): self.client=client
    async def execute(self,capability,args,context):
        if capability=="message.send": return await self.client.send(**args)
        if capability=="status.read": return await self.client.status(**args)
        raise KeyError(capability)
