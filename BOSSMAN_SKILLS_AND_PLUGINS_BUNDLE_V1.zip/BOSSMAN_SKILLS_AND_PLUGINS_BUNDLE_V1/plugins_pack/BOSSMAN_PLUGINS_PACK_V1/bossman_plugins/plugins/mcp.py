from ..base import Plugin
from ..manifests import MANIFESTS
class MCPPlugin(Plugin):
    manifest=MANIFESTS["mcp"]
    def __init__(self, bridge): self.bridge=bridge
    async def execute(self,capability,args,context):
        if capability=="server.list": return await self.bridge.list_servers()
        if capability=="tool.list": return await self.bridge.list_tools(**args)
        if capability=="tool.call": return await self.bridge.call_tool(**args)
        raise KeyError(capability)
