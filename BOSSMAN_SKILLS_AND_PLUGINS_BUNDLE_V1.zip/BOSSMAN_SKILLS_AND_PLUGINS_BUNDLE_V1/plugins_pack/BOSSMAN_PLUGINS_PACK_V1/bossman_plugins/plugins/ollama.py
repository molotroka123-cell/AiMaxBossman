from ..base import Plugin
from ..manifests import MANIFESTS
class OllamaPlugin(Plugin):
    manifest=MANIFESTS["ollama"]
    def __init__(self, gateway_adapter): self.gateway=gateway_adapter
    async def execute(self,capability,args,context):
        # Must be wired to Bossman's existing Stage 3 Gateway adapter, not a second provider client.
        if capability=="models.list": return await self.gateway.list_local_models(provider="ollama")
        if capability=="chat": return await self.gateway.chat(provider="ollama", cloud_policy="never", **args)
        raise KeyError(capability)
