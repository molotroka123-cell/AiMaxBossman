from ..base import Plugin
from ..manifests import MANIFESTS
class GitHubPlugin(Plugin):
    manifest = MANIFESTS["github"]
    def __init__(self, client): self.client = client
    async def health(self): return await self.client.health()
    async def execute(self, capability,args,context):
        mapping={"repo.read":"read_repo","issue.create":"create_issue","pr.create":"create_pr","pr.merge":"merge_pr"}
        return await getattr(self.client,mapping[capability])(**args)
