from ..base import Plugin
from ..manifests import MANIFESTS
class GmailPlugin(Plugin):
    manifest = MANIFESTS["gmail"]
    def __init__(self, client): self.client=client
    async def execute(self, capability,args,context):
        mapping={"mail.search":"search","mail.read":"read","mail.draft":"draft","mail.send":"send"}
        return await getattr(self.client,mapping[capability])(**args)
