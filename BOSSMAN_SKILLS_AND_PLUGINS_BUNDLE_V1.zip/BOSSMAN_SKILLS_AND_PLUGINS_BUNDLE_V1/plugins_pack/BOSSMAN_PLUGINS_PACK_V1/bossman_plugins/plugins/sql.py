from ..base import Plugin
from ..manifests import MANIFESTS
import re
READ_RE=re.compile(r"^\s*(select|with|pragma\s+(table_info|index_list|index_info))\b",re.I)
BAD_RE=re.compile(r"\b(insert|update|delete|drop|alter|create|attach|detach|vacuum|replace|reindex)\b",re.I)
class ReadOnlySQLPlugin(Plugin):
    manifest=MANIFESTS["sql"]
    def __init__(self, query_fn): self.query_fn=query_fn
    async def execute(self,capability,args,context):
        sql=args["sql"]
        if ";" in sql.strip().rstrip(";"):
            raise PermissionError("multiple statements denied")
        if BAD_RE.search(sql) or not READ_RE.search(sql):
            raise PermissionError("read-only SQL only")
        return await self.query_fn(sql,args.get("params",{}))
