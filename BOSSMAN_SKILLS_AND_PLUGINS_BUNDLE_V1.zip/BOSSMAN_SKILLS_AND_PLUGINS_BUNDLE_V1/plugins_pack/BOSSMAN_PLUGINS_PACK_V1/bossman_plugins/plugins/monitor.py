from ..base import Plugin
from ..manifests import MANIFESTS
from ..security import validate_http_url
class MonitorPlugin(Plugin):
    manifest=MANIFESTS["monitor"]
    def __init__(self, http_get, allowed_hosts=None):
        self.http_get=http_get; self.allowed_hosts=set(allowed_hosts) if allowed_hosts else None
    async def execute(self,capability,args,context):
        url=validate_http_url(args["url"], allowed_hosts=self.allowed_hosts, allow_private=False)
        return await self.http_get(url)
