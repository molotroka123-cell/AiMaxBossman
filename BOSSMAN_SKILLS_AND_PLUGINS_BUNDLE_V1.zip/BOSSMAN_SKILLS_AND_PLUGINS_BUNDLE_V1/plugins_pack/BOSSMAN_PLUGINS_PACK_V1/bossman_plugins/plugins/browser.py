from ..base import Plugin
from ..manifests import MANIFESTS
class BrowserPlugin(Plugin):
    manifest=MANIFESTS["browser"]
    def __init__(self, browser_bridge): self.bridge=browser_bridge
    async def execute(self,capability,args,context):
        mapping={"page.open":"open","page.read":"read","form.fill":"fill","download":"download"}
        return await getattr(self.bridge,mapping[capability])(**args)
