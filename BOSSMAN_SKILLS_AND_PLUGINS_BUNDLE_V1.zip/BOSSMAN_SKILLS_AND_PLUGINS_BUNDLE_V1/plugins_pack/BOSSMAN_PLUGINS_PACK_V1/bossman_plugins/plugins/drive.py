from ..base import Plugin
from ..manifests import MANIFESTS
class DrivePlugin(Plugin):
    manifest = MANIFESTS["drive"]
    def __init__(self, client): self.client=client
    async def execute(self, capability,args,context):
        mapping={"file.search":"search","file.read":"read","file.create":"create","file.update":"update"}
        return await getattr(self.client,mapping[capability])(**args)
