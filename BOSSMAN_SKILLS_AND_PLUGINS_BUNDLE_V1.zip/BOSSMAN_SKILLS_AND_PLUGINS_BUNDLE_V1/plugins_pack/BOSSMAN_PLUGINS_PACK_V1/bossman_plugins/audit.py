from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any
from .security import redact

@dataclass
class AuditEvent:
    plugin_id: str
    capability: str
    outcome: str
    detail: dict[str, Any]
    ts: str

class AuditSink:
    def __init__(self):
        self.events: list[dict] = []

    def emit(self, plugin_id: str, capability: str, outcome: str, detail: dict | None = None):
        evt = AuditEvent(
            plugin_id=plugin_id,
            capability=capability,
            outcome=outcome,
            detail=redact(detail or {}),
            ts=datetime.now(timezone.utc).isoformat(),
        )
        self.events.append(asdict(evt))
        return self.events[-1]
