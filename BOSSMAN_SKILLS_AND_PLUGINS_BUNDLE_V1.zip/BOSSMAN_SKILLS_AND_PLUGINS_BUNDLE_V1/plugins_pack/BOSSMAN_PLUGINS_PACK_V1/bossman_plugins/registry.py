from __future__ import annotations
from .types import PluginManifest, Capability, RiskLevel

class PluginRegistry:
    def __init__(self):
        self._manifests: dict[str, PluginManifest] = {}

    def register(self, manifest: PluginManifest):
        if manifest.plugin_id in self._manifests:
            raise ValueError(f"duplicate plugin: {manifest.plugin_id}")
        if not manifest.capabilities:
            raise ValueError("plugin must declare at least one capability")
        names = [c.name for c in manifest.capabilities]
        if len(names) != len(set(names)):
            raise ValueError("duplicate capability")
        self._manifests[manifest.plugin_id] = manifest

    def get(self, plugin_id: str) -> PluginManifest:
        return self._manifests[plugin_id]

    def list(self):
        return tuple(self._manifests.values())

    def resolve(self, plugin_id: str, capability: str) -> Capability:
        return self.get(plugin_id).capability(capability)
