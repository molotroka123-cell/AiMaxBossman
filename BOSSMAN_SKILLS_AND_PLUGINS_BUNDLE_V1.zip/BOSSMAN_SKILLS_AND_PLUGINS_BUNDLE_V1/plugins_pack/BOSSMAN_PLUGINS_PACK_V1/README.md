# BOSSMAN PLUGINS PACK V1

Production-oriented external connector/plugin layer for AiMaxBossman.

## Purpose

This pack does **not** replace Bossman's existing Gateway, approvals, policy engine,
Telegram transport, browser stack, secret store, event bus, or task engine.

It adds a narrow plugin contract:

`plugin -> declared capabilities -> scopes -> policy hint -> approval boundary -> executor -> audit`

## Included plugins

- GitHub
- Gmail
- Google Calendar
- Google Drive
- Telegram
- n8n
- Obsidian/local vault
- Playwright/browser bridge
- RSS/HTTP monitor
- SQLite/Postgres read-only bridge
- Ollama
- OpenRouter
- MCP bridge

## Security defaults

- deny-by-default capability registry
- no raw secret values in manifests or audit events
- credential references only
- explicit scopes per capability
- external writes default to ASK
- arbitrary shell is not a plugin capability
- file paths are workspace/vault confined where applicable
- SQL plugin is read-only by default
- HTTP plugins reject loopback/private/link-local targets unless explicitly allowed
- health checks do not execute destructive actions
- retries are bounded and jittered
- plugin disable is immediate
- audit log redacts token-like fields

## Integration model

Use Bossman's existing systems for:
- owner authentication
- approvals
- secrets/credential storage
- event bus
- Cost Governor
- Stage 3 Gateway
- Stage 13 Computer Operator

See `CLAUDE_INSTALL_PROMPT.md` and `INTEGRATION_GUIDE.md`.

## Test status of this ZIP

The included unit/static tests are designed to run without external credentials.
External-service LIVE acceptance is intentionally not faked.
