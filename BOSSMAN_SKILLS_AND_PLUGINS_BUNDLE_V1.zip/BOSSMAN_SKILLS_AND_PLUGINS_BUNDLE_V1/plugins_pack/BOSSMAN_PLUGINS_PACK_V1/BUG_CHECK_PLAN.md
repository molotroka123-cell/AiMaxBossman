# FINAL BUG CHECK — SKILLS + PLUGINS

Run only after both packs are integrated into the latest remote HEAD.

## Contract audit
- UI -> API -> service -> plugin manager -> plugin adapter
- exact parameter names
- exact scope names
- no duplicated auth/approval/gateway/event systems

## Security
- path traversal
- SSRF
- localhost/private IP access
- credential leakage
- audit redaction
- approval bypass
- duplicate approval replay
- plugin disabled mid-flight
- unknown capability
- arbitrary shell attempts
- SQL write attempts
- MCP scope escalation
- browser cross-domain form action
- n8n arbitrary webhook target
- stale credential
- rate-limit storms

## Reliability
- timeout
- retry
- provider down
- token expired
- plugin health degraded
- Bossman restart
- plugin registry persistence if configured
- no duplicate execution after restart

## Local/cloud boundary
- Ollama via existing Gateway only
- OpenRouter via existing Gateway + Cost Governor only
- `cloud_policy=never` proves zero cloud calls
- no plugin creates a provider bypass

## Final labels
PASS
FAIL
SKIP_HOST
SKIP_EXTERNAL_SERVICE
SKIP_EXTERNAL_CREDENTIAL
NOT_TESTED

Never convert SKIP to PASS.
