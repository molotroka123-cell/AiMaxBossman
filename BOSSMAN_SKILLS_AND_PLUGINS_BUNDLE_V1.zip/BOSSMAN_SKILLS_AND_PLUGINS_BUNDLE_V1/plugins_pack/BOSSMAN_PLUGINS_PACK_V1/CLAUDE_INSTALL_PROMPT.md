# BOSSMAN PLUGINS PACK V1 — INSTALL + INTEGRATE

Repository:
`molotroka123-cell/AiMaxBossman`

Branch:
`claude/bossman-control-v03-43igbk`

## Source of truth

1. `git fetch`
2. obtain current remote HEAD
3. read latest RC A/B/C/D and PRE-RC bug-hunt reports
4. do not trust SHA values embedded in old docs
5. no force push

## Goal

Integrate `BOSSMAN_PLUGINS_PACK_V1` as a thin plugin/connector layer.

Do NOT add another:
- Gateway
- approval engine
- policy engine
- event bus
- Telegram subsystem
- browser subsystem
- secret store
- Cost Governor

Reuse existing Bossman authorities.

## Plugins to integrate

GitHub
Gmail
Google Calendar
Google Drive
Telegram
n8n
Obsidian/local vault
Browser/Playwright bridge
RSS/HTTP monitor
read-only SQL
Ollama
OpenRouter
MCP bridge

## Mandatory architecture

`intent -> typed plugin capability -> scope/policy -> approval if required -> plugin manager -> adapter -> audit/result`

Unknown plugin/capability: DENY.

No arbitrary shell capability.

## Critical wiring rules

Ollama:
`plugin -> existing Stage3 Gateway -> local target`
with `cloud_policy=never`.

OpenRouter:
`plugin -> existing Stage3 Gateway -> Cost Governor -> provider`.

Telegram:
reuse existing durable transport and opaque approval callbacks.

Browser:
reuse existing browser/session subsystem.

Credentials:
manifest references only; resolve via existing secret broker.
Never store raw tokens in plugin DB, logs, manifests, test snapshots or frontend.

## Default action policy

Safe reads -> ALLOW where existing scopes permit.
Writes -> ASK.
Destructive writes -> ASK.
Unknown -> DENY.
Shell -> DENY.

## Plugin Manager API/UI

Add only if it cleanly fits current Command Center:
- list plugins
- state
- health
- capabilities
- scopes
- credential configured/missing only
- enable/disable
- last error
- audit
No raw secrets.

## Test requirements

Run pack tests first.

Then add integration regression tests for:
- registration
- duplicate registration reject
- disable prevents calls
- unknown capability deny
- ASK reject no execution
- ASK approve single execution
- audit redaction
- path traversal
- SSRF
- SQL writes denied
- Ollama no-cloud route
- OpenRouter Cost Governor boundary
- credential reference only
- degraded health

Then live external tests only when credentials/services exist.

Use honest:
PASS / FAIL / SKIP_HOST / SKIP_EXTERNAL_SERVICE / SKIP_EXTERNAL_CREDENTIAL / NOT_TESTED.

## Final combined bug check

After Skills Pack + Plugins Pack integration, run the complete cross-pack bug check
from `BUG_CHECK_PLAN.md` and the Skills Pack bug plan.

Do not declare the stage complete solely because static/unit tests pass.

## Output

Create:
`docs/context/PLUGINS_PACK_V1_INTEGRATION_REPORT.md`

and final combined:
`docs/context/SKILLS_PLUGINS_FINAL_BUG_CHECK.md`

Include:
START_HEAD
FINAL_HEAD
FILES_CHANGED
PLUGIN_MATRIX
SKILL_MATRIX
SECURITY
APPROVALS
CREDENTIALS
GATEWAY
COST_GOVERNOR
WINDOWS
BROWSER
MEMORY
EXTERNAL_SKIPS
FULL_TESTS
SECRET_SCAN
CI
P0
P1
P2
FINAL_GATE

Push normally, verify remote HEAD, no force push.
