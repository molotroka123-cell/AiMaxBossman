# Integration Guide

## 1. Do not create duplicate infrastructure

Map this pack onto existing Bossman components:

- `PluginManager.approval` -> existing approval engine
- `PluginManager.policy` -> existing policy/scopes engine
- credential refs -> existing secret broker/store
- plugin audit -> existing events/audit log
- Ollama/OpenRouter plugins -> existing Stage 3 Gateway
- OpenRouter cloud usage -> existing Cost Governor
- browser plugin -> existing Browser/Playwright subsystem
- Telegram plugin -> existing durable Telegram notification subsystem

## 2. Suggested directory

`bossman-core/bossman/plugins/`

Keep pack interfaces thin.

## 3. Default policy

Read operations: usually ALLOW after owner authentication.
External writes: ASK.
Destructive actions: ASK and replay-safe.
Arbitrary shell: DENY / not exposed.
Unknown capability: DENY.

## 4. Credential design

Manifests contain **references**, not secrets:
- `github.token`
- `google.oauth`
- `telegram.bot_token`
- `n8n.api_key`
- `openrouter.api_key`
- `database.dsn`

At execution time, existing Bossman secret broker resolves only the credential
needed by that plugin and scope.

## 5. Live acceptance gates

GitHub:
- read repo PASS
- create temporary issue ASK
- reject path produces no issue
- approve path creates issue
- cleanup ASK

Gmail:
- search/read PASS
- draft PASS
- send ASK
- reject sends nothing

Calendar:
- search PASS
- create ASK
- reject creates nothing

Drive:
- search/read PASS
- create/update ASK

n8n:
- list workflows PASS
- run harmless test workflow ASK

Obsidian:
- read/search PASS
- write inside vault ASK
- traversal DENY

SQL:
- SELECT PASS
- INSERT/DROP/multi-statement DENY

Ollama:
- must route through Bossman Gateway
- `cloud_policy=never`
- zero cloud calls

OpenRouter:
- must route through Gateway + Cost Governor
- exhausted budget stops before network

MCP:
- unknown/untrusted tool ASK or DENY
- tool scopes enforced
