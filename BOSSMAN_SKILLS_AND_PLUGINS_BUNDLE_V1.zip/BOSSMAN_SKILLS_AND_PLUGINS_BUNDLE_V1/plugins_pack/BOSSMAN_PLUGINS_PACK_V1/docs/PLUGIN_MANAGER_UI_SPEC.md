# Plugin Manager UI spec

Command Center page: `/plugins`

Each plugin card:
- name / id / version
- enabled / disabled / degraded / error
- health badge
- declared capabilities
- scope list
- default risk per capability
- credential reference status: configured / missing / expired
- last successful call
- last error
- rate-limit state
- retry state
- enable / disable
- test health
- revoke credential
- open audit trail

Never render raw credential values.

Capability table:
`capability | scopes | default policy | owner override | last call | status`

Owner overrides may only make a capability stricter without an explicit privileged
admin action. `DENY -> ALLOW` must never happen implicitly because a plugin requests it.

Health check is non-destructive and must not send messages, create events,
modify files, execute workflows, merge PRs, or make billable LLM calls.
