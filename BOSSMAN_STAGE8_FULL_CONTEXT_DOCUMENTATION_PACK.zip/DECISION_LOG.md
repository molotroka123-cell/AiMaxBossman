# Durable Decision Log

Use stable IDs. Do not delete superseded decisions.

## DEC-0001 — Local-first/private-first

**Status:** active  
BOSSMAN is designed primarily as a private local AI system. Public exposure is never the default.

## DEC-0002 — ComputerUse is generic capability

**Status:** active  
Browser/computer use is a shared agent capability, not a set of hard-coded site integrations.

## DEC-0003 — Consequential actions remain approval-gated

**Status:** active  
Browser/sandbox/tool execution does not bypass Bossman approvals.

## DEC-0004 — Quality over context compression

**Status:** active  
Context savings are accepted only when task quality is preserved or improved.

## DEC-0005 — Memory requires provenance and lifecycle

**Status:** active  
Durable memory includes source/provenance and supports stale/superseded/disputed states.

## DEC-0006 — Gateway is the common model transport

**Status:** active  
Agents/context/search/vision should converge on one capability-aware model gateway rather than calling providers ad hoc.

## DEC-0007 — Resource Brain controls expensive workloads

**Status:** active  
LLM/video/training/sandbox workloads must participate in resource admission rather than independently exhausting the host.

## DEC-0008 — Search Everything reuses Context Engine

**Status:** active  
No second competing RAG architecture.

## DEC-0009 — Sandbox default OFF

**Status:** active  
No meaningful sandbox runtime/resource use until explicitly enabled.

## DEC-0010 — Network default OFFLINE

**Status:** active  
Internet access requires a stronger mode/policy.

## DEC-0011 — Multiple sandbox isolation tiers

**Status:** active  
Light trusted workloads and hostile unknown workloads should not pay the same isolation cost.

## DEC-0012 — Hardware-backed isolation for hostile workloads

**Status:** active  
High-risk/unknown code should use a MicroVM/VM class isolation when host capability permits.

## DEC-0013 — CubeSandbox is a candidate/reference, not mandatory core dependency

**Status:** active  
TencentCloud/CubeSandbox has strong relevant architecture (KVM/RustVMM, eBPF networking, egress/credential proxy, snapshots) and Apache-2.0 licensing, but must be integrated behind an adapter and benchmarked on the actual host.

## DEC-0014 — Observability uses an internal neutral schema

**Status:** active  
Use OpenTelemetry/OpenInference-compatible concepts internally. External systems such as Phoenix/Langfuse are optional exporters/sidecars, not hard dependencies.

## DEC-0015 — Phoenix optional due license

**Status:** active  
Phoenix is useful for tracing/evals/datasets/replay but is ELv2; integrate by adapter/sidecar and do not copy it into BOSSMAN core.

## DEC-0016 — Langfuse optional due operational weight

**Status:** active  
Langfuse is powerful but self-hosting is comparatively heavy. It should remain optional.

## DEC-0017 — Sandbox memory is candidate memory

**Status:** active  
Sandbox-local learnings do not become trusted Stage 2.222 durable memory automatically.

## DEC-0018 — Fine-tuning consumes sanitized sandbox data

**Status:** active  
Fine-tuning is downstream from security/runtime and consumes approved dataset candidates, not raw audit logs.

## DEC-0019 — No unrestricted convenience mode

**Status:** active  
Do not ship a default “YOLO/unrestricted” button that disables the security boundary.

## DEC-0020 — Artifact return crosses an explicit gate

**Status:** active  
Outputs from untrusted execution pass path/type/size/hash/secret/executable validation before entering host/project state.
