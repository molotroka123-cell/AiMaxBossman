# BOSSMAN AI LAB / SANDBOX — Documentation & Context Pack

**Snapshot date:** 2026-08-29  
**Purpose:** give Claude Code enough durable context that a very short chat prompt is sufficient to continue implementation without reconstructing the project from conversation history.

This package is intentionally documentation-first. It contains:

1. every Markdown document from the previous Stage 1–7 handoff;
2. a durable project/context snapshot;
3. a source-of-truth and context-retention protocol;
4. the complete Stage 8 architecture/specification;
5. security, isolation, networking, secret-broker, artifact-gate and threat-model requirements;
6. observability, trajectory, memory, evaluation and synthetic-data specifications;
7. integration contracts with Stages 1–7;
8. implementation, testing, benchmarking and failure-recovery playbooks;
9. decision records and reusable templates.

The package is **not** a claim that Stage 8 code is already implemented. It is the specification and engineering handoff for Claude Code to implement against the actual current repository.

## Start

Read in this order:

1. `START_HERE.md`
2. `CONTEXT_SNAPSHOT.md`
3. `NON_NEGOTIABLES.md`
4. `CONTEXT_RETENTION_PROTOCOL.md`
5. `DECISION_LOG.md`
6. `stage8/STAGE_8_AI_LAB_SANDBOX.md`
7. `stage8/CLAUDE_BUILD_GUIDE.md`
8. remaining `stage8/*.md`
9. relevant historical docs in `legacy_stage_1_to_7_docs/`

**Actual repository HEAD remains the source of truth for code.**
