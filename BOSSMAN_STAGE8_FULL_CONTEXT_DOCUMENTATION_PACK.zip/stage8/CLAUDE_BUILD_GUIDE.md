# Claude Code Build Guide — Stage 8

## Mission

Implement Stage 8 against the real current repository.

Do not merely create placeholders.

Do not force every third-party candidate into the project.

## Phase 0 — Recon

Inspect:

- git state;
- current Stage 1–7 integration;
- migrations;
- config;
- lifecycle;
- tests;
- current Resource Brain contracts;
- current events/approvals;
- ComputerUse browser lifecycle;
- Gateway interfaces;
- Context/Memory interfaces.

Record contradictions between docs and code.

## Phase 1 — Contracts

Define typed contracts for:

- policy;
- runtime;
- session;
- risk assessment;
- network;
- secret grants;
- resource leases;
- trajectories;
- artifacts;
- evals.

Write tests for contract/state-machine behavior before expensive runtime integration.

## Phase 2 — Fake runtime

Build a deterministic fake sandbox runtime capable of simulating:

- success;
- slow start;
- crash;
- timeout;
- network denied;
- destroy failure;
- partial output.

Use it for Core integration tests.

## Phase 3 — SAFE runtime

Implement the light supported local runtime with strict defaults.

Prove:

- workspace isolation;
- quotas;
- lifecycle;
- cleanup;
- OFFLINE mode.

## Phase 4 — stronger runtime adapter

Integrate gVisor-like/runtime support if available and justified.

Do not block all Stage 8 development on one optional runtime.

## Phase 5 — HOSTILE runtime adapter

Integrate MicroVM/VM path.

CubeSandbox is a strong candidate. Verify actual installation/runtime constraints on the target host.

Never silently downgrade HOSTILE policy.

## Phase 6 — Secret Broker + egress

Implement control-plane credential/network mediation.

Test bypasses.

## Phase 7 — Artifact Gate

Build quarantine/import path.

Test symlink/traversal/archive/binary cases.

## Phase 8 — Trajectory + observability

Use internal neutral event/span schema.

Add optional Phoenix/Langfuse exporters only after core telemetry works locally.

## Phase 9 — evals and dataset candidates

Build deterministic validation and sanitization pipeline.

Do not implement automatic fine-tuning yet.

## Phase 10 — chaos/security pass

Run the attack matrix and failure recovery tests.

## Multi-agent review loop

Use independent reviewers if available:

### Architect/Builder

Owns implementation.

### Security reviewer

Attempts boundary bypass.

### Reliability reviewer

Attacks lifecycle/cancellation/restart/resource release.

### Performance reviewer

Measures overhead and rejects unnecessary complexity.

### Integration reviewer

Ensures Stage 8 reuses Stages 1–7 rather than duplicating them.

## Allowed redesign

You may change earlier-stage code if Stage 8 reveals a genuine architectural flaw.

Requirements:

- migration path;
- tests;
- decision update;
- no silent breaking behavior.

## Avoid

- huge rewrite without tests;
- second Resource Brain;
- second memory engine;
- second model gateway;
- raw Docker socket;
- privileged default container;
- `seccomp=unconfined` as a final untrusted-code security posture;
- broad host mounts;
- raw secrets in env;
- unrestricted network default;
- automatic training from logs;
- heavy observability stack forced on startup.

## Finish

Before DONE:

- full test suite;
- Stage 8 unit/integration/security/chaos tests;
- restart reconciliation;
- repository hygiene;
- secret scan;
- benchmark;
- update durable context/decision/test docs;
- list known limitations honestly.
