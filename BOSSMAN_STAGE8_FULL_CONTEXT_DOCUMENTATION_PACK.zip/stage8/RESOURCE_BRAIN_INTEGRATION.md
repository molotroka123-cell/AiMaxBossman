# Resource Brain Integration

## Stage 8 must not own a second host scheduler

Resource Brain remains the host authority for expensive workload admission.

## Sandbox request

A sandbox should declare estimates/limits such as:

- RAM;
- CPU;
- disk;
- expected duration;
- GPU/unified memory if needed;
- runtime tier;
- network mode;
- priority.

## Resource lease

Flow:

`request -> reserve -> create runtime -> run -> release`

Lease must be released on:

- normal completion;
- failure;
- cancellation;
- destroy;
- startup recovery of orphaned sessions.

Double release must be safe.

## Unified memory

On AMD unified-memory systems, avoid assuming "system RAM" and "VRAM" are independent capacities.

Use runtime/probe adapters.

## Pressure behavior

Example:

- NORMAL: admit normally;
- ELEVATED: reduce low-priority concurrency;
- HIGH: delay video/training/large sandbox work;
- CRITICAL: refuse new expensive workloads and preserve interactive/Core health.

## Fairness

A single client/agent should not monopolize all sandbox capacity.

## Disk

Dataset/checkpoint/build caches can fill disk silently.

Reserve a minimum host disk floor and enforce per-sandbox/project quotas.
