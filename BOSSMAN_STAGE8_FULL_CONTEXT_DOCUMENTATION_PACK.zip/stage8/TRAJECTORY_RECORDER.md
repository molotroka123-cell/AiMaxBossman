# Trajectory Recorder

## Purpose

Record agent behavior for:

- debugging;
- replay;
- evaluations;
- comparison;
- synthetic-data generation;
- future fine-tuning.

## Raw trajectory event model

Possible event types:

- model request/response metadata;
- tool call;
- shell command;
- file read/write metadata;
- browser action;
- network decision;
- approval request/result;
- resource snapshot;
- checkpoint;
- test result;
- evaluator result;
- artifact creation;
- failure/retry.

## Correlation

Use stable:

- trajectory ID;
- sandbox ID;
- task ID;
- run ID;
- agent ID;
- model request ID;
- parent event ID/span.

## Never blindly record secrets

Sanitize/redact:

- auth headers;
- cookies;
- API keys;
- passwords;
- private SSH material;
- secret-broker payloads;
- other policy-marked sensitive fields.

## Immutable-ish audit

Important security audit data should be append-oriented.

Optional enhancement:

- event hash chaining;
- signed session manifest.

Do not overengineer cryptography without a concrete threat model.

## Replay

Replay has two modes:

### inspect replay

Reconstruct timeline without executing side effects.

### execution replay

Run a controlled copy/fork in a fresh sandbox.

Execution replay must not inherit original secrets/network implicitly.

## Fork

A checkpoint can be used to test alternative agent/model/prompt strategies against the same starting state.
