# Runtime Selection and Risk Scoring

## Goal

Choose the least expensive runtime that still meets the required security level.

## Inputs to risk assessment

Examples:

- source is user-authored vs unknown internet repo;
- binary blobs present;
- install scripts;
- obfuscated JS/Python/shell;
- Dockerfile/privileged requirements;
- Git hooks;
- GitHub workflow code;
- package manager lifecycle scripts;
- downloaded executables;
- requests for host mounts;
- requests for network;
- requests for secrets;
- requested kernel/device access;
- known security scanner findings;
- task explicitly adversarial.

## Example risk classes

### LOW

Trusted code, no network/secrets, basic tests.

### MEDIUM

Normal third-party repo, standard dependencies, outbound allowlist.

### HIGH

Unknown repo with installers/binaries/network/scripts.

### HOSTILE

Known suspicious/adversarial code, exploit tests, exfiltration behavior or unsafe runtime requirements.

## Runtime policy

Example mapping:

- LOW -> SAFE
- MEDIUM -> DEVELOPER
- HIGH -> DEVELOPER/CONNECTED with strict policy or HOSTILE
- HOSTILE -> HOSTILE LAB

Do not make the numerical score alone authoritative. Security findings can hard-escalate mode.

## Candidate technologies

### Rootless container

Fast/cheap; shared kernel. Good for trusted/simple work.

### gVisor-like runtime

Stronger syscall isolation while keeping container ergonomics.

### CubeSandbox / KVM MicroVM

Strong candidate for HOSTILE mode:

- dedicated guest kernel;
- RustVMM/KVM;
- eBPF networking;
- L7 egress;
- credential injection;
- snapshots/clones.

Integration should be behind `SandboxRuntime` so BOSSMAN is not structurally locked to one runtime.

## Hardware/runtime capability probe

At startup or on-demand detect:

- KVM availability;
- supported container runtimes;
- gVisor availability;
- filesystem reflink support;
- eBPF capabilities;
- virtualization restrictions.

Capability probe is not permission to start the runtime while sandbox is OFF.
