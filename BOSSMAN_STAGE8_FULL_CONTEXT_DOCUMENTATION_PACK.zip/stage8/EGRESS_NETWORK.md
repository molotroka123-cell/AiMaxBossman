# Network / Egress Policy

## Modes

### OFFLINE

Default.

No normal external network.

### ALLOWLIST

Only explicit approved destinations.

Policies should support domain plus, where practical:

- scheme;
- port;
- method;
- path constraints.

### INTERNET

Broad outbound access, still with protections against host/private/control-plane access.

## Always-protected destinations

Unless an explicit internal-integration policy says otherwise, deny:

- localhost/loopback;
- host bridge/control addresses;
- RFC1918/private LAN;
- link-local;
- cloud metadata endpoints;
- BOSSMAN admin endpoints;
- raw model backend admin endpoints;
- container/runtime sockets.

Prevent DNS rebinding bypass where feasible.

## Egress audit

Capture safe metadata:

- sandbox;
- timestamp;
- hostname;
- resolved destination;
- method/protocol where known;
- allow/deny;
- policy rule;
- bytes if inexpensive.

Do not log authorization secrets.

## Approval escalation

Changing network mode upward can be approval-gated based on policy/risk.

## Failure

Proxy/policy failure in restricted mode must fail closed.
