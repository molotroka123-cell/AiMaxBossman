# Third-Party Adoption Policy

Before adding any sandbox/security/observability/training dependency:

1. confirm exact repository and maintainer;
2. inspect license;
3. inspect release/activity state;
4. inspect security model;
5. inspect installation privileges;
6. inspect network behavior;
7. inspect default credentials;
8. inspect telemetry/phone-home behavior;
9. inspect container privileges/mounts;
10. inspect dependency tree;
11. run in Stage 8 HOSTILE/DEVELOPER environment first;
12. benchmark resource overhead;
13. decide:
   - adopt;
   - adapter only;
   - copy idea/pattern only;
   - reject.

## Do not vendor blindly

Curated "awesome" repositories are sources of links/ideas, not executable dependencies.

## Pinning

If adopted:

- pin version/tag/commit;
- prefer image digest over `latest`;
- preserve license/NOTICE;
- document upgrade process;
- add regression/security tests.

## Optional systems

Phoenix/Langfuse-class systems must be optional and must not make BOSSMAN unusable when disabled.
