# Stage 8 Architecture

```text
                           BOSSMAN CORE
                                |
                         Sandbox Manager
                                |
          +---------------------+----------------------+
          |                     |                      |
      Policy Engine       Resource Brain          Approvals
          |                     |                      |
          +---------------------+----------------------+
                                |
                         Risk Classifier
                                |
             +------------------+------------------+
             |                  |                  |
            SAFE             DEVELOPER         HOSTILE LAB
             |                  |                  |
       Rootless Runtime      gVisor-like       MicroVM/VM
             |                  |                  |
             +------------------+------------------+
                                |
                         Sandbox Toolbox
                    shell / git / files / browser
                                |
                    +-----------+-----------+
                    |                       |
               Secret Broker           Egress Plane
                    |                 OFF/ALLOW/NET
                    +-----------+-----------+
                                |
                           Agent Runtime
                                |
                       Trajectory Recorder
                                |
              +-----------------+-----------------+
              |                 |                 |
            Traces           Actions           Artifacts
              |                                   |
              v                                   v
       BOSSMAN Telemetry                     Artifact Gate
              |                                   |
      optional exporters                           v
       Phoenix/Langfuse                    Approved Outputs
              |
         Replay / Fork
              |
          Evaluation
              |
      Dataset Sanitization
              |
      Dataset Candidates
              |
       Quality/Human Gate
              |
       Future SFT / DPO / RL
```

## Control plane vs execution plane

### Control plane

Runs on trusted host:

- policy;
- approvals;
- Resource Brain;
- Secret Broker;
- runtime orchestration;
- durable metadata;
- audit;
- dataset gate.

### Execution plane

Untrusted/less-trusted:

- agent-generated code;
- downloaded repositories;
- browser content;
- build tooling;
- dependency installers;
- tests;
- generated binaries.

Execution plane must not possess control-plane administrative credentials.

## Trust boundaries

1. User/remote client -> BOSSMAN API
2. BOSSMAN Core -> sandbox runtime
3. sandbox -> network
4. sandbox -> credential broker
5. sandbox -> artifact return
6. trajectory -> dataset
7. sandbox memory -> durable memory

Each crossing requires a deterministic policy.
