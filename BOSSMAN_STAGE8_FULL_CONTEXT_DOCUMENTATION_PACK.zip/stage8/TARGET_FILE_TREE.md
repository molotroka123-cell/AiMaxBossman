# Suggested Stage 8 File Tree

This is a design suggestion, not a mandatory exact layout.

```text
bossman/
  sandbox/
    __init__.py
    manager.py
    models.py
    policy.py
    risk.py
    lifecycle.py
    runtime/
      base.py
      fake.py
      rootless.py
      gvisor.py
      cube.py
    network/
      policy.py
      proxy.py
    secrets/
      broker.py
      models.py
    artifacts/
      gate.py
      scanners.py
    trajectory/
      recorder.py
      models.py
      sanitize.py
      replay.py
    evals/
      evaluator.py
      validators.py
      dataset.py
    telemetry.py
    recovery.py

tests/
  sandbox/
    test_policy.py
    test_lifecycle.py
    test_runtime_fake.py
    test_network.py
    test_secrets.py
    test_artifact_gate.py
    test_trajectory.py
    test_dataset.py
    test_recovery.py
    test_security_matrix.py
```

Prefer adapting to existing package conventions rather than forcing this tree.
