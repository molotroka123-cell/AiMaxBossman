# Failure and Recovery

## Host/Core crash

On startup:

1. find sessions not in terminal state;
2. query runtime if possible;
3. reconcile actual runtime state;
4. mark interrupted/orphaned sessions;
5. reclaim/repair Resource Brain leases;
6. revoke stale secret grants;
7. preserve audit metadata.

Do not simply assume all were destroyed.

## Runtime crash

- capture exit reason;
- collect safe diagnostics;
- close/revoke network/secret paths;
- persist partial trajectory;
- mark artifacts incomplete;
- release resource lease;
- retry only if retry policy permits.

## Provider/tool failure

A tool failure does not imply the sandbox should be destroyed.

Use structured component health/state.

## Disk full

Protect the host:

- quotas;
- minimum reserve;
- stop accepting new writes;
- fail cleanly;
- preserve minimal audit metadata.

## Network proxy failure

Restricted modes fail closed.

## Artifact validation crash

Artifact remains quarantined/untrusted.

## Trajectory recorder failure

Security-critical audit events should have a fallback/error signal. Do not claim a trajectory is complete if it is not.

## Destroy failure

Destroy is idempotent and retryable.

A session is not terminally "destroyed" until required cleanup is confirmed or explicitly marked `destroy_failed`.
