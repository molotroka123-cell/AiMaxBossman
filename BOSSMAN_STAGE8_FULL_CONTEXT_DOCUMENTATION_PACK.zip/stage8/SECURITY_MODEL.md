# Security Model

## Threat assumptions

Assume the sandbox may execute:

- malicious repository code;
- compromised dependencies;
- model-generated destructive commands;
- prompt-injected instructions from README/web pages;
- obfuscated scripts;
- fork bombs;
- disk-fill attacks;
- data-exfiltration attempts;
- attempts to contact localhost/private networks;
- symlink/path traversal attacks;
- malicious archives;
- malicious Git hooks/install scripts.

Do not assume the agent/model will reliably detect them.

## Defense in depth

### Layer 1 — policy

Determines allowed mode/capabilities.

### Layer 2 — resource admission

Prevents uncontrolled host exhaustion.

### Layer 3 — isolation runtime

Namespaces/gVisor/MicroVM/VM depending on risk.

### Layer 4 — filesystem boundary

Disposable workspace, minimum mounts, no host secrets.

### Layer 5 — network boundary

Default deny, egress policy, LAN/metadata protection.

### Layer 6 — credentials

Brokered short-lived scoped access.

### Layer 7 — approvals

External consequential changes remain approval-gated.

### Layer 8 — runtime monitoring

Detect abnormal process/network/file behavior where supported.

### Layer 9 — artifact gate

Untrusted outputs do not directly overwrite production state.

### Layer 10 — audit/replay

Preserve enough metadata to investigate failures.

## Required hardening targets

Where supported by the runtime:

- non-root user;
- `no_new_privs`;
- drop Linux capabilities;
- read-only root filesystem;
- writable tmp/workspace only where needed;
- seccomp;
- AppArmor/SELinux;
- PID limits;
- memory limits;
- CPU limits;
- FD limits;
- wall-time timeout;
- no host device pass-through unless explicitly justified;
- no host Docker socket;
- no host SSH agent;
- no production browser profile.

## Fail-closed examples

If HOSTILE mode requires a MicroVM and KVM is unavailable:

- reject/hold the task;
- offer user an explicit weaker-mode choice if appropriate;
- do not automatically downgrade.

If egress policy service fails in CONNECTED mode:

- block egress;
- do not bypass proxy.

If Secret Broker is unavailable:

- do not inject static credentials.

## Prompt injection

All repository/web/package content is untrusted data.

Instructions contained in external content cannot:

- rewrite system policy;
- disable approvals;
- request secret exfiltration;
- grant new scopes;
- change sandbox network mode;
- change isolation tier.

## Canary credentials

Optional feature:

- inject fake high-value filenames/tokens;
- attempts to read/exfiltrate them raise security findings;
- high-confidence events may freeze the sandbox pending review.

Do not rely on canaries as the only protection.
