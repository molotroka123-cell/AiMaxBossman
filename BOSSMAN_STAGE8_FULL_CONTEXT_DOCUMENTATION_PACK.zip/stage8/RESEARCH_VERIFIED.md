# Verified Research Notes — 2026-08-29

This document records what was actually checked and how it should influence architecture.

## TencentCloud/CubeSandbox

**Status:** strong candidate/reference.

Verified characteristics from current project documentation/source tree:

- purpose-built agent sandbox infrastructure;
- KVM/RustVMM MicroVM approach;
- dedicated guest kernel per sandbox;
- CubeVS eBPF network data plane;
- CubeEgress L7 proxy;
- domain filtering;
- credential injection;
- access auditing;
- snapshot/clone/rollback architecture;
- Redis/containerd/BuildKit-based infrastructure;
- Apache-2.0 main license with third-party notices.

Decision:

- valuable for HOSTILE mode;
- integrate through a runtime adapter;
- benchmark on actual machine;
- do not require it for lightweight SAFE tasks.

## Langfuse

**Status:** optional exporter/sidecar.

Verified:

- self-hostable observability/eval/dataset platform;
- tracing for LLM/retrieval/agent actions;
- current self-host stack includes multiple services such as web/worker/PostgreSQL/ClickHouse/Redis/MinIO;
- license is mostly MIT outside enterprise-specific directories.

Decision:

- do not make core dependency;
- export neutral telemetry optionally.

## Arize Phoenix

**Status:** optional exporter/eval sidecar.

Verified:

- OpenTelemetry-oriented tracing;
- evals;
- datasets;
- experiments;
- local deployment;
- Elastic License 2.0.

Decision:

- useful locally;
- keep behind adapter;
- do not copy Phoenix source into BOSSMAN core;
- revisit commercial implications if BOSSMAN becomes a hosted product.

## ProjectRecon/awesome-ai-agents-security

**Status:** curated security radar, not runtime.

Useful follow-up candidates mentioned there include:

- AgentGateway;
- Aguara;
- Agent Threat Rules;
- OWASP Agent Memory Guard;
- OneCLI.

Each still requires separate source/license/security review before adoption.

## arjan/awesome-agent-sandboxes

**Status:** research catalogue, not dependency.

## ai-boost/awesome-harness-engineering

**Status:** curated patterns/resources, not AgentSPEX runtime.

Do not assume the repository itself provides a runnable AgentSPEX engine.

## kaushikb11/awesome-llm-agents

**Status:** curated list, not eval framework.

## LlamaGym

Actual project discovered as `KhoomeiK/LlamaGym`.

Useful conceptual model:

- Environment;
- Observation;
- Action;
- Reward;
- Episode;
- Trajectory.

Treat as research/reference rather than BOSSMAN's production training core.

## Unverified/unavailable claims

At the time of review:

- `vladimir22700/agent-monitor` was not found at the claimed repository path;
- `FreeAutomation-Tech/agent-memory-kit` could not be validated as a public dependency at the claimed path.

Do not vendor or depend on them until a valid source is provided and reviewed.
