# Acceptance Gates

Stage 8 must not be marked DONE if any P0 or serious P1 remains.

## Gate A — Disabled state

PASS only if sandbox OFF causes no meaningful runtime activity.

## Gate B — Isolation

PASS only if supported runtime tests prove host-sensitive paths/control sockets are unavailable to untrusted workloads.

## Gate C — Networking

PASS only if OFFLINE and ALLOWLIST behavior are tested, including private/control-plane destinations.

## Gate D — Secrets

PASS only if production credentials are not exposed to sandbox environment/files/model context and revocation works.

## Gate E — Resources

PASS only if resource admission and enforced runtime limits prevent obvious host exhaustion scenarios.

## Gate F — Lifecycle

PASS only if create/run/cancel/freeze/destroy and restart reconciliation are tested.

## Gate G — Artifact boundary

PASS only if unsafe paths/archives/executables are rejected/quarantined.

## Gate H — Trajectory safety

PASS only if secrets/sensitive fields are sanitized before dataset candidate export.

## Gate I — Memory safety

PASS only if sandbox-originated memory cannot silently become trusted durable memory.

## Gate J — No silent security downgrade

PASS only if unavailable strong isolation fails closed for policies that require it.

## Gate K — Repository hygiene

No:

- real secrets;
- runtime profiles;
- sandbox disk images;
- generated datasets;
- model weights;
- large trajectory logs;
- caches;
- debug downloads;

committed accidentally.

## Gate L — Documentation

Current architecture, decisions, tests and known limitations match reality.
