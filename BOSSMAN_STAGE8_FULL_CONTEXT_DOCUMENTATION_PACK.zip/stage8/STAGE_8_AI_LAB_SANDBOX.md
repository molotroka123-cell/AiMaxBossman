# Stage 8 — BOSSMAN AI LAB / SANDBOX

## Mission

Build a secure local execution and experimentation platform for agents.

Stage 8 combines:

1. secure execution;
2. risk-based isolation;
3. controlled networking;
4. scoped credential access;
5. resource admission;
6. trajectory recording;
7. replay/fork;
8. evaluation;
9. dataset candidate generation;
10. future fine-tuning integration.

It must be useful even before any model fine-tuning is enabled.

## Product modes

### OFF

Everything sandbox-related is inactive.

### SAFE

For trusted/simple tasks:

- lightweight rootless runtime;
- no production secrets;
- offline by default;
- strict workspace;
- normal quotas.

### DEVELOPER

For routine coding/experimentation:

- stronger syscall/container isolation (gVisor-like where available);
- controlled workspace snapshot;
- optional allowlisted network;
- scoped brokered integrations.

### CONNECTED

For tasks that genuinely need external APIs/network:

- strong isolation;
- explicit egress policy;
- Secret Broker;
- destination/audit logging;
- stricter approvals.

### HOSTILE LAB

For unknown/suspicious repositories or intentionally adversarial tests:

- MicroVM/VM-class isolation;
- offline default;
- no host secrets;
- disposable browser/profile;
- strongest quotas;
- artifact-only output;
- optional forensic snapshot before destroy.

## High-level workflow

`Request -> Risk Analysis -> Policy -> Resource Admission -> Runtime Selection -> Workspace Snapshot -> Network/Secret Setup -> Execute -> Observe -> Checkpoint -> Evaluate -> Artifact Gate -> Dataset Candidate -> Cleanup`

## Non-goals for Stage 8

- full autonomous fine-tuning scheduler;
- public multi-tenant SaaS;
- unrestricted host-control mode;
- automatic promotion of sandbox memories;
- automatic training on raw logs.

## Required runtime abstractions

Suggested contracts:

- `SandboxManager`
- `SandboxRuntime`
- `SandboxSession`
- `SandboxSpec`
- `SandboxPolicy`
- `RiskAssessment`
- `NetworkPolicy`
- `SecretGrant`
- `ResourceLease`
- `TrajectoryRecorder`
- `ArtifactGate`
- `Evaluator`
- `DatasetCandidate`
- `RuntimeCapabilities`

Names may differ if the repo has stronger conventions.

## Lifecycle

Desired state model:

- DISABLED
- REQUESTED
- ADMITTED
- PREPARING
- READY
- RUNNING
- PAUSED
- FROZEN
- COMPLETED
- FAILED
- DESTROYING
- DESTROYED

Invalid transitions should be rejected deterministically.

## Integrations

### Resource Brain

Owns host-level resource admission/leases.

### Gateway

Provides model capabilities used by agents/evaluators/vision without leaking provider-specific credentials into sandbox.

### Context/Memory

Supplies approved task context; receives validated memory candidates only.

### ComputerUse

Can provide a sandbox-local browser capability, but sandbox browser profiles are separate from authenticated production profiles.

### Approvals

Remain the gate for consequential external actions.

### Events

Publishes lifecycle/progress/security/resource events.

### Search Everything

Can index sanitized sandbox artifacts and approved reports, not raw secrets.

## Definition of Stage 8 complete

At minimum:

- a sandbox can be created, executed, bounded and destroyed;
- OFFLINE is truly enforced in the supported runtime;
- host filesystem escape tests fail safely;
- production secrets are absent from sandbox environment/files;
- a Resource Brain lease gates expensive sessions;
- trajectories can be recorded and sanitized;
- artifacts cross an explicit validation gate;
- restart recovery is tested;
- high-risk jobs cannot silently downgrade to weak isolation;
- tests cover adversarial cases.
