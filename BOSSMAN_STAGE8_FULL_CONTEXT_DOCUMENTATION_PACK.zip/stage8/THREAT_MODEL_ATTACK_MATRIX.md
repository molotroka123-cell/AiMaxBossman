# Threat / Attack Test Matrix

These are defensive acceptance tests.

| Attack / failure | Expected result |
|---|---|
| Read host `~/.ssh` | unavailable/denied |
| Read production `.env` | unavailable/denied |
| Access host Docker socket | unavailable |
| Access localhost control plane | denied unless explicit brokered channel |
| Access private LAN in OFFLINE/ALLOWLIST | denied |
| Access cloud metadata IP | denied |
| DNS rebinding to private IP | denied where supported |
| Fork bomb | PID/CPU/resource limit contains it |
| Disk fill | sandbox quota/reserve stops host exhaustion |
| Symlink escape | Artifact/File gate rejects |
| `../` path traversal | rejected |
| Zip-slip archive | rejected/quarantined |
| Malicious Git hook | cannot escape sandbox |
| `npm`/package install script attack | contained and policy-visible |
| `curl | sh` | blocked/restricted by policy where configured |
| Secret exfiltration attempt | no raw secret available; egress denied/audited |
| Prompt injection in README | does not alter control-plane policy |
| Model requests stronger network mode | policy/approval required |
| High-risk job when KVM unavailable | no silent weak downgrade |
| Client disconnect during job | job policy determines cancel/continue; no leak |
| Host restart mid-job | reconciliation/recovery |
| Runtime dies mid-stream | cleanup/release/structured failure |
| Artifact executable returned | quarantined by default |
| Raw trajectory contains token pattern | sanitizer rejects/redacts |
| Malicious memory instruction | remains candidate/untrusted |
