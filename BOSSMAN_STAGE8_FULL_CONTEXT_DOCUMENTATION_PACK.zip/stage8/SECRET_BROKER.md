# Secret Broker

## Principle

The safest secret is the one the sandbox never sees.

## Desired behavior

Instead of:

```text
GITHUB_TOKEN=...
```

inside the sandbox, prefer:

```text
sandbox -> broker/proxy -> approved GitHub operation
```

or short-lived scoped credentials when proxying is impossible.

## Properties

A grant should include:

- grant ID;
- sandbox ID;
- integration;
- allowed scope/action;
- destination constraints;
- TTL;
- max uses if applicable;
- approval reference if required;
- revocation state.

## Rules

- no long-lived master keys inside sandbox;
- raw secret must not appear in model context/logs/trajectory;
- credential is revoked on destroy;
- credential is revoked on emergency freeze;
- broker logs metadata, not secret values;
- use least privilege;
- use short TTL;
- bind grants to sandbox/session.

## High-value integrations

Future examples:

- GitHub read-only repository access;
- package registries;
- cloud model calls via Gateway;
- limited external API calls.

## Proxy-based credential injection

CubeSandbox's egress/credential design is a useful reference:

- sandbox requests destination;
- trusted proxy validates policy;
- proxy injects auth header;
- sandbox never receives the raw key.

BOSSMAN should preserve provider neutrality via an adapter.
