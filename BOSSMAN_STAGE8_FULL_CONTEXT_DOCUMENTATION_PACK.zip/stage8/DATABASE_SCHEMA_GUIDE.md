# Persistence / Database Guide

Use the existing PostgreSQL where appropriate.

## Candidate durable entities

### sandbox_sessions

Fields may include:

- id;
- runtime;
- isolation mode;
- state;
- task/run/agent;
- policy version;
- network mode;
- workspace source/ref/hash;
- created/started/completed/destroyed timestamps;
- exit reason;
- resource lease ID;
- risk assessment ID.

### sandbox_risk_assessments

- id;
- class/score;
- findings;
- scanner versions;
- decision/runtime;
- timestamp.

### sandbox_secret_grants

Store metadata only:

- grant ID;
- integration;
- scope;
- expiry;
- revoked;
- approval reference.

Do not store plaintext secret values.

### trajectories

- ID;
- sandbox;
- storage manifest;
- hashes;
- sanitation status;
- size;
- start/end.

### artifacts

- ID;
- sandbox;
- path/name;
- content hash;
- MIME/type;
- size;
- quarantine/import status;
- validation report.

### evaluation_runs

- evaluator/version;
- trajectory/task;
- scores;
- validator outputs.

### dataset_candidates

- candidate ID;
- trajectory;
- sanitation version;
- quality state;
- destination dataset/version.

## Migrations

Never silently mutate schemas.

Add reversible/forward-safe migrations consistent with the existing migration system.

## Runtime data

Large video/artifact/trajectory blobs should not automatically live inside PostgreSQL. Store metadata in DB and use a controlled filesystem/object-store abstraction where appropriate.
