# Artifact Gate

## Goal

Nothing produced by untrusted execution directly becomes trusted host/project state.

## Pipeline

`Sandbox output -> collect -> quarantine -> normalize -> inspect -> policy -> approve/import`

## Checks

Depending on artifact type:

- canonical path;
- symlink handling;
- size;
- MIME/type;
- extension mismatch;
- content hash;
- archive listing;
- archive traversal/zip-slip;
- executable detection;
- secret scan;
- binary/malware/YARA scan if configured;
- source-code policy scan;
- provenance manifest.

## Executables

Generated/downloaded executables are quarantined by default.

Returning a binary does not imply permission to execute it on the host.

## Source patches

Preferred coding workflow:

- sandbox modifies disposable worktree;
- diff is exported;
- tests/results accompany diff;
- host-side integration/import is explicit.

## Metadata

Every artifact should be traceable to:

- sandbox ID;
- task/run;
- source commit;
- generation step/tool;
- hash;
- validation result;
- approval/import event.
