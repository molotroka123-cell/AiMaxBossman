# Observability

## Internal standard

Use a vendor-neutral internal telemetry model aligned with:

- OpenTelemetry concepts;
- OpenInference concepts for AI/LLM spans.

## Trace categories

- agent;
- model;
- retrieval;
- tool;
- sandbox;
- resource;
- network;
- artifact;
- evaluation.

## Core metrics

Examples:

- sandbox create latency;
- sandbox boot latency;
- active sessions;
- queue depth;
- resource denied count;
- sandbox crashes;
- sandbox timeout count;
- egress allow/deny;
- secret grant count;
- artifact rejected count;
- trajectory size;
- eval pass rate;
- tokens;
- LLM latency;
- tool failure rate.

## Local-first

BOSSMAN must remain usable without external observability services.

## Optional exporter: Phoenix

Useful features:

- OTel-based tracing;
- evals;
- datasets;
- experiments;
- replay/playground.

License note:

- Phoenix uses Elastic License 2.0;
- keep it optional/sidecar;
- do not merge Phoenix source into BOSSMAN core.

## Optional exporter: Langfuse

Useful features:

- traces;
- agent/retrieval/model observability;
- evals/datasets;
- prompt experiments.

Operational note:

- current self-host stack is comparatively heavy and includes web/worker/PostgreSQL/ClickHouse/Redis/MinIO;
- therefore it should be optional and OFF unless explicitly enabled.

License note:

- much of core is MIT but enterprise directories have separate terms;
- use public supported APIs/exporters instead of source copying.

## No telemetry leak

Telemetry is data. Apply sensitivity rules before exporting anywhere.
