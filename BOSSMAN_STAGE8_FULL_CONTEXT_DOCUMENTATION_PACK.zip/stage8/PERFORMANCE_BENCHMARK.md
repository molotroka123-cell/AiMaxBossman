# Performance Benchmark Plan

## Why

Stage 8 must add security without turning normal trusted workflows into unnecessary heavy jobs.

## Measure per runtime tier

- cold create latency;
- warm/resume latency if supported;
- destroy latency;
- baseline idle RAM;
- per-sandbox memory overhead;
- CPU overhead;
- disk footprint;
- concurrent create behavior;
- trajectory recording overhead;
- network proxy latency where applicable.

## Workloads

- no-op/echo;
- Python test;
- npm install/build;
- git clone + test;
- browser start/navigation;
- medium code-repair task.

## Host protection metric

More important than peak speed:

- BOSSMAN Core stays responsive under concurrent sandbox load;
- Resource Brain pressure behavior activates before OOM/disk failure.

## Vendor claims

Treat third-party benchmark claims as hypotheses until reproduced locally.
