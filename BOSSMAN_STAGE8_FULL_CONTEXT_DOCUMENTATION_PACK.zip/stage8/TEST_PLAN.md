# Stage 8 Test Plan

## Unit tests

- policy evaluation;
- risk classifier;
- runtime selection;
- lifecycle transitions;
- path containment;
- network mode validation;
- secret grant scopes/TTL;
- artifact validators;
- trajectory sanitizer;
- dataset candidate rules;
- resource lease interactions.

## Integration tests

- Core -> Resource Brain -> runtime;
- runtime -> network policy;
- runtime -> Secret Broker;
- runtime -> trajectory recorder;
- artifact export/import;
- approvals;
- events;
- context/memory candidate path;
- Gateway use from evaluator/agent.

## Runtime isolation tests

Against each supported runtime:

- host sensitive paths inaccessible;
- mount boundaries;
- process limits;
- memory limits;
- PID limits;
- network policy;
- runtime destroy;
- orphan cleanup.

## Chaos tests

- kill runtime;
- kill proxy;
- kill Core;
- queue full;
- disk reserve reached;
- resource denial;
- client disconnect;
- destroy during execution;
- recorder failure;
- malformed runtime response;
- secret broker unavailable.

## Security tests

Use the attack matrix.

## Restart tests

Persist a running session state, restart Core, reconcile accurately.

## Performance tests

Measure, do not guess:

- create latency;
- destroy latency;
- resource probe overhead;
- trajectory overhead;
- artifact hashing/scan overhead;
- concurrent sandbox pressure;
- memory overhead.

## Third-party runtime benchmark

If CubeSandbox is installed:

- verify KVM prerequisites;
- benchmark local boot/memory/density claims independently;
- do not copy vendor benchmark claims into BOSSMAN metrics.

## Test independence

Core unit tests must not require:

- internet;
- GPU;
- CubeSandbox;
- Phoenix;
- Langfuse.

Use deterministic fake runtimes/exporters/brokers.
