# Sandbox Memory and State

## Principle

Do not create another competing BOSSMAN memory subsystem.

Stage 8 uses Stage 2.222 Context & Memory Engine.

## Sandbox-local working memory

A disposable workspace may keep files such as:

```text
.bossman/
  session/
  notes/
  decisions/
  failures/
  learnings/
```

These are working artifacts, not automatically trusted durable memory.

## Promotion flow

`Sandbox learning -> MemoryCandidate -> provenance/security checks -> Distillery/validation -> active durable memory`

## Preserve negative memory

Useful sandbox outcomes include:

- failed commands;
- incompatible dependency;
- broken approach;
- exploit blocked;
- flaky test;
- dangerous package;
- rejected artifact.

These can become failure/negative memory when validated.

## Memory poisoning defense

Sources inside untrusted repos/web pages cannot directly create active durable memory.

Candidate should carry:

- source;
- sandbox ID;
- source commit/path;
- confidence;
- trust/sensitivity;
- evaluator result;
- security findings.

## Cross-session recall

Future sessions may retrieve approved durable memories through Stage 2.222 plugins/retrieval rather than mounting a global writable memory directory into untrusted sandboxes.
