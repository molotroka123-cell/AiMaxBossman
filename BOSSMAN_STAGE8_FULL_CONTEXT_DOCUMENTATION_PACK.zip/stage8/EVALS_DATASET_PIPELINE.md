# Evaluation, Synthetic Data and Fine-Tuning Data Plane

## Core rule

Fine-tuning is downstream from sandbox security.

## Pipeline

```text
Task specification
      |
Sandbox execution
      |
Raw trajectory
      |
Sanitization
      |
Deterministic validators
      |
Optional model judge
      |
Quality scoring
      |
Dataset candidate
      |
Human/quality gate
      |
Versioned dataset
      |
Future SFT / DPO / RL
```

## Evaluation hierarchy

Prefer, in order:

1. deterministic task-specific validators;
2. tests/compilers/linters;
3. artifact comparison;
4. behavioral invariants;
5. model judges as supplementary evidence.

Do not use LLM-as-judge as the sole correctness source when deterministic validation exists.

## Useful reward/eval signals

- task success;
- unit/integration tests passed;
- policy violations;
- number of retries;
- tool failures;
- unnecessary destructive actions;
- token efficiency;
- wall-clock time;
- resource usage;
- artifact validity;
- user preference/selection.

Avoid collapsing all quality into one opaque reward too early.

## SFT candidates

High-quality successful trajectories:

- task;
- relevant context;
- reasoning-visible artifacts only where policy permits;
- tool calls/results;
- final answer/output;
- validator scores.

## Preference/DPO candidates

Create pairwise examples from:

- successful vs failed attempt;
- lower-policy-violation vs higher;
- accepted artifact vs rejected;
- faster/cleaner implementation when correctness is equal.

## Curriculum

Support progressive task suites:

- shell/file basics;
- git workflows;
- debugging;
- repository repair;
- browser/tool use;
- full-stack fixes;
- long-horizon multi-step tasks.

## Dataset versioning

Every exported dataset needs:

- dataset ID/version;
- generator/runtime/model versions;
- source task suite;
- sanitation policy version;
- eval version;
- included/excluded trajectory IDs;
- checksums.

## Poisoning prevention

Do not promote data from:

- unresolved security incidents;
- unverified adversarial sources;
- secret-contaminated trajectories;
- tasks with failed validators;
- corrupted/incomplete logs;

without explicit review.
