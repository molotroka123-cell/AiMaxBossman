# Stage 8 API and Events

Exact routes should match existing Bossman API conventions.

## Candidate API operations

- create sandbox;
- get sandbox;
- list sandboxes;
- freeze;
- pause/resume where runtime supports;
- destroy;
- exec/tool request;
- inspect resource usage;
- inspect network decisions;
- list/export artifacts;
- trajectory metadata;
- replay/fork;
- evaluate;
- promote dataset candidate.

## Security

Remote API must:

- require device/client auth;
- enforce scopes;
- never return raw secrets;
- never expose control-plane runtime sockets.

## Candidate events

- `sandbox.requested`
- `sandbox.admitted`
- `sandbox.ready`
- `sandbox.started`
- `sandbox.paused`
- `sandbox.frozen`
- `sandbox.completed`
- `sandbox.failed`
- `sandbox.destroyed`
- `sandbox.resource.warning`
- `sandbox.network.denied`
- `sandbox.security.finding`
- `sandbox.artifact.created`
- `sandbox.artifact.rejected`
- `sandbox.approval.required`
- `trajectory.recorded`
- `evaluation.completed`
- `dataset.candidate.created`

## Correlation IDs

Events should include only relevant safe IDs:

- sandbox;
- task;
- run;
- agent;
- device;
- request;
- trajectory;
- artifact.

## Slow subscribers

Current event bus behavior must be reviewed for:

- slow subscriber handling;
- reconnect;
- cross-process use;
- event loss expectations.

Do not introduce Kafka unless the requirements actually need it.
