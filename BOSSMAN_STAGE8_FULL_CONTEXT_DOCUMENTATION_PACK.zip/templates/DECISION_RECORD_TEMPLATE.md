# DEC-XXXX — Title

**Status:** proposed | active | superseded | disputed  
**Date:**  
**Scope:**  

## Decision

## Why

## Alternatives

## Consequences

## Verification

## Supersedes

## Superseded by
