# SEC-XXXX — Finding

**Severity:** P0 | P1 | P2 | P3  
**Status:** open | mitigated | accepted | false-positive  
**Component:**  

## Finding

## Attack path / trigger

## Impact

## Evidence

## Fix

## Test proving fix

## Residual risk
