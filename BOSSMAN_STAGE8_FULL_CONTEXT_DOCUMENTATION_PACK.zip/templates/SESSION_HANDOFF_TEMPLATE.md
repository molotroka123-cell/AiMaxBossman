# Session Handoff

Date:
Branch/HEAD:

## Objective

## Completed

## Changed files

## Active decisions

## Exact test commands/results

## Known failures

## Security findings

## Resource/performance findings

## Open blockers

## Next actions

1.
2.
3.

## Critical anchors

- paths:
- versions:
- IDs:
- limits:
- API contracts:
