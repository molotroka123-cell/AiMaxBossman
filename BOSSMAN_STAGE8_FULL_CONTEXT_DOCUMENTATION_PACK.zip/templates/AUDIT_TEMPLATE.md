# YYYY-MM-DD__scope__audit-type__vN

Commit:
Auditor/review pass:

## Scope

## Architecture findings

## Security findings

## Reliability findings

## Performance findings

## Test gaps

## P0/P1

## Required fixes

## Accepted limitations
