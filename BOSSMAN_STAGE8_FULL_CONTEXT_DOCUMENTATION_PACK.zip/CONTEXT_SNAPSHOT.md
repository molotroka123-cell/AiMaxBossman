# Durable Context Snapshot

## Project

Repository: `molotroka123-cell/AiMaxBossman`

BOSSMAN is a local-first private AI control system intended to coordinate agents, models, browser/computer use, memory/context, search, media workflows, remote clients and later training/evaluation infrastructure on a powerful local machine.

Target host discussed for deployment:

- AMD Ryzen AI Max+ 395 class system;
- 128 GB unified memory;
- local model workloads are expected to compete with browser, video and training jobs for the same host resources.

Do not hard-code assumptions about exact hardware. Runtime adapters must probe capabilities.

---

# Existing staged architecture

## Stage 1 — ComputerUse V1.2

Shared browser/computer-use capability for agents:

- persistent Chromium profiles;
- locking;
- tabs/windows/popups;
- iframes;
- uploads/downloads;
- screenshot + vision path;
- scroll/hover;
- checkpoints;
- diagnostics;
- blocker detection;
- dangerous-submit approval gating;
- browser shutdown lifecycle.

Security boundaries:

- no CAPTCHA bypass;
- no MFA bypass;
- no anti-bot/access-control bypass;
- consequential actions remain approval-gated;
- webpage content is untrusted data.

## Stage 2.222 — Context & Memory Engine

Architecture goals:

- hybrid retrieval;
- reranking;
- deduplication;
- adaptive context packing;
- durable memory with provenance;
- decision/failure/negative memory;
- contradiction/superseding states;
- distillation;
- Compact skill;
- memory plugins;
- quality-over-token-savings.

Important memory states include:

- candidate
- active
- stale
- superseded
- disputed
- rejected

Important memory kinds include:

- fact
- decision
- failure
- procedure
- preference
- episode
- todo
- constraint
- summary

## Stage 3 — AI Gateway + Model Router

Central OpenAI-compatible model transport/routing layer intended to support:

- `/v1/chat/completions`
- `/v1/responses`
- `/v1/embeddings`
- `/v1/models`
- aliases/capabilities;
- local/cloud backends;
- health;
- fallback;
- streaming;
- queue/concurrency;
- auth/rate limiting;
- telemetry.

Cloud fallback must never bypass agent cloud policy:

- `never`
- `ask`
- `allowed`

## Stage 4 — Resource Brain

Resource admission/scheduling foundation:

- snapshots;
- workload estimates;
- model ranking;
- future leases/residency;
- RAM/disk pressure;
- unified-memory awareness.

Stage 8 must reuse and deepen this rather than invent a second scheduler.

## Stage 5 — Search Everything

One provenance-aware search plane across projects/code/docs/memory/history.

Must reuse Stage 2.222 retrieval/memory primitives, not create duplicate RAG stores.

## Stage 6 — Private Remote Client backend

Foundation for a future private phone client:

- device identities;
- scoped credentials;
- revocation;
- event delivery;
- private-network-first design.

## Stage 7 — Video Factory

Resumable scene/job pipeline:

- projects;
- scenes/takes;
- providers;
- checkpoints;
- retries;
- future QA/upscale/FFmpeg;
- Resource Brain gating.

---

# Stage 8 — BOSSMAN AI LAB / SANDBOX

Stage 8 is not merely "run code in Docker."

It is the foundation for:

- secure agent execution;
- unknown GitHub repository testing;
- agent swarms;
- trajectory recording;
- replay/fork;
- deterministic evals;
- synthetic-data generation;
- later SFT/DPO/RL pipelines.

Core security principle:

> The model is never the security boundary. Policy and isolation are enforced by deterministic code outside the sandbox.

Core product principle:

> Sandbox OFF means actually OFF: no worker, VM, browser, secret mount, inbound port or meaningful background resource use until explicitly started.

Core data principle:

> Raw trajectories never become training data automatically.

Core integration principle:

> Stage 8 must reuse Gateway, Resource Brain, Context/Memory, approvals, ComputerUse, events and existing durable storage instead of duplicating them.
