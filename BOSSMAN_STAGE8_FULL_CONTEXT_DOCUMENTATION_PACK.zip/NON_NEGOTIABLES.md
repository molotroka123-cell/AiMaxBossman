# Non-Negotiable Requirements

These requirements are architectural boundaries. A future implementation may improve how they are achieved, but must not silently weaken them.

## 1. Sandbox OFF means OFF

When disabled:

- no sandbox VM/container workers;
- no sandbox browser;
- no Jupyter/VSCode/MCP service;
- no sandbox inbound port;
- no production secrets mounted;
- no production browser profiles mounted;
- no background repository scanning;
- no trajectory capture process consuming resources.

## 2. Default network is OFFLINE

Network modes:

- `OFFLINE` — default;
- `ALLOWLIST` — explicit destinations;
- `INTERNET` — explicit user/policy choice.

Internet access is not inferred from task text alone.

## 3. No host Docker socket

Never mount `/var/run/docker.sock` or equivalent host-control sockets into untrusted workloads.

## 4. No raw production credentials

Never directly expose:

- `.env`;
- SSH keys;
- GitHub PATs;
- browser cookies;
- Telegram tokens;
- OpenRouter/API keys;
- database admin credentials;
- host cloud credentials.

Use a Secret Broker / credential-injection design.

## 5. Strong isolation tiers

Minimum target modes:

- SAFE — lightweight rootless isolation for trusted/simple work;
- DEVELOPER — stronger container/gVisor-like isolation;
- CONNECTED — strong isolation + controlled egress + scoped integrations;
- HOSTILE LAB — hardware-backed MicroVM/VM for unknown or high-risk code.

The system may map runtime technologies differently if the host does not support one, but must fail closed rather than silently downgrade high-risk jobs.

## 6. Production filesystem is not a writable sandbox mount

Use disposable snapshots/copies/worktrees.

Outputs return through an Artifact Gate.

## 7. Resource limits are enforced

A sandbox receives bounded:

- RAM;
- CPU;
- disk;
- process count;
- file descriptors;
- wall time;
- network quota where supported.

Resource Brain must participate in admission.

## 8. Approvals remain above sandbox

Sandboxing does not remove approval requirements for consequential external actions.

## 9. Browser isolation

Risky sandbox browser sessions must not reuse BOSSMAN's authenticated production Chromium profile.

## 10. Fail closed

If required policy/firewall/isolation/secret-broker infrastructure is unavailable, do not silently run with weaker controls.

## 11. Training data requires a gate

Pipeline:

`raw trajectory -> sanitize -> validate/evaluate -> dataset candidate -> quality/human gate -> training dataset`

Never:

`raw logs -> fine-tune`

## 12. No automatic memory poisoning

Sandbox learnings enter durable memory as candidates. They are not promoted to trusted durable memory without validation.

## 13. No uncontrolled public exposure

BOSSMAN sandbox/control/model endpoints are private-network-first. Do not expose raw Ollama/LM Studio/llama.cpp/CDP endpoints to the public internet by default.

## 14. Claude has engineering freedom

Claude may redesign weak components and improve architecture. These non-negotiables constrain security/product outcomes, not implementation style.
