# General Code-Writing Guide for BOSSMAN

This is the engineering standard for implementing Stage 8 and modifying earlier stages.

## 1. Begin from contracts

Before implementation, define:

- input schema;
- output schema;
- lifecycle;
- ownership;
- persistence;
- cancellation;
- error taxonomy;
- security boundary;
- metrics/events;
- test seam.

Avoid broad `dict[str, Any]` when a durable schema is known.

## 2. Prefer adapters at unstable boundaries

Interfaces should isolate:

- sandbox runtimes;
- secret backends;
- egress/firewall implementation;
- observability exporters;
- storage backends;
- video/model providers;
- resource probes.

This allows local-host-specific choices without rewriting the control plane.

## 3. Deterministic security before model judgment

Use deterministic code for:

- path containment;
- permissions;
- resource quotas;
- network policies;
- secret scopes;
- approvals;
- process limits;
- artifact validation.

LLM-based risk/judge signals may augment policy but cannot be the sole enforcement layer.

## 4. Explicit lifecycle objects

Every expensive/runtime object should have:

- `start/create`;
- `state`;
- `cancel/freeze`;
- `destroy/close`;
- idempotent cleanup;
- timeout behavior.

Avoid orphan processes, dangling leases and hidden global mutable state.

## 5. Async discipline

Do not block the event loop with:

- large file scans;
- subprocess waits;
- synchronous HTTP;
- hashing huge artifacts;
- archive expansion.

Use bounded worker pools or async subprocess/IO.

## 6. Backpressure

Never accept infinite work.

Bound:

- task queues;
- sandbox creation;
- provider calls;
- artifact processing;
- trajectory buffering;
- observability exporter buffers.

Prefer structured 429/503/resource-denied outcomes over host OOM.

## 7. Idempotence

Create/destroy/revoke/release operations should tolerate retries.

Examples:

- double `release(lease_id)` must not double-free accounting;
- double sandbox destroy should safely return already-destroyed;
- retrying an artifact import must not create silent duplicates.

## 8. Persistence boundaries

Durable:

- sandbox metadata;
- session/job state;
- approvals;
- audit metadata;
- trajectory manifests;
- dataset candidates;
- security findings.

Ephemeral:

- active process handles;
- open streams;
- temporary extraction directories;
- short-lived queue state.

Use existing PostgreSQL unless another store has a clear requirement.

## 9. Redis only with a reason

Use Redis for things like:

- TTL state;
- distributed locks;
- transient queues/pubsub;

not as a default dumping ground.

## 10. Structured events

Events should have:

- event ID;
- timestamp;
- type;
- correlation IDs;
- actor/agent/device if relevant;
- sandbox/job/task/run IDs;
- safe metadata;
- no secrets.

## 11. Structured errors

Prefer stable error codes such as:

- `SANDBOX_DISABLED`
- `POLICY_DENIED`
- `RESOURCE_DENIED`
- `ISOLATION_UNAVAILABLE`
- `NETWORK_DENIED`
- `SECRET_SCOPE_DENIED`
- `ARTIFACT_REJECTED`
- `QUEUE_FULL`
- `SANDBOX_TIMEOUT`
- `SANDBOX_CRASHED`
- `RUNTIME_UNAVAILABLE`
- `APPROVAL_REQUIRED`
- `INTERNAL_ERROR`

Do not send raw host tracebacks to remote clients.

## 12. Logs never contain secrets

Redact:

- Authorization;
- cookies;
- API keys;
- session tokens;
- SSH material;
- passwords;
- raw credential-broker payloads.

## 13. Path safety

All sandbox/host paths crossing boundaries must:

- normalize;
- resolve symlinks where relevant;
- verify containment under the allowed root;
- reject path traversal;
- reject unexpected device/proc/sys/socket paths.

## 14. Process execution

Use argument arrays, not concatenated shell strings, unless a shell is explicitly the feature being provided inside the sandbox.

Host-side FFmpeg/git/container/runtime commands should be argument-safe.

## 15. Configuration

Configuration must be:

- validated at startup;
- human-readable;
- secret-free in committed examples;
- versionable;
- explicit about defaults;
- fail-fast on impossible security combinations.

## 16. Feature flags

High-cost modules may be disabled.

A disabled module must not spawn background work.

## 17. Test every failure path

Success-only tests are insufficient.

For each component test:

- timeout;
- cancellation;
- restart;
- invalid input;
- unavailable dependency;
- queue pressure;
- partial output;
- double cleanup;
- policy denial.

## 18. Refactoring freedom

Large refactors are acceptable when they materially improve the system and are protected by tests/migrations.

Avoid enterprise theater: do not add Kubernetes/Kafka/service mesh/multiple databases just to look production-like on a single local server.

## 19. Documentation discipline

After architecture changes, update:

- decision log;
- current state;
- stage architecture;
- test status;
- migration notes;
- session handoff.

## 20. Final standard

A change is not complete because it compiles.

It is complete when:

- behavior is tested;
- failure modes are understood;
- cleanup works;
- observability exists;
- security boundary is preserved;
- docs match reality.
