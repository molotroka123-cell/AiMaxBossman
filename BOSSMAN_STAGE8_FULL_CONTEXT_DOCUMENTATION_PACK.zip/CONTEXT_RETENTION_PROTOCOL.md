# Context Retention Protocol

This file exists so future Claude sessions do not depend on chat history.

## Goal

The repository itself must contain enough current state that a fresh agent can answer:

- What are we building?
- What has already been implemented?
- What decisions are active?
- What failed before?
- What is currently broken?
- What is the next task?
- What security boundaries cannot change?
- Which tests prove the current state?

## Required durable artifacts

The implementation should maintain equivalents of:

- `docs/context/CURRENT_STATE.md`
- `docs/context/DECISIONS.md`
- `docs/context/FAILURES.md`
- `docs/context/OPEN_ISSUES.md`
- `docs/context/TEST_STATUS.md`
- `docs/context/SESSION_HANDOFF.md`

Names may change if the repo already has a better convention.

## Current-state anchors

Every session handoff should preserve exact anchors:

- current objective;
- current branch/HEAD;
- important file paths;
- active architecture decisions;
- API contracts;
- model aliases/capabilities;
- database migrations involved;
- exact unresolved blockers;
- latest test commands/results;
- known security findings;
- numbers/limits/versions that affect correctness;
- next 3–10 concrete actions.

## Source-of-truth hierarchy

Use this order:

1. current repository code/runtime;
2. tests and migrations;
3. active decision records;
4. current stage spec;
5. latest audit;
6. older docs;
7. historical chat/context.

A summary must never silently override raw evidence.

## Context update rule

After any material architectural change:

1. update decision record;
2. update current-state file;
3. update affected architecture/spec docs;
4. record superseded decision instead of deleting history;
5. update test status;
6. update session handoff.

## Compaction rule

Before a long session is compacted, generate an extractive-first handoff preserving:

- exact paths;
- exact IDs;
- exact versions;
- exact errors;
- exact tests;
- unresolved TODOs;
- explicit user corrections;
- security boundaries.

If the compact representation would lose critical anchors, use more context rather than compressing harder.

## Failure memory

Failed approaches are valuable context.

Record:

- attempt;
- symptom;
- root cause if known;
- fix/replacement;
- test proving the fix;
- whether the old approach must not be retried.

## Contradiction handling

Do not silently overwrite contradictory facts.

Use explicit states such as:

- active;
- stale;
- superseded;
- disputed;
- unverified.

## Session start

A fresh coding agent should:

1. read current state;
2. read active decisions;
3. read latest failures/open issues;
4. inspect git status/diff;
5. run the smallest relevant smoke tests;
6. then modify code.

## Session end

Before stopping:

1. run relevant tests;
2. record failures honestly;
3. update current state;
4. update active decisions;
5. write a concise session handoff;
6. ensure no secrets/runtime junk were committed.
