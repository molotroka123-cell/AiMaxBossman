# How the Future Short Prompt Should Work

The intention of this pack is that the chat prompt does **not** repeat the whole specification.

A future prompt only needs to tell Claude Code to:

- open this documentation pack;
- begin with `START_HERE.md`;
- inspect the current repository HEAD;
- implement Stage 8 autonomously;
- use multiple independent review passes;
- update durable context documents before finishing.

Do not put implementation details back into chat unless they changed after this documentation snapshot.
