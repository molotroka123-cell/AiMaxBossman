# START HERE — Claude Code

You are continuing **AiMaxBossman** after Stages 1–7.

Your job is not to mechanically follow stale chat instructions. Your job is to reconcile:

- the current repository HEAD;
- the historical Stage 1–7 documentation;
- the Stage 8 specification in this package;
- current tests and runtime reality;

and then build the strongest technically defensible version of Stage 8.

## Read order

Mandatory:

1. `CONTEXT_SNAPSHOT.md`
2. `NON_NEGOTIABLES.md`
3. `CONTEXT_RETENTION_PROTOCOL.md`
4. `DECISION_LOG.md`
5. `stage8/STAGE_8_AI_LAB_SANDBOX.md`
6. `stage8/ARCHITECTURE.md`
7. `stage8/SECURITY_MODEL.md`
8. `stage8/CLAUDE_BUILD_GUIDE.md`
9. `stage8/TEST_PLAN.md`
10. `stage8/ACCEPTANCE_GATES.md`

Then inspect the current repository, especially:

- Core startup/shutdown;
- agents/runner;
- toolkit and ComputerUse;
- approvals/policy;
- Gateway/model router;
- Resource Brain;
- Context & Memory Engine;
- Search Everything;
- Remote Client/events;
- Video Factory;
- PostgreSQL/Redis usage;
- current migrations/config;
- tests.

## Freedom

You may improve, redesign, merge, replace or delete weak implementations when the change is justified by correctness, reliability, security, maintainability, observability or performance.

Do not preserve poor code just because it already exists.

Do not rewrite stable code just for aesthetic preference.

## Multi-agent engineering

Use multiple independent reasoning/review passes where supported:

- Architect / Builder
- Security / Adversarial Reviewer
- Reliability / Chaos QA
- Performance / Resource Reviewer
- Integration / Context Reviewer

The reviewer must challenge the builder rather than rubber-stamp changes.

## Source-of-truth order

When information conflicts:

1. current code + passing tests + runtime behavior;
2. current durable decisions in `DECISION_LOG.md`;
3. Stage 8 specification;
4. historical Stage 1–7 docs;
5. old chat assumptions.

Never silently resolve a material contradiction. Record it.

## Definition of success

Stage 8 succeeds when BOSSMAN can run untrusted/unknown agent workloads through a policy-controlled, resource-bounded, auditable sandbox with strong isolation options, no implicit secret exposure, default-deny networking, safe artifact return, trajectory capture, replay/evaluation plumbing, and a clean future path to synthetic-data/fine-tuning workflows.

A pretty dashboard is not a substitute for isolation, policy enforcement, tests or recovery.
