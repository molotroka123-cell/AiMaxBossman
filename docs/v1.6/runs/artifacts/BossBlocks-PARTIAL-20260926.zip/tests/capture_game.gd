extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var game = load("res://scenes/main.tscn").instantiate()
	game.save_path = "user://bossblocks-owner-capture.json"
	root.add_child(game)
	for i in range(15):
		await process_frame
	var path := "res://tests/bossblocks-game.png"
	var error := root.get_viewport().get_texture().get_image().save_png(path)
	if error != OK:
		printerr("BOSSBLOCKS_CAPTURE_FAIL: ", error_string(error))
		quit(1)
		return
	print("BOSSBLOCKS_CAPTURE_PASS: ", ProjectSettings.globalize_path(path))
	quit(0)
