"""Real Godot checks for the playable BossBlocks vertical slice.

These replace the original candidate's method-name and 130-line shape checks.
The previous tests did not execute Godot or validate gameplay.
"""

import os
import shutil
import subprocess
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parent.parent
PINNED_GODOT = Path(
    r"C:\Users\asd\AppData\Local\Bossman\tool-cache\bossblocks-001\editor\godot.windows.editor.x86_64.exe"
)


def godot_binary() -> str:
    path = os.environ.get("GODOT_BIN") or (str(PINNED_GODOT) if PINNED_GODOT.is_file() else shutil.which("godot"))
    if not path:
        pytest.skip("Godot binary unavailable")
    return path


def run_godot(*args: str) -> str:
    result = subprocess.run(
        [godot_binary(), "--headless", "--path", str(ROOT), *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    output = result.stdout + result.stderr
    assert result.returncode == 0, output
    assert "SCRIPT ERROR" not in output and "ERROR:" not in output, output
    return output


def test_main_scene_launches():
    output = run_godot("--quit-after", "5")
    assert "Godot Engine v4.7.2" in output


def test_controls_and_block_interactions():
    output = run_godot("--script", "res://tests/owner_controls.gd")
    assert "BOSSBLOCKS_CONTROLS_PASS" in output


def test_save_survives_process_restart():
    save_output = run_godot("--script", "res://tests/owner_save.gd")
    load_output = run_godot("--script", "res://tests/owner_load.gd")
    second_load_output = run_godot("--script", "res://tests/owner_load.gd")
    assert "BOSSBLOCKS_SAVE_STAGE_PASS" in save_output
    assert "BOSSBLOCKS_LOAD_STAGE_PASS" in load_output
    assert "BOSSBLOCKS_LOAD_STAGE_PASS" in second_load_output
