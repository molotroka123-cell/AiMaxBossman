extends SceneTree

const TEST_SAVE := "user://bossblocks-owner-controls.json"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if FileAccess.file_exists(TEST_SAVE):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(TEST_SAVE))
	var game = load("res://scenes/main.tscn").instantiate()
	game.save_path = TEST_SAVE
	root.add_child(game)
	for i in range(5):
		await physics_frame
	var key := InputEventKey.new()
	key.keycode = KEY_3
	key.pressed = true
	game._unhandled_input(key)
	if game.selected_type != 3:
		return _fail("hotbar")
	key.keycode = KEY_ESCAPE
	game._unhandled_input(key)
	if not game.paused:
		return _fail("pause")
	game._unhandled_input(key)
	if game.paused:
		return _fail("resume")
	var motion := InputEventMouseMotion.new()
	motion.relative = Vector2(40, 25)
	game._unhandled_input(motion)
	if game.player.rotation.y == 0.0 or game.camera.rotation.x == 0.0:
		return _fail("mouse look")
	game.camera.rotation.x = -0.9
	game.ray.force_raycast_update()
	var hit: Vector3i = game._target_cell()
	if hit.x == 999:
		return _fail("ray target")
	var old_count: int = game.blocks.size()
	game._break_target()
	if game.blocks.has(hit) or game.blocks.size() != old_count - 1:
		return _fail("break")
	await physics_frame
	game.ray.force_raycast_update()
	var next_hit: Vector3i = game._target_cell()
	if next_hit.x == 999:
		return _fail("ray after break")
	var count_before_place: int = game.blocks.size()
	game._place_target()
	if game.blocks.size() != count_before_place + 1:
		return _fail("place")
	var was: Vector3 = game.player.position
	var forward := InputEventKey.new()
	forward.keycode = KEY_W
	forward.pressed = true
	Input.parse_input_event(forward)
	for i in range(20):
		await physics_frame
	forward.pressed = false
	Input.parse_input_event(forward)
	if game.player.position.distance_to(was) < 0.1:
		return _fail("movement")
	for step in [
		{"key": KEY_S, "axis": "z", "sign": 1.0},
		{"key": KEY_D, "axis": "x", "sign": 1.0},
		{"key": KEY_A, "axis": "x", "sign": -1.0},
	]:
		var before: Vector3 = game.player.position
		var move := InputEventKey.new()
		move.keycode = step["key"]
		move.pressed = true
		Input.parse_input_event(move)
		for i in range(12):
			await physics_frame
		move.pressed = false
		Input.parse_input_event(move)
		var axis_delta: float = game.player.position[step["axis"]] - before[step["axis"]]
		if axis_delta * step["sign"] < 0.1:
			return _fail("movement " + str(step["key"]))
	for i in range(35):
		await physics_frame
	if not game.player.is_on_floor():
		return _fail("floor collision")
	var before_jump: float = game.player.position.y
	var jump := InputEventKey.new()
	jump.keycode = KEY_SPACE
	jump.pressed = true
	Input.parse_input_event(jump)
	for i in range(5):
		await physics_frame
	jump.pressed = false
	Input.parse_input_event(jump)
	if game.player.position.y <= before_jump + 0.1:
		return _fail("jump")
	game.player.position = Vector3(0, 0.35, 0)
	game.player.velocity = Vector3.ZERO
	game.player.rotation.y = 0.0
	game.camera.rotation.x = -1.4
	await physics_frame
	game.ray.force_raycast_update()
	var underfoot: Vector3i = game._target_cell()
	if underfoot != Vector3i(0, -1, 0):
		return _fail("underfoot target")
	var before_reject: int = game.blocks.size()
	game._place_target()
	if game.blocks.size() != before_reject or game.save_note != "Cannot place inside player":
		return _fail("player placement guard")
	game.player.position = Vector3(7.5, 0.35, 0)
	game.player.velocity = Vector3.ZERO
	var into_wall := InputEventKey.new()
	into_wall.keycode = KEY_D
	into_wall.pressed = true
	Input.parse_input_event(into_wall)
	for i in range(60):
		await physics_frame
	into_wall.pressed = false
	Input.parse_input_event(into_wall)
	if game.player.position.x > 8.3:
		return _fail("wall collision")
	print("BOSSBLOCKS_CONTROLS_PASS hit=", hit, " next=", next_hit, " movement=", game.player.position.distance_to(was))
	quit(0)

func _fail(step: String) -> void:
	printerr("BOSSBLOCKS_CONTROLS_FAIL: ", step)
	quit(1)
