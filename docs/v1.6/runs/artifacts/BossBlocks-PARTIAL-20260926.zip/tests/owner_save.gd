extends SceneTree

const TEST_SAVE := "user://bossblocks-owner-test.json"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if FileAccess.file_exists(TEST_SAVE):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(TEST_SAVE))
	var game = load("res://scenes/main.tscn").instantiate()
	game.save_path = TEST_SAVE
	root.add_child(game)
	await process_frame
	var removed := Vector3i(1, -1, 0)
	var placed := Vector3i(1, 0, 0)
	if not game.blocks.has(removed) or game.blocks.has(placed):
		printerr("BOSSBLOCKS_SAVE_STAGE_FAIL: bad initial world")
		quit(1)
		return
	game._remove_block(removed)
	game._add_block(placed, 3)
	for i in range(3):
		game._save_world()
	if not FileAccess.file_exists(TEST_SAVE):
		printerr("BOSSBLOCKS_SAVE_STAGE_FAIL: save missing")
		quit(1)
		return
	if not game._overlaps_player(Vector3i(0, 2, 0)):
		printerr("BOSSBLOCKS_SAVE_STAGE_FAIL: overlap guard")
		quit(1)
		return
	print("BOSSBLOCKS_SAVE_STAGE_PASS blocks=", game.blocks.size())
	quit(0)
