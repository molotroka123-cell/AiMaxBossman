import unittest
from pathlib import Path


class TestProjectSetup(unittest.TestCase):
    def setUp(self):
        self.repo_root = Path(__file__).resolve().parent.parent
        self.project_godot = self.repo_root / "project.godot"
        self.readme = self.repo_root / "README.md"

    def test_project_title(self):
        content = self.project_godot.read_text()
        self.assertIn("BossBlocks", content)

    def test_main_scene(self):
        content = self.project_godot.read_text()
        self.assertIn("res://scenes/main.tscn", content)

    def test_readme_wip_status(self):
        content = self.readme.read_text()
        self.assertIn("work in progress", content.lower())


if __name__ == "__main__":
    unittest.main()
