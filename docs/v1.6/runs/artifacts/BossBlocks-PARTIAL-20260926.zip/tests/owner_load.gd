extends SceneTree

const TEST_SAVE := "user://bossblocks-owner-test.json"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if not FileAccess.file_exists(TEST_SAVE):
		printerr("BOSSBLOCKS_LOAD_STAGE_FAIL: save missing")
		quit(1)
		return
	var game = load("res://scenes/main.tscn").instantiate()
	game.save_path = TEST_SAVE
	root.add_child(game)
	await process_frame
	var removed := Vector3i(1, -1, 0)
	var placed := Vector3i(1, 0, 0)
	if game.blocks.has(removed) or not game.blocks.has(placed):
		printerr("BOSSBLOCKS_LOAD_STAGE_FAIL: block edits not restored")
		quit(1)
		return
	if int(game.blocks[placed].get_meta("kind")) != 3:
		printerr("BOSSBLOCKS_LOAD_STAGE_FAIL: block kind not restored")
		quit(1)
		return
	print("BOSSBLOCKS_LOAD_STAGE_PASS blocks=", game.blocks.size())
	quit(0)
