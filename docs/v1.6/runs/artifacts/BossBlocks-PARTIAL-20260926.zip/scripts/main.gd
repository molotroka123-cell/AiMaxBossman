extends Node3D

const SAVE_FILE := "user://bossblocks_world.json"
const WORLD_EDGE := 8
const BLOCK_NAMES := ["Grass", "Sand", "Stone"]

var save_path := SAVE_FILE
var blocks: Dictionary = {}
var materials: Array[StandardMaterial3D] = []
var player: CharacterBody3D
var camera: Camera3D
var ray: RayCast3D
var marker: MeshInstance3D
var hud: Label
var selected_type := 1
var paused := false
var spawn := Vector3(0, 2.0, 0)
var save_note := ""


func _ready() -> void:
	_make_materials()
	_make_world()
	_make_player()
	_make_hud()
	_make_target_marker()
	_load_world()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_refresh_hud()


func _make_materials() -> void:
	for color in [Color("69aa56"), Color("d8bc79"), Color("858f9e")]:
		var material := StandardMaterial3D.new()
		material.albedo_color = color
		material.roughness = 1.0
		materials.append(material)


func _make_world() -> void:
	for x in range(-WORLD_EDGE, WORLD_EDGE + 1):
		for z in range(-WORLD_EDGE, WORLD_EDGE + 1):
			_add_block(Vector3i(x, -2, z), 3)
			_add_block(Vector3i(x, -1, z), 1 + (abs(x) + abs(z)) % 3)
	for edge in range(-WORLD_EDGE - 1, WORLD_EDGE + 2):
		for y in range(0, 2):
			_add_block(Vector3i(-WORLD_EDGE - 1, y, edge), 3)
			_add_block(Vector3i(WORLD_EDGE + 1, y, edge), 3)
			_add_block(Vector3i(edge, y, -WORLD_EDGE - 1), 3)
			_add_block(Vector3i(edge, y, WORLD_EDGE + 1), 3)
	var sunlight := DirectionalLight3D.new()
	sunlight.rotation_degrees = Vector3(-58, -32, 0)
	sunlight.light_energy = 1.5
	add_child(sunlight)
	var environment := WorldEnvironment.new()
	var settings := Environment.new()
	settings.background_mode = Environment.BG_COLOR
	settings.background_color = Color("8dbbdd")
	settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color = Color("a9bdd0")
	settings.ambient_light_energy = 0.7
	environment.environment = settings
	add_child(environment)


func _add_block(cell: Vector3i, kind: int) -> void:
	if blocks.has(cell) or kind < 1 or kind > 3:
		return
	var body := StaticBody3D.new()
	body.name = "Block_%d_%d_%d" % [cell.x, cell.y, cell.z]
	body.position = Vector3(cell)
	body.set_meta("cell", cell)
	body.set_meta("kind", kind)
	var visual := MeshInstance3D.new()
	var cube := BoxMesh.new()
	cube.size = Vector3.ONE
	visual.mesh = cube
	visual.material_override = materials[kind - 1]
	body.add_child(visual)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3.ONE
	collision.shape = shape
	body.add_child(collision)
	add_child(body)
	blocks[cell] = body


func _remove_block(cell: Vector3i) -> void:
	if not blocks.has(cell):
		return
	var body: StaticBody3D = blocks[cell]
	blocks.erase(cell)
	body.queue_free()


func _make_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = spawn
	player.collision_layer = 2
	player.collision_mask = 1
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.7
	collision.shape = capsule
	player.add_child(collision)
	camera = Camera3D.new()
	camera.name = "Camera"
	camera.position.y = 0.64
	camera.current = true
	player.add_child(camera)
	add_child(player)
	ray = RayCast3D.new()
	ray.target_position = Vector3(0, 0, -6)
	ray.collision_mask = 1
	ray.enabled = true
	ray.add_exception(player)
	camera.add_child(ray)


func _make_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Label.new()
	hud.position = Vector2(16, 14)
	hud.add_theme_font_size_override("font_size", 18)
	layer.add_child(hud)
	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.add_theme_font_size_override("font_size", 28)
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-7, -18)
	layer.add_child(crosshair)


func _make_target_marker() -> void:
	marker = MeshInstance3D.new()
	var cube := BoxMesh.new()
	cube.size = Vector3.ONE * 1.035
	marker.mesh = cube
	var highlight := StandardMaterial3D.new()
	highlight.albedo_color = Color(1.0, 0.88, 0.2, 0.28)
	highlight.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	highlight.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	marker.material_override = highlight
	marker.visible = false
	add_child(marker)


func _refresh_hud() -> void:
	var status := "PAUSED · Esc resume · Q quit" if paused else "WASD move · Mouse look · Space jump · Left break · Right place · 1–3 select · F5 save · Esc pause · Q quit"
	hud.text = "BossBlocks  |  %s: %s\n%s\n%s" % [str(selected_type), BLOCK_NAMES[selected_type - 1], status, save_note]


func _physics_process(delta: float) -> void:
	if paused:
		return
	var motion := player.velocity
	if player.is_on_floor():
		if Input.is_key_pressed(KEY_SPACE):
			motion.y = 7.5
		else:
			motion.y = 0.0
	else:
		motion.y -= 20.0 * delta
	var direction := Vector3.ZERO
	if Input.is_key_pressed(KEY_W):
		direction.z -= 1.0
	if Input.is_key_pressed(KEY_S):
		direction.z += 1.0
	if Input.is_key_pressed(KEY_A):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		direction.x += 1.0
	direction = direction.rotated(Vector3.UP, player.rotation.y).normalized()
	motion.x = direction.x * 5.5
	motion.z = direction.z * 5.5
	player.velocity = motion
	player.move_and_slide()
	if player.position.y < -5.0:
		player.position = spawn
		player.velocity = Vector3.ZERO
	_update_target()


func _update_target() -> void:
	ray.force_raycast_update()
	var body := ray.get_collider()
	if ray.is_colliding() and body is StaticBody3D and body.has_meta("cell"):
		marker.position = body.position
		marker.visible = true
	else:
		marker.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_ESCAPE:
				paused = not paused
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if paused else Input.MOUSE_MODE_CAPTURED
				_refresh_hud()
				get_viewport().set_input_as_handled()
			KEY_Q:
				_save_world()
				get_tree().quit()
			KEY_F5:
				_save_world()
			KEY_1, KEY_2, KEY_3:
				selected_type = int(event.keycode) - int(KEY_1) + 1
				_refresh_hud()
	if paused:
		return
	if event is InputEventMouseMotion:
		player.rotate_y(-event.relative.x * 0.002)
		camera.rotation.x = clampf(camera.rotation.x - event.relative.y * 0.002, -1.4, 1.4)
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			_break_target()
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			_place_target()


func _target_cell() -> Vector3i:
	ray.force_raycast_update()
	var body := ray.get_collider()
	if not ray.is_colliding() or not (body is StaticBody3D) or not body.has_meta("cell"):
		return Vector3i(999, 999, 999)
	return body.get_meta("cell")


func _break_target() -> void:
	var cell := _target_cell()
	if cell.y <= -2 or abs(cell.x) > WORLD_EDGE or abs(cell.z) > WORLD_EDGE:
		return
	_remove_block(cell)
	_save_world()


func _place_target() -> void:
	var hit := _target_cell()
	if hit.x == 999:
		return
	var normal := ray.get_collision_normal()
	var cell := hit + Vector3i(int(round(normal.x)), int(round(normal.y)), int(round(normal.z)))
	if blocks.has(cell) or cell.y < -1 or cell.y > 5 or abs(cell.x) > WORLD_EDGE or abs(cell.z) > WORLD_EDGE:
		return
	if _overlaps_player(cell):
		save_note = "Cannot place inside player"
		_refresh_hud()
		return
	_add_block(cell, selected_type)
	_save_world()


func _overlaps_player(cell: Vector3i) -> bool:
	var point := Vector3(cell)
	var center := player.global_position
	return abs(point.x - center.x) < 0.84 and abs(point.z - center.z) < 0.84 and abs(point.y - center.y) < 1.36


func _save_world() -> void:
	var records: Array[Dictionary] = []
	for cell in blocks.keys():
		if cell.y <= -2 or abs(cell.x) > WORLD_EDGE or abs(cell.z) > WORLD_EDGE:
			continue
		var body: StaticBody3D = blocks[cell]
		records.append({"x": cell.x, "y": cell.y, "z": cell.z, "kind": int(body.get_meta("kind"))})
	var file := FileAccess.open(save_path, FileAccess.WRITE)
	if file == null:
		save_note = "Save failed: %s" % error_string(FileAccess.get_open_error())
	else:
		file.store_string(JSON.stringify({"version": 1, "blocks": records}))
		file.close()
		save_note = "Saved %d blocks" % records.size()
	_refresh_hud()


func _load_world() -> void:
	if not FileAccess.file_exists(save_path):
		return
	var payload = JSON.parse_string(FileAccess.get_file_as_string(save_path))
	if not (payload is Dictionary) or not (payload.get("blocks") is Array):
		save_note = "Invalid save; new world loaded"
		return
	for cell in blocks.keys():
		if cell.y > -2 and abs(cell.x) <= WORLD_EDGE and abs(cell.z) <= WORLD_EDGE:
			_remove_block(cell)
	for record in payload["blocks"]:
		if not (record is Dictionary):
			continue
		if not record.has_all(["x", "y", "z", "kind"]):
			continue
		var cell := Vector3i(int(record["x"]), int(record["y"]), int(record["z"]))
		if cell.y >= -1 and cell.y <= 5 and abs(cell.x) <= WORLD_EDGE and abs(cell.z) <= WORLD_EDGE:
			_add_block(cell, int(record["kind"]))
	save_note = "Loaded saved world"
