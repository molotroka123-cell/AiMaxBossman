@echo off
"C:\Users\asd\AppData\Local\Bossman\tool-cache\bossblocks-001\editor\godot.windows.editor.x86_64.exe" --path "%~dp0." %*
