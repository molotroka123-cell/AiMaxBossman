# BossBlocks

Work in progress. This is a playable **PARTIAL** fallback for BOSSBLOCKS-001, built after the Bossman coding task stalled. It does not satisfy the Bossman-only owner benchmark.

On the owner machine, double-click `PLAY-BOSSBLOCKS.cmd`. It uses the pinned Godot 4.7.2 editor at `C:\Users\asd\AppData\Local\Bossman\tool-cache\bossblocks-001\editor\godot.windows.editor.x86_64.exe`. You can also open `project.godot` in Godot and run the main scene.

## Controls

| Input | Action |
| --- | --- |
| WASD | Move |
| Mouse | Look |
| Space | Jump |
| Left click | Break targeted block |
| Right click | Place selected block next to target |
| 1, 2, 3 | Select grass, sand, stone |
| F5 | Save |
| Esc | Pause or resume and release or capture mouse |
| Q | Save and quit |

Breaking and placing save automatically. The world is stored in Godot's user data as `bossblocks_world.json`; restarting the game restores it. The game rejects placement inside the player. Boundary walls and the lower bedrock layer cannot be broken.

## Verification

Run the three Godot scripts in `tests/` to check controls and two-process save/restart. `tests/bossblocks-game.png` is a captured frame from the real Godot Vulkan renderer. These checks are automated and do not replace a full human owner play session.
