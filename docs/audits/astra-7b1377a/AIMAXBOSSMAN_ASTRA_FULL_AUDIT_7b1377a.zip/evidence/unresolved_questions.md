# Unresolved and deliberately unrun

- Real OpenRouter request, billing reconciliation, provider rate limits and tool schema compatibility: NOT_RUN; deterministic provider fixture does not measure these.
- AI MAX 128GB hardware, driver/backend, usable shared memory, KV residency, power and thermal behavior: NOT_RUN. No current product spec or speed claim was assumed.
- Authenticated remote Fleet transport is absent. Real multi-node crash, network partition and replay resistance remain unimplemented/unproven.
- Exact deployment exposure, reverse-proxy trusted-hop config, TLS cookie behavior and Windows ACLs: not attested by local source inspection.
- Browser visual/accessibility testing and full owner mission usability: NOT_RUN; UX findings are source-based.
- Source can move during the audit. Findings stay bound to 7b1377a; unrelated local modifications and later commits are excluded. Report commit SHA is not FINAL_AUDITED_SHA.
- Complete repository-wide success path coverage and dead-code reachability are not claimed. Principal authorities were traced and lexical inventory retained for follow-up.
- Cost/token denominators, retrieval precision/recall, state reconstruction ratio and long-run failure metrics require instrumented representative missions; unavailable values must remain null/UNMEASURED.
- Branch protection API returned unprotected and empty rulesets; external governance outside accessible repository API remains unknown.
- No actual secret was established merely from entropy alerts. Public-data fixtures must be triaged without weakening scanner globally.
