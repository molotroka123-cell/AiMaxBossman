import os,sys,json
from pathlib import Path
root=Path(os.environ.get('ASTRA_REPO_ROOT', str(Path.cwd()))).resolve()
sys.path[:0]=[str(root/'command-center'),str(root/'bossman-core'),str(root)]
from bcc.v2.memory.context_pack import build_context_pack,estimate_tokens
from bcc.v2.memory.memsearch_bridge import MemoryHit
from bcc.v2.openrouter_ext import parse_model_card
from bcc import metrics
hits=[MemoryHit(str(i)+'a'*9,'s'+str(i)) for i in range(8)]
budget=sum(estimate_tokens(f'[SOURCE: {h.source}]\n{h.content}') for h in hits)
p=build_context_pack('q',hits,max_tokens=budget)
metrics.shutil.which=lambda _: 'nvidia-smi'
metrics._smi=lambda exe,q,kind: [['GPU-1','Test','0','2048','8192','40']] if kind=='gpu' else None
out={'context_pack':{'budget':budget,'serialized_estimated_tokens':p.estimated_tokens,'items':len(p.items)},'missing_pricing':{'price_in':parse_model_card({'id':'test'}).price_in,'price_out':parse_model_card({'id':'test'}).price_out},'unavailable_process_query':metrics._nvidia()[0]}
# Evidence goes to stdout; redirect explicitly to a task-owned output path.
print(json.dumps(out,indent=2))

