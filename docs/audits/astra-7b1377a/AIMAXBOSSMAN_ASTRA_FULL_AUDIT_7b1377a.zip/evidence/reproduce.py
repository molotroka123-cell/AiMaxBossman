"""Read-only audit probes; all mutations confined to a TemporaryDirectory."""
import gc, json, os, sys, tempfile
from pathlib import Path
ROOT = Path(os.environ.get('ASTRA_REPO_ROOT', str(Path.cwd()))).resolve()
sys.path[:0] = [str(ROOT/'bossman-core'), str(ROOT/'command-center'), str(ROOT)]
results = []
def check(name, fn):
    try:
        results.append({'probe': name, 'result': fn(), 'status': 'EXECUTED'})
    except Exception as e:
        results.append({'probe': name, 'status': 'ERROR', 'error': type(e).__name__+': '+str(e)})
with tempfile.TemporaryDirectory(prefix='astra-audit-') as tmp:
    root = Path(tmp)
    os.environ['BOSSMAN_EVIDENCE_KEY_FILE'] = str(root/'evidence.key')
    from bossman_v3.memory.journal import TaskJournal, JournalStep
    from bossman_v3.memory.assembler import ContextAssembler, redact
    from bossman_v3.execution.compound import CompoundRunner, PlanStep
    from bossman_v3.contracts import TypedAction
    from bossman_v3.organization.bridges import V3ExecutionBridge
    from bossman_v3.organization.contracts import DelegationContract, EvidenceRequirement
    from bossman_v3.organization.models import Evidence, WorkResult
    from bossman_v3.organization.memory_scope import ScopedKnowledge
    from bossman_v3.fleet.store import FleetStore
    from bossman_v3.fleet.leases import LeaseManager
    from bossman_v3.fleet.queue import WorkQueue
    from bossman_v3.fleet.scheduler import FleetScheduler
    def forged():
        j = TaskJournal('forged', [JournalStep('s','write',receipt={'effect_id':'invented'},verified=True)])
        class Never:
            def run(self,*a): raise AssertionError('should execute')
        r = CompoundRunner(Never(), j).run([PlanStep('s','write',TypedAction('file.write'))])
        return {'completed':r.completed,'executed':r.executed,'signature_valid':j.steps[0].signature_valid('forged')}
    check('unsigned_journal_skips_execution', forged)
    def changed():
        c=DelegationContract('w','m','d','write','file',['written'],[EvidenceRequirement('file','b.txt')])
        b=V3ExecutionBridge(agent_factory=lambda *a:None,journal_root=root/'journal')
        old=PlanStep('s','write A',TypedAction('file.write',{'path':'a.txt'}))
        j=b.journal(c,[old]); j.record('s',receipt={'effect_id':'old'},verified=True)
        new=PlanStep('s','write B',TypedAction('file.write',{'path':'b.txt'}))
        loaded=b.journal(c,[new])
        return {'new_intent':new.intent,'loaded_intent':loaded.steps[0].intent,'finished':loaded.steps[0].finished}
    check('changed_action_same_step_id', changed)
    def replay():
        e=Evidence.signed('file','result.txt',source='journal:other-mission/step',observed_at='2000-01-01T00:00:00+00:00')
        c=DelegationContract('new','new-mission','d','new contents','file',['new contents'],[EvidenceRequirement('file','result.txt',{'contains':'new contents'})])
        ok,errors=c.validate(WorkResult('new',True,[e]))
        return {'accepted':ok,'errors':errors,'source':e.source,'observed_at':e.observed_at}
    check('signed_stale_cross_mission_evidence',replay)
    def paths():
        TaskJournal.start(task_id='../escaped',plan=[],root=root/'journals-safe')
        return {'outside_journal_root_created':(root/'escaped.json').exists()}
    check('journal_path_traversal_confined_probe',paths)
    def context():
        pack=ContextAssembler().assemble(TaskJournal('x'*80,[]),budget_tokens=1)
        return {'budget':1,'reported_tokens':pack.tokens,'over_budget':pack.tokens>1}
    check('context_header_exceeds_budget',context)
    def redaction():
        s='-----BEGIN PRIVATE KEY-----\nSYNTHETIC_BODY_ONLY\n-----END PRIVATE KEY-----'
        return {'synthetic_pem_body_survives':'SYNTHETIC_BODY_ONLY' in redact(s)}
    check('pem_body_redaction',redaction)
    def scope():
        class Store:
            def facts(self,s):
                return [{'fact_id':'f','scope':s,'kind':'note','payload':{'synthetic':True}}] if s=='department:other' else []
        rows=ScopedKnowledge(Store()).read('mission:mine',include_parents=('department:other',))
        return {'foreign_parent_returned':len(rows)==1}
    check('parent_scope_prefix_only',scope)
    def lease():
        lm=LeaseManager(FleetStore(root/'leases.sqlite'))
        a=lm.acquire(node_id='n',work_id='a',now=0,ttl_seconds=100,exclusive=False)
        b=lm.acquire(node_id='n',work_id='b',now=1,ttl_seconds=100,exclusive=True)
        return {'exclusive_granted_while_shared_active':bool(b),'old_shared_valid':lm.valid(a,now=2)}
    check('shared_exclusive_lease_conflict',lease)
    def queue():
        st=FleetStore(root/'queue.sqlite')
        st.enqueue('w','m',5,{},{}); st.claim('w','node-a',0)
        st.release_claim('w'); second=st.claim('w','node-b',1)
        removed=st.dequeue('w')
        return {'new_claim_fence':second,'delete_without_owner_fence':removed}
    check('queue_ack_without_owner',queue)
    def backoff():
        st=FleetStore(root/'backoff.sqlite'); st.enqueue('w','m',5,{},{}); st.claim('w','n',0)
        q=WorkQueue(st,None)
        decision=q.on_failure('w','m',reason='timeout',attempts=1)
        return {'decision':decision,'immediately_unclaimed':len(st.queue(unclaimed_only=True))==1}
    check('retry_delay_not_persisted',backoff)
    def crash():
        from bossman_v3.fleet.resume import FleetResumeKernel
        from bossman_v3.contracts import SideEffectClass
        j=TaskJournal('crashed',[JournalStep('s','external submit')])
        p=PlanStep('s','external submit',TypedAction('submit',side_effect=SideEffectClass.IRREVERSIBLE))
        r=FleetResumeKernel().decide(j,[p],lost_in_flight=True)
        return {'resumable':r.resumable,'reason':r.reason,'crash_window':'effect happened before journal.record'}
    check('irreversible_pending_after_crash',crash)
    gc.collect()
print(json.dumps(results,indent=2,ensure_ascii=False))
