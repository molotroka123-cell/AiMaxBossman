import os,sys,json,tempfile
from pathlib import Path
BASE=Path(os.environ.get('ASTRA_REPO_ROOT', str(Path.cwd()))).resolve()
sys.path[:0]=[str(BASE/'bossman-core'),str(BASE/'command-center'),str(BASE)]
from bossman_v3.organization.contracts import DelegationContract
from bossman_v3.organization.models import Resources,AgentProfile,TaskState,Department
from bossman_v3.organization.marketplace import CapabilityMarketplace
from bossman_v3.organization.treasury import ResourceTreasury
from bossman_v3.organization.store import OrganizationStore
from bossman_v3.fleet.models import NodeState,PlacementRequirement
from bossman_v3.fleet.scheduler import FleetScheduler
from bossman_v3.fleet.node_agent import _minimized
out=[]
def p(name,fn):
 try: out.append({'probe':name,'status':'EXECUTED','result':fn()})
 except Exception as e: out.append({'probe':name,'status':'ERROR','error':str(e)})
def contract(m='m'): return DelegationContract('same',m,'d','goal','read',['observed'],[],side_effect=False)
def cloud():
 a=AgentProfile('cloud','d',{'executor'},{'read'},tier='frontier')
 c=contract(); c.privacy='local_only'
 return {'privacy':c.privacy,'selected':CapabilityMarketplace([a]).route(c).selected}
p('local_only_cloud_marketplace',cloud)
def negative():
 t=ResourceTreasury();t.set_limit('organization',Resources(usd=10))
 t.reserve(['organization'],Resources(usd=-100))
 return {'reserved':t.envelope('organization').reserved.usd,'overspend_eligible':t.preflight(['organization'],Resources(usd=100)).allowed,'nan_eligible':Resources(usd=10).fits(Resources(usd=float('nan')))[0]}
p('negative_nan_treasury',negative)
def collision():
 with tempfile.TemporaryDirectory() as tmp:
  s=OrganizationStore(Path(tmp)/'o.sqlite');s.save_work(contract('first'),state=TaskState.COMPLETED);s.save_work(contract('second'),state=TaskState.PLANNED)
  r=s.work('same');result = {'column_mission':r['mission_id'],'contract_mission':r['contract'].mission_id,'second_mission_rows':len(s.works('second')),'state':r['state']}
  import gc; del s; gc.collect(); return result
p('cross_mission_work_collision',collision)
p('unified_pool_double_count',lambda:{'rejections':FleetScheduler().reject_reasons(NodeState('n',ram_gb=16,gpu_memory_gb=16,unified_memory=True),PlacementRequirement(min_ram_gb=12,min_gpu_memory_gb=12)),'requested_total':24,'physical_pool':16})
def minimized():
 c=contract();c.constraints=['Never transmit payload'];c.steps=[{'args':{'secret':'synthetic-private'}}]
 m=_minimized(c);return {'constraints':m.constraints,'steps':m.steps}
p('minimized_discards_constraints_keeps_step_payload',minimized)
print(json.dumps(out,indent=2))

