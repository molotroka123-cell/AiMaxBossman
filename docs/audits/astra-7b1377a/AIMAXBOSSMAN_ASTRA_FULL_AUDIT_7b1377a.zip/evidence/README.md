# Evidence interpretation

Source evidence is pinned to audited SHA. Tests were run against then-unchanged relevant source files in the outer workspace; a detached baseline worktree was subsequently created after unrelated Solana changes appeared. No Solana live transactions were run. Probes use synthetic data and a temporary key confined to a temporary directory.

Reproduce script: copy into a repository checkout (or set its ROOT to the checkout root), run `python -X utf8 reproduce.py`; current packaged script locates root relative to its original .audit-work location and must be adjusted when extracted standalone. The script mutates only temporary files/SQLite databases and removes them after garbage collection. Its output describes vulnerabilities, so an observed true flag is a reproduced defect, not a passing security invariant.

Commands: `python -m pytest -q` on the five focused Fleet/Organization files with PYTHONPATH including repo/bossman-core, repo/command-center and repo. Corrected final command: `python -X utf8 -m pytest -q -o asyncio_mode=auto command-center/tests/test_feat_organization.py command-center/tests/test_feat_openrouter_agent_flow.py bossman-core/tests/test_v3_organization_e2e.py`. Full list and test scope appear in tests_reviewed.txt. Windows interpreter was Python 3.14.3; Linux CI matrix uses 3.11 and 3.12.

Pytest exited zero in the corrected retest but printed an atexit Windows permission cleanup warning. Do not treat that as target-platform cleanliness. Original raw CI logs remain outside the ZIP; curated CI evidence contains only job names, conclusions, paths and alert categories to avoid echoing potential secret values.

Portable probe invocation: run from a checkout of audited SHA, or set ASTRA_REPO_ROOT to that checkout. The packaged root reproduce.py was adjusted to honor this variable; this supersedes the earlier path-adjustment note. Specialist probes retain their recorded baseline paths and may need the equivalent root override.
