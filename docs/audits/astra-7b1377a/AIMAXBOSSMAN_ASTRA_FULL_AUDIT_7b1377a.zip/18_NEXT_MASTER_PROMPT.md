# Next implementation mission

Start by fetching actual remote HEAD of claude/bossman-control-v03-43igbk; compare to audited 7b1377a4f69336a1ca9d8eb4d432a758e195ae33. Read this ZIP's machine/findings.json and evidence/probes.json. Treat audit findings as hypotheses with evidence, not permission to expand access. Preserve other tasks' uncommitted changes in an isolated checkout.

Implement the smallest coherent truth closure: Core mandatory effect gate, journal signature/action binding, contract proof obligation validation, durable effect intent and ambiguous-effect reconciliation. Convert the supplied boundary probes into negative regression tests in the existing project suites; ensure Organization/Fleet/BCC projections agree. Then address privacy egress, queue ownership/backoff, cross-mission IDs, risk review and atomic treasury reservations using specialist findings.

For each change record original finding ID, exact before/after code, positive/negative oracle, tests and migration behavior. Use crash barriers with a durable fake sink rather than real external side effects. No new cloud expense, financial transaction or outbound message is required. Do not equate a signed artifact or a passing fake-provider test to real provider/hardware acceptance.

Run focused checks first, then required complete CI on the exact candidate SHA. Test Windows UTF-8 and ACL behavior explicitly. Reconcile branch movement before claiming readiness. Publish a new remediation ZIP with changed findings, unresolved cases and exact-SHA CI, preserving null for unmeasured economics. Push only task-owned report/code artifacts as authorized by the owner; no force push.
