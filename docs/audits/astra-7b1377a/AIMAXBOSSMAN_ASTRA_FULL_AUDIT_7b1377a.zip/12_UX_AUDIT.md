# Mission UX audit

Baseline7b1377a4f69336a1ca9d8eb4d432a758e195ae33. Console IMPLEMENTED; integration PARTIAL. Browser visual/accessibility evaluation NOT_RUN in this lane. `command-center/ui/pages/mission_console.js` uses explicit no-data labels, data-src and independent endpoint fallback, useful truth controls.

PROD-004: `scopeTasks:228-233` filters mission after fetching global `/api/tasks?limit=100` (line289). With100 newer unrelated tasks, active mission tasks disappear from its graph. No pagination/completeness marker is provided. Fetch mission-scoped tasks with pagination; test101 unrelated newer tasks.

Quick command “Останови текущую задачу” (line838) only fills text; submit posts a new task prompt/title/run_now (line872). Comments explain template behavior, so this is not a disguised hard API call. However “Команда принята” must not be read as cancellation. Add explicit cancel/pause buttons with durable command IDs/worker acknowledgements and distinguish text requests.

pickMission/pickCurrent (`:217,:237`) use heuristics rather than stable owner selection. Concurrent work can change focus. One run's events and V2 endpoints do not expose unified Organization/Fleet state. This is a gap in this console, not proof those features are absent globally.

Required visible stages: proposed, approval-required, placed, executing, observing, verifying, verified, blocked, failed, cancelled and stale/unknown. Signed/completed cannot automatically become verified green. Browser follow-up must cover keyboard names/focus across rerenders, announcements, reduced motion, contrast and mobile layout before conformance claims.
