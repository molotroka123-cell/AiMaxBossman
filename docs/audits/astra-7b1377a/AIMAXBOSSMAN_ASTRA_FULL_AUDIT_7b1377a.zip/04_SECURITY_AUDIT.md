Audited SHA: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope is the immutable `.audit-work/baseline` snapshot; concurrent working-copy changes are excluded. Findings are source review, synthetic local probes or supplied exact-SHA CI evidence, not production attestation.

Security status: PARTIAL. Four additional actionable findings below complement the central audit findings for journal path confinement, PEM-body redaction and memory parent-scope inheritance. These central findings are intentionally not duplicated in this machine findings file.

Authentication and controls observed: Command Center `api.py:237-250` resolves server sessions, checks CSRF on unsafe methods and optionally supports the legacy custom header. `sessions.py:92-101` sets HttpOnly, SameSite=strict and mode-dependent Secure. `api.py:492-509` checks login rate limiting before token comparison. Gateway `auth.py:57-70` refuses unauthenticated loopback when forwarding headers exist; `config.py:124` defaults unauthenticated loopback to false. No CORS permissive middleware was found in reviewed API searches. These are implementation observations, not an external penetration test.

Approval boundary: `command-center/bcc/approvals.py:56-81` atomically consumes approved records matching kind and preview, protecting ordinary replay. It does not itself take task/run/expiry parameters; action-specific canonical preview and task linkage require further integration review before claiming cross-task authority isolation. Core approvals are a separate PostgreSQL queue (`bossman/approvals.py:13-46`), not interchangeable with Command Center approvals. No blanket approval-bypass claim is made.

SSRF distinction matters: Command Center `plugin_security.py:127-180` validates all resolved IPs and uses a pinned backend; `safe_get:187-235` streams with max_bytes and revalidates redirects. Core's independent HTTP tool retains the DNS race and unbounded body. Tests for one stack cannot attest the other.

Shell/plugin/MCP boundary: plugin contents and model tool arguments remain untrusted inputs; authorization is granted by owner configuration. This sub-audit did not dynamically execute host shell, connect external MCP services, inspect live tokens, or test reverse-proxy/Tailscale deployment. Browser debugging-port exposure, local vault ACLs, transport identity and live cookie behavior remain UNPROVEN deployment questions. Never extend localhost or model text into proof of owner authority.

## ASTRA-SEC-101 — Core HTTP policy has a DNS validation/connection race

- **severity**: P1
- **confidence**: HIGH
- **files**: [{"path": "bossman-core/bossman/toolkit/net.py", "line": 155, "symbol": "_request_checked"}]
- **failure_scenario**: Attacker-controlled hostname resolves publicly during check_url, then to loopback/private IP when ordinary httpx opens the connection. Confirmation of the public URL does not authorize the rebinding destination. No live exploit attempted.
- **why_it_matters**: Attacker-controlled hostname resolves publicly during check_url, then to loopback/private IP when ordinary httpx opens the connection. Confirmation of the public URL does not authorize the rebinding destination. No live exploit attempted.
- **affected_invariant**: Network egress must use the destination actually authorized
- **minimal_fix**: Use a transport pinned to validated IPs at every redirect; retain original hostname for TLS/SNI.
- **ideal_fix**: Share a tested bounded pinned egress transport across Core and Command Center.
- **tests**: ["Two-answer DNS rebinding fixture must connect only to first approved address", "Mixed A/AAAA denial and redirect rebinding", "Proxy-environment behavior"]
- **estimated_effort**: 1-2 days
- **regression_risk**: Medium: HTTP proxy and TLS compatibility
- **dependencies**: ["Common transport interface"]
- **evidence_type**: SOURCE

## ASTRA-SEC-102 — Core HTTP response has no byte budget before buffering or logging

- **severity**: P2
- **confidence**: HIGH
- **files**: [{"path": "bossman-core/bossman/toolkit/net.py", "line": 175, "symbol": "http"}]
- **failure_scenario**: A slow but continuously streaming or very large public response is fully buffered by client.request before token clipping, then duplicated into text/log content. A 60-second timeout is not an aggregate byte cap. Can exhaust worker memory/disk and expose raw returned sensitive fields in local assets/logs.
- **why_it_matters**: A slow but continuously streaming or very large public response is fully buffered by client.request before token clipping, then duplicated into text/log content. A 60-second timeout is not an aggregate byte cap. Can exhaust worker memory/disk and expose raw returned sensitive fields in local assets/logs.
- **affected_invariant**: Bound external input and protect telemetry privacy
- **minimal_fix**: Stream with decompressed-byte cap; reject oversize responses and redact persisted output.
- **ideal_fix**: Unified egress budgets for bytes, duration and storage; explicit artifact classification and retention.
- **tests**: ["Compressed-response expansion over limit", "Chunked body without content-length", "Response with synthetic sensitive fields in ignored fields"]
- **estimated_effort**: 1 day
- **regression_risk**: Medium: callers relying on full raw downloads
- **dependencies**: []
- **evidence_type**: SOURCE

## ASTRA-SEC-103 — ZIP scanner omits private-key members and treats scan failures as clean

- **severity**: P1
- **confidence**: HIGH
- **files**: [{"path": "tools/ci_secret_scan.py", "line": 117, "symbol": "scan_zip"}]
- **failure_scenario**: Synthetic private-key marker in private.txt is detected but identical marker in private.pem is skipped. Nested ZIP and corrupt ZIP both return zero findings. Top-level forbidden-name policy is not applied to archive members; >2 MB files are also skipped. This is a scanner completeness defect, not proof that committed archives contain real credentials.
- **why_it_matters**: Synthetic private-key marker in private.txt is detected but identical marker in private.pem is skipped. Nested ZIP and corrupt ZIP both return zero findings. Top-level forbidden-name policy is not applied to archive members; >2 MB files are also skipped. This is a scanner completeness defect, not proof that committed archives contain real credentials.
- **affected_invariant**: UNKNOWN != PASS; NOT_RUN != PASS
- **minimal_fix**: Apply forbidden member paths before suffix filtering; emit unscannable findings for corrupt/oversize/unsupported archive contents.
- **ideal_fix**: Bounded recursive archive scanner with depth, aggregate expanded-size limits and explicit scanned/skipped/error coverage manifest.
- **tests**: ["scanner_probe.json: pem=[], text=[private key], nested=[], corrupt=[]", "Archive traversal member names are inspected but never extracted", "ZIP bomb limits produce UNKNOWN/BLOCKED rather than PASS"]
- **estimated_effort**: 1-2 days
- **regression_risk**: Medium: historical archives need triage
- **dependencies**: []
- **evidence_type**: SYNTHETIC_RUNTIME_PROBE

## ASTRA-SEC-104 — Default startup announcement writes the installation bearer token to stdout

- **severity**: P2
- **confidence**: HIGH
- **files**: [{"path": "command-center/bcc/auth.py", "line": 41, "symbol": "TokenAuth.announce"}]
- **failure_scenario**: TokenAuth defaults announce=True and Services defaults announce_token=True. A redirected console or process manager captures the long-lived access token unless operator pre-sets BCC_TOKEN_STDOUT=0. Probe captured a generated temporary token without recording its value. No existing production log was searched for secrets.
- **why_it_matters**: TokenAuth defaults announce=True and Services defaults announce_token=True. A redirected console or process manager captures the long-lived access token unless operator pre-sets BCC_TOKEN_STDOUT=0. Probe captured a generated temporary token without recording its value. No existing production log was searched for secrets.
- **affected_invariant**: Secrets must not enter ordinary telemetry
- **minimal_fix**: Suppress announcement for non-TTY stdout by default; print only path and explicit retrieval instructions.
- **ideal_fix**: Short-lived setup challenge and platform key storage; token rotation and revocation.
- **tests**: ["Redirect stdout and assert token absent", "Explicit interactive opt-in test", "Existing token restart does not reprint token"]
- **estimated_effort**: 0.5-1 day
- **regression_risk**: Low: onboarding needs clear token retrieval
- **dependencies**: []
- **evidence_type**: SYNTHETIC_RUNTIME_PROBE