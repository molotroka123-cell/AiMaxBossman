Audited SHA: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope is the immutable `.audit-work/baseline` snapshot; concurrent working-copy changes are excluded. Findings are source review, synthetic local probes or supplied exact-SHA CI evidence, not production attestation.

Exact-SHA result: 16 completed check runs, 12 success and 4 failure. Failed names: `compile + секреты`, `секреты, JS, запрещённые файлы`, `root pytest + hygiene (py3.11)`, `root pytest + hygiene (py3.12)`. Root failure includes the secret-scanner assertion, not proof every root test failed. Scanner logs identify Solana suite pattern/entropy alerts; those alerts alone do not identify leaked credentials. Remote branch protection API returned 404 `Branch not protected`; rulesets response was `[]`. This is stronger than inferring protection from workflow files, but it is a point-in-time API observation.

Workflow positives: least-privilege contents:read; push and PR triggers; Python 3.11/3.12 test matrices; fail-fast:false; bounded job/test timeouts; Core and Command Center cancel obsolete runs by ref; Core/root/benchmark historical tests get full history; Chromium installed and Command Center BCC_REQUIRE_BROWSER=1 prevents silently skipping browser tests. Root docker smoke validates packaged shared imports. Root workflow lacks cancellation grouping, an efficiency opportunity rather than a demonstrated correctness failure.

Local focused rerun on immutable snapshot: Windows Python 3.11, `python -X utf8 -m pytest tests/test_secrem_f004_http_ssrf.py -q -o asyncio_mode=auto --basetemp <owned new directory>`: 19 passed, exit 0. First attempt passed all 19 test bodies but exited 1 during pytest global temp cleanup with Windows PermissionError; it is not recorded as a successful command. A dedicated fresh basetemp resolved that environment issue. These tests use MockTransport and DNS monkeypatches: they prove target/redirect policy but cannot exercise the real socket DNS-rebinding race.

No full coverage percentage, mutation score or flake frequency was measured here. Existing green unit jobs do not attest live OpenRouter, physical Windows automation, KVM/runsc or authenticated multi-node fleet behavior.

## ASTRA-CI-101 — Exact audited SHA is not green and branch has no enforced required checks

- **severity**: P1
- **confidence**: HIGH
- **files**: [{"path": ".github/workflows/root-ci.yml", "line": 11, "symbol": "jobs.root-tests"}]
- **failure_scenario**: GitHub check evidence reports 16 completed checks: 12 success and 4 failure on the audited SHA. Protection API reports Branch not protected and rulesets list is empty. Pushes can advance this branch without a clean audit gate. Scanner alerts in Solana code are not automatically credential leaks.
- **why_it_matters**: GitHub check evidence reports 16 completed checks: 12 success and 4 failure on the audited SHA. Protection API reports Branch not protected and rulesets list is empty. Pushes can advance this branch without a clean audit gate. Scanner alerts in Solana code are not automatically credential leaks.
- **affected_invariant**: UNKNOWN != PASS; exact-SHA verification
- **minimal_fix**: Triage scanner alerts at their exact locations, fix genuine content issues or narrowly annotate proven public/synthetic data, then run all required checks on resulting SHA.
- **ideal_fix**: Enforce a named aggregate exact-SHA gate and branch rules; record expected checks, conclusion and SHA, treating absent/cancelled/pending as not verified.
- **tests**: ["Missing/empty/cancelled checks never pass acceptance", "Move branch between check fetch and acceptance: reject stale SHA", "Protected branch rejects failed required gate"]
- **estimated_effort**: 1-2 days
- **regression_risk**: Medium: rules depend on repository owner permissions
- **dependencies**: ["GitHub branch rule authorization and repository plan"]
- **evidence_type**: REMOTE_API_AND_CI_LOGS

## ASTRA-CI-102 — SAST and dependency audit cannot block and installation errors are swallowed

- **severity**: P2
- **confidence**: HIGH
- **files**: [{"path": ".github/workflows/bossman-core-ci.yml", "line": 157, "symbol": "jobs.compile dependency audit"}]
- **failure_scenario**: pip-audit and bandit use continue-on-error plus || true; dependency installation also uses || true. A scan failure or vulnerability can appear as successful step execution. Earlier secret-scan failure can prevent these subsequent checks from running altogether. Same pattern exists in command-center-ci.yml:117-129.
- **why_it_matters**: pip-audit and bandit use continue-on-error plus || true; dependency installation also uses || true. A scan failure or vulnerability can appear as successful step execution. Earlier secret-scan failure can prevent these subsequent checks from running altogether. Same pattern exists in command-center-ci.yml:117-129.
- **affected_invariant**: NOT_RUN != PASS; UNKNOWN != PASS
- **minimal_fix**: Capture machine-readable scan results as always-uploaded artifacts; separate tooling failure from findings.
- **ideal_fix**: Pinned reproducible SCA/SAST jobs with reviewed expiring baseline and blocking new high-confidence high-severity findings.
- **tests**: ["Inject scanner tool failure and assert ERROR", "Inject known vulnerable fixture dependency and assert finding", "Ensure scan still runs when independent secret gate fails"]
- **estimated_effort**: 1-2 days
- **regression_risk**: Medium: initial baseline noise
- **dependencies**: []
- **evidence_type**: SOURCE

## ASTRA-CI-103 — Linux-only CI misses a demonstrated Windows permission assertion failure

- **severity**: P2
- **confidence**: HIGH
- **files**: [{"path": ".github/workflows/bossman-core-ci.yml", "line": 28, "symbol": "jobs.core.runs-on"}]
- **failure_scenario**: All reviewed workflow jobs use ubuntu-latest. On Windows test_v3_evidence_signing.py:75 assumes POSIX mode 0600; root agent local evidence reports failure. POSIX permission bits do not attest Windows ACL protection. Windows path, launcher and event-loop regressions have no hosted gate.
- **why_it_matters**: All reviewed workflow jobs use ubuntu-latest. On Windows test_v3_evidence_signing.py:75 assumes POSIX mode 0600; root agent local evidence reports failure. POSIX permission bits do not attest Windows ACL protection. Windows path, launcher and event-loop regressions have no hosted gate.
- **affected_invariant**: Platform-specific claims require matching evidence
- **minimal_fix**: Add Windows portable-contract smoke job and replace unconditional POSIX assertion with platform-specific security check.
- **ideal_fix**: Windows ACL and launcher acceptance lane plus Linux sandbox/hardware lane, publishing independent capabilities.
- **tests**: ["Windows key ACL forbids unintended readers", "UNC/drive/case/path traversal suite", "Fresh UTF-8 subprocess and explicit asyncio-mode harness"]
- **estimated_effort**: 2-3 days
- **regression_risk**: Medium: dependencies and Windows timing
- **dependencies**: []
- **evidence_type**: WORKFLOW_SOURCE_AND_ROOT_AGENT_TEST_EVIDENCE

## ASTRA-CI-104 — Known hangs and real sandbox execution are outside normal CI evidence

- **severity**: P2
- **confidence**: HIGH
- **files**: [{"path": ".github/workflows/command-center-ci.yml", "line": 86, "symbol": "jobs.test BCC_CI_SKIP_RUNNER_HANGS"}]
- **failure_scenario**: CI sets BCC_CI_SKIP_RUNNER_HANGS=1 for two tests and core sets BOSSMAN_RUN_REAL_SANDBOX=0 at bossman-core-ci.yml:126. Green unit jobs cannot prove real containment or the skipped teardown/retry invariants. Exclusions are documented; this is an acceptance coverage gap.
- **why_it_matters**: CI sets BCC_CI_SKIP_RUNNER_HANGS=1 for two tests and core sets BOSSMAN_RUN_REAL_SANDBOX=0 at bossman-core-ci.yml:126. Green unit jobs cannot prove real containment or the skipped teardown/retry invariants. Exclusions are documented; this is an acceptance coverage gap.
- **affected_invariant**: NOT_RUN != PASS; UNPROVEN != VERIFIED
- **minimal_fix**: Publish skip reasons/counts and scheduled unskipped reproduction with strict timeouts.
- **ideal_fix**: Capability-addressed acceptance runner with signed environment identity, cancellation-safe teardown and required sandbox lane before autonomy.
- **tests**: ["Run skipped retry and discovery tests in fresh processes", "Cancellation during process/network teardown", "Sandbox escape/egress tests on actual runtime"]
- **estimated_effort**: 2-4 days
- **regression_risk**: Medium: runner-specific nondeterminism
- **dependencies**: ["Controlled sandbox/hardware runner"]
- **evidence_type**: SOURCE