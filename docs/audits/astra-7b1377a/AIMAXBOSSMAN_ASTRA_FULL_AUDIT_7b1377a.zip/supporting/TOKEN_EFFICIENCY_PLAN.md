# Token efficiency plan

Fix hard-budget correctness first (PROD-001 and V3 header case), then optimize. Required policy or post-state evidence cannot be dropped to improve token statistics.

Collect immutable usage by root mission/task/attempt/role/model/provider with price snapshot, cache mode, input/output/reasoning tokens, estimated-versus-provider provenance, context_manifest_id and verifier outcome. No private prompt text in general metrics.

Definitions: COST_PER_VERIFIED_SUCCESS=all cohort attempt cost/distinct independently verified successes. TOKENS_PER_VERIFIED_SUCCESS includes failures/retries and every token category. CLOUD_AVOIDANCE_RATE=eligible requests fulfilled locally/all requests eligible for either local or cloud; report private-only separately. MODEL_ESCALATION_RATE=tasks moving up explicit tier ladder/routed tasks. TEAM_OVERHEAD_RATIO=coordination+review+redundant reconstruction tokens/all team tokens; report necessary review separately. RETRY_COST_MULTIPLIER=all-attempt/first-attempt cost on same cohort. Zero or unknown denominator=>null.

Rollout: exact serialization/tokenizer bound; bounded referenced tool artifacts; stable cache prefix bound to policy/scope/model; state deltas; routing by measured verified quality/total cost; adaptive teams only after benefit exceeds coordination overhead. Gate every stage on retrieval recall, verification quality and privacy.

Compare identical immutable workloads including abandoned attempts/cache misses; report p50/p95 context size and cost with known/unknown fractions. Set targets after baseline. Current requested metrics are UNMEASURED; no percentage improvement asserted.
