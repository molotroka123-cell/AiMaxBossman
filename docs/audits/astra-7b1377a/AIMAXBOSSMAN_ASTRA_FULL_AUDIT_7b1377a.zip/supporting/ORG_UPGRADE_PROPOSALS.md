# Organization upgrade proposals

Implement safety dependencies first. These are proposals, not completed code or proven runtime guarantees. Do not implement a remote transport before fencing, policy propagation, durable reservation/identity and unknown-effect reconciliation are working.

## O001 (P1, effort L)

Stage 1: Reject cloud-tier/provider candidates for local_only/private policies and propagate an immutable privacy policy to V2/model broker.

Target: One end-to-end data-egress policy enforced at every model/tool/network sink, with approved declassification.

Acceptance: Cloud-only pool + local_only fails closed; fallback cannot cloud-escalate; capture outgoing requests to prove payload remains local.

Risk: high. Dependencies: Model broker and V2 privacy integration.

## O002 (P1, effort L)

Stage 1: Reject any already-owned work_id at mission intake and validate digest/mission on updates transactionally.

Target: Composite (mission_id,work_id) keys through contracts, results, queue, flights, journals and APIs, with migration.

Acceptance: Two missions sharing task-1 cannot overwrite; completed work remains completed; interrupted receive is atomic.

Risk: high. Dependencies: Fleet/store schema migration.

## O003 (P1, effort M)

Stage 1: Reject negative/NaN/infinite and invalid integral values on every constructor/deserializer and external cost receipt.

Target: Validated resource types, decimal money, bounded arithmetic and immutable signed usage receipts.

Acceptance: Negative reserve rejected; NaN/infinity rejected through API and direct construction; no state mutation on invalid input.

Risk: medium. Dependencies: none.

## O004 (P1, effort M)

Stage 1: Evaluate all mandatory review roles and aggregate fail-closed; distinguish proof revalidation from substantive risk review.

Target: Persist independent policy/risk/QA verdicts bound to contract and evidence hashes with quorum rules.

Acceptance: Reviewer approves while risk vetoes: mission must not complete; missing or crashed risk verdict blocks.

Risk: medium. Dependencies: ReviewerPort contract.

## O005 (P1, effort L)

Stage 1: Persist reservation ID and envelope debit atomically before dispatch; reconcile unknown in-flight outcomes on restart rather than dropping reserve. Wrap reviewer/settlement lifecycle with durable cleanup state.

Target: Transactional usage ledger and per-attempt reservation IDs, provider receipt reconciliation, fencing and outbox.

Acceptance: Kill after reserve, after provider charge, during review and before settlement; restart preserves exposure and cannot double settle.

Risk: high. Dependencies: O002; root crash-before-journal finding.

## O006 (P2, effort M)

Stage 1: Separate consumable totals from renewable gauges and release capacity in settlement.

Target: Resource dimensions tagged quantity/rate/capacity with interval-based occupancy and actual metering.

Acceptance: Many serial one-slot jobs under concurrency cap 1 succeed; overlapping two-slot occupancy is rejected.

Risk: medium. Dependencies: none.

## O007 (P1, effort M)

Stage 1: Resolve permitted ancestors from durable ownership, not request strings; bind export policy to stored source scope.

Target: Central scope authorization graph and audited capability grants for reads/writes/exports.

Acceptance: Mission A cannot read department B via include_parents; forged source department cannot authorize export.

Risk: medium. Dependencies: Scope ownership store.

## Organization rollout gate

Unify immutable mission/work identity and scope ownership, durable attempt ledger, reviewed evidence bindings and provider usage receipts. Keep roles declarative; prohibit treating role labels or principal prefixes as authorization. Maintain a visible matrix separating deterministic evidence checks, model review, human authorization and externally verified effect.