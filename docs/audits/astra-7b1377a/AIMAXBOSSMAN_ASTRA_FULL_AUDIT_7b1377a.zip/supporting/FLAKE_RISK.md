Audited SHA: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope is the immutable `.audit-work/baseline` snapshot; concurrent working-copy changes are excluded. Findings are source review, synthetic local probes or supplied exact-SHA CI evidence, not production attestation.

| Risk | Evidence | Distinguish from logic failure | Action |
|---|---|---|---|
| Async teardown/discovery hang | command-center-ci.yml:86 documented skips | Skipped test is not passed | Fresh process repro; timeout stack dump; expiring quarantine |
| Global pytest temp symlink cleanup on Windows | Agent command exited 1 after 19 passed bodies | Infrastructure cleanup PermissionError | Unique owned --basetemp; do not delete unrelated temp trees |
| UTF-8 and async pytest mode differences | Root audit harness notes; focused command explicit modes | Harness compatibility, not fixed application behavior | Pin dev harness configuration; test clean environment |
| POSIX 0600 test on Windows | test_v3_evidence_signing.py:75 | Deterministic platform assumption, not a random flake | ACL assertion on Windows; mode assertion on POSIX |
| Browser process teardown/network wait | Workflow installs Chromium and timeout controls | Require browser execution and failure artifacts | Trace/screenshot/log on failure, lifecycle cleanup |
| Historical worktree tests | Core/root fetch-depth:0 | Missing commit is unavailable evidence, not a passing substitute | Verify SHA exists and isolate worktree mutations |
| Unpinned pip dependencies | Workflow pip install and floating action majors | Same commit may see different tool behavior | Lock audit/test dependencies and save versions |
| Hardware skip accumulation | Core sandbox flag disabled | Honest omission but weak acceptance | Separate capabilities inventory and hardware runner |

Repeated-run statistics NOT_MEASURED. No test has been called flaky solely because it failed once. Do not hide invariant failures behind retries; require a failure classifier and preserve first-run evidence.
