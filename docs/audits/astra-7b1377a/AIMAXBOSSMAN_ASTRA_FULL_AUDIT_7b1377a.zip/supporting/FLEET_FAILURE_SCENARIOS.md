# Fleet failure scenarios

Baseline: 7b1377a4f69336a1ca9d8eb4d432a758e195ae33. Tests below are acceptance requirements unless explicitly marked EXECUTED.

## F001: Lease acquisition violates shared/exclusive exclusion and fences live sharers

Exclusive acquisition checks only existing exclusive leases; a live shared lease does not prevent an exclusive lease. New shared leases also invalidate older shared tokens. Root executed shared_exclusive_lease_conflict.

Required outcome: A valid exclusive owner must have no concurrent shared owner; valid sharers must coexist.

Regression: Shared→exclusive and exclusive→shared rejection; shared→shared both valid; TTL/reclaim race.

Evidence: EXECUTED: ../probes.json; source `bossman-core/bossman_v3/fleet/leases.py:38`.

## F002: Fencing checked after dispatch, not before resource mutation

The request contains lease_id/fence but dispatch only reads contract/context_policy/agent_id. FleetControlPlane validates at control_plane.py:220 after execute returns. An expired worker can already mutate before its result is refused.

Required outcome: Stale workers cannot mutate a fenced resource.

Regression: Expire lease while paused immediately before mutation; stale write must fail and fresh owner must succeed.

Evidence: SOURCE_INSPECTED; source `bossman-core/bossman_v3/fleet/node_agent.py:72`.

## F003: Queue completion has no owner or fence check

Worker A loses its claim; B receives claim fence 2; A invokes complete(work_id) and deletes B’s live work. fleet/store.py:224 DELETE filters only work_id.

Required outcome: Only the current claim owner and generation can acknowledge/dead-letter/release work.

Regression: Reclaim A→B then stale A complete/release/failure; none may alter B claim.

Evidence: EXECUTED: ../probes.json; source `bossman-core/bossman_v3/fleet/queue.py:77`.

## F004: Retry and human-wait decisions leave queue immediately claimable

BACKOFF returns REQUEUE_AFTER_2s but persists no availability timestamp; HUMAN_REQUIRED releases claim then returns WAIT_HUMAN with no blocked state. eligible_for reads all unclaimed rows at line 53.

Required outcome: Backoff and human-wait states must control eligibility durably.

Regression: Immediate claim after timeout denied; clock advance allows; approval remains unclaimable after restart.

Evidence: EXECUTED BACKOFF: ../probes.json; SOURCE_INSPECTED HUMAN_REQUIRED; source `bossman-core/bossman_v3/fleet/queue.py:85`.

## F005: Unified memory admission double-counts physical headroom

A node with 16 GB unified pool admits 12 GB host plus 12 GB GPU requirements: the probe returns no rejection. Separate comparisons and max(gpu_free,ram_free) reuse one pool.

Required outcome: Physical aggregate reserved demand cannot exceed shared available capacity.

Regression: 16 GB rejects disjoint 12+12; non-unified independent pools pass where appropriate; concurrent reservations cannot oversubscribe.

Evidence: EXECUTED: probes.json/unified_pool_double_count; source `bossman-core/bossman_v3/fleet/scheduler.py:43`.

## F006: Minimized contract drops constraints while retaining sensitive step arguments

Minimized transport removes constraints/deadline/dependencies/metadata but retains whole goal, placement and steps; synthetic payload remains in step args. PrivacyRouter public/untrusted selection therefore does not prove payload minimization.

Required outcome: Minimization must preserve enforceable restrictions and remove non-authorized data.

Regression: Nested sensitive steps/goal/placement scrub or reject; constraints survive; minimized contract cannot expand permissions.

Evidence: EXECUTED: probes.json/minimized_discards_constraints_keeps_step_payload; source `bossman-core/bossman_v3/fleet/node_agent.py:98`.

## Crash and cancellation matrix

Crash before dispatch: preserve queued intent and reservation; after sink mutation/before receipt: UNKNOWN_EFFECT and reconcile, never blindly replay irreversible action; after receipt/before acknowledgement: return persisted result through same idempotency key; after lease expiry: sink refuses stale owner. Root has executed the pending irreversible crash probe, which currently allows resume.

Local cancellation and timeouts are unsupported: do not report a successful stop after cancel returns False. Remote partitions, authenticated replay/nonce windows, rotating keys, disconnected artifact verification and cross-host recovery were NOT EXECUTED.