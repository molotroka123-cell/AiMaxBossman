Audited SHA: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope is the immutable `.audit-work/baseline` snapshot; concurrent working-copy changes are excluded. Findings are source review, synthetic local probes or supplied exact-SHA CI evidence, not production attestation.

1. Restore exact-SHA scanner/root gates after alert triage; scope annotations to demonstrated public/synthetic literals. Do not broad-exclude the new package or archives.
2. Introduce aggregate acceptance manifest containing expected check names, audited SHA, conclusion, timestamps and relevant skip capability labels. Absent, cancelled, pending, neutral and UNKNOWN do not satisfy required evidence.
3. Apply branch rules requiring this gate. Audit does not mutate repository protection settings.
4. Separate secret, SAST and SCA jobs so earlier failures cannot erase independent scan evidence. Upload reports with always() and distinguish scanner crash from findings. Add narrow expiring baselines, then block new serious findings.
5. Add Windows smoke, ACL, path and launcher checks. Use OS-compatible timeout methods and explicit UTF-8/async harness configuration.
6. Add unskipped sandbox and cancellation/recovery acceptance on an identified owner runner before unattended autonomy; keep missing hardware marked BLOCKED.
7. Store test count/skip count and JUnit artifacts by SHA. Add property tests for approval consumption, archive recursion budgets and DNS pinning. Mutation targets: invert verification predicate, remove kind/preview approval clause, suppress cap and replace pinned IP with hostname; each must kill at least one meaningful test.
8. Pin dependency versions/actions by reviewed immutable revisions, schedule updates, and add root concurrency cancellation for obsolete runs without cancelling a release attestation mid-publication.

Per-finding files, tests, effort and risk are in CI_AUDIT.md and findings.json. Benchmarks need real resource/cost telemetry; raw pytest counts are not performance or deployment attestation.
