# Memory vNext design

Proposal, not implemented. Consolidate authority contracts rather than forcing every store into one technology. Store typed references carrying content hash, observed_at, valid_until, scope, trust_class, producing attempt, verifier reference and supersedes relation. Workflow checkpoints remain authoritative; model summaries remain derived and cannot set verified status.

Replace FailureMemory read-modify-overwrite (`bossman-core/bossman_v3/memory/failure_memory.py:23-34`) behind its existing interface with transactional append-only records and versioned projections. Quarantine corrupt state; reconcile old file row counts/hashes before activating migration. Atomically persist checkpoint and artifact references; recover projections after crash without replaying external effects.

Retrieval flow: authorize scope -> expire/revoke -> retrieve -> preserve authoritative/current and conflicting evidence -> assemble final model-specific serialized budget -> emit manifest. Oversized mandatory context returns CONTEXT_BUDGET_BLOCKED, never silently drops policy. Recheck private-data policy after model fallback. Repeated model claims or repeated retrieval are not independent confirmation.

Tests: crash at each commit point, simultaneous writers, sibling canaries, inherited read versus write scope, expiry boundaries, contradictory tails sharing500-character prefix, Cyrillic/CJK/tool-schema overflow, model switch, corrupt projection recovery and stale-summary override attempt. Shadow manifests first, then transactional adapter, then strict guards; evaluate precision/recall on owner-labeled cases before tuning ranking. Effort estimate1-2weeks for contracts/storage plus evaluation; no measured delivery commitment.
