# Organization failure scenarios

Baseline: 7b1377a4f69336a1ca9d8eb4d432a758e195ae33. Tests below are acceptance requirements unless explicitly marked EXECUTED.

## O001: Private/local-only contract can route to cloud-tier agent

Only frontier executor registered: local_only contract routes to that cloud-tier executor. Fleet selecting a trusted local node does not restrict a model endpoint. command-center/bcc/features/organization.py:73-99 binds a V2 agent but does not copy contract.privacy into task metadata.

Required outcome: Privacy must hold through agent/model/provider routing and tool egress, not only physical placement.

Regression: Cloud-only pool + local_only fails closed; fallback cannot cloud-escalate; capture outgoing requests to prove payload remains local.

Evidence: EXECUTED selection: probes.json/local_only_cloud_marketplace; no real cloud request made; source `bossman-core/bossman_v3/organization/marketplace.py:77`.

## O002: Cross-mission work ID collision corrupts ownership and payload

Saving work same for first then second mission preserves SQL mission_id=first but replaces contract.mission_id=second and resets state to planned; second mission contains no rows. receive_mission:139 only checks duplicate IDs within incoming contracts. Fleet tables likewise globally key work_id.

Required outcome: Mission/work identity and immutable contract payload must remain consistent; a second mission cannot reset first mission’s completed work.

Regression: Two missions sharing task-1 cannot overwrite; completed work remains completed; interrupted receive is atomic.

Evidence: EXECUTED: probes.json/cross_mission_work_collision; source `bossman-core/bossman_v3/organization/store.py:163`.

## O003: Negative and non-finite resources bypass budget admission

Reserve USD -100 under cap 10 makes USD 100 request eligible; NaN usage fits finite cap because comparison is false. Resource dataclass has no validation.

Required outcome: Resource estimates, limits and actuals are finite non-negative values with explicit units.

Regression: Negative reserve rejected; NaN/infinity rejected through API and direct construction; no state mutation on invalid input.

Evidence: EXECUTED: probes.json/negative_nan_treasury; source `bossman-core/bossman_v3/organization/models.py:74`.

## O004: Mandatory risk role is formed but never reviewed when reviewer exists

High-risk department requires reviewer and risk. Team formation requires both, but runtime selects reviewer_id = REVIEWER or RISK and calls reviewer once; risk member has no veto opportunity.

Required outcome: Every mandatory review gate must produce its own independent verdict before completion.

Regression: Reviewer approves while risk vetoes: mission must not complete; missing or crashed risk verdict blocks.

Evidence: SOURCE_INSPECTED; source `bossman-core/bossman_v3/organization/runtime.py:398`.

## O005: Treasury reserve and execution state are not a crash-consistent transaction

Reserve mutates only memory; work is persisted executing; envelope persistence happens after commit at line 414. Crash after charge or reviewer exception leaves no settled durable usage. restore at treasury.py:94 explicitly drops reservations; restarted or concurrent runtime can spend available budget again.

Required outcome: Every in-flight spend has one durable reservation and every incurred charge is reconciled exactly once.

Regression: Kill after reserve, after provider charge, during review and before settlement; restart preserves exposure and cannot double settle.

Evidence: SOURCE_INSPECTED; source `bossman-core/bossman_v3/organization/runtime.py:334`.

## O006: Renewable capacity is accumulated as lifetime spend

Resources combines consumables (USD/tokens) and renewable capacity (concurrency/gpu_memory_gb). commit adds every actual dimension to spent. Sequential concurrency=1 jobs exhaust concurrency limit after N jobs although no jobs remain active.

Required outcome: Capacity is reserved while occupied and released on completion; consumption accumulates.

Regression: Many serial one-slot jobs under concurrency cap 1 succeed; overlapping two-slot occupancy is rejected.

Evidence: SOURCE_INSPECTED; source `bossman-core/bossman_v3/organization/treasury.py:136`.

## O007: Knowledge parent read trusts caller-supplied prefixes instead of lineage

include_parents=(department:foreign,) is accepted solely by prefix and exposes foreign facts; root probe parent_scope_prefix_only returned foreign_parent_returned true. export similarly trusts caller supplied source_department without matching fact ownership.

Required outcome: Cross-scope access requires authenticated membership/lineage or explicit authorized export.

Regression: Mission A cannot read department B via include_parents; forged source department cannot authorize export.

Evidence: EXECUTED read: ../probes.json; SOURCE_INSPECTED export; source `bossman-core/bossman_v3/organization/memory_scope.py:120`.

## Review and restart matrix

ContractReviewer is deterministic metadata/evidence validation, not semantic risk review. Required gates must all run, report durable verdicts, and fail closed on reviewer exception. Concurrent direct OrganizationRuntime callers have no distributed lock/CAS; Command Center serializes only within its service instance. Restart tests must use two processes and actual kill points, not only fresh object construction.