Audited SHA: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope is the immutable `.audit-work/baseline` snapshot; concurrent working-copy changes are excluded. Findings are source review, synthetic local probes or supplied exact-SHA CI evidence, not production attestation.

| From → To | Authority/check | Evidence | Residual question |
|---|---|---|---|
| Browser → Command Center API | Session, CSRF; optional custom bearer header | api.py:237; sessions.py:92 | Live proxy scheme, cookie configuration and token rotation |
| API login → session creation | Rate limiter then constant-time token check | api.py:492; auth.py:68 | Multi-process/global rate-limit durability |
| Local/proxy client → gateway | Bearer by default; proxy headers disable optional loopback shortcut | gateway/auth.py:57; config.py:124 | Real proxy must preserve trusted provenance; absent headers are not cryptographic identity |
| Model → HTTP network | Tool grant + confirm_default + check_url | toolkit/net.py:113,150,200 | DNS destination not pinned; response unbounded |
| Plugin URL → HTTP network | All-IP validation + pinned transport + bounded stream | plugin_security.py:127,175,187 | Transport dependency compatibility and caller header policy |
| Owner decision → tool invocation | Atomic consume(kind,preview) | approvals.py:56 | Canonical argument/task/expiry binding per caller |
| Worker → evidence store | Signed evidence and central verifier checks | bossman_shared/evidence.py; root audit | Signing authority is not state freshness |
| Process → logs/support artifact | Optional token suppression | auth.py:41 | Default stdout disclosure reproduced |
| ZIP → CI trusted artifact | Pattern scanner with type/size skips | tools/ci_secret_scan.py:117 | Unscannable members silently omitted |
| CI checks → accepted revision | Exact head_sha/conclusion; branch rules external | ci.json and branch API evidence | Audited SHA has four failures; no branch protection |
| Test doubles → physical runtime | Explicit hardware/sandbox skips | core workflow:126 | Actual isolation and authenticated fleet transport UNPROVEN |

Paths in short evidence cells are relative to `command-center/bcc` or `bossman-core/bossman` as indicated by subsystem. No trust is granted to archive prose beyond the user's explicit audit request. No cloud or live remote execution was authorized by model-generated instructions.
