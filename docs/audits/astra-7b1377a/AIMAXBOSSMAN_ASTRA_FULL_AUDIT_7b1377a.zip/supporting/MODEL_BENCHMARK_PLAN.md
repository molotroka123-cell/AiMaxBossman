# Model benchmark plan

Proposed execution plan, not completed benchmark. Existing router role_scores/latency/gen_tps/success_rate (`command-center/bcc/v2/model_router.py:79-99`) need measured evidence. Record exact model/provider/backend versions, source SHA and immutable cases; separate advertised, tested-pass, tested-fail and stale capabilities.

Cases: structured JSON; malformed schema; reversible file creation with independent hash; browser observation after external mutation; private-memory no-cloud fallback; multilingual retrieval; growing context; tool outage;429/timeout; interrupted stream; unknown tool; parallel tools; missing pricing; local memory pressure; model switching during resume. Deterministic tests precede bounded paid live tests.

Collect input/output/reasoning/cache tokens, tokenizer, first-token/full latency, generation rate, attributable peak RAM/VRAM, all attempts, price snapshot, route decisions and independent verifier result. Failure/timeouts stay in denominators. Separate cold load, warm request and saturation; record OS, backend, quantization and KV settings. Syntactically valid tool calls cannot pass effect cases.

Proposed acceptance: zero privacy and duplicate-effect violations; mandatory schema and tool-proof cases pass before verified tool eligibility. Quality/latency targets follow measured baseline, not invented numbers. Repeat seeds and publish counts/uncertainty. Current throughput/cost/latency are null / UNMEASURED.

Artifact fields: benchmark_run_id, case_id, source_sha, model/provider/backend IDs, hardware_snapshot_id, policy_hash, attempts, evidence_refs, outcome/failure_class, usage_known, cost_known, timing and sample_count. Changed model/backend invalidates old capability attestation.
