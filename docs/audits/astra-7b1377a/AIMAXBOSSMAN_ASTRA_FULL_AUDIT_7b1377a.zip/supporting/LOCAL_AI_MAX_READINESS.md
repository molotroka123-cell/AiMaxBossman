# Local AI MAX readiness

Verdict: relevant abstractions exist; hardware acceptance BLOCKED/UNMEASURED until target hardware is tested.128GB is a future target, not measured installed RAM. No GLM, chipset or throughput promise is inferred.

`model_router.py:41-74` derives local eligibility without model-brand hardcoding. Candidates carry memory/context requirements. Organization Resources includes GPU time/memory/network (`bossman-core/bossman_v3/organization/models.py:76-94`). `command-center/bcc/metrics.py:171-205` offers AMD/sysfs best effort. These fields do not attest unified-memory safety, NUMA scheduling, backend support or model quality.

Unknown memory requirement currently passes router checks. Admit large models only after measuring weights+KV+runtime+OS headroom. Unified RAM/VRAM requires a single shared physical-capacity ledger, not adding duplicate capacities. Include browser, embedding, vision and load-transition peaks.

Acceptance: inventory OS/driver/backend/memory; verify endpoint binding and authenticated LAN policy; measure cold/warm small model; increase context/concurrency gradually; test pressure, cancellation, restart, disk-full and thermal soak; run the same independent verifiers as cloud. Record model hash/license/quantization/KV/offload settings.

Required evidence remains peak attributable memory, sustained throughput, tool/schema pass rate, queue latency, no-swap policy and recovery. Missing AMD sysfs on Windows means unknown metrics, not no GPU use. PROD-003 shows unavailable NVIDIA process telemetry also needs correction. Do not select/purchase hardware based on these unmeasured assumptions.
