# Success paths and prerequisites

1. Core worker: runner.py:319 run_task initializes done at :358; no-tool response at :410 breaks; :438–449 writes final states. Reachable through worker :487–505. No independent completion gate on this path. ASTRA-001.
2. BCC engine: :788–837 executes critical completion hooks and escalates exceptions; :838–841 finishes only after no FAIL. NOT_APPLICABLE from every hook remains a possible informational terminal result. Gate installation and action classification must be included in each side-effect acceptance test.
3. UniversalComputerAgent: agent.py:77–101 validates policy, approval, executor support, observation timing and verifier. Requires a trustworthy port; model text never enters this verifier method as authority.
4. CompoundRunner: compound.py:118–131 persists a successful step then requires all required IDs in finished(). Direct caller can observe a false completed flag under ASTRA-002; bridge export can still refuse it.
5. Organization: runtime.py:392–430 validates evidence, independent reviewer can veto, completion requires ok and result.verified. runtime.py:505–518 aggregates mission. Evidence freshness/content binding is ASTRA-004; risk-role coverage assessed in Organization report.
6. Fleet: control_plane.py:217–249 checks lease after dispatch and rejects stale return, transitions through OBSERVED/VERIFYING/VERIFIED. This guards accepted result, not physical exactly-once execution.
7. Persisted WorkResult: models.WorkResult.verified uses success and evidence booleans. status() trusts restored result property; validity re-check after arbitrary local DB tampering is UNPROVEN. SQLite is a trusted-local storage boundary, not a hostile-node protocol.

Tests cited in evidence/tests_reviewed.txt exercise selected paths. Exit 0, HTTP 200, tool-called and cache hit must remain distinct from verified expected state.
