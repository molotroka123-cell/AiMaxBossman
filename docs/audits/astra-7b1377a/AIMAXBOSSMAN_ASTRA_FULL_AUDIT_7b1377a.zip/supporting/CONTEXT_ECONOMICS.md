# Context economics

Baseline: 7b1377a4f69336a1ca9d8eb4d432a758e195ae33. No joined production usage and independently verified outcome corpus was available.

| Metric | Value | Required denominator/data |
|---|---|---|
| TOKENS_PER_VERIFIED_SUCCESS | null / UNMEASURED | All input/output/reasoning/retry tokens divided by distinct independently verified task IDs |
| CONTEXT_REBUILD_COST | null / UNMEASURED | Token and CPU/provider expense of rebuilding context per task/attempt/model |
| STATE_RECONSTRUCTION_RATIO | null / UNMEASURED | Reconstructed-state tokens divided by all supplied input tokens, using non-overlapping buckets |
| MEMORY_REUSE_RATE | null / UNMEASURED | Requests consuming authorized relevant previous memory divided by eligible retrieval requests |

Zero denominator yields null, never perfect efficiency. Include failed/abandoned attempts. Cache artifact reuse is not new execution. V2 synthetic budget56 -> estimated72 is28.6% overflow in that fixture, not a production waste estimate. V2 character divisor3.5 (`context_pack.py:25`) differs from V3 estimator (`assembler.py:50`); neither establishes provider-token accuracy.

Record tokenizer/version, estimated and actual input, static prefix, retrieval, reconstruction and tool-result buckets, plus model/policy/context manifest IDs and cache billing fields. Join immutable task/attempt IDs to verifier outcomes. Compare identical replay cohorts before/after optimization; token reduction must not reduce verified outcomes or weaken privacy. No savings percentage is claimed.
