# Fleet upgrade proposals

Implement safety dependencies first. These are proposals, not completed code or proven runtime guarantees. Do not implement a remote transport before fencing, policy propagation, durable reservation/identity and unknown-effect reconciliation are working.

## F001 (P1, effort M)

Stage 1: Reject exclusive requests when any live lease exists and shared requests when an exclusive lease exists; separate shared membership from ownership generations.

Target: Transactional resource lease state with exclusive generation and explicit shared holders.

Acceptance: Shared→exclusive and exclusive→shared rejection; shared→shared both valid; TTL/reclaim race.

Risk: medium. Dependencies: none.

## F002 (P1, effort L)

Stage 1: Pass a lease capability to the execution boundary and validate before every mutating step.

Target: Sink-enforced fencing and idempotency with monotonic resource generations, cancellation and reconciliation.

Acceptance: Expire lease while paused immediately before mutation; stale write must fail and fresh owner must succeed.

Risk: high. Dependencies: F001; root crash-before-journal finding.

## F003 (P1, effort M)

Stage 1: Require Claim on complete and CAS delete by work_id, claimed_by and claim_fence; fence release/failure too.

Target: One transaction for result commit, fenced acknowledgement and durable event.

Acceptance: Reclaim A→B then stale A complete/release/failure; none may alter B claim.

Risk: medium. Dependencies: none.

## F004 (P1, effort M)

Stage 1: Persist state/not_before/attempt count and exclude waiting-human and future rows; only authenticated approval clears wait.

Target: Durable retry policy machine with jitter, clock control, max elapsed budget and fenced transitions.

Acceptance: Immediate claim after timeout denied; clock advance allows; approval remains unclaimable after restart.

Risk: medium. Dependencies: none.

## F005 (P1, effort M)

Stage 1: Represent unified pool once; add disjoint host/GPU demands plus safety margin and deduct active reservations atomically.

Target: Typed resource topology with measured resident model footprint, KV/workspace buffers, pool overlap semantics and fair reservation.

Acceptance: 16 GB rejects disjoint 12+12; non-unified independent pools pass where appropriate; concurrent reservations cannot oversubscribe.

Risk: medium. Dependencies: F001.

## F006 (P1, effort M)

Stage 1: Preserve policy/security envelope and allowlist only transport-required payload fields; reject minimization when action needs undisclosed sensitive data.

Target: Content-classified immutable envelope with separate executable policy and encrypted artifact capabilities.

Acceptance: Nested sensitive steps/goal/placement scrub or reject; constraints survive; minimized contract cannot expand permissions.

Risk: medium. Dependencies: none.

## Distributed rollout gate

Ship local-only characterization first; introduce sink-enforced execution capabilities and resource reservations next; only then implement authenticated remote node identity, signed requests, replay windows, encrypted channel and key rotation. Require two-host fault injection covering partitions, stale heartbeats, disk full, scheduler restart, duplicate delivery, stale acknowledgements and ambiguous external effects. Capacity planning must reflect shared UMA, model weights, KV cache and active reservations rather than marketing RAM size.