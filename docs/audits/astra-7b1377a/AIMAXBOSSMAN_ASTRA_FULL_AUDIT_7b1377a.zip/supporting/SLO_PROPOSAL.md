# SLO proposal

Candidate engineering targets, not achieved measurements. Establish actual baseline before owner commitments.

| Indicator | Proposed target | Evidence |
|---|---|---|
| False verified outcomes |0|Independent post-state proof for every attempt|
| Duplicate non-idempotent effects |0|Effect IDs across retries/restarts|
| Private data to forbidden provider |0|Every attempt and fallback|
| Durable terminal-state reconstruction |100%|Crash injection checkpoints|
| Owner command API acknowledgement |p95<=1s|Accept/reject receipt, not effect completion|
| Healthy snapshot freshness |p95<=5s|Source commit to displayed revision|
| Hardware metric age |<=30s or explicit stale|Existing10s sampler plus failure handling|
| Cancellable worker cancel acknowledgement |p95<=5s|Request to worker receipt; effects reconciled separately|
| Serialized context budget adherence |100%|Tokenizer count incl. tools/output reserve|

Availability failures cannot relax correctness/privacy/evidence. Missing metrics retain null/status; PROD-003 violates that contract. Use histograms and error classes, immutable attempt/epoch trace IDs, bounded metric cardinality and no private text in labels. Correctness breaches alert immediately; sustained availability/freshness alerts avoid noise. Retain sanitized events and artifact hashes for reconstruction. Actual p95/availability/correctness population rates remain UNMEASURED.
