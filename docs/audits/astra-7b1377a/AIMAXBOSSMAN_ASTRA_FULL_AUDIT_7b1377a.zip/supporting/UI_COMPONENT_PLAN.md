# UI component plan

Use the existing DOM component system; no unsolicited frontend rewrite. `mission_console.js:146` val is a starting point for SourceValue. Centralize schema-backed status adapters.

| Component | Contract | Acceptance |
|---|---|---|
| MissionSelector |Stable mission ID|Concurrent events cannot switch focus|
| TruthStageBadge |Typed stage+proof metadata|Executed/signed/completed cannot imply VERIFIED|
| SourceValue |Value/unit/source/time/availability|null and stale distinct from0|
| TaskGraph |Mission-scoped pages+required edges|Unrelated tasks cannot hide children|
| PlacementCard |Agent/model/node/epoch/reasons|Placed differs from executing|
| EvidenceDrawer |Immutable proof/time/verifier/digest|Stale evidence visibly invalid|
| ApprovalCard |Action digest/revision/policy|Changed action invalidates approval|
| MissionControls |Command ID/revision/ack stage|Toast cannot prove cancellation|
| CostPanel |Actual/estimated/unknown/reserved/retry|Missing price cannot render free|
| ArtifactShelf |Hash/attempt/verification/preview|Cache reuse cannot imply new effect|
| AttentionQueue |Blocker/dependency/safe next step|Owner resolves without raw logs|

Separate read/control contracts. Add keyboard labels, focus preservation, announcements and responsive checks to interactive components. Validate contract tests plus actual browser action flows; screenshot/snapshot tests alone do not prove action semantics. All components above are proposals.
