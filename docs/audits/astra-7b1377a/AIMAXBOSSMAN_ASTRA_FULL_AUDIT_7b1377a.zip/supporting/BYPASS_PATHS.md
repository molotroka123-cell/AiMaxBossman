# Bypass and ambiguity paths

ASTRA-001: no-tool final response → Core done → task.updated → completed memory.
ASTRA-002: untrusted journal flags → finished() → CompoundRunner skip → completed=True. Bridge signature check prevents simple escalation of this unsigned record.
ASTRA-003: same IDs + changed action → retained signed old journal → new plan labels old evidence. Digest must cover args, expectation, root, scope and side-effect class.
ASTRA-004: valid HMAC + matching kind/target + forged executed boolean from an untrusted bridge → validate True despite old or cross-mission evidence. Trusted signing key access is not claimed for a remote attacker.
ASTRA-005: irreversible effect → process killed → PENDING journal → safe-to-resume decision. An intent write is missing; result fencing after execution is too late to prevent the effect.

Additional bypass surfaces are documented by the specialists: ownerless queue acknowledgement, missing risk review, scope parent selection, privacy propagation and context redaction. Refer to machine/findings.json for exact preconditions and confidence. Unknown network exploitability remains unknown.
