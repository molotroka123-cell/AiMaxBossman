# Cost traps

Source-grounded risks; no production loss/savings amount claimed.

1. Unknown OpenRouter prices become free (`openrouter_ext.py:13-21,65-66`), accepted by output cap/scoring. PROD-002: fix availability/freshness admission before score tuning.
2. Actual expense substituted by estimated budget (`organization/runtime.py:411`). Add per-dimension provenance and late settlement; otherwise accounting accuracy is UNPROVEN.
3. V2/V3 context framing overflow and differing estimators (`v2/memory/context_pack.py:25,56-73`; V3 `assembler.py:50,114`) can cause rejection/rebuild/retry. Fix hard serialized bounds.
4. Nested reviewer/executor/retry expense needs shared root budget; process-local treasury (`treasury.py:58,118`) cannot enforce global caps across independent processes. Measure team benefit before parallelizing everything.
5. Mean input/output price scoring (`model_router.py:176-177`) ignores task-specific expected volume and cache billing. Use bounded expected total cost with uncertainty.
6. Local GPU/network/energy/opportunity costs differ from API USD (`organization/models.py:86-94`), but are real admission constraints.
7. Escalation may repeat expensive reconstruction. Reuse verified artifacts and manifests while refusing stale execution proof.

Measure all-attempt cost against an identical verified-work cohort, including failed and abandoned work. Unknown cost remains null. Policy: finite attempt tree, per-tool caps, remaining-budget visibility, conservative unknown reservation and explicit owner budget extension. A budget field alone does not physically stop a third-party bill.
