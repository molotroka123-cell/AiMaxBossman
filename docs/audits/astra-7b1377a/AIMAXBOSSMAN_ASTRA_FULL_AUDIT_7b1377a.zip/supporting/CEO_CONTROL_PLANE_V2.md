# CEO control plane v2 proposal

One versioned read model should join immutable mission/task/run/attempt/agent/node IDs. Do not reconcile truth in browser status strings. Gap evidence: current console SRC/render (`mission_console.js:39-50,285-328`) reads V2 lists, while Organization/Fleet hold separate state.

Snapshot: snapshot_id/revision/observed_at/source age; goal/status; required-child graph; current action/attempt; selected model/provider/node; placement reasons/rejected alternatives; epoch/lease deadline; proof stage/verifier reference/freshness; approval action digest/policy; blockers/retries; actual/estimated/unknown expense/reservations; owner attention reason. Disclose inconsistent source revisions rather than fabricating atomicity.

Commands: pause/cancel/resume/approve/reject/retry with changed budget. Every command binds idempotency key, expected revision and actor identity. Return accepted plus command_id; show worker-observed and verified acknowledgement separately. Natural-language stop text cannot replace hard cancellation. Recheck authorization at execution.

Flow: durable canonical events -> transactional projections -> bounded deltas -> reconnect cursor -> resnapshot on gap. Count telemetry drops. Payloads use references/hashes and sanitized metadata, not unrestricted prompts/secrets/tool outputs.

Acceptance: restart awaiting approval, disconnected node during effect, stale UI approval, required child failure, billing after cancel, missed event range, unknown metrics and paginated missions. Test state transitions/effects, not toast text. Rollout shadow projection before changing owner controls.
