Audited SHA: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope is the immutable `.audit-work/baseline` snapshot; concurrent working-copy changes are excluded. Findings are source review, synthetic local probes or supplied exact-SHA CI evidence, not production attestation.

Goal: cause an unauthorized effect, disclosure or false acceptance.

1. Cross external-input → host-network boundary: model supplies attacker domain; DNS is public at policy check and private at connection; Core HTTP reaches private service (SEC-101). Required preconditions: tool granted and request approved or owner waiver. Default confirmation lowers opportunity but does not close transport race.
2. Cross external-response → memory/disk boundary: approved host streams excessive content; Core buffers/writes body before clipping (SEC-102). Continuous transfer can outlive per-read timeout assumptions.
3. Cross development-artifact → repository-trust boundary: put synthetic/private material in excluded archive type or nested ZIP; scan returns no findings (SEC-103). A corrupt archive is also uninspected, not clean.
4. Cross process-output → operator credential boundary: ordinary stdout capture records startup bearer token; log recipient can present it (SEC-104). Probe only used an ephemeral generated token.
5. Cross CI-report → acceptance boundary: select successful checks while omitting four failed exact-SHA jobs, or mistake advisory scan exit handling for clean scans (CI-101/102). Missing branch rules permit unchecked advancement.
6. Cross runtime-evidence → product-claim boundary: Linux-only or skipped/mock sandbox tests are advertised as Windows/remote containment (CI-103/104). Failure is overstatement, not demonstrated sandbox escape.
7. Cross task/model-data → persistence boundary: central audit journal escape, memory scope and redaction probes must be fixed alongside these findings. Do not treat valid signature alone as fresh authorized post-state evidence.

Defenses with positive source evidence: cookie sessions + CSRF; constant-time token comparison; default authenticated gateway; single-use approval update; Command Center pinned transport. Residual risk must be tested per actual deployment rather than inferred from existence of these helpers.
