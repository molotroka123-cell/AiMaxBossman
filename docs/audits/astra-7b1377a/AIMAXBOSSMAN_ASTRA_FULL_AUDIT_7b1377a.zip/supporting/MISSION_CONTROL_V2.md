# Mission control v2 design

Retain existing source-labelled/no-data values, replace global list inference with a selected mission snapshot. Owner selection remains stable across rerenders and restart. Evidence: current console filters a capped global list (`mission_console.js:228-233,289`).

Layout: goal and verified progress; agent/node/model/current step; typed timeline; required-child graph; evidence drawer; owner attention/approval queue; remaining budget/retry panel; artifact shelf; explicit pause/cancel/resume; natural-language composer. Every changing metric carries source age and availability.

Timeline contains execution facts, not model chain-of-thought. VERIFIED opens observation time/verifier/post-state digest/action binding. BLOCKED shows primary reason, dependency chain, safe next action and budget. PLACED is scheduling, never proof.

Commands preview exact action/plan diff/policy; approval binds digest/revision. Accepted -> worker observed -> effect reconciled are separate. Disconnect leaves unknown until durable snapshot resolves. A cancel HTTP200 cannot show stopped without acknowledgement.

Migration: mission-scoped API/tests -> canonical IDs across Organization/Fleet -> opt-in snapshot view -> status adapter consolidation -> retire old view after parity. Test >100 tasks, multiple missions, stale approvals, partial child failure, offline endpoint, restart and keyboard flow. These are proposed changes, not implemented UI.
