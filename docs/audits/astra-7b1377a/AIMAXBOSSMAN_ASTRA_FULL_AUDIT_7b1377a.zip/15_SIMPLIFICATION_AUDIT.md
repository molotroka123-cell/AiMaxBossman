# Simplification audit

The principal simplification is a shared completion authority, not removal of V2 safety layers. Core runner, BCC hooks, V3 journal, Organization result validation and passive scoring currently have different truth semantics (ASTRA-001–006). Reuse BCC ExpectedState verifiers and preserve V3 ports while normalizing obligations and terminal transitions.

Organization contracts.EvidenceRequirement already subclasses the Company requirement type; do not duplicate it again. V3 evidence.py is a thin fail-closed bridge to bossman_shared.evidence, not dead code. Organization bridges.py explicitly replaces the direction of older ExecutiveOSBridge proposals; old ZIP design is not runtime authority. FleetResumeKernel deliberately reuses TaskJournal, but its crash semantics still need an intent state.

The repository contains 18 tracked ZIP files (inventory in evidence/archive_inventory.txt). They are provenance/design inputs, not evidence of deployed capability. Candidate relocation to releases should follow extraction inventory, documentation-link review, license/ownership checks and history retention. No ZIP was deleted. Source equivalence has NOT been established for every member.

Core gateway and BCC model_router are independently purposeful interfaces but duplicate policy, local/cloud and pricing vocabulary. Share a schema/capability and privacy contract first; do not delete a router merely because names overlap. FailureMemory JSON and scoped SQLite knowledge serve different records; consolidating storage is reasonable only after atomic migration and corruption behavior are specified.

Deletion candidates are conditional. No production packages or APIs were removed, and repository-wide dead-code reachability is UNPROVEN. Prioritize removing unsafe completion branches through replacement tests, then archive duplicate design bundles.
