# Treasury audit

Baseline:7b1377a4f69336a1ca9d8eb4d432a758e195ae33. `bossman-core/bossman_v3/organization/treasury.py:110-147` implements reserve/commit/release across scopes and records actual overruns. It does not guarantee provider billing stays below estimates. Local GPU time/memory/network resource fields exist (`organization/models.py:76-94`).

Reservations are process-local mutable envelopes; reserve is check-then-update with no operation ID or transaction. This is a multi-process risk, not a reproduced race in the product's serialized local mission service. Shared atomic admission, reservation IDs, idempotent commits and reconciliation are prerequisites for independent workers. restore drops reservations (`treasury.py:94-99`); correctness requires proving old attempts cannot continue billing/executing.

`organization/runtime.py:411` substitutes contract.budget if all actual fields are zero. This conflates legitimate0 with missing measurement. Partially measured result tokens can prevent fallback while USD remains unknown0. Preserve known/estimated/actual per dimension; reconcile bills later. PROD-002 additionally proves missing catalog price0. Price freshness is not a ModelCandidate field.

| Metric | Value |
|---|---|
| COST_PER_VERIFIED_SUCCESS | null / UNMEASURED |
| TOKENS_PER_VERIFIED_SUCCESS | null / UNMEASURED |
| CLOUD_AVOIDANCE_RATE | null / UNMEASURED |
| MODEL_ESCALATION_RATE | null / UNMEASURED |
| TEAM_OVERHEAD_RATIO | null / UNMEASURED |
| RETRY_COST_MULTIPLIER | null / UNMEASURED |

No joined actual-usage/independent-verification corpus was available. Account reviewer, retries, nested-agent, embeddings and tool/API expense against root mission. Tests: two-process final-budget race, duplicate commit, missing versus actual0 cost, partial usage, stale price, restart with in-flight billing and reviewer retry exhaustion. Definitions appear in TOKEN_EFFICIENCY_PLAN.md.
