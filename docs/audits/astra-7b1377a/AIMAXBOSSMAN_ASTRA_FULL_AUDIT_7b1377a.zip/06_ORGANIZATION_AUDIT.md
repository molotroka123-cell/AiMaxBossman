# Organization audit



Baseline: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope: source inspection plus isolated synthetic runtime probes; no remote deployment, real provider spend, destructive action or live fleet crash was performed.



Verdict: useful local control-plane implementation, not production-ready distributed safety. RemoteNodeTransport explicitly raises RemoteTransportUnavailable; node authentication is not implemented. Production UI OrganizationService wires V3ExecutionBridge directly, not FleetExecutionBridge. Therefore fleet unit tests do not prove the product path uses fleet scheduling.



Evidence: `probes.json` and `probes.py` in this report directory; shared root `.audit-work/probes.json`. Root owns the critical journal signature, plan identity, evidence replay and crash-before-journal findings; they are dependencies rather than duplicated IDs here.



Status distinction: deterministic ContractReviewer revalidates supplied evidence and identity; it does not run an independent reviewer model or observe the external world. Local cancellation returns False, timeout_seconds is unused by LocalNodeTransport, and a post-return stale check cannot undo mutations.



## O001 — Private/local-only contract can route to cloud-tier agent

Severity **P1**, confidence **high**, evidence **EXECUTED selection: probes.json/local_only_cloud_marketplace; no real cloud request made**.

Location: `bossman-core/bossman_v3/organization/marketplace.py:77`, `CapabilityMarketplace._reject_reason`.

Failure: Only frontier executor registered: local_only contract routes to that cloud-tier executor. Fleet selecting a trusted local node does not restrict a model endpoint. command-center/bcc/features/organization.py:73-99 binds a V2 agent but does not copy contract.privacy into task metadata.

Invariant: Privacy must hold through agent/model/provider routing and tool egress, not only physical placement.

Minimal fix: Reject cloud-tier/provider candidates for local_only/private policies and propagate an immutable privacy policy to V2/model broker.

Ideal fix: One end-to-end data-egress policy enforced at every model/tool/network sink, with approved declassification.

Tests: Cloud-only pool + local_only fails closed; fallback cannot cloud-escalate; capture outgoing requests to prove payload remains local.

Effort: L; change risk: high; dependencies: Model broker and V2 privacy integration.



## O002 — Cross-mission work ID collision corrupts ownership and payload

Severity **P1**, confidence **high**, evidence **EXECUTED: probes.json/cross_mission_work_collision**.

Location: `bossman-core/bossman_v3/organization/store.py:163`, `OrganizationStore.save_work`.

Failure: Saving work same for first then second mission preserves SQL mission_id=first but replaces contract.mission_id=second and resets state to planned; second mission contains no rows. receive_mission:139 only checks duplicate IDs within incoming contracts. Fleet tables likewise globally key work_id.

Invariant: Mission/work identity and immutable contract payload must remain consistent; a second mission cannot reset first mission’s completed work.

Minimal fix: Reject any already-owned work_id at mission intake and validate digest/mission on updates transactionally.

Ideal fix: Composite (mission_id,work_id) keys through contracts, results, queue, flights, journals and APIs, with migration.

Tests: Two missions sharing task-1 cannot overwrite; completed work remains completed; interrupted receive is atomic.

Effort: L; change risk: high; dependencies: Fleet/store schema migration.



## O003 — Negative and non-finite resources bypass budget admission

Severity **P1**, confidence **high**, evidence **EXECUTED: probes.json/negative_nan_treasury**.

Location: `bossman-core/bossman_v3/organization/models.py:74`, `Resources / Resources.fits`.

Failure: Reserve USD -100 under cap 10 makes USD 100 request eligible; NaN usage fits finite cap because comparison is false. Resource dataclass has no validation.

Invariant: Resource estimates, limits and actuals are finite non-negative values with explicit units.

Minimal fix: Reject negative/NaN/infinite and invalid integral values on every constructor/deserializer and external cost receipt.

Ideal fix: Validated resource types, decimal money, bounded arithmetic and immutable signed usage receipts.

Tests: Negative reserve rejected; NaN/infinity rejected through API and direct construction; no state mutation on invalid input.

Effort: M; change risk: medium; dependencies: none.



## O004 — Mandatory risk role is formed but never reviewed when reviewer exists

Severity **P1**, confidence **high**, evidence **SOURCE_INSPECTED**.

Location: `bossman-core/bossman_v3/organization/runtime.py:398`, `OrganizationRuntime._attempt`.

Failure: High-risk department requires reviewer and risk. Team formation requires both, but runtime selects reviewer_id = REVIEWER or RISK and calls reviewer once; risk member has no veto opportunity.

Invariant: Every mandatory review gate must produce its own independent verdict before completion.

Minimal fix: Evaluate all mandatory review roles and aggregate fail-closed; distinguish proof revalidation from substantive risk review.

Ideal fix: Persist independent policy/risk/QA verdicts bound to contract and evidence hashes with quorum rules.

Tests: Reviewer approves while risk vetoes: mission must not complete; missing or crashed risk verdict blocks.

Effort: M; change risk: medium; dependencies: ReviewerPort contract.



## O005 — Treasury reserve and execution state are not a crash-consistent transaction

Severity **P1**, confidence **high**, evidence **SOURCE_INSPECTED**.

Location: `bossman-core/bossman_v3/organization/runtime.py:334`, `OrganizationRuntime._attempt / ResourceTreasury.restore`.

Failure: Reserve mutates only memory; work is persisted executing; envelope persistence happens after commit at line 414. Crash after charge or reviewer exception leaves no settled durable usage. restore at treasury.py:94 explicitly drops reservations; restarted or concurrent runtime can spend available budget again.

Invariant: Every in-flight spend has one durable reservation and every incurred charge is reconciled exactly once.

Minimal fix: Persist reservation ID and envelope debit atomically before dispatch; reconcile unknown in-flight outcomes on restart rather than dropping reserve. Wrap reviewer/settlement lifecycle with durable cleanup state.

Ideal fix: Transactional usage ledger and per-attempt reservation IDs, provider receipt reconciliation, fencing and outbox.

Tests: Kill after reserve, after provider charge, during review and before settlement; restart preserves exposure and cannot double settle.

Effort: L; change risk: high; dependencies: O002; root crash-before-journal finding.



## O006 — Renewable capacity is accumulated as lifetime spend

Severity **P2**, confidence **high**, evidence **SOURCE_INSPECTED**.

Location: `bossman-core/bossman_v3/organization/treasury.py:136`, `ResourceTreasury.commit`.

Failure: Resources combines consumables (USD/tokens) and renewable capacity (concurrency/gpu_memory_gb). commit adds every actual dimension to spent. Sequential concurrency=1 jobs exhaust concurrency limit after N jobs although no jobs remain active.

Invariant: Capacity is reserved while occupied and released on completion; consumption accumulates.

Minimal fix: Separate consumable totals from renewable gauges and release capacity in settlement.

Ideal fix: Resource dimensions tagged quantity/rate/capacity with interval-based occupancy and actual metering.

Tests: Many serial one-slot jobs under concurrency cap 1 succeed; overlapping two-slot occupancy is rejected.

Effort: M; change risk: medium; dependencies: none.



## O007 — Knowledge parent read trusts caller-supplied prefixes instead of lineage

Severity **P1**, confidence **high**, evidence **EXECUTED read: ../probes.json; SOURCE_INSPECTED export**.

Location: `bossman-core/bossman_v3/organization/memory_scope.py:120`, `ScopedKnowledge.read`.

Failure: include_parents=(department:foreign,) is accepted solely by prefix and exposes foreign facts; root probe parent_scope_prefix_only returned foreign_parent_returned true. export similarly trusts caller supplied source_department without matching fact ownership.

Invariant: Cross-scope access requires authenticated membership/lineage or explicit authorized export.

Minimal fix: Resolve permitted ancestors from durable ownership, not request strings; bind export policy to stored source scope.

Ideal fix: Central scope authorization graph and audited capability grants for reads/writes/exports.

Tests: Mission A cannot read department B via include_parents; forged source department cannot authorize export.

Effort: M; change risk: medium; dependencies: Scope ownership store.

