# Daily-use capability gap analysis

Desired capabilities grounded in this repository, not claims about current commercial ChatGPT features. No external product comparison was performed. Estimates are design estimates, not delivery commitments.

| Capability | Starting point / gap | Value | Risk | Effort | Dependencies | Why now / not now |
|---|---|---|---|---|---|---|
| Long mission UX |Console exists, cross-layer snapshot partial|High|Medium|1-2w|Truth/scoped API|Daily visibility now|
| Session handoff |V3 journals exist, durability defects|High|High|1-2w|Atomic checkpoints/proof binding|After correctness fixes|
| Artifact workspace |Tools/events exist; shelf absent in console|High|Medium|1w|Hashes/attempt IDs/safe preview|After canonical task linkage|
| Action preview/plan diff |Approvals exist; text composer lacks typed command preview|High|Medium|1-2w|Action digest/revision|Clearer owner authority now|
| Semantic memory |V2 retrieval/V3 journals fragmented|High|High|2w+|Scope/expiry/token contracts|Fix isolation before expansion|
| Proactive attention |Event bus exists; durable cross-layer queue gap|High|Medium|1w|Snapshot/notification policy|Actionable blockers only|
| Browser state understanding |bossman/computer_operator/observer.py exists|High|High|Evaluate first|Fresh observations/verifier|Test existing engine before duplication|
| Web research |bossman/search_everything/router.py exists|Medium|Medium|Evaluate first|Attribution/trust controls|Quality evidence before new engine|
| Background jobs |Fleet/Organization primitives exist|High|High|2w+|Leases/idempotency/budget ledger|After distributed correctness|
| Multimodal screen |Computer operator and ai-webcam-vision exist|Medium|High|2w+|Privacy/local benchmark|Hardware/evaluation blocked|
| Voice |Completeness unproven in targeted review|Medium|Medium|Spike first|Audio permission/interruption|Stabilize task control first|
| Sandbox snapshots/rollback |Effect evidence exists; reversibility not universal|High|High|2-4w|Effect taxonomy/snapshots|Start reversible files; no universal undo|
| Simulation/dry-run |Typed proposals can support previews|High|Medium|1-2w|Policy/tool capabilities|Useful now; label simulated, never verified|
| Owner policy presets |Agent policy/router rules exist|High|High|1w|Versioned policy/preview/tests|Bound scope and rollback now|
| Skill marketplace |Repository skills exist; supply-chain trust separate|Medium|High|Multiweek|Signing/review/permissions|Later; avoid expanding authority blindly|

Highest-value foundation sequence: canonical mission snapshot, explicit controls, verified artifact shelf, attention queue, memory contracts. Do not add another agent framework before execution truth, privacy and restart correctness. Existing module names establish a starting point, not complete product acceptance. Browser, voice and screen feature quality remain UNMEASURED in this lane.
