# Execution truth map

Scope: principal runnable completion authorities were traced; the broad lexical inventory in evidence/success-search.txt is a navigation index, not a claim that every application-specific status assignment received call-graph review.

| Entry | Execution and observation | Completion authority | Judgment |
|---|---|---|---|
| Core Redis/DB worker | runner.worker → run_task → model/tool loop | runner.py default done and final UPDATE | ASTRA-001: side-effect final text bypass |
| BCC task worker | engine tool policy, approval, execute_tool; feature hooks | engine.py gate_completion → _finish | Hooks fail closed when malformed; coverage depends on obligations and feature applicability |
| BCC review feature | structured ExpectedState → verify_all(file/db/browser/app) | features/review_gate.py | No review metadata => NOT_APPLICABLE; not a universal side-effect proof |
| V3 one action | UniversalComputerAgent policy → approval → execute → fresh observation → verifier | VerificationResult.passed | Freshness comparison present; correctness depends on trusted executor/observer ports |
| V3 compound | run steps; journal record only after passed verifier | required journal.finished set | ASTRA-002/003/005: unsigned flags, plan mutation and crash window |
| Organization | plan → roles → reserve → execution bridge → contract.validate → reviewer → persist | runtime._attempt and _finish_mission | Required results/children checked; ASTRA-004 weak claim binding |
| Fleet | placement → lease → transport → reread journal → lease validity → validate | FlightState.VERIFIED | Distinct states; post-return fencing cannot undo stale external effects |
| BCC Organization projection | run_mission → sync terminal work to V2 | finish_v2_task direct DB status write | Delegates authority to Org; resume projection gap in product findings |
| Benchmark/README | adapter events → passive scorer → README update | reporting only | Does not execute; missing data cannot attest correctness |

ExecutionReceipt is the V3 name for the action receipt (contracts.py), carrying action_type, start/end, effect_id and references. It is not itself post-state evidence. CommandCenterObserver reuses bcc.v2.verification; absent expectations produce UNVERIFIED. CommandCenterExecutor raises on tool error and asserts the BCC run fence when available. The Fleet lease fence is a separate authority and is not passed to an external mutation sink by LocalNodeTransport.

The strongest implemented path is Organization → V3 bridge → actual local file writes with fresh reads, signed journal, distinct reviewer and passive score export in test_v3_cross_layer_e2e.py. Its deterministic local passes do not cover live cloud, real remote node authentication, killed-process unknown effects, or every legacy entry point.

No in-memory boolean or HMAC alone is sufficient to establish new side effects. Required future transition: PROPOSED → APPROVAL_REQUIRED (if needed) → INTENT_DURABLE → DISPATCHED → EXECUTED_OR_UNKNOWN → OBSERVED → VERIFIED → FINALIZED. Recovery of UNKNOWN must reconcile rather than equate absence of a journal receipt to absence of an effect.
