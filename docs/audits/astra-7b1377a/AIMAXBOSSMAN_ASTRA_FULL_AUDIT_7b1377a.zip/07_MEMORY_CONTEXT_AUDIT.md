# Memory and context audit

Baseline: 7b1377a4f69336a1ca9d8eb4d432a758e195ae33. Source inspection plus deterministic probes, not production quality measurements.

Memory is fragmented across V3 TaskJournal/FailureMemory/ContextAssembler and V2 Obsidian retrieval/context packs. Both are IMPLEMENTED; uniform authority, isolation, durability and token accounting are UNPROVEN. `bossman-core/bossman_v3/memory/journal.py:92-99` writes destination JSON directly. `failure_memory.py:23-34` treats malformed JSON as empty, then read-modify-overwrites all rows. A crash can destroy memory, and a later record can overwrite corrupt history. Root execution findings cover journal proof defects separately.

V3 `assembler.py:50` estimates from characters and `assemble:114-137` budgets items before final wrapping. Root probe demonstrates budget1 returns reported21. A model tokenizer contract is absent: Cyrillic/CJK, JSON and model switching require fixtures. Security findings cover scope inheritance and PEM redaction; memory content must remain untrusted data, never execution proof.

PROD-001 is independently reproduced in V2 `command-center/bcc/v2/memory/context_pack.py:56-73`: preflight counts unnumbered SOURCE blocks, while final output adds numbered labels and separators. Eight unique ten-character hits fit budget56 but serialize to estimated72. `agent-product/probes.json` is actual execution evidence. This is a framing bug independent of real tokenizer error.

`context_pack.py:29-31` deduplicates by only the first500 normalized characters; distinct tails can be dropped. `memory/service.py:50-60,66-87` silently falls back after rerank/expand errors: useful availability behavior but degraded retrieval is invisible in ContextPack. Source/heading/hash provenance exists; this pack builder does not enforce expiry, contradiction precedence or confidence decay.

Priorities: transactional journal/failure storage with quarantine; scope-before-retrieval; serialized budget guard; trusted policy precedence; explicit stale/conflicting facts; crash/resume without repeat effects. Retrieval precision/recall and long-horizon quality are UNMEASURED. No live embedding or provider benchmark was performed.
