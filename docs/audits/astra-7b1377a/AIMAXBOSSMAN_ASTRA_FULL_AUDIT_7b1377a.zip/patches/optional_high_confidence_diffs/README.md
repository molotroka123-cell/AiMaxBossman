No production patches included. Schema/ownership changes require implementation tests and migration review; this deliverable is the audit and proposed remediation, not an untested rewrite.
