# Observability audit

Baseline7b1377a4f69336a1ca9d8eb4d432a758e195ae33. Hardware sampler, events and mission views are IMPLEMENTED; unified owner visibility across V2/V3/Organization/Fleet remains PARTIAL. `command-center/bcc/metrics.py:24-25,60-75` samples10s and retains24h by default; `v2/context_telemetry.py:15-42` supplies budget/drop/scope/latency fields. Schemas are not measured SLO compliance.

PROD-003: `_nvidia_procs:125-141` collapses failed process query/N/A/no processes; `_nvidia:167` reports0. Baseline deterministic probe returns process0 despite intentionally unavailable query and card use2048MiB. `tests/test_metrics_gpu.py:62-68` even asserts0 for N/A despite its title. Unknown is not measured idle. Preserve query availability and per-process unknownness.

`MetricsSampler.sample:63` synchronously calls read, including two nvidia-smi subprocess queries with5s timeout (`metrics.py:104-116`), within async execution. Worst timeout path can block the event loop approximately10s. This is source-level latency risk, not a measured load result. Use bounded worker/thread sampling with freshness/error provenance.

`mission_console.js:285-328` merges several endpoints and one current run's events; source labels/allSettled help but do not create coherent cross-layer snapshots. No source timestamp/age or Organization/Fleet query is present in this path. Live events and signed receipts alone do not prove retention, tamper resistance or observed effects.

Current V2 task/model/approvals are partly visible. Placement explanation, epoch, restart reconciliation and required-child truth need canonical joins. Verification depth, retry expense, unknown measurement and stale snapshots should be primary states. Production histograms and SLO measurements remain UNMEASURED.
