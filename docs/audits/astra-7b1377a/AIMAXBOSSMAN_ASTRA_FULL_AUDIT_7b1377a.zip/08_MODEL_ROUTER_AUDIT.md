# Model routing audit

Baseline: 7b1377a4f69336a1ca9d8eb4d432a758e195ae33. `command-center/bcc/v2/model_router.py` implements pure filtering/shortlisting/scoring; `features/router.py:259-315` integrates pick_model; OpenRouter provider/catalog paths are implemented. Live provider verification is NOT_RUN in this lane.

Positive controls: falsified capability overrides advertising; cloud-disabled rejects nonlocal candidates; derive_local checks model kind, provider allowlist and endpoint host; shortlist default12 and rejection detail24 bound output; adaptive L3/L4 enables verified requirements (`features/router.py:283-288`).

Ordinary RouteRequest defaults require_verified=False (`model_router.py:118`), so advertised tools are not guaranteed tested. Unknown memory_mb passes available-memory filtering (line163); eligibility does not prove a model fits. Role scores, speed and success_rate are data consumers, not evidence. Average list-price penalty ignores expected task input/output and price freshness.

PROD-002: missing/malformed catalog price becomes0 (`openrouter_ext.py:13-21,48-66`), sync persists it (`openrouter_catalog_service.py:97-98`), and price cap/scoring cannot distinguish unknown from free. Baseline probe confirms missing pricing0/0. Need price-known, finite/nonnegative validation, snapshot age and conservative reservation or rejection.

`engine.py:841-881` tries selected model, agent model and fallback. Cross-path policy enforcement must be correlated with security preflight hooks; pure-router filters alone do not prove fallback privacy. A test accepting tool error or API200 is not live effect verification. Required gates: capability evidence age/version, full context+output/tools budget, per-attempt policy recheck, bounded retries, structured schema validation and independent post-state verifier.
