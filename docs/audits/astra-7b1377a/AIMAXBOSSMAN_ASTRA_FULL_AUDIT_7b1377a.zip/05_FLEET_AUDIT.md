# Fleet audit



Baseline: `7b1377a4f69336a1ca9d8eb4d432a758e195ae33`. Scope: source inspection plus isolated synthetic runtime probes; no remote deployment, real provider spend, destructive action or live fleet crash was performed.



Verdict: useful local control-plane implementation, not production-ready distributed safety. RemoteNodeTransport explicitly raises RemoteTransportUnavailable; node authentication is not implemented. Production UI OrganizationService wires V3ExecutionBridge directly, not FleetExecutionBridge. Therefore fleet unit tests do not prove the product path uses fleet scheduling.



Evidence: `probes.json` and `probes.py` in this report directory; shared root `.audit-work/probes.json`. Root owns the critical journal signature, plan identity, evidence replay and crash-before-journal findings; they are dependencies rather than duplicated IDs here.



Status distinction: deterministic ContractReviewer revalidates supplied evidence and identity; it does not run an independent reviewer model or observe the external world. Local cancellation returns False, timeout_seconds is unused by LocalNodeTransport, and a post-return stale check cannot undo mutations.



## F001 — Lease acquisition violates shared/exclusive exclusion and fences live sharers

Severity **P1**, confidence **high**, evidence **EXECUTED: ../probes.json**.

Location: `bossman-core/bossman_v3/fleet/leases.py:38`, `LeaseManager.acquire / valid`.

Failure: Exclusive acquisition checks only existing exclusive leases; a live shared lease does not prevent an exclusive lease. New shared leases also invalidate older shared tokens. Root executed shared_exclusive_lease_conflict.

Invariant: A valid exclusive owner must have no concurrent shared owner; valid sharers must coexist.

Minimal fix: Reject exclusive requests when any live lease exists and shared requests when an exclusive lease exists; separate shared membership from ownership generations.

Ideal fix: Transactional resource lease state with exclusive generation and explicit shared holders.

Tests: Shared→exclusive and exclusive→shared rejection; shared→shared both valid; TTL/reclaim race.

Effort: M; change risk: medium; dependencies: none.



## F002 — Fencing checked after dispatch, not before resource mutation

Severity **P1**, confidence **high**, evidence **SOURCE_INSPECTED**.

Location: `bossman-core/bossman_v3/fleet/node_agent.py:72`, `LocalNodeTransport.dispatch`.

Failure: The request contains lease_id/fence but dispatch only reads contract/context_policy/agent_id. FleetControlPlane validates at control_plane.py:220 after execute returns. An expired worker can already mutate before its result is refused.

Invariant: Stale workers cannot mutate a fenced resource.

Minimal fix: Pass a lease capability to the execution boundary and validate before every mutating step.

Ideal fix: Sink-enforced fencing and idempotency with monotonic resource generations, cancellation and reconciliation.

Tests: Expire lease while paused immediately before mutation; stale write must fail and fresh owner must succeed.

Effort: L; change risk: high; dependencies: F001; root crash-before-journal finding.



## F003 — Queue completion has no owner or fence check

Severity **P1**, confidence **high**, evidence **EXECUTED: ../probes.json**.

Location: `bossman-core/bossman_v3/fleet/queue.py:77`, `WorkQueue.complete`.

Failure: Worker A loses its claim; B receives claim fence 2; A invokes complete(work_id) and deletes B’s live work. fleet/store.py:224 DELETE filters only work_id.

Invariant: Only the current claim owner and generation can acknowledge/dead-letter/release work.

Minimal fix: Require Claim on complete and CAS delete by work_id, claimed_by and claim_fence; fence release/failure too.

Ideal fix: One transaction for result commit, fenced acknowledgement and durable event.

Tests: Reclaim A→B then stale A complete/release/failure; none may alter B claim.

Effort: M; change risk: medium; dependencies: none.



## F004 — Retry and human-wait decisions leave queue immediately claimable

Severity **P1**, confidence **high**, evidence **EXECUTED BACKOFF: ../probes.json; SOURCE_INSPECTED HUMAN_REQUIRED**.

Location: `bossman-core/bossman_v3/fleet/queue.py:85`, `WorkQueue.on_failure`.

Failure: BACKOFF returns REQUEUE_AFTER_2s but persists no availability timestamp; HUMAN_REQUIRED releases claim then returns WAIT_HUMAN with no blocked state. eligible_for reads all unclaimed rows at line 53.

Invariant: Backoff and human-wait states must control eligibility durably.

Minimal fix: Persist state/not_before/attempt count and exclude waiting-human and future rows; only authenticated approval clears wait.

Ideal fix: Durable retry policy machine with jitter, clock control, max elapsed budget and fenced transitions.

Tests: Immediate claim after timeout denied; clock advance allows; approval remains unclaimable after restart.

Effort: M; change risk: medium; dependencies: none.



## F005 — Unified memory admission double-counts physical headroom

Severity **P1**, confidence **high**, evidence **EXECUTED: probes.json/unified_pool_double_count**.

Location: `bossman-core/bossman_v3/fleet/scheduler.py:43`, `FleetScheduler.reject_reasons`.

Failure: A node with 16 GB unified pool admits 12 GB host plus 12 GB GPU requirements: the probe returns no rejection. Separate comparisons and max(gpu_free,ram_free) reuse one pool.

Invariant: Physical aggregate reserved demand cannot exceed shared available capacity.

Minimal fix: Represent unified pool once; add disjoint host/GPU demands plus safety margin and deduct active reservations atomically.

Ideal fix: Typed resource topology with measured resident model footprint, KV/workspace buffers, pool overlap semantics and fair reservation.

Tests: 16 GB rejects disjoint 12+12; non-unified independent pools pass where appropriate; concurrent reservations cannot oversubscribe.

Effort: M; change risk: medium; dependencies: F001.



## F006 — Minimized contract drops constraints while retaining sensitive step arguments

Severity **P1**, confidence **high**, evidence **EXECUTED: probes.json/minimized_discards_constraints_keeps_step_payload**.

Location: `bossman-core/bossman_v3/fleet/node_agent.py:98`, `_minimized`.

Failure: Minimized transport removes constraints/deadline/dependencies/metadata but retains whole goal, placement and steps; synthetic payload remains in step args. PrivacyRouter public/untrusted selection therefore does not prove payload minimization.

Invariant: Minimization must preserve enforceable restrictions and remove non-authorized data.

Minimal fix: Preserve policy/security envelope and allowlist only transport-required payload fields; reject minimization when action needs undisclosed sensitive data.

Ideal fix: Content-classified immutable envelope with separate executable policy and encrypted artifact capabilities.

Tests: Nested sensitive steps/goal/placement scrub or reject; constraints survive; minimized contract cannot expand permissions.

Effort: M; change risk: medium; dependencies: none.

