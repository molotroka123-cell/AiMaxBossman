# Astra architecture proposals

These are proposed repository-specific extensions, not implemented features or claims of universal novelty. Existing Fleet twin, context guardian, signed evidence and overlay are reused; adding duplicate replacement frameworks is rejected. Ranking is editorial, with explicit costs and dependencies.

## IDEA-01: Obligation compiler

Problem: Current kind/target evidence matching loses expected values and action identity (ASTRA-003/004).

Why current system does not solve it: Current kind/target evidence matching loses expected values and action identity (ASTRA-003/004). Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Compile each requested effect to a canonical predicate, resource identity and verifier-specific proof schema.

Data model: `obligation_id, action_digest, resource_uri, predicate_hash, verifier_version, freshness_policy`.

Control flow: Plan creates obligations; policy approves their digest; sink executes; observer emits typed values; finalizer discharges all required obligations.

Security model: Only verifier role can issue discharge; proof is bound to task/attempt and cannot authorize future effects.

Failure modes: Over-specific predicates reject legitimate changes; compiler/schema upgrades can invalidate old evidence.

Test plan: Mutate one field at a time and require rejection; property tests compare compiler and verifier across file/db/browser.

Cost impact: Extra hashing negligible; fewer expensive reruns after ambiguous completion.

Expected benefit: Eliminates multiple mismatched truth layers; explicit reuse of immutable artifact evidence.

Implementation difficulty: HIGH. Dependencies: ASTRA-003, ASTRA-004; typed expected-state adapters.

Migration plan: Add shadow obligations alongside existing gates, compare decisions, migrate active tasks only at checkpoint.

## IDEA-02: Effect uncertainty escrow

Problem: No durable STARTED state distinguishes an absent effect from lost acknowledgment (ASTRA-005).

Why current system does not solve it: No durable STARTED state distinguishes an absent effect from lost acknowledgment (ASTRA-005). Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Keep ambiguous effects in a durable UNKNOWN exposure record; reconcile with sink before retry.

Data model: `effect_key, attempt_epoch, intent_hash, delivery_state, observed_receipt, reconciliation_deadline`.

Control flow: Reserve effect identity before dispatch; record sink ACK; after restart probe sink; replay only if absence is proven or idempotency is enforced.

Security model: Only original approved payload may be retried; escalation cannot expand scopes.

Failure modes: Sink has no lookup; an old effect appears late; observation itself times out.

Test plan: Crash at every barrier and require <=1 effect; delayed ACK test must remain blocked.

Cost impact: Small storage cost; cuts duplicates and repeated model diagnosis.

Expected benefit: Makes exactly-once claims conditional on sink capabilities, rather than journal optimism.

Implementation difficulty: HIGH. Dependencies: sink idempotency interfaces; durable attempt ownership.

Migration plan: Wrap one file writer first; irreversible remote tools remain manual reconciliation until supported.

## IDEA-03: Privacy lineage certificate

Problem: Placement trust and provider egress policy are different decisions.

Why current system does not solve it: Placement trust and provider egress policy are different decisions. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Propagate non-relaxing data-classification lineage across task, context, node and model dispatch.

Data model: `lineage_id, parent_labels, effective_privacy, approved_egress, transform_hash, policy_epoch`.

Control flow: Assembler joins labels; scheduler selects node; provider validates same certificate immediately before network call.

Security model: Only owner-authorized declassification can lower privacy; model claims cannot.

Failure modes: Missing certificate, stale policy epoch, minimizer leaks nested fields.

Test plan: Private task on local cloud-backed node must make zero network calls; nested secrets and label mutation fixtures.

Cost impact: Cheap validation; may block formerly cheap cloud fallback.

Expected benefit: A single explicit reason explains privacy blocks across all layers.

Implementation difficulty: MEDIUM. Dependencies: privacy router; context provenance; provider adapter.

Migration plan: Log lineage in shadow mode for public tasks, enforce mandatory certificate for private tasks first.

## IDEA-04: Review independence graph

Problem: Distinct reviewer labels do not alone demonstrate independent checks; risk slot may never execute.

Why current system does not solve it: Distinct reviewer labels do not alone demonstrate independent checks; risk slot may never execute. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Record reviews as a graph of principals, canonical models, shared contexts and verifier implementations; enforce role-specific veto obligations.

Data model: `review_id, obligation_id, principal_id, model_fingerprint, verifier_family, input_evidence_hash, dependencies`.

Control flow: Team formation declares review obligations; each role supplies own verdict; finalizer requires the independent set.

Security model: Verified principal identity rather than human: or role strings; reviewers cannot manufacture execution evidence.

Failure modes: Same vendor aliases; reviewers share poisoned evidence; unreachable risk reviewer.

Test plan: Alias graph and veto tests, plus absent-risk-verdict must block.

Cost impact: Some extra review cost; suppress redundant same-evidence reviews.

Expected benefit: Pays for independent checks with measurable diversity, not agent count.

Implementation difficulty: MEDIUM. Dependencies: canonical model catalog; Organization review ports.

Migration plan: Start deterministic validation labels; require independent observation for highest-risk actions.

## IDEA-05: Budget exposure ledger

Problem: Reserve/release cannot represent late provider bills or irreversible work with unknown outcome.

Why current system does not solve it: Reserve/release cannot represent late provider bills or irreversible work with unknown outcome. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Track settled, reserved and uncertain liability separately with atomic hierarchical admission.

Data model: `reservation_id, parent_scope, attempt_id, estimated_max, settled_actual, exposure_status, price_snapshot`.

Control flow: Reserve worst-case attempt plus review envelope; timeout transfers to uncertain exposure; reconcile invoice by provider request ID.

Security model: Caps enforced transactionally; owner authorizes increased exposure; negative/NaN values rejected.

Failure modes: Provider lacks usage ID; price moves; overlapping retry bills.

Test plan: Concurrent last-dollar reservation; delayed usage, duplicate settlement and crash replay.

Cost impact: Prevents hidden retry spend; conservative exposure reduces concurrency until reconciliation.

Expected benefit: Owner sees maximum plausible outstanding cost rather than a falsely low settled total.

Implementation difficulty: HIGH. Dependencies: treasury atomic store; usage correlation.

Migration plan: Introduce liability alongside current spent counters; reconcile open attempts before enabling enforcement.

## IDEA-06: Recovery state diff

Problem: Resume currently assumes that stored finished steps remain valid after world changes.

Why current system does not solve it: Resume currently assumes that stored finished steps remain valid after world changes. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Before resuming, show machine-computed differences between checkpoint assumptions and fresh selected state.

Data model: `checkpoint_id, assumption_hashes, observed_versions, invalidated_obligations, proposed_resume_step`.

Control flow: Sample only dependencies of unfinished work; invalidate affected proofs; propose bounded replan with preserved approvals only for unchanged payloads.

Security model: Diff stores redacted identifiers; changes cannot broaden approval scope.

Failure modes: External state changes after diff; expensive or unavailable observations.

Test plan: Change one external dependency while offline; ensure unrelated proof remains reusable and changed proof invalidated.

Cost impact: Avoids full context rebuild; bounded observations add latency.

Expected benefit: Fast model-independent handoff with explicit uncertainty.

Implementation difficulty: MEDIUM. Dependencies: obligation compiler; journal migration.

Migration plan: Shadow diff against completed local file missions, then enable for restart flows.

## IDEA-07: Counterfactual placement replay

Problem: Scheduler explanations show current weights but not whether a different placement would have been cheaper or safer.

Why current system does not solve it: Scheduler explanations show current weights but not whether a different placement would have been cheaper or safer. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Persist normalized eligibility inputs and replay alternative ranking policies offline without dispatch.

Data model: `decision_id, node_snapshot_hash, requirement_hash, policy_version, eligible_set, observed_outcome`.

Control flow: Record decision; offline twin replays candidates; compare wait/cost/failure predictions; owner promotes measured policy version.

Security model: Replay cannot call tools or alter live placement; private snapshots stay local.

Failure modes: Counterfactual outcome bias; stale node metrics; benchmark overfitting.

Test plan: Golden eligibility masks, private-node exclusion and replay determinism; holdout workload comparison.

Cost impact: Offline CPU only; improves model warmth/locality choices before cloud trials.

Expected benefit: Evidence-driven scheduler tuning with a reversible policy rollout.

Implementation difficulty: MEDIUM. Dependencies: Fleet twin; flight recorder; truthful utilization data.

Migration plan: Add replay records only; keep current scheduler until holdout gain is demonstrated.

## IDEA-08: Shared-memory reservation envelope

Problem: Unified RAM and GPU demands may pass separate checks while overcommitting one physical pool.

Why current system does not solve it: Unified RAM and GPU demands may pass separate checks while overcommitting one physical pool. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Represent physical pools and allocations as resource constraints, including OS reserve, KV cache and transient load buffers.

Data model: `pool_id, capacity_bytes, reserved_bytes, residency_id, peak_estimate, uncertainty_margin`.

Control flow: Model admission estimates peak demand; atomic allocation claims shared pool; runtime pressure adjusts confidence and blocks new starts.

Security model: Node reports authenticated in future transport; cannot advertise capacity as permission to send private data.

Failure modes: Fragmentation, unknown peak, driver allocations and warm-model eviction races.

Test plan: RAM+GPU fit individually but not jointly; cold load burst; simultaneous KV growth; no hardware speed claims from synthetic tests.

Cost impact: Better packing but conservative margins may reduce throughput.

Expected benefit: Makes future 128GB acceptance based on measurements rather than a product name.

Implementation difficulty: HIGH. Dependencies: Fleet reservation store; backend memory telemetry.

Migration plan: Model current discrete pools first; add unified pool profile behind a hardware-tested flag.

## IDEA-09: Truth completeness ledger

Problem: Passive scoring can award maximum sub-scores for absent events (ASTRA-006).

Why current system does not solve it: Passive scoring can award maximum sub-scores for absent events (ASTRA-006). Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Publish coverage and missing evidence as first-class records before calculating score.

Data model: `mission_id, required_dimensions, event_sequence_range, missing_proofs, source_sha, attestation_level`.

Control flow: Each stage declares expected proof events; auditor checks gaps; scorer excludes unexercised dimensions and displays confidence bounds.

Security model: Append-only signed checkpoint; producer events cannot attest themselves without independent artifact linkage.

Failure modes: Lost events, duplicate sequence, old signed report copied to new SHA.

Test plan: Delete/reorder events and require UNPROVEN; empty checks and changed Git HEAD cannot inherit score.

Cost impact: Small event bookkeeping; avoids wasteful benchmark claims and reruns.

Expected benefit: Separates diagnostic scores, tested behavior and attested deployments visibly.

Implementation difficulty: MEDIUM. Dependencies: overlay collector; CI exact-SHA inventory.

Migration plan: Add coverage sidecar and keep old diagnostic score labeled non-authoritative during migration.

## IDEA-10: Scoped retrieval handles

Problem: Caller-selected include_parents accepts any parent-shaped department/project string.

Why current system does not solve it: Caller-selected include_parents accepts any parent-shaped department/project string. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Mint bounded retrieval handles from verified organizational ancestry and purpose, not arbitrary scope names.

Data model: `handle_id, principal, allowed_scopes, purpose, ttl, max_tokens, export_policy_epoch`.

Control flow: Mission start derives ancestry; assembler redeems handle; retrieval records which facts were actually consumed.

Security model: Handle validated in server context; no capability-bearing secret is placed in model prompts.

Failure modes: Stale department transfer; cached handle outlives revoked scope; poisoned fact within allowed scope.

Test plan: Sibling parent spoof, revoked scope, expired handle and allowed explicit export.

Cost impact: Less irrelevant context and fewer accidental cross-project reads.

Expected benefit: Measurable retrieval precision with enforceable scope boundaries.

Implementation difficulty: MEDIUM. Dependencies: ScopedKnowledge; organization identity.

Migration plan: Keep internal scope API but require handle at agent-facing reads; migrate callers incrementally.

## IDEA-11: Causal cost attribution

Problem: Costs, model usage and verified outcomes span V2 runs, V3 work and Fleet attempts without one economic unit.

Why current system does not solve it: Costs, model usage and verified outcomes span V2 runs, V3 work and Fleet attempts without one economic unit. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Join usage to causal attempt and discharged obligation; attribute retries/reviews and cache work separately.

Data model: `causal_attempt_id, parent_attempt, provider_request_id, token_usage, cache_class, obligation_ids, billing_state`.

Control flow: Propagate ID at dispatch; ingest actual usage; finalize metrics only when proof and billing completeness are known.

Security model: Logs contain IDs and quantities, not prompt text or credentials.

Failure modes: Missing usage reports; many obligations share one call; denominator zero.

Test plan: Reconcile invoices to attempts; prevent double-count on retries; null ratio when no verified success.

Cost impact: Enables bounded optimizations of tokens per verified success instead of cheapest token price.

Expected benefit: Comparable model/team decisions across mission types and local/cloud execution.

Implementation difficulty: MEDIUM. Dependencies: exposure ledger; telemetry propagation.

Migration plan: Add IDs without changing routing; report coverage before displaying ratios.

## IDEA-12: Acceptance capsules

Problem: Existing acceptance ZIPs can drift from current code and hardware without an executable evidence contract.

Why current system does not solve it: Existing acceptance ZIPs can drift from current code and hardware without an executable evidence contract. Existing components cover parts of the flow but do not enforce this proposed end-to-end contract.

Design: Package a minimal workload, expected invariants, environment fingerprint and replay instructions with each acceptance claim.

Data model: `capsule_id, source_sha, workload_hash, required_capabilities, commands, expected_oracles, run_records`.

Control flow: CI generates capsule; owner hardware runs it; result artifact is linked to exact environment and SHA; moved branch requires new run.

Security model: Capsules contain no credentials; live effect fixtures default disabled; signed result is distinct from actual proof artifacts.

Failure modes: Stale dependencies; environment differences; fake success logs.

Test plan: Re-run on Linux/Windows; mutate expected post-state; reject reports with missing artifacts.

Cost impact: Reduces repeated manual setup and ambiguous acceptance discussions.

Expected benefit: Portable owner acceptance for OpenRouter now and measured local hardware later.

Implementation difficulty: MEDIUM. Dependencies: focused test harness; artifact manifests; SHA-pinned dependency evidence.

Migration plan: Create read-only and local-file capsule first; promote only after repeatable run on target host.
