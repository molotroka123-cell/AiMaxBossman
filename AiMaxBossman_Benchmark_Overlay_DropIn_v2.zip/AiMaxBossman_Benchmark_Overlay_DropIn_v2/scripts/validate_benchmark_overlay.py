from pathlib import Path
import compileall, os, subprocess, sys, re

ROOT = Path(__file__).resolve().parents[1]
PROD = ROOT/"production"/"bossman-core"
TESTS = ROOT/"tests"/"bossman-core"/"tests"/"benchmark_overlay"

assert compileall.compile_dir(str(PROD), quiet=1)

patterns = [
    re.compile(r"(?i)api[_-]?key\s*[:=]\s*['\"][A-Za-z0-9_\-]{16,}"),
    re.compile(r"(?i)secret\s*[:=]\s*['\"][A-Za-z0-9_\-]{16,}"),
]
for p in ROOT.rglob("*"):
    if p.is_file() and p.suffix in {".py",".md",".json",".txt"}:
        t=p.read_text(encoding="utf-8",errors="ignore")
        if any(rx.search(t) for rx in patterns):
            raise SystemExit(f"secret-like pattern in {p}")

env=dict(os.environ)
env["PYTHONPATH"]=str(PROD)+os.pathsep+env.get("PYTHONPATH","")
cp=subprocess.run([sys.executable,"-m","pytest","-q",str(TESTS)],env=env)
if cp.returncode:
    raise SystemExit(cp.returncode)
print("BENCHMARK_OVERLAY_VALIDATION=PASS")
