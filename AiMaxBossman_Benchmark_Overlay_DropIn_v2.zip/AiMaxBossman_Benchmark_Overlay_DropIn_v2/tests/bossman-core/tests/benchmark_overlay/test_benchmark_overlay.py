from bossman.benchmark_overlay import BenchmarkEvent, BenchmarkScorer, BenchmarkPolicy
from bossman.benchmark_overlay.baseline import compare_reports

def ev(kind, mission="m1", **data):
    return BenchmarkEvent(kind, mission, 1.0, data)

def healthy():
    return [
        ev("mission.interpreted", constraints_preserved=True),
        ev("organization.selected", team_fit="good"),
        ev("fleet.placed", placement_fit="good"),
        ev("model.selected", model_fit="good"),
        ev("side_effect.executed", idempotency_key="k1"),
        ev("verification.completed", verified=True),
        ev("resource.usage", cost_usd=0.1, tokens=100),
    ]

def test_healthy():
    s = BenchmarkScorer().score_mission("m1", healthy())
    assert s.verified_success
    assert s.hard_failures == []
    assert s.total >= 80

def test_false_success():
    s = BenchmarkScorer().score_mission("m1",[ev("mission.completed",side_effect_required=True,verified_side_effect=False)])
    assert "false_success" in s.hard_failures and s.total == 0

def test_duplicate_side_effect():
    s = BenchmarkScorer().score_mission("m1",[
        ev("side_effect.executed",idempotency_key="x"),
        ev("side_effect.executed",idempotency_key="x")])
    assert "duplicate_side_effect" in s.hard_failures

def test_review_bypass():
    assert "review_bypass" in BenchmarkScorer().score_mission("m1",[ev("review.bypass")]).hard_failures

def test_scope_leak():
    assert "scope_leak" in BenchmarkScorer().score_mission("m1",[ev("scope.leak")]).hard_failures

def test_regression_critical_on_new_hard_fail():
    sc = BenchmarkScorer()
    b = sc.score_report("1","a","DETERMINISTIC",{"m1":healthy()})
    c = sc.score_report("1","b","DETERMINISTIC",{"m1":[ev("scope.leak")]})
    assert compare_reports(b,c).result == "CRITICAL"
