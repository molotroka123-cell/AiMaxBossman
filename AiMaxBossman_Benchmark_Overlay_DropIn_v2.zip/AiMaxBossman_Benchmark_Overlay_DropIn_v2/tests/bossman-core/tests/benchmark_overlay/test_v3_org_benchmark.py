import pytest
from bossman.benchmark_overlay import OrgBenchmarkSuite

@pytest.mark.asyncio
async def test_compound_failure_5_children_blocks_parent():
    suite = OrgBenchmarkSuite()
    async def scenario():
        return {
            "children": [
                {"id":"c1","verified":True},
                {"id":"c2","verified":True},
                {"id":"c3","verified":False},
                {"id":"c4","verified":True},
                {"id":"c5","verified":True},
            ],
            "parent_completed": False,
        }
    r = await suite.run_compound_failure_benchmark(scenario)
    assert r.passed

@pytest.mark.asyncio
async def test_compound_failure_detects_illegal_parent_success():
    suite = OrgBenchmarkSuite()
    async def scenario():
        return {
            "children":[{"verified":True},{"verified":False},{"verified":True},{"verified":True},{"verified":True}],
            "parent_completed": True,
        }
    assert not (await suite.run_compound_failure_benchmark(scenario)).passed

@pytest.mark.asyncio
async def test_cross_department_leak_probe_fail_closed():
    suite = OrgBenchmarkSuite()
    async def probe():
        return {"blocked":True,"leaked":False,"source":"research","target":"trading"}
    assert (await suite.run_cross_department_leak_probe(probe)).passed

@pytest.mark.asyncio
async def test_long_horizon_resume_no_duplicate():
    suite = OrgBenchmarkSuite()
    async def scenario():
        return {"total_steps":10,"crash_after_step":7,"completed_steps":10,"resumed":True,"duplicate_side_effect_count":0}
    assert (await suite.run_long_horizon_resume_benchmark(scenario)).passed

@pytest.mark.asyncio
async def test_fleet_topology_stress_tags_not_manual_ip():
    suite = OrgBenchmarkSuite()
    async def scenario():
        return {
            "capability_tags_respected":True,
            "no_manual_ip_routing":True,
            "privacy_violation":False,
            "source_node":"laptop-8gb",
            "target_node":"ai-max-128gb",
        }
    assert (await suite.run_fleet_topology_stress(scenario)).passed

def test_token_value_metric():
    suite = OrgBenchmarkSuite()
    assert suite.token_value_metric(quality=0.9,reliability=0.95,cost=0.1) == 8.55
    assert suite.token_value_metric(quality=1,reliability=1,cost=0) is None
