# AiMaxBossman Benchmark Overlay Drop-In v2

Adds a passive V3 benchmark overlay plus deterministic Organization/Fleet stress scenarios and `test_v3_org_benchmark.py`.

Designed for the current 8-agent integration swarm.
