import json
from pathlib import Path

def write_reports(report, output_dir):
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    jp = out/"benchmark-report.json"
    mp = out/"benchmark-report.md"
    data = report.to_dict()
    jp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    a = report.aggregate
    lines = [
        "# Bossman Benchmark Report","",
        f"- Git SHA: `{report.git_sha}`",
        f"- Mode: `{report.mode}`",
        f"- Total score: **{a.get('total_score',0)}/100**",
        f"- Hard failures: `{', '.join(a.get('hard_failures') or []) or 'none'}`",
    ]
    mp.write_text("\n".join(lines), encoding="utf-8")
    return jp, mp
