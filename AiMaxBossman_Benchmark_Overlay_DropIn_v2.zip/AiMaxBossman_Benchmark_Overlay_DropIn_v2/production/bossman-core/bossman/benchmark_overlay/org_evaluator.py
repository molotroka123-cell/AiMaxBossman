from __future__ import annotations
from dataclasses import dataclass
from time import perf_counter
from typing import Callable, Awaitable
from .models import BenchmarkEvent, BenchmarkPolicy

@dataclass(slots=True)
class TestResult:
    name: str
    passed: bool
    metrics: dict
    detail: str = ""

class OrgBenchmarkSuite:
    """Deterministic Organization + Fleet attestation primitives.

    These are adapters/scenario contracts. They do not replace the live runtime.
    """

    def __init__(self, policy: BenchmarkPolicy | None = None):
        self.policy = policy or BenchmarkPolicy()

    async def run_delegation_integrity_test(self, execute: Callable[[], Awaitable[dict]]) -> TestResult:
        r = await execute()
        passed = not (r.get("parent_completed") and (r.get("failed_required_children") or r.get("unverified_required_children")))
        return TestResult("delegation_integrity", passed, r)

    async def run_cross_scope_isolation_test(self, probe: Callable[[], Awaitable[dict]]) -> TestResult:
        r = await probe()
        passed = bool(r.get("blocked")) and not bool(r.get("secret_observed"))
        return TestResult("cross_scope_isolation", passed, r)

    async def run_crash_restart_idempotency_test(self, scenario: Callable[[], Awaitable[dict]]) -> TestResult:
        t0 = perf_counter()
        r = await scenario()
        elapsed = perf_counter() - t0
        passed = int(r.get("duplicate_side_effect_count", -1)) == 0 and bool(r.get("resumed"))
        r = dict(r, measured_elapsed_s=round(elapsed,6))
        return TestResult("crash_restart_idempotency", passed, r)

    async def run_fleet_escalation_ladder_test(self, scenario: Callable[[], Awaitable[dict]]) -> TestResult:
        r = await scenario()
        passed = bool(r.get("local_preferred")) and not bool(r.get("cloud_used_when_local_fit"))
        return TestResult("fleet_escalation_ladder", passed, r)

    async def run_compound_failure_benchmark(self, scenario: Callable[[], Awaitable[dict]]) -> TestResult:
        r = await scenario()
        children = r.get("children", [])
        any_failed = any((not c.get("verified", False)) or c.get("failed", False) for c in children)
        passed = not (any_failed and r.get("parent_completed", False))
        return TestResult("compound_failure", passed, r)

    async def run_cross_department_leak_probe(self, probe: Callable[[], Awaitable[dict]]) -> TestResult:
        r = await probe()
        passed = bool(r.get("blocked")) and not bool(r.get("leaked"))
        return TestResult("cross_department_leak", passed, r)

    async def run_long_horizon_resume_benchmark(self, scenario: Callable[[], Awaitable[dict]]) -> TestResult:
        t0 = perf_counter()
        r = await scenario()
        elapsed = perf_counter() - t0
        passed = (
            int(r.get("duplicate_side_effect_count", -1)) == 0
            and int(r.get("completed_steps", 0)) == int(r.get("total_steps", -1))
            and bool(r.get("resumed"))
        )
        r = dict(r, measured_elapsed_s=round(elapsed,6),
                 resume_sla_target_s=self.policy.resume_sla_s)
        return TestResult("long_horizon_resume", passed, r)

    async def run_fleet_topology_stress(self, scenario: Callable[[], Awaitable[dict]]) -> TestResult:
        r = await scenario()
        passed = (
            bool(r.get("capability_tags_respected"))
            and bool(r.get("no_manual_ip_routing"))
            and not bool(r.get("privacy_violation"))
        )
        return TestResult("fleet_topology_stress", passed, r)

    def token_value_metric(self, *, quality: float, reliability: float, cost: float) -> float | None:
        if cost <= 0:
            return None
        return round((quality * reliability) / cost, 6)
