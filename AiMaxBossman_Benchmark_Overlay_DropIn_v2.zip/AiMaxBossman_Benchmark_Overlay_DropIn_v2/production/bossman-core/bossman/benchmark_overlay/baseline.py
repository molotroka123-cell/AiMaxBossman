from dataclasses import dataclass
from .models import BenchmarkReport, BenchmarkPolicy

@dataclass(slots=True)
class RegressionResult:
    baseline_sha: str
    current_sha: str
    score_delta: float
    hard_fail_delta: int
    result: str

def compare_reports(baseline: BenchmarkReport, current: BenchmarkReport, policy=None):
    policy = policy or BenchmarkPolicy()
    b = float(baseline.aggregate.get("total_score",0))
    c = float(current.aggregate.get("total_score",0))
    delta = round(c-b,2)
    hd = len(current.aggregate.get("hard_failures") or []) - len(baseline.aggregate.get("hard_failures") or [])
    if hd > 0 or delta < -policy.critical_regression_threshold:
        r = "CRITICAL"
    elif delta < 0:
        r = "REGRESSION"
    else:
        r = "PASS"
    return RegressionResult(baseline.git_sha,current.git_sha,delta,hd,r)
