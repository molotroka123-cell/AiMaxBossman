from __future__ import annotations
from collections import defaultdict
from .models import BenchmarkEvent

class BenchmarkCollector:
    """Passive collector. Never changes mission state and is never execution proof."""
    def __init__(self):
        self._events: list[BenchmarkEvent] = []

    def record(self, event: BenchmarkEvent) -> None:
        self._events.append(event)

    def by_mission(self) -> dict[str, list[BenchmarkEvent]]:
        out = defaultdict(list)
        for e in self._events:
            out[e.mission_id].append(e)
        return dict(out)

    def all(self) -> list[BenchmarkEvent]:
        return list(self._events)
