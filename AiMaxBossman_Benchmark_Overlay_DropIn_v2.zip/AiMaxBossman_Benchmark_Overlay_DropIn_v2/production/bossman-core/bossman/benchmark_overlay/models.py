from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass(slots=True)
class BenchmarkEvent:
    kind: str
    mission_id: str
    ts: float
    data: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class BenchmarkPolicy:
    stale_evidence_max_age_s: float = 300.0
    critical_regression_threshold: float = 5.0
    resume_sla_s: float = 1.5

@dataclass(slots=True)
class MissionScore:
    mission_id: str
    scores: dict[str, float]
    hard_failures: list[str]
    verified_success: bool
    metrics: dict[str, float] = field(default_factory=dict)

    @property
    def total(self) -> float:
        if self.hard_failures:
            return 0.0
        vals = list(self.scores.values())
        return round((sum(vals) / max(len(vals), 1)) * 10.0, 2)

@dataclass(slots=True)
class BenchmarkReport:
    benchmark_version: str
    git_sha: str
    mode: str
    mission_scores: list[MissionScore]
    aggregate: dict[str, Any]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
