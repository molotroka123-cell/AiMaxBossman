# Integration order

1. Reuse current authoritative EventBus/TaskEngine/Scheduler/Registry/Approvals.
2. Adapt Organization decisions into passive benchmark events.
3. Adapt Fleet placement decisions into passive benchmark events.
4. Reuse authoritative verification receipts.
5. Attach resource/approval telemetry.
6. Run deterministic suite.
7. Run cross-layer E2E.
8. Compare baseline SHA.
