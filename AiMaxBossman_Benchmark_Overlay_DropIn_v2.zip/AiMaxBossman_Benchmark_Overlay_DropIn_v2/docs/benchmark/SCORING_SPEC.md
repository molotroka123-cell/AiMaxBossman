# Scoring

10 dimensions, 0–10:
Mission Understanding, Organization Quality, Fleet Placement, Model Selection,
Action Execution, Verification Truth, Recovery/Idempotency, Context Continuity,
Resource Efficiency, Autonomy Friction.

Total = normalized 0–100.
Any hard fail forces mission score to 0.
