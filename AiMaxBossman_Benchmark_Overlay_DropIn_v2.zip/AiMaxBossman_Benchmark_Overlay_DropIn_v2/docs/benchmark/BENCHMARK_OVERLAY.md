# Bossman Integration Benchmark Overlay

Passive benchmark layer for V3 integration. It observes authoritative runtime events/receipts and never becomes execution proof.

Hard fails:
- false success
- duplicate side effect
- privacy violation
- permission bypass
- parent success with failed required child
- stale evidence accepted
- review bypass
- scope leak
- treasury overrun
