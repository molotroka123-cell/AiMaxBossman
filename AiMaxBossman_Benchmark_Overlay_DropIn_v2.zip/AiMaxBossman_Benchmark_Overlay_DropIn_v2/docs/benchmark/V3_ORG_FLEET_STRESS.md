# V3 Organization + Fleet Stress Extensions

Required deterministic scenarios:

1. CompoundFailureBenchmark
   - 5+ required children
   - any failed/unverified required child blocks parent completion.

2. CrossDepartmentLeakProbe
   - Research attempts to read Trading-only data.
   - fail closed, no prompt leakage.

3. LongHorizonResumeBenchmark
   - 10-step mission
   - crash after step 7
   - resume from first safe incomplete step
   - DUPLICATE_SIDE_EFFECT_COUNT=0.

4. FleetTopologyStress
   - heterogeneous laptop / AI MAX / cloud node descriptors
   - placement by capability/resource/privacy tags
   - no hard-coded IP/port routing.

5. TokenValueMetric
   - Quality × Reliability / Cost
   - report N/A for zero monetary cost rather than divide by zero.

A live 1.5s recovery SLA must only be claimed when measured against the actual integrated runtime.
