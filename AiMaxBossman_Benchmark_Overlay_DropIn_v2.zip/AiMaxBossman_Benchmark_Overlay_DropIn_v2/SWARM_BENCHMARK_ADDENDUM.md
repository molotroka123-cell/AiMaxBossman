AIMAXBOSSMAN — 8-AGENT SWARM BENCHMARK CORRECTION
MISSION_ADDENDUM_ID: BOSS-SWARM-BENCHMARK-002

Use the provided Benchmark Overlay v2 during the current cross-layer integration mission.

Agent 7 = E2E + BENCHMARK ENGINEER.
Agent 8 = sole integration/merge authority.

The benchmark is PASSIVE:
authoritative runtime -> thin adapters -> collector -> scorer -> hard-fail gate -> report.

Never let benchmark events become execution proof.

Add these mandatory V3 stress evaluations:
- CompoundFailureBenchmark with 5+ required children
- CrossDepartmentLeakProbe
- LongHorizonResumeBenchmark (crash at step 7/10, duplicate side effect count 0)
- FleetTopologyStress for heterogeneous nodes and capability-tag placement
- TokenValueMetric = Quality × Reliability / Cost

Required hard fails:
FALSE_SUCCESS
DUPLICATE_SIDE_EFFECT
PRIVACY_VIOLATION
PERMISSION_BYPASS
PARENT_SUCCESS_WITH_FAILED_REQUIRED_CHILD
STALE_EVIDENCE_ACCEPTED
REVIEW_BYPASS
SCOPE_LEAK
TREASURY_OVERRUN

Do not claim:
- 9+/10 maturity,
- <=1.5s real recovery,
- live fleet readiness,
unless the integrated repository actually executes and measures those cases.

Merge gate:
TESTS_GREEN
AND KNOWN_P0 == 0
AND HARD_FAILS == 0
AND DUPLICATE_SIDE_EFFECT_COUNT == 0
AND BENCHMARK_REGRESSION != CRITICAL

Final additions:
BENCHMARK_OVERLAY=
COMPOUND_FAILURE_BENCHMARK=
CROSS_DEPARTMENT_LEAK_PROBE=
LONG_HORIZON_RESUME=
FLEET_TOPOLOGY_STRESS=
TOKEN_VALUE_METRIC=
RECOVERY_TIME_MEASURED_S=
RECOVERY_SLA_1_5S=
TOTAL_SCORE=
HARD_FAILS=
BASELINE_SHA=
CURRENT_SHA=
REGRESSION_RESULT=

Repository truth wins over drop-in paths.
