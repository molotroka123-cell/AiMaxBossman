# CLAUDE OPUS 5 — BOSSMAN PROMPT CACHE INTEGRATION
Work from CURRENT REMOTE HEAD.
1. git fetch --all --prune and verify origin/claude/bossman-control-v03-43igbk.
2. Read existing Stage3 Gateway, Cost Governor and telemetry. Do not create a second Gateway.
3. Integrate prompt_cache.py into the existing OpenRouter/cloud request path.
4. For anthropic/claude-opus-5 send stable session_id plus cache_control. Default 5m for dense loops; configurable 1h for human-in-loop sessions.
5. Stable prefix first: system/policy, tools/schemas, role, stable project context. Dynamic tail last.
6. Never persist prompt cache contents/secrets locally. Store only numeric cache telemetry.
7. Dashboard: Cache Hit %, Cached Tokens, Cache Write Tokens, Saved $, Session Affinity, TTL, Provider, miss reason.
8. Preserve cloud_policy, Cost Governor reserve->call->commit/release, circuit breaker, failover, auth and streaming.
9. Required: CACHE_STABLE_SESSION_ID, ANTHROPIC_CACHE_CONTROL, CACHE_1H_TTL, UNSUPPORTED_PROVIDER_FAIL_OPEN, CACHE_USAGE_TELEMETRY, COST_GOVERNOR_NOT_BYPASSED, CLOUD_POLICY_NEVER_NOT_BYPASSED, STREAMING_NOT_BROKEN.
10. Run targeted Gateway + Cost Governor tests, secret scan and affected regression. Commit small, push without force, report remote HEAD. STOP.
