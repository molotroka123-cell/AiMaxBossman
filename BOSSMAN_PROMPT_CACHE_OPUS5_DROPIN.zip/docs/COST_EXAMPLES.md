# Claude Opus 5 planning
OpenRouter currently lists base pricing: input $5/M, output $25/M, cache read $0.50/M.
Example: 10 turns reuse 40k stable tokens, add 4k fresh input/turn, output 3k/turn.
No cache: 440k input=$2.20; 30k output=$0.75; ~$2.95.
Simplified warm-cache case (before exact write premiums): first 40k fresh + 9*40k cached + 40k dynamic ~= $0.58 input; +$0.75 output ~= $1.33.
Output is expensive: instruct Opus to edit/test and report concisely rather than narrate.
