# Latest useful dashboard additions for API economics
1. Cache Hit Ratio.
2. Effective Input Cost after cache discount.
3. Saved $ vs fresh-input baseline.
4. Cache Write vs Cache Read.
5. Session Affinity / provider drift warning.
6. TTL state (5m/1h/cold).
7. Model economics: input/output/cache-read.
8. Cost per task/session/agent.
9. Cache miss hints: short prefix, expiry, unstable prefix, provider drift.
10. Prefix stability score based on hashes/metadata only; never persist secrets or raw cached content.
