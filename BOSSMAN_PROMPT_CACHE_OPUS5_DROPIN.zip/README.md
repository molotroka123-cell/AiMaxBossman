# Bossman Prompt Cache / Claude Opus 5 Drop-in
Drop-in helper for the existing Stage3 Gateway. It adds stable OpenRouter session affinity, Anthropic cache_control (5m/1h), optional explicit breakpoints, and cache telemetry normalization. It stores no prompt/cache contents locally.

Integration: copy prompt_cache.py into bossman-core/bossman/gateway/. Immediately before the existing OpenRouter/cloud json_request or stream_request call, run prepare_openrouter_payload() and send its returned payload. Preserve Cost Governor reserve -> call -> commit/release, cloud_policy, circuit breaker and failover. After responses, feed only numeric extract_cache_usage() data to existing telemetry.

Keep stable content first: system policy -> tools/schemas -> agent role -> stable repo context. Put timestamps, current diff, diagnostics, tool results and latest task last.
