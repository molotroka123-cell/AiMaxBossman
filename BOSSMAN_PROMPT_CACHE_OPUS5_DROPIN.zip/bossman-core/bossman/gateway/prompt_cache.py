from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Mapping
import copy

@dataclass(frozen=True, slots=True)
class PromptCachePolicy:
    enabled: bool=True
    ttl: str="5m"
    automatic: bool=True
    def cache_control(self)->dict[str,str]:
        d={"type":"ephemeral"}
        if self.ttl=="1h": d["ttl"]="1h"
        return d

def stable_session_id(agent_id="", project_id="", conversation_id="")->str:
    raw="|".join((agent_id,project_id,conversation_id))
    if not raw.strip("|"): return ""
    h=sha256(raw.encode()).hexdigest()[:24]
    prefix="-".join(x for x in (agent_id,project_id) if x)[:80]
    return f"bossman-{prefix}-{h}"[:256]

def add_explicit_breakpoint(payload:dict[str,Any], cc:dict[str,str])->bool:
    msgs=payload.get("messages")
    if not isinstance(msgs,list): return False
    for msg in msgs:
        if not isinstance(msg,dict) or msg.get("role") not in {"system","developer"}: continue
        content=msg.get("content")
        if not isinstance(content,list): return False
        for block in reversed(content):
            if isinstance(block,dict) and block.get("type")=="text":
                block["cache_control"]=dict(cc); return True
        return False
    return False

def prepare_openrouter_payload(payload:dict[str,Any], *, provider_model:str,
    agent_id:str="", project_id:str="", conversation_id:str="",
    policy:PromptCachePolicy|None=None)->tuple[dict[str,Any],dict[str,Any]]:
    p=copy.deepcopy(payload); pol=policy or PromptCachePolicy()
    meta={"enabled":pol.enabled,"cache_mode":"none","session_id_set":False}
    if not pol.enabled: return p,meta
    sid=stable_session_id(agent_id,project_id,conversation_id)
    if sid:
        p["session_id"]=sid; meta["session_id_set"]=True
        meta["session_id_hash"]=sha256(sid.encode()).hexdigest()[:12]
    model=(provider_model or p.get("model") or "").lower()
    if "anthropic/" in model or "claude-" in model:
        cc=pol.cache_control()
        if pol.automatic:
            p["cache_control"]=cc; meta["cache_mode"]=f"anthropic-auto-{pol.ttl}"
        elif add_explicit_breakpoint(p,cc):
            meta["cache_mode"]=f"anthropic-explicit-{pol.ttl}"
        else:
            p["cache_control"]=cc; meta["cache_mode"]=f"anthropic-auto-fallback-{pol.ttl}"
    else:
        meta["cache_mode"]="provider-implicit-or-none"
    return p,meta

def extract_cache_usage(body:Mapping[str,Any])->dict[str,int|float|None]:
    usage=body.get("usage",{}) if isinstance(body,Mapping) else {}
    usage=usage if isinstance(usage,Mapping) else {}
    details=usage.get("prompt_tokens_details") or usage.get("input_tokens_details") or {}
    details=details if isinstance(details,Mapping) else {}
    return {
      "prompt_tokens":int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0),
      "completion_tokens":int(usage.get("completion_tokens") or usage.get("output_tokens") or 0),
      "cached_tokens":int(details.get("cached_tokens") or usage.get("cached_tokens") or 0),
      "cache_write_tokens":int(usage.get("cache_write_tokens") or details.get("cache_write_tokens") or 0),
      "cache_discount":usage.get("cache_discount"),
    }
