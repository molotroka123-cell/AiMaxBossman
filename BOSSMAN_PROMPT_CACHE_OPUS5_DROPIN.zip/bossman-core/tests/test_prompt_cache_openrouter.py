from bossman.gateway.prompt_cache import *
def test_sid():
    a=stable_session_id("coder","bossman","x")
    assert a==stable_session_id("coder","bossman","x") and len(a)<=256
def test_anthropic_auto():
    src={"model":"anthropic/claude-opus-5","messages":[{"role":"system","content":"stable"}]}
    out,m=prepare_openrouter_payload(src,provider_model=src["model"],conversation_id="x",policy=PromptCachePolicy(ttl="1h"))
    assert out["cache_control"]=={"type":"ephemeral","ttl":"1h"} and out["session_id"]
    assert "cache_control" not in src
def test_explicit():
    src={"model":"anthropic/claude-opus-5","messages":[{"role":"system","content":[{"type":"text","text":"stable"}]}]}
    out,m=prepare_openrouter_payload(src,provider_model=src["model"],conversation_id="x",policy=PromptCachePolicy(automatic=False))
    assert out["messages"][0]["content"][0]["cache_control"]=={"type":"ephemeral"}
def test_fallback():
    out,m=prepare_openrouter_payload({"model":"x/y","messages":[]},provider_model="x/y",conversation_id="x")
    assert "cache_control" not in out and out["session_id"]
def test_usage():
    u=extract_cache_usage({"usage":{"prompt_tokens":100,"prompt_tokens_details":{"cached_tokens":80}}})
    assert u["cached_tokens"]==80
