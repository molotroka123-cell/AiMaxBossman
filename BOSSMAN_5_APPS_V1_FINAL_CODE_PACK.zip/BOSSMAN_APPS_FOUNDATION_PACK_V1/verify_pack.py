#!/usr/bin/env python3
from pathlib import Path
import compileall, sys, yaml
root=Path(__file__).resolve().parent
ok=compileall.compile_dir(str(root/"apps"),quiet=1)
for m in (root/"apps").glob("*/app.manifest.yaml"):
    data=yaml.safe_load(m.read_text(encoding="utf-8"))
    assert data["runtime"]["standalone"] is True
    assert data["runtime"]["imports_bossman"] is False
print("compile:", "PASS" if ok else "FAIL")
print("manifests: PASS")
sys.exit(0 if ok else 1)
