# BOSSMAN — 5 Apps V1.0

Final code pass for:
1. Bossman Accountant
2. File Commander Mini
3. Exam Trainer AI
4. Travel Architect / Deal Hunter
5. PC Autopilot Mini

The apps are standalone-first and Bossman-enhanced.

Start with `FINAL_READINESS.md`, then each app's `TECHNICAL_SPEC.md`.

No fake-green: browser/provider/Windows live execution must be accepted on the target host.
