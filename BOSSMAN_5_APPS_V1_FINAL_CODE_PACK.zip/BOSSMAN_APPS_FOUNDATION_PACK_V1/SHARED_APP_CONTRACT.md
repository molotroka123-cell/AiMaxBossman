# SHARED APP CONTRACT — V1

## 1. Boundary

Standalone App <-> HTTP Control Contract <-> BOSSMAN.

Ни приложение, ни BOSSMAN не импортируют бизнес-код друг друга.

## 2. Common minimum operations

- `GET /health`
- `GET /capabilities`
- `GET /metrics`
- `POST /api/jobs`
- `GET /api/jobs`
- `GET /api/jobs/{job_id}`
- `POST /api/jobs/{job_id}/cancel`
- `GET /api/jobs/{job_id}/artifacts`

## 3. Local Task Exchange (planned thin adapter)

Нужен только как транспорт для:
App -> local task file -> Bossman agent -> result file -> App.

Не создавать новый task engine.

Предлагаемая директория:

data/bossman/
  inbox/
  claimed/
  completed/
  failed/
  artifacts/

Формат должен включать:
- task_id
- created_at
- app_id
- type
- priority
- input
- requested_capabilities
- idempotency_key
- reply_to

Claim должен быть atomic (rename/lease).
Повторная обработка одного idempotency_key запрещена.
Любой side effect всё равно проходит существующую BOSSMAN policy/approval цепочку.

## 4. Truth states

Только:
PASS / FAIL / NOT_RUN / SKIP_HOST / SKIP_EXTERNAL_SERVICE / SKIP_EXTERNAL_CREDENTIAL.

Никакого fake-green.

## 5. Security

- secrets only env/reference;
- localhost by default;
- no autonomous payment;
- no silent destructive filesystem action;
- no arbitrary LLM -> shell;
- app requests capabilities, authority remains with existing BOSSMAN policy.
