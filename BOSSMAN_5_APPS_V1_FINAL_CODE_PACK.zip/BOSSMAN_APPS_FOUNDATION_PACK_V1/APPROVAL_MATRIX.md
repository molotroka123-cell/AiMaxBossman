# APPROVAL MATRIX

Ниже 25 улучшений. Отметь `APPROVE / REJECT / LATER`.


## 1. Bossman Accountant

1. **CZ/SK country pack** — Добавить локальные правила, налоговый календарь, форматы банков и экспорт для бухгалтера. Не смешивать country logic с ядром.  
   Decision: `_____`

2. **Invoice/receipt ingestion** — OCR + извлечение поставщика, НДС, суммы, даты, валюты; всегда сохранять confidence и оригинал.  
   Decision: `_____`

3. **Owner Morning Digest** — Автоматический краткий отчёт владельцу: выручка, расходы, маржа, runway, аномалии, неоплаченные обязательства.  
   Decision: `_____`

4. **Reconciliation assistant** — Сопоставление банковских транзакций со счетами/чеками и очередь unmatched items для ручной проверки.  
   Decision: `_____`

5. **Forecast scenarios** — What-if по расходам, росту выручки, зарплатам и налоговым резервам с несколькими сценариями.  
   Decision: `_____`


## 2. File Commander Mini

1. **Semantic sorter** — Лёгкая локальная классификация файлов по проектам/темам, без тяжёлого LLM на каждом файле.  
   Decision: `_____`

2. **Safe rollback snapshots** — Перед массовым rename/move сохранять manifest операции и уметь полностью откатить её.  
   Decision: `_____`

3. **Smart duplicate sets** — Хеши + near-duplicate detection для фото/документов, но удаление только после preview/approval.  
   Decision: `_____`

4. **Project bundle creator** — Одна команда собирает связанные файлы проекта в portable bundle с индексом.  
   Decision: `_____`

5. **Watch-folder mode** — Опционально следить за Downloads/Inbox и только предлагать действия, не применять без правил.  
   Decision: `_____`


## 3. Exam Trainer AI

1. **Exam Probability Map** — Вес тем и типов задач по официальному blueprint, публичным пробникам и историческим открытым материалам; без обещаний угадать секретные вопросы.  
   Decision: `_____`

2. **Adaptive AI Tutor** — Сложность, темп и объяснения меняются по ошибкам, времени ответа и mastery score ученика.  
   Decision: `_____`

3. **Global language layer** — Вопрос может оставаться на языке экзамена, а объяснение и обучение — на любом выбранном языке.  
   Decision: `_____`

4. **Voice tutor mode** — Разговорная подготовка для языковых/устных экзаменов с таймером, rubric scoring и обратной связью.  
   Decision: `_____`

5. **Hourly commercial plans** — Пакеты часов, active-study metering, прогресс, родитель/teacher report и SaaS-ready billing hooks.  
   Decision: `_____`


## 4. Travel Architect / Deal Hunter

1. **Multi-origin optimizer** — Одновременно сравнивать Прагу, Вену, Берлин и другие разрешённые аэропорты с учётом дороги до них.  
   Decision: `_____`

2. **True trip cost engine** — Считать багаж, трансфер, resort fee, страховку, питание, парковку и локальный транспорт.  
   Decision: `_____`

3. **Package-vs-DIY arbitrage** — Сравнивать туроператора с самостоятельным flight+hotel и показывать реальную экономию/риск.  
   Decision: `_____`

4. **Price watch & trigger** — Лёгкий периодический watcher без LLM: уведомлять только при достижении заданной цены/качества.  
   Decision: `_____`

5. **Constraint intelligence** — Погода, визовые требования, сезонность, события, пересадки, ночные прилёты и качество района как hard/soft constraints.  
   Decision: `_____`


## 5. PC Autopilot Mini

1. **Teach-by-demonstration** — Записать действия пользователя и превратить их в устойчивый workflow с selectors и expected-state checks.  
   Decision: `_____`

2. **Selector self-healing** — При изменении UI не угадывать молча: найти вероятный новый selector, поставить PAUSED_NEEDS_REPAIR и запросить approval.  
   Decision: `_____`

3. **Dry-run simulator** — Показывать будущие действия и затрагиваемые файлы/окна до реального запуска.  
   Decision: `_____`

4. **Versioned macros** — Каждый workflow имеет версии, diff, rollback и last-known-good.  
   Decision: `_____`

5. **Triggers without AI** — Расписание, появление файла, запуск программы или hotkey могут запускать детерминированный макрос без LLM.  
   Decision: `_____`
