"""Minimal wiring shape. Replace mocks with canonical AiMaxBossman adapters."""
from datetime import datetime, timezone
from bossman_v3.contracts import *
from bossman_v3.computer_agent import UniversalComputerAgent

class Policy:
    def authorize(self, action, context): return PolicyDecision(True, action.side_effect != SideEffectClass.READ_ONLY)
class Approval:
    def request(self, action, policy, context): return ApprovalDecision(True,"demo-approval")
class Executor:
    ALLOWED={"browser.click","browser.read"}
    def supports(self,t): return t in self.ALLOWED
    def execute(self,a):
        now=datetime.now(timezone.utc)
        return ExecutionReceipt(a.action_type,now,now,"demo-effect")
class Observer:
    def observe_fresh(self,a,r): return Observation(datetime.now(timezone.utc),"demo",{"result":"observed"})
class Verifier:
    def verify(self,a,r,o): return VerificationResult(True,"fresh state matches expected outcome")

agent=UniversalComputerAgent(Policy(),Approval(),Executor(),Observer(),Verifier())
print(agent.run(TypedAction("browser.read",{"target":"status"})))
