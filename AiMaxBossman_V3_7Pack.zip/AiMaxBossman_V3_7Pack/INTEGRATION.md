# Integration into AiMaxBossman

This pack was prepared against the current connected repository snapshot of branch `claude/bossman-control-v03-43igbk`. Reconcile against remote HEAD again immediately before applying because other agents may push concurrently.

## 1. Do not replace core authorities

Reuse the repository's current canonical implementations for:

- Gateway/model calls;
- Tool Registry;
- Policy/scopes;
- Approvals;
- Secret/Vault storage;
- EventBus/telemetry transport;
- Memory/database persistence;
- Cost Governor;
- Session engine;
- Browser and Computer Operator.

The V3 package is orchestration/intelligence around these authorities, not a competing core.

## 2. Recommended wiring order

1. Copy `bossman_v3/` into the repository as a feature-gated package or adapt its modules into the current package layout.
2. Implement thin adapters from canonical Policy/Approval/Tool Registry/Computer Operator/Verifier/Memory/EventBus objects to `bossman_v3.contracts`.
3. Keep all V3 flags OFF.
4. Run existing full regressions plus this pack's tests.
5. Enable Context/Data Guardian in shadow A/B mode first and measure raw vs filtered verified success.
6. Enable Visual State in shadow mode.
7. Connect Universal Computer Agent only to pre-registered typed actions.
8. Add Self-Healing and Recovery Kernel after Failure Memory/checkpoint persistence are proven.
9. Keep Skill Factory at EXPERIMENTAL/SHADOW until reliability lower bound and benchmark gates pass.
10. Keep Self-Improvement Laboratory proposal-only; release/promotion still requires canonical policy/approval.

## 3. Integration proof

A production claim requires proving the real sequence:

`task → working state/context → typed action → policy → approval if needed → canonical executor → fresh observation → verifier → state update → telemetry`

Module imports and unit tests alone are not production proof.

## 4. Data Guardian A/B gate

For the same model/task/fixture/tool permissions compare raw context and guarded context.

`IntelligenceRetention = VerifiedSuccess_filtered / VerifiedSuccess_raw`

Reject production-default filtering when:

`VerifiedSuccess_raw - VerifiedSuccess_filtered > 0.01`

Also report:

`ContextGain = (VerifiedQuality/EffectiveCost)_filtered / (VerifiedQuality/EffectiveCost)_raw`

Do not hide quality loss behind token savings.

## 5. Rollback

Every feature is independently gated and the master V3 flag defaults OFF. Rollback is therefore configuration-first, not destructive migration-first.
