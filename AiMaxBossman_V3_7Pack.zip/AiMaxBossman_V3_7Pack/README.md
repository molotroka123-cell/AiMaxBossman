# AiMaxBossman V3 — 7 Pack

Drop-in implementation package for the seven selected V3 capabilities:

1. Universal Computer Agent
2. Visual State Engine
3. Self-Healing Agent
4. Skill Factory
5. Recovery Kernel
6. Self-Improvement Laboratory
7. Context/Data Guardian

## Non-negotiable invariant

`intent → typed action → policy/scopes → approval → executor → fresh observation → verification`

**Never:** `LLM → arbitrary shell`.

This package deliberately **does not create another** Gateway, Tool Registry, Policy engine, Approval engine, Secret Store/Vault, EventBus, Memory engine, Cost Governor, Session engine, Browser, or Computer Operator. Existing AiMaxBossman components remain authoritative. `bossman_v3.contracts` defines ports and `bossman_v3.adapters` shows thin adapter patterns.

## Safety defaults

Every V3 feature is OFF by default. The master flag and the individual feature flag must both be enabled.

```text
BOSSMAN_V3_ENABLED=1
BOSSMAN_V3_COMPUTER_AGENT=1
BOSSMAN_V3_VISUAL_STATE=1
BOSSMAN_V3_SELF_HEALING=1
BOSSMAN_V3_SKILL_FACTORY=1
BOSSMAN_V3_RECOVERY_KERNEL=1
BOSSMAN_V3_SELF_IMPROVEMENT=1
BOSSMAN_V3_DATA_GUARDIAN=1
```

`BOSSMAN_LOW_MEMORY=1` makes the Context/Data Guardian use its bounded low-memory token budget.

## Context/Data Guardian

The Guardian exists specifically to prevent orchestration from making the base model less capable through context starvation.

Hard-critical information is protected: security, policy, objective, constraints, fresh observations, active errors, key decisions, P0/P1 and priority P0/P1/P2 records.

It implements:

- stable-hash exact deduplication;
- mandatory context reservation;
- conflict preservation;
- raw-artifact fallback references;
- `KeepRisk = Importance × Uncertainty × Irrecoverability`;
- `ContextLossRisk = P(important evidence removed) × Impact`;
- Deep Context escalation when omission is unsafe;
- recall check before final decisions;
- A/B production gate for intelligence retention;
- rejection if filtered verified-success degrades by more than 1 percentage point by default.

The budget is **soft for critical evidence**. If correctness requires more context than the nominal budget, critical evidence wins.

## Universal Computer Agent

The agent contains no subprocess or shell executor. It accepts only typed actions supported by an injected canonical executor/registry. Raw action types such as `bash`, `powershell`, `cmd`, `shell`, and `exec` are rejected before policy/execution.

## Skill Factory

Skills can only be learned from fully verified traces of typed actions. Lifecycle:

`EXPERIMENTAL → SHADOW → PRODUCTION`

Reliability uses a Beta posterior and conservative lower credible bound. Security regressions or >1 pp verified-success degradation block production promotion.

## Recovery Kernel

Contains checkpoint hashing, verified-only restore, loop detection, watchdog and budget-runaway directives. The included filesystem checkpoint store is for tests/demo only; production should adapt the canonical Bossman persistence layer.

## Self-Improvement Laboratory

It evaluates candidate changes using Pareto and architecture ROI. It **does not merge, push, deploy, or grant itself authority**. Promotion remains a proposal gated by the existing Bossman policy/approval/release process.

## Run tests

```bash
python -m compileall -q bossman_v3
pytest -q
```
