from bossman_v3.data_guardian import *

def item(i, **kw):
    defaults=dict(item_id=i,category="background",content=i,raw_ref=f"raw:{i}",token_count=100,priority=6,importance=.1,uncertainty=.1,irrecoverability=.1,probability_important=.1,impact=.1,savings_utility=.3)
    defaults.update(kw); return ContextItem(**defaults)

def test_critical_evidence_never_omitted_even_over_budget():
    g=ContextDataGuardian(GuardianConfig(token_budget=10))
    critical=item("goal",category="objective",priority=1,token_count=1000)
    r=g.select([critical])
    assert critical in r.selected and not r.omitted and r.selected_tokens>10

def test_raw_fallback_is_kept_for_omitted():
    g=ContextDataGuardian(GuardianConfig(token_budget=100))
    a=item("a",token_count=100,importance=.9); b=item("b",token_count=100,importance=.01)
    r=g.select([a,b])
    assert any(x.item_id=="b" for x in r.omitted)
    assert "raw:b" in r.raw_fallback_refs

def test_conflict_preserved():
    g=ContextDataGuardian(GuardianConfig(token_budget=50))
    a=item("a",category="objective",priority=1,conflict_group="x",token_count=100)
    b=item("b",conflict_group="x",token_count=100)
    r=g.select([a,b])
    assert {x.item_id for x in r.selected}=={"a","b"}

def test_high_omission_risk_forces_deep_context():
    g=ContextDataGuardian(GuardianConfig(token_budget=10,keep_risk_threshold=.2))
    risky=item("r",token_count=1000,importance=.9,uncertainty=.9,irrecoverability=.9,savings_utility=.95,probability_important=.1,impact=.1)
    r=g.select([risky])
    assert risky in r.selected and r.deep_escalated

def test_retention_gate_rejects_over_one_percentage_point_drop():
    g=ContextDataGuardian()
    m=g.retention_gate(raw_verified_success=.90,filtered_verified_success=.88,raw_quality=.9,filtered_quality=.9,raw_effective_cost=2,filtered_effective_cost=1)
    assert not m.production_allowed
    assert m.context_gain>1
