from datetime import datetime,timezone,timedelta
import pytest
from bossman_v3.visual_state import *

def test_structured_state_beats_vision_hint_and_keeps_artifact():
    now=datetime.now(timezone.utc)
    e=VisualStateEngine(max_age_seconds=5)
    r=e.fuse([StateFragment("dom",now,{"button":"Save"},"dom"),StateFragment("vision",now,{"button":"Maybe"},"vision","shot:1")],now=now)
    assert r.structured["button"]=="Save"
    assert r.structured["vision_hint.button"]=="Maybe"
    assert "shot:1" in r.screenshot_refs

def test_stale_visual_state_rejected():
    now=datetime.now(timezone.utc)
    with pytest.raises(StaleVisualStateError): VisualStateEngine(1).fuse([StateFragment("dom",now-timedelta(seconds=2),{},"dom")],now=now)
