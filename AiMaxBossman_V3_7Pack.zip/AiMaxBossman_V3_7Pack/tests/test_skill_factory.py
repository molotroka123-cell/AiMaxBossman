from bossman_v3.skill_factory import *
from bossman_v3.contracts import TypedAction
import pytest

def test_skill_requires_verified_typed_trace():
    f=SkillFactory()
    with pytest.raises(ValueError): f.from_verified_trace("bad",[TraceStep(TypedAction("browser.click"),False)],input_schema={},output_schema={})
    with pytest.raises(ValueError): f.from_verified_trace("bad",[TraceStep(TypedAction("bash"),True)],input_schema={},output_schema={})

def test_bayesian_lcb_is_conservative_and_promotion_gated():
    f=SkillFactory(); c=f.from_verified_trace("ok",[TraceStep(TypedAction("browser.click"),True)],input_schema={},output_schema={})
    assert c.status=="ESTIMATED"
    for _ in range(100): f.record(c,True)
    assert 0<c.reliability_lcb()<1
    ev=PromotionEvidence(100,1.0,1.0,0,0,True)
    assert f.promote(c,ev)==SkillStage.SHADOW
    assert f.promote(c,ev,min_lcb=.8)==SkillStage.PRODUCTION
