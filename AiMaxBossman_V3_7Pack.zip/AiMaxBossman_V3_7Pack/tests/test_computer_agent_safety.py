from datetime import datetime, timezone, timedelta
import pytest
from bossman_v3.contracts import *
from bossman_v3.computer_agent import *

class Recorder:
    def __init__(self): self.events=[]; self.allow=True; self.need_approval=False; self.approve=True; self.fresh=True
    def authorize(self,a,c): self.events.append("policy"); return PolicyDecision(self.allow,self.need_approval,"deny")
    def request(self,a,p,c): self.events.append("approval"); return ApprovalDecision(self.approve,"ap-1","no")
    def supports(self,t): return True
    def execute(self,a): self.events.append("execute"); now=datetime.now(timezone.utc); return ExecutionReceipt(a.action_type,now,now,"effect")
    def observe_fresh(self,a,r): self.events.append("observe"); dt=r.completed_at + (timedelta(milliseconds=1) if self.fresh else -timedelta(seconds=1)); return Observation(dt,"test",{"ok":1})
    def verify(self,a,r,o): self.events.append("verify"); return VerificationResult(True,"ok")

def agent(rec): return UniversalComputerAgent(rec,rec,rec,rec,rec)

def test_raw_shell_is_rejected_even_if_executor_supports_it():
    r=Recorder()
    with pytest.raises(UnsafeActionError): agent(r).run(TypedAction("bash",{"cmd":"echo nope"}))
    assert r.events == []

def test_order_and_fresh_observation():
    r=Recorder(); r.need_approval=True
    out=agent(r).run(TypedAction("browser.click",{"target":"save"}))
    assert out.verification.passed
    assert r.events == ["policy","approval","execute","observe","verify"]

def test_policy_denial_stops_execution():
    r=Recorder(); r.allow=False
    with pytest.raises(PolicyDeniedError): agent(r).run(TypedAction("browser.click"))
    assert r.events == ["policy"]

def test_approval_denial_stops_execution():
    r=Recorder(); r.need_approval=True; r.approve=False
    with pytest.raises(ApprovalDeniedError): agent(r).run(TypedAction("browser.click"))
    assert r.events == ["policy","approval"]

def test_stale_observation_is_rejected():
    r=Recorder(); r.fresh=False
    with pytest.raises(StaleObservationError): agent(r).run(TypedAction("browser.click"))
    assert "verify" not in r.events
