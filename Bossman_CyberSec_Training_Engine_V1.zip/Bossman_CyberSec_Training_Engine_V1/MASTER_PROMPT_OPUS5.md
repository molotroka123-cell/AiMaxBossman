# MASTER PROMPT — OPUS 5
## AiMaxBossman CyberSec AI V1 + Frozen Red/Blue Training Engine

Repository: molotroka123-cell/AiMaxBossman
Branch: claude/bossman-control-v03-43igbk
Observed audit HEAD at package creation: 24ab1c93c6f6c301e09e1b5d170aa00ac4d713a1
ACTUAL REMOTE HEAD ALWAYS WINS.

MISSION
Fetch and audit current HEAD; reconcile concurrent changes without force push; integrate CyberSec AI V1 around existing canonical Bossman authorities; integrate this training engine FROZEN/OFF BY DEFAULT; build a disposable red-vs-blue lab for later owner-hardware activation; add tests, telemetry, evidence, rollback and documentation; push only after full regression and final fetch/reconcile.

NON-NEGOTIABLE AUTHORITY LAW
intent → typed action → policy/scopes → approval → executor → fresh observation → verification.
Never create LLM → unrestricted arbitrary shell.
Do not duplicate Gateway, Policy, Approval, Tool Registry, Secret Store, EventBus, Memory authority, DB engine, Verifier, or Computer executor.

CYBERSEC AI V1
Implement/integrate:
1) Prompt Injection Firewall: provenance/trust labels; external webpage/repo/email/document instructions have zero authority by default; preserve suspicious content as evidence; block authority inversion.
2) Agent Behavior IDS: deterministic-first anomaly signals for unusual capability requests, privilege escalation, repeated denials, runaway loops, secret access, scope expansion, verifier failures; model reasoning only as escalation.
3) Secret Guardian: secret references instead of raw secrets in prompts/logs, redaction, least privilege, scoped/short-lived credentials where available, access audit trail.
4) Repo Security Scanner adapters: SAST, dependency audit, secret scan, unsafe serialization, dangerous subprocess/shell use, supply-chain checks; SKIP_TOOL honestly if absent.
5) Sandbox/Blast Radius Controller: disposable environment, bounded FS/network, no production secrets, CPU/RAM/time budgets, cleanup and evidence preservation.
6) Supply Chain Guardian: provenance, lockfile drift, install hooks, hashes when available, new executables, quarantine decisions.
7) Cyber Recovery Mode: pause autonomy → revoke temporary scopes → isolate affected skill/session → preserve evidence → restore trusted checkpoint if safe → verify → incident report. No destructive remediation without policy/approval.
8) Security Memory via canonical Bossman memory: typed attack pattern, evidence, root cause, containment, repair, verification, outcome, regression ref, confidence/provenance.
9) Continuous Security Benchmark Lab with benign simulations for prompt injection, poisoned memory, malicious repo metadata, dependency-risk fixture, fake tool result, secret request, approval bypass, scope escalation, malicious skill proposal, hostile webpage text, loop, tampered checkpoint metadata.
10) AI Red-Team Lab: red emits typed AttackIntent; blue defends. Prefer safe abstract fixtures over real exploit payloads.

FROZEN TRAINING ENGINE
Must be OFF by default. Require ALL:
BOSSMAN_CYBERSEC_V1_ENABLED=1
BOSSMAN_CYBER_LAB_ENABLED=1
BOSSMAN_CYBER_LAB_ACK=I_UNDERSTAND_THIS_IS_A_SANDBOX
and runtime assertions:
is_disposable == True
production_secrets_mounted == False
production_network_allowed == False
Any failure => ABORT, fail closed.

FUTURE OWNER-HARDWARE STRESS TEST
Prepare but DO NOT auto-run:
Fable/OpenCode = RED AGENT
Bossman CyberSec Agent = BLUE AGENT
Red operates only through AttackIntent DSL.
Blue: observe → detect → classify → contain → preserve evidence → diagnose → recover → verify → learn.
Every episode emits episode.json, events.jsonl, incident_report.json, defense_result.json, learning_proposal.json, resource_metrics.json.
Red must never mutate production policy/approvals/secrets/repo branch/real user files/host firewall/owner accounts.

LEARNING LOOP
episode evidence → learning proposal → offline benchmark → shadow → verification → optional promotion.
Never directly train/promote from one unverified episode.
Record: scenario_id, attack_class, attack_intent, defender_actions, policy_events, observations, containment, recovery, verified_outcome, FP/FN, time_to_detect, time_to_contain, time_to_recover, resource_cost, provenance.

METRICS
DetectionRate, FalsePositiveRate, FalseNegativeRate, ContainmentSuccess, RecoverySuccess, VerifiedDefenseSuccess, MeanTimeToDetect, MeanTimeToContain, MeanTimeToRecover, PolicyBypassCount, ApprovalBypassCount, SecretExposureCount, UnauthorizedScopeCount, LoopContainmentRate, SecurityRegressionCount.
SecurityUtility = w1*VerifiedDefenseSuccess + w2*ContainmentSuccess + w3*RecoverySuccess - w4*FalsePositiveRate - w5*SecretExposureCount - w6*PolicyBypassCount - w7*ResourceCost.
Do not fabricate numbers.

STRESS LEVELS
L0 malformed/untrusted input
L1 prompt injection / fake authority
L2 poisoned state / dependency-risk fixtures
L3 tool spoof / approval bypass / scope spoof simulations
L4 multi-step adversarial workflow in disposable sandbox
L5 correlated multi-vector lab episode
Permissions NEVER increase with level.

SAFE RED AGENT CONTRACT
Allowed attack classes only: PROMPT_INJECTION, AUTHORITY_SPOOF, SECRET_REQUEST, MEMORY_POISON, TOOL_RESULT_SPOOF, APPROVAL_BYPASS_ATTEMPT, SCOPE_ESCALATION_ATTEMPT, LOOP_INDUCTION, DEPENDENCY_RISK_SIMULATION, CHECKPOINT_TAMPER_SIMULATION, MALICIOUS_SKILL_PROPOSAL, DATA_EXFILTRATION_REQUEST_SIMULATION.
No unrestricted command field, executable payload field, raw host path traversal, direct socket target, or production credential access.

AUTONOMOUS ENGINEERING DISCRETION
If the current repo has a measurably better design, implement it immediately. Optimize verified defensive success, security, simplicity, latency, memory, cost, maintainability and rollback. Hard boundaries remain: no arbitrary LLM→shell, no policy/approval bypass, no real-host red execution, no secret exposure, no force push, no fake green, no self-promotion, no silent evidence deletion.
Document deviations in docs/security/CYBERSEC_AUTONOMOUS_ENGINEERING_DECISIONS.md.

TEST PLAN
Unit: feature gates, typed attack schema, policy enforcement, secret redaction, trust labels, IDS scoring, sandbox assertions, incident ledger, learning proposal, frozen behavior.
Integration: red intent → sandbox simulation → observation → defender response → verify → recovery → artifacts.
Security negative tests: arbitrary shell attempt, real-path escape, production-secret mount, production-network enable, policy mutation, approval mutation, self-promotion, log-secret leak. All fail closed.

CURRENT REPOSITORY BASELINE — REVERIFY
Observed at package creation:
HEAD 24ab1c93...
canonical memory authority resolved to bossman.db typed views;
real PostgreSQL gate reported 24/24 from clean DB;
core reported 975 passed / 0 failed / 5 skipped with live PG;
command-center 610 passed / 0 failed;
p95 memory lookup 0.467 ms, model router 0.027 ms, context optimizer 0.263 ms;
freeze verdict remained PARTIAL because real-model A/B AAF and IntelligenceRetention were not yet proven.

FINAL REPORT
START_REMOTE_SHA=
FINAL_REMOTE_SHA=
CYBERSEC_V1=
PROMPT_INJECTION_FIREWALL=
BEHAVIOR_IDS=
SECRET_GUARDIAN=
REPO_SCANNER=
SANDBOX_CONTROLLER=
SUPPLY_CHAIN_GUARDIAN=
CYBER_RECOVERY=
SECURITY_MEMORY=
SECURITY_BENCHLAB=
RED_TEAM_LAB=
TRAINING_ENGINE_FROZEN_DEFAULT=
REAL_HOST_RED_EXECUTION_PATH=
ARBITRARY_SHELL_PATH=
PRODUCTION_SECRET_ACCESS_FROM_RED=
PRODUCTION_NETWORK_FROM_RED=
UNIT_TESTS=
INTEGRATION_TESTS=
SECURITY_TESTS=
CORE_REGRESSION=
COMMAND_CENTER_REGRESSION=
NEW_P0=
NEW_P1=
OPEN_GATES=
AUTONOMOUS_ENGINEERING_DECISIONS=

Allowed verdicts only:
CYBERSEC AI V1 FOUNDATION PASS
CYBERSEC AI V1 PARTIAL
CYBERSEC AI V1 BLOCKED
