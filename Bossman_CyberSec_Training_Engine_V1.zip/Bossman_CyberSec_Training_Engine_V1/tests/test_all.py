import pytest
from bossman_cyber_training.gates import SandboxFacts,assert_lab_enabled
from bossman_cyber_training.models import AttackIntent,AttackClass
from bossman_cyber_training.defender import defend
from bossman_cyber_training.secret_guardian import redact
from bossman_cyber_training.ids import BehaviorSignal,score_behavior

def test_frozen_by_default(monkeypatch):
    for k in ["BOSSMAN_CYBERSEC_V1_ENABLED","BOSSMAN_CYBER_LAB_ENABLED","BOSSMAN_CYBER_LAB_ACK"]: monkeypatch.delenv(k,raising=False)
    with pytest.raises(RuntimeError): assert_lab_enabled(SandboxFacts(True,False,False))

def gates(monkeypatch):
    monkeypatch.setenv("BOSSMAN_CYBERSEC_V1_ENABLED","1"); monkeypatch.setenv("BOSSMAN_CYBER_LAB_ENABLED","1"); monkeypatch.setenv("BOSSMAN_CYBER_LAB_ACK","I_UNDERSTAND_THIS_IS_A_SANDBOX")

def test_reject_non_disposable(monkeypatch):
    gates(monkeypatch)
    with pytest.raises(RuntimeError): assert_lab_enabled(SandboxFacts(False,False,False))

def test_reject_prod_secrets(monkeypatch):
    gates(monkeypatch)
    with pytest.raises(RuntimeError): assert_lab_enabled(SandboxFacts(True,True,False))

def test_reject_prod_network(monkeypatch):
    gates(monkeypatch)
    with pytest.raises(RuntimeError): assert_lab_enabled(SandboxFacts(True,False,True))

def test_attack_metadata_rejects_shell():
    a=AttackIntent("x",AttackClass.PROMPT_INJECTION,1,"fixture",metadata={"shell":"x"})
    with pytest.raises(ValueError): a.validate()

def test_secret_request_denied(): assert defend(AttackIntent("x",AttackClass.SECRET_REQUEST,2,"fixture")).action=="DENY_AND_QUARANTINE"
def test_memory_poison_reverify(): assert defend(AttackIntent("x",AttackClass.MEMORY_POISON,2,"fixture")).action=="ISOLATE_AND_REVERIFY"
def test_secret_redaction(): assert "SUPERSECRET" not in redact("api_key=SUPERSECRET")
def test_ids(): assert score_behavior(BehaviorSignal(secret_requests=2,scope_escalations=1)).score>=0.6
