import os
from dataclasses import dataclass
@dataclass(frozen=True)
class SandboxFacts:
    is_disposable: bool
    production_secrets_mounted: bool
    production_network_allowed: bool

def assert_lab_enabled(facts: SandboxFacts) -> None:
    required = {
        "BOSSMAN_CYBERSEC_V1_ENABLED":"1",
        "BOSSMAN_CYBER_LAB_ENABLED":"1",
        "BOSSMAN_CYBER_LAB_ACK":"I_UNDERSTAND_THIS_IS_A_SANDBOX",
    }
    for key, expected in required.items():
        if os.getenv(key) != expected:
            raise RuntimeError(f"training lab frozen: missing gate {key}")
    if not facts.is_disposable: raise RuntimeError("training lab requires disposable sandbox")
    if facts.production_secrets_mounted: raise RuntimeError("production secrets must not be mounted")
    if facts.production_network_allowed: raise RuntimeError("production network scope must be disabled")
