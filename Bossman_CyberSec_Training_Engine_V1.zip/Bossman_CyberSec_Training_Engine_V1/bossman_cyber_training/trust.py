from enum import IntEnum
class TrustLevel(IntEnum):
    UNKNOWN=0; EXTERNAL=1; TRUSTED_REPO=2; VERIFIED_TOOL=3; SIGNED_INTERNAL=4; OWNER_POLICY=5
def has_authority(source_trust: TrustLevel, required: TrustLevel) -> bool:
    return source_trust >= required
