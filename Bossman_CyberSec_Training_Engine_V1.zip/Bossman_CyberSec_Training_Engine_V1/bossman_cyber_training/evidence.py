from pathlib import Path
import json,time,uuid
from .secret_guardian import redact
class EvidenceLedger:
    def __init__(self,root:str): self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def write_episode(self,scenario_id:str,records:dict)->Path:
        d=self.root/f"{int(time.time())}-{uuid.uuid4().hex[:8]}"; d.mkdir()
        safe=json.loads(redact(json.dumps(records,default=str)))
        (d/"episode.json").write_text(json.dumps(safe,indent=2),encoding="utf-8")
        return d
