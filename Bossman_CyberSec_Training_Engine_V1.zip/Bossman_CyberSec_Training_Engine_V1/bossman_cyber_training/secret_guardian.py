import re
_PATTERNS=[re.compile(r"(?i)(api[_-]?key|token|secret|password)\s*[:=]\s*([^\s,;]+)"), re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",re.S)]
def redact(text: str) -> str:
    out=text
    for p in _PATTERNS:
        out = p.sub((lambda m:f"{m.group(1)}=<REDACTED>") if p.groups>=2 else "<REDACTED_PRIVATE_KEY>", out)
    return out
