from dataclasses import dataclass
from .models import AttackIntent,AttackClass
@dataclass(frozen=True)
class DefenseDecision:
    action:str; rationale:str; requires_owner_approval:bool=False
def defend(intent:AttackIntent)->DefenseDecision:
    intent.validate()
    if intent.attack_class in {AttackClass.SECRET_REQUEST,AttackClass.DATA_EXFILTRATION_REQUEST_SIMULATION,AttackClass.APPROVAL_BYPASS_ATTEMPT,AttackClass.SCOPE_ESCALATION_ATTEMPT}:
        return DefenseDecision("DENY_AND_QUARANTINE","authority or data-exposure boundary triggered")
    if intent.attack_class in {AttackClass.MEMORY_POISON,AttackClass.TOOL_RESULT_SPOOF,AttackClass.CHECKPOINT_TAMPER_SIMULATION}:
        return DefenseDecision("ISOLATE_AND_REVERIFY","integrity/provenance verification required")
    if intent.attack_class==AttackClass.LOOP_INDUCTION:
        return DefenseDecision("BREAK_LOOP_AND_REPLAN","repeated-state/action defense")
    return DefenseDecision("SANDBOX_AND_OBSERVE","untrusted scenario remains confined")
