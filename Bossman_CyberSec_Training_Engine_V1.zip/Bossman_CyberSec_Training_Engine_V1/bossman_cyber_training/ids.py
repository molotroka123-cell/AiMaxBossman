from dataclasses import dataclass
@dataclass(frozen=True)
class BehaviorSignal:
    policy_denials:int=0; secret_requests:int=0; scope_escalations:int=0; repeated_actions:int=0; verifier_failures:int=0
@dataclass(frozen=True)
class IDSResult:
    score:float; severity:str; reasons:tuple[str,...]
def score_behavior(s:BehaviorSignal)->IDSResult:
    score=min(1.0,0.18*s.policy_denials+0.30*s.secret_requests+0.25*s.scope_escalations+0.08*max(0,s.repeated_actions-2)+0.10*s.verifier_failures)
    reasons=[]
    if s.secret_requests: reasons.append("secret_access")
    if s.scope_escalations: reasons.append("scope_escalation")
    if s.policy_denials: reasons.append("policy_denials")
    if s.repeated_actions>2: reasons.append("loop_risk")
    if s.verifier_failures: reasons.append("verification_failures")
    sev="critical" if score>=.8 else "high" if score>=.6 else "medium" if score>=.3 else "low"
    return IDSResult(score,sev,tuple(reasons))
