from dataclasses import dataclass
@dataclass(frozen=True)
class LearningProposal:
    scenario_id:str; pattern:str; mitigation:str; verified:bool; eligible_for_shadow:bool
def propose_learning(scenario_id,pattern,mitigation,verified):
    return LearningProposal(scenario_id,pattern,mitigation,bool(verified),bool(verified))
