from dataclasses import asdict
from .gates import assert_lab_enabled
from .defender import defend
from .evidence import EvidenceLedger
from .learning import propose_learning
class FrozenTrainingEngine:
    def __init__(self,evidence_root:str): self.ledger=EvidenceLedger(evidence_root)
    def run(self,intent,sandbox):
        assert_lab_enabled(sandbox); intent.validate(); decision=defend(intent)
        verified=decision.action in {"DENY_AND_QUARANTINE","ISOLATE_AND_REVERIFY","BREAK_LOOP_AND_REPLAN","SANDBOX_AND_OBSERVE"}
        proposal=propose_learning(intent.scenario_id,intent.attack_class.value,decision.action,verified)
        result={"scenario":asdict(intent),"defense":asdict(decision),"verified_outcome":verified,"learning_proposal":asdict(proposal)}
        result["evidence_path"]=str(self.ledger.write_episode(intent.scenario_id,result)); return result
