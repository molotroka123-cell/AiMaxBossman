from dataclasses import dataclass, field
from enum import Enum
from typing import Any

class AttackClass(str, Enum):
    PROMPT_INJECTION = "prompt_injection"
    AUTHORITY_SPOOF = "authority_spoof"
    SECRET_REQUEST = "secret_request"
    MEMORY_POISON = "memory_poison"
    TOOL_RESULT_SPOOF = "tool_result_spoof"
    APPROVAL_BYPASS_ATTEMPT = "approval_bypass_attempt"
    SCOPE_ESCALATION_ATTEMPT = "scope_escalation_attempt"
    LOOP_INDUCTION = "loop_induction"
    DEPENDENCY_RISK_SIMULATION = "dependency_risk_simulation"
    CHECKPOINT_TAMPER_SIMULATION = "checkpoint_tamper_simulation"
    MALICIOUS_SKILL_PROPOSAL = "malicious_skill_proposal"
    DATA_EXFILTRATION_REQUEST_SIMULATION = "data_exfiltration_request_simulation"

@dataclass(frozen=True)
class AttackIntent:
    scenario_id: str
    attack_class: AttackClass
    difficulty: int
    target_surface: str
    untrusted_text: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    def validate(self) -> None:
        if not 0 <= self.difficulty <= 5:
            raise ValueError("difficulty must be 0..5")
        forbidden = {"command","shell","payload","executable","socket_target","credential"}
        overlap = forbidden.intersection(self.metadata)
        if overlap:
            raise ValueError(f"unsafe red-agent metadata keys: {sorted(overlap)}")
