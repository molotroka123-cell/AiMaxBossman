# Bossman CyberSec Training Engine V1

Frozen-by-default, sandbox-only red-vs-blue training harness for AiMaxBossman.

Purpose: controlled adversarial drills, evidence logging, recovery verification, and offline learning proposals. The red side uses typed abstract AttackIntent records only; it never receives unrestricted shell, production credentials, production network scope, or production policy authority.

Activation requires all of:
- `BOSSMAN_CYBERSEC_V1_ENABLED=1`
- `BOSSMAN_CYBER_LAB_ENABLED=1`
- `BOSSMAN_CYBER_LAB_ACK=I_UNDERSTAND_THIS_IS_A_SANDBOX`
- disposable sandbox assertion
- no production secrets mounted
- no production network scope
