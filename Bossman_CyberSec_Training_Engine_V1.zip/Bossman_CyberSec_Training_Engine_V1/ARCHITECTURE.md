# Architecture

Red Agent → typed AttackIntent → Lab Policy → Disposable Sandbox → Observation/Telemetry → Bossman Defender → Containment → Verification → Recovery → Evidence Ledger → Learning Proposal → benchmark/shadow gate.

CyberSec AI V1 modules:
1. Prompt Injection Firewall
2. Agent Behavior IDS
3. Secret Guardian
4. Repo Security Scanner adapters
5. Sandbox / Blast Radius Controller
6. Supply Chain Guardian
7. Cyber Recovery Mode
8. Security Memory adapter
9. Continuous Security Benchmark Lab
10. AI Red-Team Lab

Trust order:
System/Owner policy > signed internal state > verified tools > trusted repo data > external content > unknown input.

The lab never grants the red side production secrets, unrestricted host shell, production DB, owner sessions, policy mutation, approval mutation, or deployment authority.
