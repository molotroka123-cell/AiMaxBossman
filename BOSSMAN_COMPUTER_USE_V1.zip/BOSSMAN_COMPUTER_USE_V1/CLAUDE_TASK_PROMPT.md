# Prompt to paste into Claude Code

You are integrating the attached `BOSSMAN_COMPUTER_USE_V1` package into the current `molotroka123-cell/AiMaxBossman` repository.

Read `CLAUDE_START_HERE.md`, `TECH_SPEC.md`, `PATCH_MANIFEST.md`, `docs/GITHUB_REPO_HYGIENE.md`, and `docs/AUDIT_PROTOCOL.md` first. Then inspect the current repository and compare it with the assumptions in the package.

Implement the shared ComputerUse layer in `bossman-core`; do not create a site-specific Higgsfield app and do not break existing agent/tool/approval architecture. Every current and future agent should receive the generic browser tools by default with `computer_use: false` as an opt-out. Preserve manual per-agent grants. Use the existing approval loop for consequential actions; `browser.click` must reject likely dangerous targets and instruct the model to use `browser.confirmed_click`, which requires approval.

You may run `python scripts/apply_patch.py <repo-root>` from inside this package as a starting point, but you MUST inspect the resulting diff and adapt it to newer repository code rather than blindly accepting it.

Run all relevant existing tests plus the new ComputerUse tests. Verify imports and, where the environment allows it, perform a Playwright smoke test with a benign local/static page. Do not test against real payments, account changes, messaging, destructive actions, CAPTCHA bypass, rate-limit bypass, or anti-bot bypass.

Before finishing, clean up repository placement/naming according to the hygiene guide without deleting historical artifacts unless safe and clearly obsolete. Prefer moving obsolete root handoff ZIPs to the documented archive path or recommending a Release migration if binary history should be preserved.

Create the implementation audit exactly as:
`docs/audits/YYYY/2026-08-29__computer-use__implementation-audit__v1.md`
(adapt the year directory only if the actual execution date differs). Include branch, exact commit SHA, files changed, tests actually executed, security checks, limitations, unresolved findings and repo-hygiene findings.

Use Conventional Commits. Suggested branch: `feature/computer-use-v1`.
