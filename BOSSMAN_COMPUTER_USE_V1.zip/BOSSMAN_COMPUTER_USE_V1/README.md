# BOSSMAN_COMPUTER_USE_V1

Handoff bundle for adding generic browser/computer-use capability to every AiMaxBossman agent.

Start with `CLAUDE_START_HERE.md`.

Contents:
- complete technical spec;
- implementation-ready Playwright toolkit module;
- tests;
- conservative patch helper;
- GitHub repository sorting/hygiene rules;
- durable audit naming and report protocol;
- ready-to-paste Claude Code task prompt.
