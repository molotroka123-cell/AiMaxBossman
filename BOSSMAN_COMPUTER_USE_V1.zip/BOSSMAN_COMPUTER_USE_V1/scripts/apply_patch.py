"""Best-effort mechanical patcher for BOSSMAN ComputerUse v1.

Claude Code should inspect the diff after running this script. It intentionally aborts when
expected anchors are missing instead of guessing and corrupting newer code.
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

import yaml

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
PKG = Path(__file__).resolve().parents[1]
CORE = ROOT / "bossman-core"


def require(path: Path) -> None:
    if not path.exists():
        raise SystemExit(f"required path not found: {path}")


for p in [CORE / "bossman/toolkit/__init__.py", CORE / "bossman/agents.py", CORE / "pyproject.toml"]:
    require(p)

# 1. New browser module and tests.
shutil.copy2(PKG / "code/bossman-core/bossman/toolkit/browser.py", CORE / "bossman/toolkit/browser.py")
shutil.copy2(PKG / "code/bossman-core/tests/test_browser_policy.py", CORE / "tests/test_browser_policy.py")

# 2. Register module.
p = CORE / "bossman/toolkit/__init__.py"
s = p.read_text(encoding="utf-8")
if "browser" not in s.split("from . import", 1)[-1]:
    anchor = "from . import files, shell, gitops, journal, net, media, office"
    if anchor not in s:
        raise SystemExit("toolkit import anchor changed; integrate browser manually")
    s = s.replace(anchor, anchor + ", browser")
    p.write_text(s, encoding="utf-8")

# 3. Dependency.
p = CORE / "pyproject.toml"
s = p.read_text(encoding="utf-8")
if '"playwright>=' not in s:
    anchor = '    "pydantic>=2.7",\n'
    if anchor not in s:
        raise SystemExit("pyproject dependency anchor changed; add playwright manually")
    s = s.replace(anchor, anchor + '    "playwright>=1.47",\n')
    p.write_text(s, encoding="utf-8")

# 4. Agent default Browser grants.
p = CORE / "bossman/agents.py"
s = p.read_text(encoding="utf-8")
if "BASE_COMPUTER_USE_TOOLS" not in s:
    anchor = 'CLOUD_POLICIES = ("never", "ask", "allowed")\n'
    block = '''CLOUD_POLICIES = ("never", "ask", "allowed")\n\n# Generic ComputerUse is a core capability for every current/future agent.\n# An agent can opt out with `computer_use: false` in agent.yaml.\nBASE_COMPUTER_USE_TOOLS: tuple[tuple[str, bool | None], ...] = (\n    ("browser.open", None),\n    ("browser.observe", None),\n    ("browser.extract", None),\n    ("browser.screenshot", None),\n    ("browser.wait", None),\n    ("browser.click", None),\n    ("browser.confirmed_click", True),\n    ("browser.type", None),\n    ("browser.press", None),\n    ("browser.select", None),\n    ("browser.download", None),\n    ("browser.close", None),\n)\n'''
    if anchor not in s:
        raise SystemExit("agents.py CLOUD_POLICIES anchor changed; integrate defaults manually")
    s = s.replace(anchor, block)

    fn_anchor = "def load_agent(path: Path) -> AgentSpec:\n"
    helper = '''def _merge_computer_use_tools(grants: list[ToolGrant], enabled: bool) -> list[ToolGrant]:\n    if not enabled:\n        return grants\n    # Manual agent.yaml declaration wins over the default.\n    existing = {g.name for g in grants}\n    merged = list(grants)\n    for name, confirm in BASE_COMPUTER_USE_TOOLS:\n        if name not in existing:\n            merged.append(ToolGrant(name, confirm=confirm))\n    return merged\n\n\n'''
    if fn_anchor not in s:
        raise SystemExit("agents.py load_agent anchor changed; integrate helper manually")
    s = s.replace(fn_anchor, helper + fn_anchor)

    old = '        tools=_parse_tools(cfg.get("tools")),\n'
    new = '        tools=_merge_computer_use_tools(_parse_tools(cfg.get("tools")), bool(cfg.get("computer_use", True))),\n'
    if old not in s:
        raise SystemExit("agents.py tools assignment changed; integrate merge manually")
    s = s.replace(old, new)
    p.write_text(s, encoding="utf-8")

# 5. Documentation.
(ROOT / "docs").mkdir(exist_ok=True)
shutil.copy2(PKG / "docs/GITHUB_REPO_HYGIENE.md", ROOT / "docs/GITHUB_REPO_HYGIENE.md")
shutil.copy2(PKG / "docs/AUDIT_PROTOCOL.md", ROOT / "docs/AUDIT_PROTOCOL.md")

# 6. Gitignore additions, conservative and idempotent.
p = ROOT / ".gitignore"
existing = p.read_text(encoding="utf-8") if p.exists() else ""
block = """\n# Bossman ComputerUse runtime\n.browser-profiles/\nbrowser-profiles/\nplaywright/.auth/\n**/browser-profile/\n**/browser-profiles/\n**/.auth/\n"""
if "# Bossman ComputerUse runtime" not in existing:
    p.write_text(existing.rstrip() + block + "\n", encoding="utf-8")

print("ComputerUse patch applied. NEXT: inspect git diff, install Playwright Chromium, run tests, audit.")
