"""Generic browser / ComputerUse tools for Bossman agents.

Design goals:
- one persistent Chromium profile per agent;
- DOM-first operation, screenshot available for vision fallback;
- no site-specific logic;
- dangerous labels are rejected by browser.click and must use
  browser.confirmed_click, which the toolkit registers with confirmation enabled;
- never bypass CAPTCHAs, rate limits or explicit automation blocks.
"""
from __future__ import annotations

import asyncio
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from . import ToolContext, ToolDef, ToolResult, clip, register

try:
    from playwright.async_api import BrowserContext, Page, Playwright, async_playwright
except Exception:  # pragma: no cover - gives a useful runtime error before install
    BrowserContext = Any  # type: ignore[assignment,misc]
    Page = Any  # type: ignore[assignment,misc]
    Playwright = Any  # type: ignore[assignment,misc]
    async_playwright = None  # type: ignore[assignment]


# Deliberately broad. False positives are safer: model can retry through confirmed_click.
_SENSITIVE = re.compile(
    r"\b("
    r"buy|purchase|checkout|place\s+order|pay|payment|"
    r"send\s+(money|funds|crypto)|transfer|withdraw|withdrawal|"
    r"authorize|authorise|sign\s+(transaction|order|contract)|"
    r"confirm\s+(transaction|payment|purchase|order|transfer|withdrawal)|"
    r"delete|remove\s+permanently|permanent(?:ly)?\s+delete|"
    r"publish|post\s+now|send\s+(message|email)|"
    r"change\s+password|reset\s+password|security\s+settings|"
    r"create\s+api\s+key|revoke\s+api\s+key|close\s+account"
    r")\b",
    re.IGNORECASE,
)

_BLOCKERS = re.compile(
    r"captcha|verify you are human|too many requests|rate limit|"
    r"automation (?:is )?not allowed|bot detected|unusual traffic",
    re.IGNORECASE,
)


def is_sensitive_label(label: str) -> bool:
    return bool(_SENSITIVE.search(label or ""))


def _safe_agent(name: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.-]+", "-", name).strip("-._") or "agent"


def _headless() -> bool:
    return os.environ.get("BOSSMAN_BROWSER_HEADLESS", "0").strip().lower() in {
        "1", "true", "yes", "on"
    }


def profile_root() -> Path:
    raw = os.environ.get("BOSSMAN_BROWSER_PROFILE_ROOT")
    return Path(raw).expanduser().resolve() if raw else (Path.home() / ".bossman" / "browser-profiles")


def profile_path(agent: str) -> Path:
    return profile_root() / _safe_agent(agent)


@dataclass
class Session:
    context: BrowserContext
    page: Page
    refs: dict[str, str] = field(default_factory=dict)  # eN -> CSS-ish selector
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class BrowserManager:
    def __init__(self) -> None:
        self._pw: Playwright | None = None
        self._sessions: dict[str, Session] = {}
        self._start_lock = asyncio.Lock()

    async def _ensure_playwright(self) -> Playwright:
        if async_playwright is None:
            raise RuntimeError(
                "Playwright is not installed. Run: pip install playwright && "
                "python -m playwright install chromium"
            )
        async with self._start_lock:
            if self._pw is None:
                self._pw = await async_playwright().start()
        return self._pw

    async def session(self, agent: str) -> Session:
        existing = self._sessions.get(agent)
        if existing is not None:
            try:
                if not existing.page.is_closed():
                    return existing
            except Exception:
                pass

        pw = await self._ensure_playwright()
        root = profile_path(agent)
        root.mkdir(parents=True, exist_ok=True)
        context = await pw.chromium.launch_persistent_context(
            user_data_dir=str(root),
            headless=_headless(),
            accept_downloads=True,
            viewport={"width": 1440, "height": 1000},
        )
        pages = context.pages
        page = pages[0] if pages else await context.new_page()
        sess = Session(context=context, page=page)
        self._sessions[agent] = sess
        return sess

    async def close(self, agent: str) -> None:
        sess = self._sessions.pop(agent, None)
        if sess is not None:
            await sess.context.close()


MANAGER = BrowserManager()


def _target_selector(sess: Session, target: str) -> tuple[str, str]:
    target = (target or "").strip()
    if not target:
        raise ValueError("target is empty")
    if target.startswith("ref="):
        ref = target[4:]
        selector = sess.refs.get(ref)
        if not selector:
            raise ValueError(f"unknown/stale ref: {ref}; call browser.observe again")
        return selector, target
    if target.startswith("css="):
        return target[4:], target
    if target.startswith("text="):
        text = target[5:]
        # Playwright text locator; exact=False intentionally handles common UI labels.
        return f"text={text}", target
    return target, target


async def _blocker_check(page: Page) -> str | None:
    try:
        body = (await page.locator("body").inner_text(timeout=1500))[:12000]
    except Exception:
        return None
    hit = _BLOCKERS.search(body)
    return hit.group(0) if hit else None


async def _open(args: dict, ctx: ToolContext) -> ToolResult:
    url = str(args.get("url", "")).strip()
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        return ToolResult("refused: browser.open accepts only http/https URLs", error=True)
    sess = await MANAGER.session(ctx.agent)
    async with sess.lock:
        await sess.page.goto(url, wait_until="domcontentloaded", timeout=45_000)
        blocker = await _blocker_check(sess.page)
        text = f"opened: {sess.page.url}\ntitle: {await sess.page.title()}"
        if blocker:
            text += f"\nSTOP condition detected: {blocker}. Do not bypass; ask user."
        return ToolResult(text, one_line=f"browser.open: {sess.page.url}")


async def _observe(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    async with sess.lock:
        page = sess.page
        # Extract a compact inventory of interactive/meaningful elements.
        data = await page.locator(
            "a,button,input,textarea,select,[role=button],[role=link],[contenteditable=true]"
        ).evaluate_all(
            """els => els.slice(0, 180).map((e, i) => ({
              i,
              tag: e.tagName.toLowerCase(),
              text: (e.innerText || e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('placeholder') || '').trim().replace(/\\s+/g,' ').slice(0,160),
              type: e.getAttribute('type') || '',
              name: e.getAttribute('name') || '',
              id: e.id || '',
              disabled: !!e.disabled,
              visible: !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
            })).filter(x => x.visible)"""
        )
        sess.refs.clear()
        lines = [f"url: {page.url}", f"title: {await page.title()}", "interactive:"]
        # Construct selectors using nth-of-type-independent locator indexes within the same query.
        query = "a,button,input,textarea,select,[role=button],[role=link],[contenteditable=true]"
        visible_index = 0
        for item in data:
            if not item.get("visible"):
                continue
            ref = f"e{visible_index}"
            # Playwright locator(...).nth(index) cannot be serialized as CSS. Use a private ref token
            # mapped to a locator query + nth encoded for _locator().
            sess.refs[ref] = f"__BOSSMAN_NTH__:{query}:{int(item['i'])}"
            label = item.get("text") or item.get("name") or item.get("id") or "(unlabelled)"
            state = " disabled" if item.get("disabled") else ""
            lines.append(f"{ref} <{item.get('tag')}> {label!r}{state}")
            visible_index += 1
        blocker = await _blocker_check(page)
        if blocker:
            lines.append(f"STOP condition detected: {blocker}. Do not bypass; ask user.")
        content, truncated = clip("\n".join(lines), 3500)
        return ToolResult(content, one_line=f"browser.observe: {page.url}", truncated=truncated,
                          more="call browser.observe after narrowing/navigating" if truncated else "")


def _locator(page: Page, selector: str):
    prefix = "__BOSSMAN_NTH__:"
    if selector.startswith(prefix):
        rest = selector[len(prefix):]
        query, idx = rest.rsplit(":", 1)
        return page.locator(query).nth(int(idx))
    if selector.startswith("text="):
        return page.get_by_text(selector[5:], exact=False).first
    return page.locator(selector).first


async def _label_for(page: Page, selector: str) -> str:
    loc = _locator(page, selector)
    try:
        return ((await loc.inner_text(timeout=1200)) or
                (await loc.get_attribute("aria-label")) or
                (await loc.get_attribute("title")) or "")[:300]
    except Exception:
        return ""


async def _click_impl(args: dict, ctx: ToolContext, confirmed: bool) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    async with sess.lock:
        selector, shown = _target_selector(sess, str(args.get("target", "")))
        label = await _label_for(sess.page, selector)
        combined = f"{shown} {label}"
        if not confirmed and is_sensitive_label(combined):
            return ToolResult(
                "refused: target appears externally consequential or destructive "
                f"({label or shown!r}). Use browser.confirmed_click so Bossman asks for approval.",
                one_line="browser.click: refused sensitive target",
                error=True,
            )
        await _locator(sess.page, selector).click(timeout=15_000)
        await sess.page.wait_for_timeout(250)
        blocker = await _blocker_check(sess.page)
        out = f"clicked: {label or shown}\nurl: {sess.page.url}"
        if blocker:
            out += f"\nSTOP condition detected: {blocker}. Do not bypass; ask user."
        return ToolResult(out, one_line=f"browser.click: {label or shown}")


async def _click(args: dict, ctx: ToolContext) -> ToolResult:
    return await _click_impl(args, ctx, confirmed=False)


async def _confirmed_click(args: dict, ctx: ToolContext) -> ToolResult:
    return await _click_impl(args, ctx, confirmed=True)


async def _type(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    async with sess.lock:
        selector, shown = _target_selector(sess, str(args.get("target", "")))
        text = str(args.get("text", ""))
        loc = _locator(sess.page, selector)
        if bool(args.get("clear", True)):
            await loc.fill(text, timeout=15_000)
        else:
            await loc.type(text, timeout=15_000)
        return ToolResult(f"typed {len(text)} chars into {shown}", one_line="browser.type: done")


async def _press(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    key = str(args.get("key", "")).strip()
    if not key:
        return ToolResult("key is empty", error=True)
    async with sess.lock:
        await sess.page.keyboard.press(key)
        return ToolResult(f"pressed: {key}", one_line=f"browser.press: {key}")


async def _select(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    async with sess.lock:
        selector, shown = _target_selector(sess, str(args.get("target", "")))
        value = str(args.get("value", ""))
        selected = await _locator(sess.page, selector).select_option(value=value)
        return ToolResult(f"selected {selected} in {shown}", one_line="browser.select: done")


async def _wait(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    timeout_ms = max(0, min(int(args.get("timeout_ms", 10_000)), 60_000))
    text = str(args.get("text", "")).strip()
    selector_raw = str(args.get("selector", "")).strip()
    async with sess.lock:
        if text:
            await sess.page.get_by_text(text, exact=False).first.wait_for(timeout=timeout_ms)
            detail = f"text appeared: {text}"
        elif selector_raw:
            selector, _ = _target_selector(sess, selector_raw)
            await _locator(sess.page, selector).wait_for(timeout=timeout_ms)
            detail = f"selector appeared: {selector_raw}"
        else:
            await sess.page.wait_for_timeout(timeout_ms)
            detail = f"waited {timeout_ms} ms"
        blocker = await _blocker_check(sess.page)
        if blocker:
            detail += f"\nSTOP condition detected: {blocker}. Do not bypass; ask user."
        return ToolResult(detail, one_line="browser.wait: done")


async def _extract(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    raw = str(args.get("selector", "")).strip()
    async with sess.lock:
        if raw:
            selector, _ = _target_selector(sess, raw)
            text = await _locator(sess.page, selector).inner_text(timeout=10_000)
        else:
            text = await sess.page.locator("body").inner_text(timeout=10_000)
        content, truncated = clip(text, 4000)
        return ToolResult(content, one_line="browser.extract: done", truncated=truncated,
                          more="use a narrower selector" if truncated else "")


async def _screenshot(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    dest = ctx.workdir / "screenshots"
    dest.mkdir(parents=True, exist_ok=True)
    # run_id keeps names deterministic enough and avoids leaking page titles into filenames.
    stamp = f"run-{ctx.run_id or 0}-{int(asyncio.get_running_loop().time() * 1000)}.png"
    path = dest / stamp
    async with sess.lock:
        await sess.page.screenshot(path=str(path), full_page=bool(args.get("full_page", False)))
    return ToolResult(f"screenshot: {path}", one_line="browser.screenshot: saved")


async def _download(args: dict, ctx: ToolContext) -> ToolResult:
    sess = await MANAGER.session(ctx.agent)
    dest = ctx.workdir / "downloads"
    dest.mkdir(parents=True, exist_ok=True)
    async with sess.lock:
        selector, shown = _target_selector(sess, str(args.get("target", "")))
        async with sess.page.expect_download(timeout=30_000) as info:
            await _locator(sess.page, selector).click(timeout=15_000)
        download = await info.value
        name = Path(download.suggested_filename).name
        path = dest / name
        # Avoid overwriting previous output.
        if path.exists():
            path = dest / f"{path.stem}-{ctx.run_id or 0}{path.suffix}"
        await download.save_as(str(path))
        return ToolResult(f"downloaded: {path}\nsource target: {shown}", one_line=f"browser.download: {name}")


async def _close(args: dict, ctx: ToolContext) -> ToolResult:
    await MANAGER.close(ctx.agent)
    return ToolResult("browser context closed; persistent profile retained", one_line="browser.close: done")


_TARGET = {"type": "string", "description": "css=..., text=..., ref=eN from browser.observe, or raw selector"}

register(ToolDef(
    name="browser.open", description="Open an http/https URL in the agent's persistent Chromium profile.",
    rights="read", handler=_open, params={"url": {"type": "string"}}, required=["url"], token_limit=800,
))
register(ToolDef(
    name="browser.observe", description="Inspect current page and list compact interactive elements with refs.",
    rights="read", handler=_observe, params={}, token_limit=3500,
))
register(ToolDef(
    name="browser.extract", description="Extract visible text from the page or a target selector.",
    rights="read", handler=_extract, params={"selector": _TARGET}, token_limit=4000,
))
register(ToolDef(
    name="browser.screenshot", description="Save a PNG screenshot in the agent workspace for vision/debugging.",
    rights="read", handler=_screenshot,
    params={"full_page": {"type": "boolean", "default": False}}, token_limit=500,
))
register(ToolDef(
    name="browser.wait", description="Wait up to 60s for text/selector or a bounded time, then re-check stop conditions.",
    rights="read", handler=_wait,
    params={"timeout_ms": {"type": "integer", "minimum": 0, "maximum": 60000},
            "text": {"type": "string"}, "selector": _TARGET}, token_limit=500,
))
register(ToolDef(
    name="browser.click", description="Click a normal UI target. Refuses likely payment/delete/publish/transfer actions.",
    rights="write", handler=_click, params={"target": _TARGET}, required=["target"], token_limit=700,
))
register(ToolDef(
    name="browser.confirmed_click", description="Click an externally consequential/destructive target after user approval.",
    rights="write", handler=_confirmed_click, params={"target": _TARGET}, required=["target"],
    confirm_default=True, token_limit=700,
))
register(ToolDef(
    name="browser.type", description="Fill or type text into a page field; does not submit the form.",
    rights="write", handler=_type,
    params={"target": _TARGET, "text": {"type": "string"}, "clear": {"type": "boolean", "default": True}},
    required=["target", "text"], token_limit=500,
))
register(ToolDef(
    name="browser.press", description="Press a keyboard key in the current page (e.g. Escape, ArrowDown).",
    rights="write", handler=_press, params={"key": {"type": "string"}}, required=["key"], token_limit=300,
))
register(ToolDef(
    name="browser.select", description="Select an option by value in a select element.",
    rights="write", handler=_select, params={"target": _TARGET, "value": {"type": "string"}},
    required=["target", "value"], token_limit=500,
))
register(ToolDef(
    name="browser.download", description="Click a download target and save the file in the agent workspace.",
    rights="write", handler=_download, params={"target": _TARGET}, required=["target"], token_limit=500,
))
register(ToolDef(
    name="browser.close", description="Close this agent's browser context while retaining its persistent login profile.",
    rights="exec", handler=_close, params={}, token_limit=300,
))
