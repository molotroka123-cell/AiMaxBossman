from pathlib import Path

from bossman.toolkit.browser import is_sensitive_label, profile_path


def test_sensitive_labels():
    positives = [
        "Pay now",
        "Delete account",
        "Publish",
        "Confirm transaction",
        "Withdraw funds",
        "Place order",
        "Change password",
    ]
    for label in positives:
        assert is_sensitive_label(label), label


def test_normal_labels_are_not_sensitive():
    for label in ["Next", "Generate", "Open project", "Download", "Preview", "Save draft"]:
        assert not is_sensitive_label(label), label


def test_profile_is_agent_isolated(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("BOSSMAN_BROWSER_PROFILE_ROOT", str(tmp_path))
    a = profile_path("analyst")
    b = profile_path("coder")
    assert a != b
    assert a.parent == tmp_path.resolve()
    assert b.parent == tmp_path.resolve()
