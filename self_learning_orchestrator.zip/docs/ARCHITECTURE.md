# Self-Learning Orchestrator — Архитектура

## Принцип

Runtime-агент никогда не меняет собственное поведение напрямую. Он только производит
traces (записи выполнения). Всё остальное — отдельный, изолированный, evidence-gated
контур, который читает traces batch'ами, находит устойчивые паттерны, предлагает
изменения, проверяет их на benchmark/holdout и только после этого продвигает их в
production через версионирование и canary rollout.

## Слои и поток данных

```
Runtime Agent (bossman-core)
      │  (после каждого run)
      ▼
[1] TRACE  ───────────────► traces (Postgres)
      │  (batch, по расписанию, не на каждый run)
      ▼
[2] EVAL   ───────────────► evals (rule-based + LLM judge)
      │
      ▼
[3] PATTERN MINER  ───────► сгруппировать failure_tags, min_support >= 3
      │
      ▼
[4] REFLECT (synthesizer) ─► reflections (структурированные "уроки", pgvector embedding)
      │
      ▼
[5] IMPROVE (candidate_generator) ► candidates (prompt / memory / tool_policy / workflow / skill_code)
      │
      ▼
[6] VALIDATE (harness)   ─► validation_reports (benchmark + holdout сравнение)
      │
      ▼
[7] GATE (decision)      ─► AUTO / ASK / DENY
      │             │              │
      │        approval_requests   │
      │             │              │
      ▼             ▼              ▼
   promote      wait human      reject
      │
      ▼
[8] VERSION + CANARY (agent_versions) ─► canary traffic % ─► monitor ─► activate / rollback
```

## Почему batch, а не per-request

Если reflection/improve запускать на каждый ответ агента, система будет реагировать на
шум, а не на сигнал. Batch-обработка (по расписанию, раз в N часов или после M новых
traces) даёт статистическую устойчивость: паттерн должен повториться минимум 3 раза
(MIN_SUPPORT), прежде чем система вообще начнёт его обсуждать.

## Категории изменений и риск

| Категория | Что меняет | Риск | Дефолтный gate |
|---|---|---|---|
| prompt | Добавляет правило в system prompt | Низкий | AUTO (если confidence высокий) |
| memory | Правило записи/чтения памяти | Низкий-средний | AUTO/ASK |
| tool_policy | Порядок/выбор инструментов | Средний | ASK |
| workflow | Граф шагов агента | Средний-высокий | ASK |
| skill_code | Изменение кода/навыка | Высокий | Всегда тикет человеку/dev-агенту, никогда авто-diff |

## Canary и rollback

Каждая продвинутая версия сначала получает canary_pct трафика (по умолчанию 10%).
Отдельный scheduled job (canary monitor, не включён в MVP-код, добавляется отдельно)
сравнивает live-метрики canary vs baseline за окно наблюдения и решает:
activate_version() (сделать основной) или rollback_version() (откатить и заморозить
candidate как rejected).

## Валидация: benchmark vs holdout

- **benchmark** — набор задач, на которых мы явно тестируем; допустимо, что reflection
  был вдохновлён похожими traces.
- **holdout** — набор задач, который НЕ участвовал в обучении/reflection. Если
  candidate улучшает benchmark, но проседает на holdout — это overfitting на
  конкретные traces, и он должен быть rejected.

## Безопасность и governance

- Никакая автоматика не трогает runtime напрямую — только versioned config.
- skill_code изменения никогда не генерируются как автоматический diff — только как
  структурированный тикет для человека или dev-агента с последующей повторной
  валидацией через тот же pipeline.
- approval_requests — таблица для UI Bossman Command Center: показывать pending
  approvals с diff_description, validation report, категорией риска.
- Все версии неизменяемы (append-only) — rollback это создание новой активной
  версии = предыдущий parent, а не удаление истории.

## Интеграционные точки с bossman-core

1. Runtime агента должен вызывать `POST /traces` после каждого task run (или писать
   в общую шину/очередь, откуда SLO читает).
2. Command Center UI должен иметь страницу approvals, читающую `approval_requests` и
   вызывающую `POST /approvals/decide`.
3. `run_benchmark()` в `validate/harness.py` — единственная функция-заглушка,
   которую нужно подключить к реальному test harness bossman-core
   (`cd command-center && python -m pytest` эквивалент, но для агентных задач).
4. Активная версия (`agent_versions.is_active = true`) должна читаться runtime-слоем
   при старте каждой сессии агента и применяться как system prompt / policy overlay.
