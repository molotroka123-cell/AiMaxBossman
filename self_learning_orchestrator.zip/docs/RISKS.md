# Риски self-learning orchestrator и митигации

| Риск | Описание | Митигация |
|---|---|---|
| Reward hacking | Агент/judge находит способ повышать composite_score без реального улучшения | Разделение rule-based и judge весов; периодический ручной аудит топ reflections |
| Overfitting на traces | Candidate хорошо работает только на traces, которые его вызвали | Обязательный holdout-набор, не пересекающийся с evidence_trace_ids |
| Runaway recursion | Improvement loop генерирует изменения быстрее, чем можно проверить | max_reflection_batch, MIN_SUPPORT=3, cron interval (не event-driven) |
| Ложные "уроки" | LLM synthesizer придумывает правило не по делу | confidence threshold >=0.6 для активации; ASK gate для tool_policy/workflow |
| Скрытая деградация safety/cost | Candidate улучшает качество, но ломает cost/latency budget | ValidationReport.cost_delta_pct/latency_delta_pct обязательны перед promote |
| Неаудируемые изменения | Никто не понимает, почему агент стал вести себя иначе | agent_versions append-only + reflection_ids + diff_description на каждый candidate |
