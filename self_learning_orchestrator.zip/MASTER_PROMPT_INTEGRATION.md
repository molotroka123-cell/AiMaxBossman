# MASTER PROMPT: Внедрение Self-Learning Orchestrator в AiMaxBossman Core

Скопируй этот промпт целиком в Claude Code (или другого dev-агента), находясь в
корне репозитория `molotroka123-cell/AiMaxBossman`, в отдельной ветке
`claude/self-learning-orchestrator`.

---

## КОНТЕКСТ

В репозитории уже есть рабочий control plane `command-center` (Bossman Control v0.3+),
агентный runtime с tool calling, память, снапшоты и AUTO/ASK/DENY права доступа
(см. `docs/context/CURRENT_STATE.md` и `docs/V2_1_*`). Нужно добавить новый модуль
`bossman-core/self_learning_orchestrator/` (SLO) — evidence-gated контур
самообучения агентов, который: записывает traces выполнения → оценивает их →
находит устойчивые паттерны ошибок/успехов → синтезирует reflections → генерирует
candidate changes → валидирует на benchmark/holdout → продвигает через gate
(AUTO/ASK/DENY) с canary rollout и rollback.

Полная база уже подготовлена в архиве `self_learning_orchestrator.zip` (структура,
код, миграции, тесты, docs/ARCHITECTURE.md, docs/RISKS.md). Твоя задача — не писать
всё с нуля, а:

1. Распаковать и интегрировать этот модуль в существующую архитектуру `bossman-core`.
2. Подключить недостающие места (отмечены `NotImplementedError` / TODO).
3. Соединить SLO с реальным runtime и Command Center UI.
4. Прогнать тесты и зафиксировать коммит с чётким сообщением и номером.

---

## ШАГИ ВНЕДРЕНИЯ

### Шаг 1 — Распаковка и размещение
- Распакуй `self_learning_orchestrator.zip` в `bossman-core/self_learning_orchestrator/`.
- Проверь, что структура директорий не конфликтует с существующими модулями
  `bossman-core/*`. Если есть конфликт имён (`config.py`, `models.py`), переименуй
  пакет в `slo_orchestrator` и обнови импорты.

### Шаг 2 — Зависимости и окружение
- Добавь зависимости из `requirements.txt` SLO в основной `pyproject.toml`/
  `requirements.txt` bossman-core (или создай отдельный extras-группу `[project.optional-dependencies] slo = [...]`).
- Прогони `docker compose -f self_learning_orchestrator/docker-compose.yml up -d`
  либо интегрируй Postgres+pgvector/Redis сервисы SLO в существующий
  `bossman-infra` compose (LiteLLM, llama-swap, Postgres+pgvector, Redis, Open WebUI,
  Uptime Kuma) — предпочтительно объединить в один compose, чтобы не плодить
  отдельные инстансы Postgres.
- Скопируй `.env.example` в `.env`, заполни `DATABASE_URL`, `ANTHROPIC_API_KEY`,
  `OPENAI_API_KEY` реальными значениями из существующей конфигурации bossman-core
  (не хардкодь секреты в коде — используй тот же секрет-менеджмент, что уже принят
  в проекте).

### Шаг 3 — Применить миграции
```bash
cd bossman-core/self_learning_orchestrator
python -m migrations.run
```
Убедись, что таблицы `traces`, `evals`, `reflections`, `candidates`,
`validation_reports`, `agent_versions`, `approval_requests` созданы. Если в проекте
уже есть Alembic — перепиши `migrations/001_init.sql` в Alembic revision вместо
прямого SQL-раннера.

### Шаг 4 — Подключить TraceRecorder к runtime
- Найди в `bossman-core` основной цикл выполнения агента (agent run loop, вероятно
  в `bossman-core/` рядом с логикой AUTO/ASK/DENY прав).
- После завершения каждого task run вызови:
```python
from self_learning_orchestrator.orchestrator.trace.recorder import TraceRecorder
from self_learning_orchestrator.orchestrator.store.repository import TraceRepository
from self_learning_orchestrator.orchestrator.models import TraceRecord

recorder = TraceRecorder(TraceRepository())
await recorder.record(TraceRecord(
    agent_id=agent.id,
    task_id=task.id,
    session_id=session.id,
    input_prompt=task.input,
    plan=agent.last_plan,
    tool_calls=[...],       # смапь реальные tool calls агента в ToolCall
    output=agent.last_output,
    status=...,             # success/failure/partial/error
    cost_usd=...,
    latency_ms=...,
))
```
- Это **write-only** вызов — не должен блокировать основной runtime; сделай его
  fire-and-forget (background task / очередь), чтобы latency агента не страдала.

### Шаг 5 — Заполнить NotImplementedError в validate/harness.py
- Функция `run_benchmark()` сейчас заглушка. Подключи её к существующему тест-
  харнессу bossman-core (`cd command-center && timeout 900 python -u -m pytest -q`
  эквивалент, но для агентных задач — вероятно, нужен отдельный набор
  agent-benchmark задач с эталонными ответами).
- Создай два датасета: `benchmark_v1` (задачи, на которых мы явно тестируем
  изменения) и `holdout_v1` (задачи, НЕ пересекающиеся с evidence_trace_ids,
  использованными для reflection). Без holdout gate валидации бессмысленен —
  не пропускай этот шаг.

### Шаг 6 — Подключить embeddings и judge к реальным ключам
- `orchestrator/memory/embeddings.py` и `orchestrator/eval/judge.py` /
  `orchestrator/reflect/synthesizer.py` сейчас с пустым `Authorization`/`x-api-key`.
  Подключи реальные ключи через переменные окружения, НЕ хардкодь их в коде.
- Если в проекте уже есть LiteLLM как единая точка доступа к моделям — маршрутизируй
  judge/embedding вызовы через LiteLLM вместо прямых вызовов Anthropic/OpenAI API,
  это соответствует существующей инфраструктуре `bossman-infra`.

### Шаг 7 — Command Center UI: approvals
- Добавь страницу/панель в Command Center dashboard, которая:
  - Читает `GET` эндпоинт (добавь его в `orchestrator/api/main.py`) со списком
    pending `approval_requests` (join с `candidates` и `validation_reports`).
  - Показывает `diff_description`, `category`, `validation.recommendation`,
    `benchmark_score_before/after`, `holdout_score_before/after`.
  - Кнопки Approve/Deny вызывают `POST /approvals/decide`.
- Реализуй `POST /approvals/decide` полностью (сейчас `raise HTTPException(501)` —
  замени на реальный вызов `GateController.promote()` при approved=True и
  `status=rejected` при approved=False.

### Шаг 8 — Canary monitor (недостающий компонент)
- Добавь `orchestrator/gate/canary_monitor.py` — scheduled job (через тот же
  APScheduler `scheduler.py`), который раз в N минут:
  - Смотрит traces за canary-версией (нужно протаскивать `version_id` в
    `TraceRecord.metadata` при записи).
  - Сравнивает средний composite_score/cost/latency canary vs baseline.
  - При выполнении критерия успеха (например improvement >= promotion_min_improvement_pct
    в течение минимального количества сэмплов) вызывает `gate.finalize_canary(version_id, success=True)`.
  - При деградации — `finalize_canary(version_id, success=False)` (rollback).

### Шаг 9 — Подключить активную версию к runtime
- При старте каждой сессии агента runtime должен читать
  `agent_versions WHERE agent_id = ... AND is_active = true` и применять
  `payload` как overlay:
  - `type: prompt_append` → добавить текст к system prompt.
  - `type: memory_policy_rule` → зарегистрировать правило в memory-слое.
  - `type: tool_policy_patch` → применить к tool selection logic.
  - `type: workflow_graph_patch` → применить к workflow graph агента.

### Шаг 10 — Тесты и коммит
```bash
cd bossman-core/self_learning_orchestrator
pip install -e .
python -m pytest -q
```
Убедись, что все тесты зелёные, затем:
```bash
git checkout -b claude/self-learning-orchestrator
git add bossman-core/self_learning_orchestrator
git commit -m "feat(slo): add self-learning orchestrator (trace/eval/reflect/improve/validate/gate)

- New module bossman-core/self_learning_orchestrator with 8-layer pipeline
- Postgres+pgvector schema for traces/evals/reflections/candidates/versions
- FastAPI surface + APScheduler periodic cycle trigger
- Evidence-gated: batch pattern mining (min_support=3), holdout validation, canary rollout
- skill_code changes always raised as human/dev-agent tickets, never auto-diffed
- TODO follow-up: wire run_benchmark() to real agent benchmark harness (see docs/ARCHITECTURE.md)"
git push origin claude/self-learning-orchestrator
```
Открой PR с описанием, ссылающимся на `docs/ARCHITECTURE.md` и `docs/RISKS.md` из
модуля — это должно стать частью ревью-чеклиста.

---

## КРИТЕРИИ ГОТОВНОСТИ (Definition of Done)

- [ ] Модуль лежит в `bossman-core/self_learning_orchestrator/`, импортируется без конфликтов.
- [ ] Миграции применены, таблицы существуют в общей Postgres+pgvector базе bossman-infra.
- [ ] Runtime агента пишет traces через TraceRecorder после каждого run, неблокирующим образом.
- [ ] `run_benchmark()` подключён к реальным benchmark_v1/holdout_v1 датасетам, `NotImplementedError` больше нет.
- [ ] Judge/embedding вызовы маршрутизируются через существующую модель-инфраструктуру (LiteLLM или прямые ключи из secret-менеджмента), без хардкода.
- [ ] Command Center UI показывает pending approvals и умеет Approve/Deny.
- [ ] Реализован `canary_monitor.py`, подключён к scheduler.
- [ ] Runtime применяет `is_active=true` версию как overlay при старте сессии агента.
- [ ] `python -m pytest -q` зелёный для модуля SLO.
- [ ] Коммит и PR созданы в ветке `claude/self-learning-orchestrator` с сообщением из Шага 10.
- [ ] Ни одно изменение поведения агента не применяется без прохождения gate (AUTO только для category=prompt/memory с высоким confidence, ASK для tool_policy/workflow, всегда тикет для skill_code).

Если что-то из шагов 5-9 требует архитектурных решений, которых нет в текущем
bossman-core (например, отсутствует единый agent run loop с явной точкой "task
завершён") — остановись и сформулируй короткий ADR (Architecture Decision Record)
в `docs/adr/` перед тем как продолжать, вместо того чтобы гадать.
