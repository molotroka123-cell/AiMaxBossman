# Self-Learning Orchestrator (SLO) — Bossman Core Module

Автономный контур улучшения агентов: trace -> eval -> reflect -> improve -> validate -> gate -> promote.

## Слои

1. **trace** — запись всех запусков агента (вход, действия, tool calls, вывод, cost, latency).
2. **eval** — оценка качества запуска (rule-based, tests, LLM-judge, business metrics).
3. **memory** — episodic + semantic + reflections (структурированные "уроки").
4. **reflect** — синтез повторяющихся failure/success паттернов в структурированные learnings.
5. **improve** — генерация кандидатных изменений (prompt patch, memory rule, tool policy, workflow patch).
6. **validate** — прогон кандидата на benchmark/holdout, safety/cost/latency проверки.
7. **gate** — approval workflow (AUTO/ASK/DENY), версионирование, canary rollout, rollback.
8. **store** — Postgres+pgvector схема для traces/evals/reflections/candidates/versions.
9. **api** — FastAPI-роуты для интеграции с bossman-core control plane.

## Быстрый старт

```bash
cd self_learning_orchestrator
pip install -r requirements.txt
cp .env.example .env
docker compose up -d          # postgres+pgvector, redis
python -m migrations.run       # применить схему
uvicorn orchestrator.api.main:app --reload --port 8801
```

## Принцип

Никакое изменение поведения агента не применяется в runtime напрямую.
Runtime только производит traces. Все изменения проходят gate: evidence -> validation -> approval -> versioned promotion.
Это описано подробно в docs/ARCHITECTURE.md и в MASTER_PROMPT_INTEGRATION.md (корневой файл проекта, для вставки в Claude Code/Bossman Core).
