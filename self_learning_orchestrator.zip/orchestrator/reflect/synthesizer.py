"""
Reflection synthesizer: turns a mined pattern (tag + evidence traces) into a
structured, testable rule using an LLM call. Output feeds directly into the
CandidateChange generator in improve/.
"""
import json
import httpx
from orchestrator.config import settings
from orchestrator.models import ReflectionRecord, TraceRecord

SYNTH_SYSTEM_PROMPT = """You convert recurring agent failure patterns into a single,
concrete, testable rule. Be specific and actionable, not generic advice.
Return ONLY JSON: {"pattern_summary": string, "derived_rule": string, "category": string, "confidence": float}.
category must be one of: prompt, memory, tool_policy, workflow, skill_code."""


async def synthesize_reflection(agent_id: str, tag: str, evidence_traces: list[TraceRecord]) -> ReflectionRecord:
    examples = "\n---\n".join(
        f"INPUT: {t.input_prompt}\nOUTPUT: {t.output}\nSTATUS: {t.status}" for t in evidence_traces[:5]
    )
    user_content = f"Failure tag observed {len(evidence_traces)} times: {tag}\n\nExamples:\n{examples}"

    payload = {
        "model": settings.llm_judge_model,
        "max_tokens": 400,
        "system": SYNTH_SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_content}],
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            json=payload,
            headers={"x-api-key": "", "anthropic-version": "2023-06-01"},
        )
        resp.raise_for_status()
        parsed = json.loads(resp.json()["content"][0]["text"])

    return ReflectionRecord(
        agent_id=agent_id,
        pattern_summary=parsed["pattern_summary"],
        evidence_trace_ids=[t.trace_id for t in evidence_traces],
        derived_rule=parsed["derived_rule"],
        confidence=float(parsed["confidence"]),
        category=parsed["category"],
    )
