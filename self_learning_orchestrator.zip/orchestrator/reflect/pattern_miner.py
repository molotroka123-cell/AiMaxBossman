"""
Failure/success pattern mining: groups eval failure_tags across a batch of traces
to find *recurring* issues rather than one-off noise. Minimum support threshold
avoids reacting to single incidents.
"""
from collections import Counter
from orchestrator.models import EvalResult

MIN_SUPPORT = 3  # a tag must appear at least this many times to be considered a pattern


def mine_patterns(evals: list[EvalResult]) -> dict[str, list[str]]:
    tag_to_traces: dict[str, list[str]] = {}
    for e in evals:
        for tag in e.failure_tags:
            tag_to_traces.setdefault(tag, []).append(e.trace_id)

    counts = Counter({tag: len(ids) for tag, ids in tag_to_traces.items()})
    significant = {tag: tag_to_traces[tag] for tag, c in counts.items() if c >= MIN_SUPPORT}
    return significant
