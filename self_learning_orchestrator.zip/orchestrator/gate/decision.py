"""
Gate layer: final go/no-go for promoting a candidate to a new active version.
Modes:
  AUTO - promote automatically if validation says "promote" (use only for
         low-risk categories like prompt/memory with high confidence).
  ASK  - create an approval request; a human (or Bossman Command Center UI)
         must click approve/deny before promotion.
  DENY - never promote automatically; always requires manual promotion.
"""
from orchestrator.config import settings
from orchestrator.models import CandidateChange, ValidationReport, VersionRecord, GateDecision
from orchestrator.store.repository import VersionRepository

HIGH_RISK_CATEGORIES = {"skill_code", "tool_policy", "workflow"}


def decide_gate_mode(candidate: CandidateChange) -> GateDecision:
    if candidate.category in HIGH_RISK_CATEGORIES:
        return GateDecision.ASK
    return GateDecision(settings.gate_mode)


class GateController:
    def __init__(self, repo: VersionRepository):
        self.repo = repo

    async def process(self, candidate: CandidateChange, report: ValidationReport) -> str:
        if report.recommendation != "promote":
            return "not_promoted"

        mode = decide_gate_mode(candidate)

        if mode == GateDecision.DENY:
            return "denied_by_policy"

        if mode == GateDecision.ASK:
            await self.repo.create_approval_request(candidate, report)
            return "pending_human_approval"

        # AUTO
        return await self.promote(candidate)

    async def promote(self, candidate: CandidateChange) -> str:
        active = await self.repo.get_active_version(candidate.agent_id)
        new_version = VersionRecord(
            agent_id=candidate.agent_id,
            parent_version_id=active.version_id if active else None,
            candidate_id=candidate.candidate_id,
            payload=candidate.proposed_payload,
            is_active=False,
            canary_pct=settings.canary_traffic_pct,
        )
        await self.repo.insert_version(new_version)
        await self.repo.start_canary(new_version.version_id)
        return f"promoted_canary:{new_version.version_id}"

    async def finalize_canary(self, version_id: str, success: bool) -> str:
        if success:
            await self.repo.activate_version(version_id)
            return "activated"
        await self.repo.rollback_version(version_id)
        return "rolled_back"
