"""
Repository layer over Postgres+pgvector. Uses raw SQL via SQLAlchemy core for
transparency and control-plane auditability — every write is explicit.
Schema is defined in migrations/001_init.sql.
"""
import json
from sqlalchemy import text
from orchestrator.store.db import AsyncSessionLocal
from orchestrator.models import (
    TraceRecord, EvalResult, ReflectionRecord, CandidateChange,
    ValidationReport, VersionRecord,
)


class TraceRepository:
    async def insert_trace(self, trace: TraceRecord):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("""INSERT INTO traces (trace_id, agent_id, task_id, session_id,
                        input_prompt, system_prompt_version, plan, tool_calls, output,
                        status, cost_usd, latency_ms, tokens_in, tokens_out, metadata, created_at)
                        VALUES (:trace_id, :agent_id, :task_id, :session_id, :input_prompt,
                        :system_prompt_version, :plan, :tool_calls, :output, :status,
                        :cost_usd, :latency_ms, :tokens_in, :tokens_out, :metadata, :created_at)"""),
                {
                    **trace.model_dump(exclude={"tool_calls", "metadata"}),
                    "tool_calls": json.dumps([tc.model_dump() for tc in trace.tool_calls], default=str),
                    "metadata": json.dumps(trace.metadata, default=str),
                },
            )
            await session.commit()

    async def get_trace(self, trace_id: str):
        async with AsyncSessionLocal() as session:
            result = await session.execute(text("SELECT * FROM traces WHERE trace_id = :id"), {"id": trace_id})
            return result.mappings().first()

    async def list_traces(self, agent_id: str, limit: int = 100):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                text("SELECT * FROM traces WHERE agent_id = :agent_id ORDER BY created_at DESC LIMIT :limit"),
                {"agent_id": agent_id, "limit": limit},
            )
            return result.mappings().all()


class EvalRepository:
    async def insert_eval(self, eval_result: EvalResult):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("""INSERT INTO evals (eval_id, trace_id, rule_based_score, judge_score,
                        judge_rationale, composite_score, failure_tags, created_at)
                        VALUES (:eval_id, :trace_id, :rule_based_score, :judge_score,
                        :judge_rationale, :composite_score, :failure_tags, :created_at)"""),
                {**eval_result.model_dump(exclude={"failure_tags", "business_metric", "passed_tests", "failed_tests"}),
                 "failure_tags": json.dumps(eval_result.failure_tags)},
            )
            await session.commit()

    async def list_recent_evals(self, agent_id: str, limit: int = 200):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                text("""SELECT e.* FROM evals e JOIN traces t ON e.trace_id = t.trace_id
                        WHERE t.agent_id = :agent_id ORDER BY e.created_at DESC LIMIT :limit"""),
                {"agent_id": agent_id, "limit": limit},
            )
            return result.mappings().all()


class MemoryRepository:
    async def insert_reflection(self, reflection: ReflectionRecord):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("""INSERT INTO reflections (reflection_id, agent_id, pattern_summary,
                        evidence_trace_ids, derived_rule, confidence, category, created_at)
                        VALUES (:reflection_id, :agent_id, :pattern_summary, :evidence_trace_ids,
                        :derived_rule, :confidence, :category, :created_at)"""),
                {**reflection.model_dump(exclude={"evidence_trace_ids"}),
                 "evidence_trace_ids": json.dumps(reflection.evidence_trace_ids)},
            )
            await session.commit()

    async def list_reflections(self, agent_id: str, min_confidence: float = 0.0):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                text("""SELECT * FROM reflections WHERE agent_id = :agent_id
                        AND confidence >= :min_confidence ORDER BY created_at DESC"""),
                {"agent_id": agent_id, "min_confidence": min_confidence},
            )
            return result.mappings().all()

    async def vector_search_reflections(self, agent_id: str, embedding: list[float], top_k: int = 5):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                text("""SELECT *, embedding <-> :query_vec AS distance FROM reflections
                        WHERE agent_id = :agent_id ORDER BY distance ASC LIMIT :top_k"""),
                {"agent_id": agent_id, "query_vec": str(embedding), "top_k": top_k},
            )
            return result.mappings().all()


class VersionRepository:
    async def get_active_version(self, agent_id: str):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                text("SELECT * FROM agent_versions WHERE agent_id = :agent_id AND is_active = true LIMIT 1"),
                {"agent_id": agent_id},
            )
            return result.mappings().first()

    async def insert_version(self, version: VersionRecord):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("""INSERT INTO agent_versions (version_id, agent_id, parent_version_id,
                        candidate_id, payload, is_active, canary_pct, created_at)
                        VALUES (:version_id, :agent_id, :parent_version_id, :candidate_id,
                        :payload, :is_active, :canary_pct, :created_at)"""),
                {**version.model_dump(exclude={"payload"}), "payload": json.dumps(version.payload)},
            )
            await session.commit()

    async def start_canary(self, version_id: str):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("UPDATE agent_versions SET canary_started_at = now() WHERE version_id = :id"),
                {"id": version_id},
            )
            await session.commit()

    async def activate_version(self, version_id: str):
        async with AsyncSessionLocal() as session:
            row = await session.execute(text("SELECT agent_id FROM agent_versions WHERE version_id = :id"), {"id": version_id})
            agent_id = row.mappings().first()["agent_id"]
            await session.execute(text("UPDATE agent_versions SET is_active = false WHERE agent_id = :aid"), {"aid": agent_id})
            await session.execute(text("UPDATE agent_versions SET is_active = true WHERE version_id = :id"), {"id": version_id})
            await session.commit()

    async def rollback_version(self, version_id: str):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("UPDATE agent_versions SET is_active = false, rolled_back_at = now() WHERE version_id = :id"),
                {"id": version_id},
            )
            await session.commit()

    async def create_approval_request(self, candidate: CandidateChange, report: ValidationReport):
        async with AsyncSessionLocal() as session:
            await session.execute(
                text("""INSERT INTO approval_requests (candidate_id, report_id, status, created_at)
                        VALUES (:candidate_id, :report_id, 'pending', now())"""),
                {"candidate_id": candidate.candidate_id, "report_id": report.report_id},
            )
            await session.commit()
