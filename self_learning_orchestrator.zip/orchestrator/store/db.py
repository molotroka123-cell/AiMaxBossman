from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from orchestrator.config import settings

engine = create_async_engine(settings.database_url, pool_size=10, max_overflow=20)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_session() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        yield session
