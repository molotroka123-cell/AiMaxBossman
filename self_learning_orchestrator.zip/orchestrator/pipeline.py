"""
The self-learning orchestrator pipeline. This is the top-level coroutine that
ties every layer together. Called on a schedule (e.g. every N hours or after
every M new traces) — NOT on every single agent run.

Flow:
  1. Pull recent traces for agent_id
  2. Evaluate any traces not yet evaluated
  3. Mine recurring failure patterns (min support threshold)
  4. Synthesize reflections for each significant pattern
  5. Generate candidate changes from reflections
  6. Validate each candidate on benchmark + holdout
  7. Gate: auto-promote / ask for approval / reject
  8. Canary monitor (separate scheduled job) decides activate vs rollback
"""
import logging
from orchestrator.config import settings
from orchestrator.models import TraceRecord
from orchestrator.trace.recorder import TraceRecorder
from orchestrator.eval.composite import evaluate_trace
from orchestrator.reflect.pattern_miner import mine_patterns
from orchestrator.reflect.synthesizer import synthesize_reflection
from orchestrator.improve.candidate_generator import generate_candidate
from orchestrator.validate.harness import validate_candidate
from orchestrator.gate.decision import GateController
from orchestrator.store.repository import (
    TraceRepository, EvalRepository, MemoryRepository, VersionRepository,
)

logger = logging.getLogger("slo.pipeline")


class SelfLearningOrchestrator:
    def __init__(self):
        self.trace_repo = TraceRepository()
        self.eval_repo = EvalRepository()
        self.memory_repo = MemoryRepository()
        self.version_repo = VersionRepository()
        self.gate = GateController(self.version_repo)

    async def run_cycle(self, agent_id: str):
        logger.info(f"[SLO] starting improvement cycle for agent={agent_id}")

        traces = await self.trace_repo.list_traces(agent_id, limit=settings.max_reflection_batch)
        if not traces:
            logger.info("[SLO] no traces found, skipping cycle")
            return {"status": "no_traces"}

        evals = []
        for row in traces:
            trace = TraceRecord(**dict(row))
            eval_result = await evaluate_trace(trace, use_judge=True)
            await self.eval_repo.insert_eval(eval_result)
            evals.append(eval_result)

        patterns = mine_patterns(evals)
        if not patterns:
            logger.info("[SLO] no recurring patterns found above support threshold")
            return {"status": "no_patterns", "traces_evaluated": len(evals)}

        results = []
        active_version = await self.version_repo.get_active_version(agent_id)
        base_version = active_version["version_id"] if active_version else "v0"

        for tag, trace_ids in patterns.items():
            evidence_traces = [
                TraceRecord(**dict(row))
                for row in traces
                if row["trace_id"] in trace_ids
            ]

            reflection = await synthesize_reflection(agent_id, tag, evidence_traces)
            await self.memory_repo.insert_reflection(reflection)

            candidate = generate_candidate(reflection, base_version)

            if candidate.category == "skill_code":
                results.append({"tag": tag, "action": "raised_as_ticket", "candidate_id": candidate.candidate_id})
                continue

            report = await validate_candidate(candidate)
            gate_result = await self.gate.process(candidate, report)

            results.append({
                "tag": tag,
                "reflection_id": reflection.reflection_id,
                "candidate_id": candidate.candidate_id,
                "validation": report.recommendation,
                "gate_result": gate_result,
            })

        logger.info(f"[SLO] cycle complete: {results}")
        return {"status": "completed", "traces_evaluated": len(evals), "patterns_found": len(patterns), "results": results}
