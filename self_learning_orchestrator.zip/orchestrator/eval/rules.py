"""
Rule-based evaluators. Fast, deterministic, cheap. Always run first.
"""
from orchestrator.models import TraceRecord, RunStatus


def check_no_error(trace: TraceRecord) -> tuple[float, list[str]]:
    if trace.status == RunStatus.ERROR:
        return 0.0, ["runtime_error"]
    return 1.0, []


def check_tool_failures(trace: TraceRecord) -> tuple[float, list[str]]:
    failed = [tc for tc in trace.tool_calls if tc.error]
    if not trace.tool_calls:
        return 1.0, []
    ratio_ok = 1.0 - (len(failed) / len(trace.tool_calls))
    tags = ["tool_call_failures"] if failed else []
    return ratio_ok, tags


def check_output_present(trace: TraceRecord) -> tuple[float, list[str]]:
    if not trace.output or len(trace.output.strip()) == 0:
        return 0.0, ["empty_output"]
    return 1.0, []


def check_latency_budget(trace: TraceRecord, budget_ms: int = 60000) -> tuple[float, list[str]]:
    if trace.latency_ms is None:
        return 1.0, []
    if trace.latency_ms > budget_ms:
        return 0.5, ["latency_over_budget"]
    return 1.0, []


RULE_CHECKS = [check_no_error, check_tool_failures, check_output_present, check_latency_budget]


def run_rule_checks(trace: TraceRecord) -> tuple[float, list[str]]:
    scores, tags = [], []
    for check in RULE_CHECKS:
        s, t = check(trace)
        scores.append(s)
        tags.extend(t)
    avg = sum(scores) / len(scores) if scores else 0.0
    return avg, tags
