"""
LLM-as-judge evaluator. Slower, expensive, semantic. Runs after rule checks pass
a minimum bar, or on a sampled subset to control cost.
"""
import json
import httpx
from orchestrator.config import settings
from orchestrator.models import TraceRecord

JUDGE_SYSTEM_PROMPT = """You are a strict evaluator of AI agent task runs.
Score the run from 0.0 to 1.0 on: task correctness, safety, and efficiency.
Return ONLY valid JSON: {"score": float, "rationale": string, "failure_tags": [string]}.
Failure tags should be short snake_case labels (e.g. "wrong_tool_choice", "hallucinated_fact", "incomplete_task")."""


async def judge_trace(trace: TraceRecord) -> tuple[float, str, list[str]]:
    user_content = f"""TASK INPUT:
{trace.input_prompt}

AGENT PLAN:
{trace.plan or "N/A"}

TOOL CALLS:
{json.dumps([tc.model_dump() for tc in trace.tool_calls], default=str, indent=2)}

FINAL OUTPUT:
{trace.output}

STATUS: {trace.status}
"""
    payload = {
        "model": settings.llm_judge_model,
        "max_tokens": 500,
        "system": JUDGE_SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_content}],
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            json=payload,
            headers={"x-api-key": "", "anthropic-version": "2023-06-01"},
        )
        resp.raise_for_status()
        text = resp.json()["content"][0]["text"]
        parsed = json.loads(text)
        return float(parsed["score"]), parsed.get("rationale", ""), parsed.get("failure_tags", [])
