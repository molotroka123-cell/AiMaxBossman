"""
Combines rule-based + judge scores into a single composite score and EvalResult.
"""
from orchestrator.models import TraceRecord, EvalResult
from orchestrator.eval.rules import run_rule_checks
from orchestrator.eval.judge import judge_trace

RULE_WEIGHT = 0.4
JUDGE_WEIGHT = 0.6


async def evaluate_trace(trace: TraceRecord, use_judge: bool = True) -> EvalResult:
    rule_score, rule_tags = run_rule_checks(trace)

    judge_score, rationale, judge_tags = None, None, []
    if use_judge and rule_score > 0.0:
        judge_score, rationale, judge_tags = await judge_trace(trace)

    if judge_score is not None:
        composite = RULE_WEIGHT * rule_score + JUDGE_WEIGHT * judge_score
    else:
        composite = rule_score

    return EvalResult(
        trace_id=trace.trace_id,
        rule_based_score=rule_score,
        judge_score=judge_score,
        judge_rationale=rationale,
        composite_score=round(composite, 4),
        failure_tags=list(set(rule_tags + judge_tags)),
    )
