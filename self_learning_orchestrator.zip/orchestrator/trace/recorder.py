"""
Trace layer: records every agent run. Runtime code calls TraceRecorder.record(...)
after each task completes. Nothing here mutates agent behavior — write-only.
"""
from orchestrator.models import TraceRecord
from orchestrator.store.repository import TraceRepository


class TraceRecorder:
    def __init__(self, repo: TraceRepository):
        self.repo = repo

    async def record(self, trace: TraceRecord) -> str:
        await self.repo.insert_trace(trace)
        return trace.trace_id

    async def get(self, trace_id: str) -> TraceRecord | None:
        return await self.repo.get_trace(trace_id)

    async def recent(self, agent_id: str, limit: int = 100) -> list[TraceRecord]:
        return await self.repo.list_traces(agent_id=agent_id, limit=limit)
