"""
FastAPI surface for the Self-Learning Orchestrator. Designed to be mounted
inside Bossman Command Center as a sub-app or called via internal HTTP.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from orchestrator.pipeline import SelfLearningOrchestrator
from orchestrator.scheduler import register_agent_schedule, start as start_scheduler
from orchestrator.trace.recorder import TraceRecorder
from orchestrator.store.repository import TraceRepository
from orchestrator.models import TraceRecord

app = FastAPI(title="Bossman Self-Learning Orchestrator", version="0.1.0")
slo = SelfLearningOrchestrator()
trace_recorder = TraceRecorder(TraceRepository())


@app.on_event("startup")
async def on_startup():
    start_scheduler()


@app.post("/traces")
async def submit_trace(trace: TraceRecord):
    trace_id = await trace_recorder.record(trace)
    return {"trace_id": trace_id}


class CycleRequest(BaseModel):
    agent_id: str


@app.post("/cycle/run")
async def run_cycle(req: CycleRequest):
    result = await slo.run_cycle(req.agent_id)
    return result


class ScheduleRequest(BaseModel):
    agent_id: str
    cron_hours: int = 6


@app.post("/cycle/schedule")
async def schedule_cycle(req: ScheduleRequest):
    register_agent_schedule(req.agent_id, req.cron_hours)
    return {"status": "scheduled", "agent_id": req.agent_id, "every_hours": req.cron_hours}


@app.get("/health")
async def health():
    return {"status": "ok"}


class ApprovalDecision(BaseModel):
    candidate_id: str
    approved: bool


@app.post("/approvals/decide")
async def decide_approval(decision: ApprovalDecision):
    # Wire to GateController.promote / reject depending on decision.approved
    if not decision.approved:
        return {"status": "rejected", "candidate_id": decision.candidate_id}
    raise HTTPException(status_code=501, detail="Wire this endpoint to GateController.promote in production")
