"""
Pydantic schemas shared across the orchestrator layers.
"""
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field
import uuid


def new_id() -> str:
    return str(uuid.uuid4())


class GateDecision(str, Enum):
    AUTO = "AUTO"
    ASK = "ASK"
    DENY = "DENY"


class RunStatus(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    ERROR = "error"


class ToolCall(BaseModel):
    tool_name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    result: Optional[Any] = None
    latency_ms: Optional[int] = None
    error: Optional[str] = None


class TraceRecord(BaseModel):
    trace_id: str = Field(default_factory=new_id)
    agent_id: str
    task_id: str
    session_id: Optional[str] = None
    input_prompt: str
    system_prompt_version: Optional[str] = None
    plan: Optional[str] = None
    tool_calls: list[ToolCall] = Field(default_factory=list)
    output: Optional[str] = None
    status: RunStatus = RunStatus.SUCCESS
    cost_usd: Optional[float] = None
    latency_ms: Optional[int] = None
    tokens_in: Optional[int] = None
    tokens_out: Optional[int] = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class EvalResult(BaseModel):
    eval_id: str = Field(default_factory=new_id)
    trace_id: str
    rule_based_score: Optional[float] = None
    judge_score: Optional[float] = None
    judge_rationale: Optional[str] = None
    passed_tests: Optional[int] = None
    failed_tests: Optional[int] = None
    business_metric: Optional[dict[str, Any]] = None
    composite_score: float
    failure_tags: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ReflectionRecord(BaseModel):
    reflection_id: str = Field(default_factory=new_id)
    agent_id: str
    pattern_summary: str
    evidence_trace_ids: list[str] = Field(default_factory=list)
    derived_rule: str
    confidence: float
    category: str  # "prompt" | "memory" | "tool_policy" | "workflow" | "skill_code"
    created_at: datetime = Field(default_factory=datetime.utcnow)


class CandidateChange(BaseModel):
    candidate_id: str = Field(default_factory=new_id)
    agent_id: str
    category: str
    reflection_ids: list[str] = Field(default_factory=list)
    diff_description: str
    proposed_payload: dict[str, Any]
    base_version: str
    status: str = "pending_validation"  # pending_validation | validated | rejected | promoted | rolled_back
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ValidationReport(BaseModel):
    report_id: str = Field(default_factory=new_id)
    candidate_id: str
    benchmark_score_before: float
    benchmark_score_after: float
    holdout_score_before: float
    holdout_score_after: float
    safety_violations: int = 0
    cost_delta_pct: float = 0.0
    latency_delta_pct: float = 0.0
    recommendation: str = "hold"  # promote | reject | hold
    created_at: datetime = Field(default_factory=datetime.utcnow)


class VersionRecord(BaseModel):
    version_id: str = Field(default_factory=new_id)
    agent_id: str
    parent_version_id: Optional[str] = None
    candidate_id: Optional[str] = None
    payload: dict[str, Any]
    is_active: bool = False
    canary_pct: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
