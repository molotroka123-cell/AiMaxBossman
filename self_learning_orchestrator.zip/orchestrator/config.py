import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    llm_judge_model: str = os.getenv("LLM_JUDGE_MODEL", "claude-opus-4-5")
    llm_judge_provider: str = os.getenv("LLM_JUDGE_PROVIDER", "anthropic")
    gate_mode: str = os.getenv("GATE_MODE", "ASK")  # AUTO | ASK | DENY
    canary_traffic_pct: int = int(os.getenv("CANARY_TRAFFIC_PCT", "10"))
    promotion_min_samples: int = int(os.getenv("PROMOTION_MIN_SAMPLES", "30"))
    promotion_min_improvement_pct: float = float(os.getenv("PROMOTION_MIN_IMPROVEMENT_PCT", "5"))
    max_reflection_batch: int = int(os.getenv("MAX_REFLECTION_BATCH", "200"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

settings = Settings()
