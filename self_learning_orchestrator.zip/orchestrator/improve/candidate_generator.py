"""
Turns validated ReflectionRecords into a concrete CandidateChange payload,
depending on category. Never applied directly — only proposed for validation.
"""
from orchestrator.models import ReflectionRecord, CandidateChange


def build_prompt_patch(reflection: ReflectionRecord, base_version: str) -> CandidateChange:
    payload = {
        "type": "prompt_append",
        "text": f"\n\nLEARNED RULE: {reflection.derived_rule}",
    }
    return CandidateChange(
        agent_id=reflection.agent_id,
        category="prompt",
        reflection_ids=[reflection.reflection_id],
        diff_description=f"Append learned rule to system prompt: {reflection.derived_rule}",
        proposed_payload=payload,
        base_version=base_version,
    )


def build_memory_rule(reflection: ReflectionRecord, base_version: str) -> CandidateChange:
    payload = {
        "type": "memory_policy_rule",
        "rule": reflection.derived_rule,
        "confidence": reflection.confidence,
    }
    return CandidateChange(
        agent_id=reflection.agent_id,
        category="memory",
        reflection_ids=[reflection.reflection_id],
        diff_description=f"Add memory retrieval/write policy: {reflection.derived_rule}",
        proposed_payload=payload,
        base_version=base_version,
    )


def build_tool_policy(reflection: ReflectionRecord, base_version: str) -> CandidateChange:
    payload = {"type": "tool_policy_patch", "rule": reflection.derived_rule}
    return CandidateChange(
        agent_id=reflection.agent_id,
        category="tool_policy",
        reflection_ids=[reflection.reflection_id],
        diff_description=f"Patch tool ordering/selection policy: {reflection.derived_rule}",
        proposed_payload=payload,
        base_version=base_version,
    )


def build_workflow_patch(reflection: ReflectionRecord, base_version: str) -> CandidateChange:
    payload = {"type": "workflow_graph_patch", "rule": reflection.derived_rule}
    return CandidateChange(
        agent_id=reflection.agent_id,
        category="workflow",
        reflection_ids=[reflection.reflection_id],
        diff_description=f"Adjust workflow graph: {reflection.derived_rule}",
        proposed_payload=payload,
        base_version=base_version,
    )


def build_skill_code_ticket(reflection: ReflectionRecord, base_version: str) -> CandidateChange:
    """Skill/code changes are never auto-generated as diffs here — only raised as
    a structured ticket for a human/dev-agent to implement and re-submit."""
    payload = {
        "type": "skill_code_ticket",
        "rule": reflection.derived_rule,
        "requires_human_or_dev_agent": True,
    }
    return CandidateChange(
        agent_id=reflection.agent_id,
        category="skill_code",
        reflection_ids=[reflection.reflection_id],
        diff_description=f"Code-level fix needed: {reflection.derived_rule}",
        proposed_payload=payload,
        base_version=base_version,
    )


GENERATORS = {
    "prompt": build_prompt_patch,
    "memory": build_memory_rule,
    "tool_policy": build_tool_policy,
    "workflow": build_workflow_patch,
    "skill_code": build_skill_code_ticket,
}


def generate_candidate(reflection: ReflectionRecord, base_version: str) -> CandidateChange:
    builder = GENERATORS.get(reflection.category, build_prompt_patch)
    return builder(reflection, base_version)
