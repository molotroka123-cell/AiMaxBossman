"""
APScheduler-based periodic trigger. Runs the improvement cycle per agent on a
cron-like schedule, decoupled from the request/response runtime path.
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from orchestrator.pipeline import SelfLearningOrchestrator

orchestrator = SelfLearningOrchestrator()
scheduler = AsyncIOScheduler()


def register_agent_schedule(agent_id: str, cron_hours: int = 6):
    scheduler.add_job(
        orchestrator.run_cycle,
        "interval",
        hours=cron_hours,
        args=[agent_id],
        id=f"slo_cycle_{agent_id}",
        replace_existing=True,
    )


def start():
    scheduler.start()
