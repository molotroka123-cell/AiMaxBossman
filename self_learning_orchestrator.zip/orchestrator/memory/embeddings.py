"""
Thin embedding client wrapper. Swap provider via config without touching callers.
"""
import httpx
from orchestrator.config import settings


async def embed_text(text: str) -> list[float]:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.openai.com/v1/embeddings",
            json={"model": "text-embedding-3-large", "input": text},
            headers={"Authorization": "Bearer "},
        )
        resp.raise_for_status()
        return resp.json()["data"][0]["embedding"]
