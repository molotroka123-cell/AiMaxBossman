"""
Memory layer: episodic traces, semantic retrieval (pgvector), and reflections.
Three tiers: raw traces -> structured learnings (reflections) -> derived policies (candidate changes).
"""
from orchestrator.models import ReflectionRecord
from orchestrator.store.repository import MemoryRepository


class MemoryStore:
    def __init__(self, repo: MemoryRepository):
        self.repo = repo

    async def save_reflection(self, reflection: ReflectionRecord) -> str:
        await self.repo.insert_reflection(reflection)
        return reflection.reflection_id

    async def search_similar_reflections(self, agent_id: str, query_embedding: list[float], top_k: int = 5):
        return await self.repo.vector_search_reflections(agent_id, query_embedding, top_k)

    async def active_policies(self, agent_id: str) -> list[ReflectionRecord]:
        return await self.repo.list_reflections(agent_id=agent_id, min_confidence=0.6)
