"""
Validation harness: runs the candidate against a fixed benchmark set and a
holdout set NOT used during reflection mining, to avoid overfitting to the
traces that triggered the change. Produces a ValidationReport with a
promote/reject/hold recommendation.
"""
from orchestrator.models import CandidateChange, ValidationReport
from orchestrator.config import settings


async def run_benchmark(agent_id: str, payload: dict, dataset: str) -> float:
    """Placeholder: wire this to your actual benchmark runner (e.g. bossman-core
    test harness). Must return a 0-1 composite score across the dataset."""
    raise NotImplementedError("Wire run_benchmark to your bossman-core eval harness")


async def validate_candidate(candidate: CandidateChange) -> ValidationReport:
    before = await run_benchmark(candidate.agent_id, {}, dataset="benchmark_v1")
    after = await run_benchmark(candidate.agent_id, candidate.proposed_payload, dataset="benchmark_v1")

    holdout_before = await run_benchmark(candidate.agent_id, {}, dataset="holdout_v1")
    holdout_after = await run_benchmark(candidate.agent_id, candidate.proposed_payload, dataset="holdout_v1")

    improvement_pct = ((after - before) / before * 100) if before > 0 else 0.0
    holdout_improvement_pct = ((holdout_after - holdout_before) / holdout_before * 100) if holdout_before > 0 else 0.0

    recommendation = "hold"
    if (
        improvement_pct >= settings.promotion_min_improvement_pct
        and holdout_improvement_pct >= 0
    ):
        recommendation = "promote"
    elif improvement_pct < 0 or holdout_improvement_pct < -2:
        recommendation = "reject"

    return ValidationReport(
        candidate_id=candidate.candidate_id,
        benchmark_score_before=before,
        benchmark_score_after=after,
        holdout_score_before=holdout_before,
        holdout_score_after=holdout_after,
        recommendation=recommendation,
    )
