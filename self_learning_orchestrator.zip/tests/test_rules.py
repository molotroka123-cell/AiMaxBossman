from orchestrator.models import TraceRecord, RunStatus, ToolCall
from orchestrator.eval.rules import run_rule_checks


def test_no_error_pass():
    trace = TraceRecord(agent_id="a1", task_id="t1", input_prompt="x", output="ok", status=RunStatus.SUCCESS)
    score, tags = run_rule_checks(trace)
    assert score == 1.0
    assert tags == []


def test_error_status_fails():
    trace = TraceRecord(agent_id="a1", task_id="t1", input_prompt="x", output="", status=RunStatus.ERROR)
    score, tags = run_rule_checks(trace)
    assert "runtime_error" in tags
    assert score < 1.0


def test_tool_call_failure_detected():
    trace = TraceRecord(
        agent_id="a1", task_id="t1", input_prompt="x", output="ok", status=RunStatus.SUCCESS,
        tool_calls=[ToolCall(tool_name="search", error="timeout")],
    )
    score, tags = run_rule_checks(trace)
    assert "tool_call_failures" in tags
