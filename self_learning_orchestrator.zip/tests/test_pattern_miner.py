from orchestrator.models import EvalResult
from orchestrator.reflect.pattern_miner import mine_patterns


def test_mine_patterns_min_support():
    evals = [
        EvalResult(trace_id=f"t{i}", composite_score=0.5, failure_tags=["tool_call_failures"])
        for i in range(3)
    ] + [
        EvalResult(trace_id="t99", composite_score=0.9, failure_tags=["empty_output"])
    ]
    patterns = mine_patterns(evals)
    assert "tool_call_failures" in patterns
    assert "empty_output" not in patterns  # below MIN_SUPPORT
    assert len(patterns["tool_call_failures"]) == 3
