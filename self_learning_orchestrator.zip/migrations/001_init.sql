-- Self-Learning Orchestrator schema
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS traces (
    trace_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    task_id TEXT NOT NULL,
    session_id TEXT,
    input_prompt TEXT NOT NULL,
    system_prompt_version TEXT,
    plan TEXT,
    tool_calls JSONB DEFAULT '[]',
    output TEXT,
    status TEXT NOT NULL DEFAULT 'success',
    cost_usd NUMERIC,
    latency_ms INTEGER,
    tokens_in INTEGER,
    tokens_out INTEGER,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_traces_agent_id ON traces (agent_id, created_at DESC);

CREATE TABLE IF NOT EXISTS evals (
    eval_id TEXT PRIMARY KEY,
    trace_id TEXT NOT NULL REFERENCES traces(trace_id),
    rule_based_score NUMERIC,
    judge_score NUMERIC,
    judge_rationale TEXT,
    composite_score NUMERIC NOT NULL,
    failure_tags JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_evals_trace_id ON evals (trace_id);

CREATE TABLE IF NOT EXISTS reflections (
    reflection_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    pattern_summary TEXT NOT NULL,
    evidence_trace_ids JSONB DEFAULT '[]',
    derived_rule TEXT NOT NULL,
    confidence NUMERIC NOT NULL,
    category TEXT NOT NULL,
    embedding VECTOR(1536),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_reflections_agent_id ON reflections (agent_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reflections_embedding ON reflections USING hnsw (embedding vector_l2_ops);

CREATE TABLE IF NOT EXISTS candidates (
    candidate_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    category TEXT NOT NULL,
    reflection_ids JSONB DEFAULT '[]',
    diff_description TEXT NOT NULL,
    proposed_payload JSONB NOT NULL,
    base_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending_validation',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS validation_reports (
    report_id TEXT PRIMARY KEY,
    candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),
    benchmark_score_before NUMERIC,
    benchmark_score_after NUMERIC,
    holdout_score_before NUMERIC,
    holdout_score_after NUMERIC,
    safety_violations INTEGER DEFAULT 0,
    cost_delta_pct NUMERIC DEFAULT 0,
    latency_delta_pct NUMERIC DEFAULT 0,
    recommendation TEXT NOT NULL DEFAULT 'hold',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_versions (
    version_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    parent_version_id TEXT,
    candidate_id TEXT REFERENCES candidates(candidate_id),
    payload JSONB NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT false,
    canary_pct INTEGER DEFAULT 0,
    canary_started_at TIMESTAMPTZ,
    rolled_back_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_versions_agent_id ON agent_versions (agent_id, is_active);

CREATE TABLE IF NOT EXISTS approval_requests (
    id SERIAL PRIMARY KEY,
    candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),
    report_id TEXT NOT NULL REFERENCES validation_reports(report_id),
    status TEXT NOT NULL DEFAULT 'pending',
    decided_by TEXT,
    decided_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
