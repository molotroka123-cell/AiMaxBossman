"""Apply migrations/*.sql in order against DATABASE_URL (sync psycopg2 for simplicity)."""
import glob
import os
import psycopg2
from orchestrator.config import settings

def main():
    sync_url = settings.database_url.replace("postgresql+asyncpg://", "postgresql://")
    conn = psycopg2.connect(sync_url)
    conn.autocommit = True
    cur = conn.cursor()
    for path in sorted(glob.glob(os.path.join(os.path.dirname(__file__), "*.sql"))):
        print(f"Applying {path}")
        with open(path) as f:
            cur.execute(f.read())
    print("All migrations applied.")

if __name__ == "__main__":
    main()
