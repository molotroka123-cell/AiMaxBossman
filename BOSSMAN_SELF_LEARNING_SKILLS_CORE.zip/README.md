# BOSSMAN Self-Learning Skills Core

This pack adds the missing durable/self-improvement skills to the existing
AiMaxBossman skill set.

Existing repository skills observed before this pack:

- browser-research
- model-eval
- night-mission
- openrouter-sync
- repo-audit
- safe-code-change
- safe-terminal
- skill-forge

This pack adds:

1. memory-recall
2. memory-curator
3. context-builder
4. failure-retrospective
5. skill-evaluator
6. permission-auditor
7. proof-before-done

After merge the recommended core is **15 skills total**.

This is intentionally small.

Do NOT pre-create dozens of domain skills. Skill Forge should grow the library
only from real repeated workflows.

Start with:

`CLAUDE_REVIEW_AND_MERGE.md`
