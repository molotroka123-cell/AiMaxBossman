# BOSSMAN Controlled Self-Learning Policy

## What "learning" means

BOSSMAN may improve through:

1. Memory
2. Skills
3. Model routing scores
4. Tool/provider performance history
5. Reviewer/evaluation evidence

It does NOT automatically modify model weights.

## Safe improvement loop

```text
Experience
  ↓
Memory
  ↓
Pattern detected
  ↓
Skill Forge proposal
  ↓
Permission diff
  ↓
Skill evaluation
  ↓
Proof
  ↓
Version promotion
```

## Promotion requirements

A candidate skill is not promoted merely because it was generated.

Required:

- valid SKILL.md
- provenance
- version
- no unapproved privilege expansion
- reproducible evaluation where applicable
- no critical regression
- rollback path

## Memory vs Skill

Write to Memory when:
- it is a fact
- decision
- lesson
- project-specific convention
- result of an experiment

Create/update a Skill when:
- it is a repeatable workflow
- multiple tasks need the same procedure
- stable sequencing matters
- the process reduces recurring errors

## Avoid skill bloat

Prefer 15 excellent generic skills + dynamically grown domain skills
over hundreds of always-present prompt wrappers.

Only assigned/relevant skills should enter an agent's active context.
