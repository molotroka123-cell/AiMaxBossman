# Recommended BOSSMAN Core Skills

## Safety / engineering
- repo-audit
- safe-code-change
- safe-terminal
- permission-auditor
- proof-before-done

## Browser / research / models
- browser-research
- model-eval
- openrouter-sync

## Autonomy
- night-mission

## Memory / context
- memory-recall
- memory-curator
- context-builder

## Self-improvement
- skill-forge
- failure-retrospective
- skill-evaluator

Total recommended generic core: **15**.

After this point:
- domain skills should be created through actual use
- avoid manually building a huge static skill catalog
