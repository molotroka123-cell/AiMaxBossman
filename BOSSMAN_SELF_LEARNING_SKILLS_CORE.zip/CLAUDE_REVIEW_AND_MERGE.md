# Claude Code — Quick Skills Review + Merge

The user wants a compact BOSSMAN core skill set with controlled self-improvement.

## Existing skills

Before making changes, confirm the current `.agents/skills/` directory.

Expected existing core:

- browser-research
- model-eval
- night-mission
- openrouter-sync
- repo-audit
- safe-code-change
- safe-terminal
- skill-forge

## New supplied skills

Copy/review:

- memory-recall
- memory-curator
- context-builder
- failure-retrospective
- skill-evaluator
- permission-auditor
- proof-before-done

Do not rewrite them from scratch for style.

Adjust only if current BOSSMAN/OpenCode skill parser requires a format change.

## Important objective

We do NOT want uncontrolled "self-learning".

Target loop:

```text
Task / Mission
      ↓
runtime result + Reviewer + KPI
      ↓
Memory Curator
      ↓
Failure Retrospective when needed
      ↓
Skill Forge proposes create/update
      ↓
Permission Auditor checks privilege delta
      ↓
Skill Evaluator A/B tests candidate
      ↓
Proof Before Done verifies evidence
      ↓
PROMOTE
or
REJECT / ROLLBACK
```

Memory and Skills are the primary learnable layers.

Do not fine-tune/change model weights automatically.

## Please do one short audit yourself

After reading the existing repository, answer:

> Is there any genuinely critical generic skill still missing from this core?

Rules for your answer:

- suggest at most **3**
- only add one if it serves many BOSSMAN tasks
- do not add narrow domain skills such as SEO, marketing, image prompts, finance, etc.
- do not duplicate behavior already covered by existing skills/runtime
- explain why it cannot simply live as part of an existing skill

If nothing critical is missing, write:

`CORE SKILLS COMPLETE — grow domain skills through Skill Forge.`

## Integration checks

Verify:

1. BOSSMAN Skill Library discovers all new `.agents/skills/*/SKILL.md`.
2. OpenCode can discover the portable location.
3. Skill metadata/version is visible.
4. Skill updates can retain prior versions.
5. Skill Forge does not overwrite active skills without review.
6. permission expansion triggers approval.
7. Skill Evaluator can store baseline/candidate evaluation result.
8. failed evaluation does not replace active version.
9. Memory Curator can write through the memory layer if enabled.
10. Context Builder is invoked before oversized context injection where practical.

## Final mini-report

Create:

`docs/CORE_SKILLS_AUDIT.md`

Keep it under ~250 lines.

Include:

- skills present
- duplicates found
- missing critical generic skills, if any
- integration gaps
- self-learning loop status:
  - REAL
  - PARTIAL
  - ABSENT
- exact next step

Do not spend a full Claude session on this review.
This should be a quick focused pass.
