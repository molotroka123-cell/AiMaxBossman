"""Run the affected regression suites in the user's existing Python environment."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

p=argparse.ArgumentParser();p.add_argument("--repo",required=True);args=p.parse_args()
repo=Path(args.repo).resolve();out=Path(__file__).resolve().parent/"verification-results";out.mkdir(exist_ok=True)
core=[str(x.relative_to(repo)) for x in sorted((repo/"bossman-core/tests").glob("test_v3_*.py"))]
core += ["bossman-core/tests/test_astra_remediation.py","bossman-core/tests/test_secrem_f004_http_ssrf.py"]
commands={
 "core":[sys.executable,"-m","pytest","-q",*core,"--timeout=120","--timeout-method=thread",f"--junitxml={out/'core.xml'}"],
 "command-center":[sys.executable,"-m","pytest","-q","command-center/tests/test_astra_remediation_cc.py",
                   "command-center/tests/test_metrics_gpu.py","command-center/tests/test_feat_openrouter.py",
                   "command-center/tests/test_v21_openrouter_router.py","command-center/tests/test_fable_hard_cap.py",
                   "command-center/tests/test_v2_poststate_verifiers.py",
                   "command-center/tests/test_finalize_gate.py",
                   "-o","asyncio_mode=auto",
                   "--timeout=120","--timeout-method=thread",f"--junitxml={out/'cc.xml'}"],
 "ci-gate":[sys.executable,"-m","pytest","-q","tests/test_astra_security_gate.py",f"--junitxml={out/'ci-gate.xml'}"],
 "secrets":[sys.executable,"tools/ci_secret_scan.py"],
 "runner":[sys.executable,"tools/astra_acceptance.py","--profile","runner","--output",str(out/'runner')],
}
results={}
for name,cmd in commands.items():
 print(f"Running {name}...",flush=True)
 try:
  report=next((Path(arg.split("=",1)[1]) for arg in cmd if arg.startswith("--junitxml=")),None)
  if report: report.unlink(missing_ok=True)
  with (out/f"{name}.log").open("w",encoding="utf-8") as log:
   run=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=600,check=False)
  results[name]={"exit_code":run.returncode,"status":"PASS" if run.returncode == 0 else "FAIL"}
  if results[name]["status"] == "PASS" and report:
   try:
    suites=list(ET.parse(report).getroot().iter("testsuite"))
    count=sum(int(x.get("tests",0)) for x in suites)
    skipped=sum(int(x.get("skipped",0)) for x in suites)
    errors=sum(int(x.get("errors",0))+int(x.get("failures",0)) for x in suites)
    results[name].update(tests=count,skipped=skipped)
    if count == 0 or skipped or errors: results[name]["status"]="INCOMPLETE"
   except (OSError,ET.ParseError,ValueError): results[name]["status"]="INVALID_REPORT"
 except subprocess.TimeoutExpired:results[name]={"status":"TIMEOUT"}
 print(name,results[name]["status"],flush=True)
(out/"summary.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
raise SystemExit(0 if all(r["status"]=="PASS" for r in results.values()) else 1)
