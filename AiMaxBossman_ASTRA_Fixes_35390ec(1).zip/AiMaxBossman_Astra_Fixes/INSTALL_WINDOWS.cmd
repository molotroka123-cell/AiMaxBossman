@echo off
setlocal
set /p "BOSSMAN_PATCH_REPO=Path to AiMaxBossman repository: "
py -3 "%~dp0apply_fixes.py" --repo "%BOSSMAN_PATCH_REPO%" --apply
pause
