"""UX 2.0 — настольное окно (bcc-desktop): реальный предустановленный Chromium в режиме --app
против живого сервера; переиспользование уже запущенного сервера; секрет не попадает в URL."""
from __future__ import annotations

import io
import json
import os
import sys
import subprocess
import tempfile
import time
from pathlib import Path

import pytest

from bcc import desktop

from .browser_support import chromium_available, reason as browser_reason
from .test_ux2_thinking_pane import live  # noqa: F401


def _use_temp_data_dir(monkeypatch, path) -> Path:
    """Подменить каталог данных ВМЕСТЕ с адресом базы.

    `Settings.database_url` вычисляется один раз в `__post_init__`, поэтому
    подмена только `data_dir` оставляет адрес базы прежним — и тест, поднимающий
    настоящий сервер, идёт в БОЕВУЮ базу репозитория. Локально она есть, и тест
    зелёный; в CI её нет, сервер падает `unable to open database file`, `run()`
    возвращает 3 вместо кода launcher'а. Меняем обе величины разом.
    """
    from bcc.config import settings

    path = Path(path)
    monkeypatch.setattr(settings, "data_dir", path)
    monkeypatch.setattr(settings, "database_url", f"sqlite+aiosqlite:///{path / 'bcc.db'}")
    return path


@pytest.fixture(autouse=True)
def _isolated_data_dir(tmp_path_factory, monkeypatch):
    """Тесты не должны писать в боевой каталог данных владельца.

    `desktop.run()` ведёт `desktop-run.log` и `desktop.lock` в `settings.data_dir`.
    Без изоляции прогон тестов засорял журнал, который владелец читает при
    разборе сбоя (в присланном логе видны строки с эфемерными портами pytest),
    а убитый в середине прогон мог оставить там же чужой lock-файл.
    """
    _use_temp_data_dir(monkeypatch, tmp_path_factory.mktemp("bcc-data"))


def test_find_browser_prefers_preinstalled_chromium(tmp_path):
    fake = tmp_path / "chromium"
    fake.write_text("")
    assert desktop.find_browser([str(fake), "definitely-not-a-browser-xyz"]) == str(fake)
    assert desktop.find_browser(["definitely-not-a-browser-xyz", ""]) is None


def test_browser_argv_is_app_window_without_secret(tmp_path):
    argv = desktop.browser_argv("/usr/bin/chromium", "http://127.0.0.1:8800/", tmp_path / "prof")
    assert argv[0] == "/usr/bin/chromium"
    assert "--app=http://127.0.0.1:8800/" in argv
    assert any(a.startswith("--user-data-dir=") and a.endswith("prof") for a in argv)
    assert "--no-first-run" in argv
    with pytest.raises(ValueError):
        desktop.browser_argv("/usr/bin/chromium", "http://127.0.0.1:8800/?token=abc", tmp_path)


def test_run_reuses_running_server_and_does_not_bind_twice(live, tmp_path):  # noqa: F811
    calls: list[dict] = []

    def fake_launcher(browser, url, profile_dir, *, extra=(), window_size="1440,900"):
        calls.append({"browser": browser, "url": url, "profile": Path(profile_dir), "extra": tuple(extra)})
        return 0

    out = io.StringIO()
    code = desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--browser-arg=--x-test", "--no-show-token"],
                       launcher=fake_launcher, out=out)
    assert code == 0
    assert calls == [{"browser": "/bin/true", "url": f"http://127.0.0.1:{live.port}/", "profile": tmp_path / "prof", "extra": ("--x-test",)}]
    assert "Command Center уже работает" in out.getvalue()
    assert "token" not in out.getvalue().lower()


def test_run_reports_missing_browser(tmp_path, monkeypatch):
    monkeypatch.setattr(desktop, "find_browser", lambda *a, **k: None)
    out = io.StringIO()
    assert desktop.run(["--profile", str(tmp_path), "--no-server", "--port", "1"], launcher=lambda *a, **k: 0, out=out) == 2
    assert "не найден" in out.getvalue()


def test_local_health_checks_ignore_proxy_environment(live, monkeypatch):  # noqa: F811
    """Прокси из окружения не должен применяться к 127.0.0.1.

    ALL_PROXY/HTTP(S)_PROXY адресованы внешним провайдерам; если проверка
    «сервер уже работает» унаследует их, она уйдёт на прокси и либо соврёт
    (чужой ответ), либо упадёт. Здесь прокси заведомо мёртв и указывает на
    закрытый порт: живой локальный сервер всё равно должен определяться.
    """
    from .test_ux2_thinking_pane import _free_port, loopback_get

    dead = f"socks5://127.0.0.1:{_free_port()}"
    for var in ("ALL_PROXY", "all_proxy", "HTTP_PROXY", "http_proxy", "HTTPS_PROXY", "https_proxy"):
        monkeypatch.setenv(var, dead)
    for var in ("NO_PROXY", "no_proxy"):
        monkeypatch.delenv(var, raising=False)

    assert desktop.server_alive(live.url + "/") is True      # запуск окна: сервер найден
    assert loopback_get(live.url + "/").status_code < 500    # готовность в тестах и снимках
    # и никакого «сервера» там, где его нет
    assert desktop.server_alive(f"http://127.0.0.1:{_free_port()}/") is False


def _devtools_endpoint(profile_dir, proc, timeout: float = 60.0):
    """Порт и ws-путь отладки из ``DevToolsActivePort`` в профиле окна.

    Браузер создаёт этот файл только после того, как отладочный сервер начал
    слушать, поэтому файл — сам по себе признак готовности: ни угадывания
    порта, ни гонки, ни опроса чужого адреса. HTTP-эндпоинт ``/json/version``
    здесь сознательно не используется: именно он в CI не отвечал 30 секунд,
    пока браузер был жив и уже печатал «DevTools listening».
    """
    marker = Path(profile_dir) / "DevToolsActivePort"
    deadline = time.monotonic() + timeout
    seen = ""
    while time.monotonic() < deadline:
        rc = proc.poll()
        if marker.exists():
            seen = marker.read_text(encoding="utf-8", errors="replace")
            lines = seen.splitlines()
            if len(lines) >= 2 and lines[0].strip().isdigit():
                return int(lines[0].strip()), lines[1].strip()
        if rc is not None:
            raise AssertionError(f"окно завершилось, rc={rc}, DevToolsActivePort={seen!r}")
        time.sleep(0.1)
    raise AssertionError(
        f"DevToolsActivePort не появился за {timeout} с (rc={proc.poll()}, содержимое={seen!r})")


# Запас, а не ослабление проверки: тест поднимает НАСТОЯЩЕЕ окно Chromium,
# ждёт DevTools и рендер. Типичная длительность на раннере — 37–48 с, но на
# загруженной ноде py3.12 (после ~1400 других тестов, часть из которых тоже
# браузерные) он вышел за 120 с и уронил CI, тогда как py3.11 в ТОМ ЖЕ прогоне
# прошёл. Ассерты не тронуты: зависшее окно по-прежнему провалит тест, просто
# позже, а разброс скорости раннера больше не выдаёт себя за дефект.
@pytest.mark.timeout(300)
@pytest.mark.skipif(not chromium_available(), reason=browser_reason())
def test_real_chromium_app_window_renders_command_center(live, tmp_path):  # noqa: F711
    """Настоящее окно --app с предустановленным Chromium: без дисплея — headless-снимок,
    который доказывает, что команда окна работает и страница входа отрисована."""
    from playwright.sync_api import sync_playwright

    browser = desktop.find_browser()
    assert browser, "предустановленный Chromium не найден"
    profile = tmp_path / "profile"
    # Порт отладки выбирает сам браузер (0) и публикует его в профиле. Тест
    # больше не занимает порт заранее: между выбором и запуском окна ядро могло
    # отдать его другому соединению, и тогда мы опрашивали чужой адрес.
    proc = desktop.open_window(
        browser, live.url + "/", profile,
        extra=("--headless=new", "--no-sandbox", "--disable-gpu",
               "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0"))
    try:
        port, ws_path = _devtools_endpoint(profile, proc)
        # Регрессия к сбою CI: порт получен из DevToolsActivePort, а не угадан.
        assert port > 0 and ws_path.startswith("/devtools/browser/"), (port, ws_path)
        with sync_playwright() as pw:
            b = pw.chromium.connect_over_cdp(f"ws://127.0.0.1:{port}{ws_path}")
            info = b.new_browser_cdp_session().send("Browser.getVersion")
            assert "Chrome" in info.get("product", ""), info
            pages = [p for c in b.contexts for p in c.pages]
            page = next((p for p in pages if p.url.startswith(live.url)), None)
            assert page is not None, [p.url for p in pages]
            page.wait_for_selector("#login:not([hidden])", timeout=15000)   # окно показало вход в Command Center
            assert "BOSSMAN" in page.title()
            # войти прямо в окне: cookie сессии остаётся в профиле окна, а не в URL
            page.fill("#login-token", live.svc.auth.token)
            page.click("#login-submit")
            page.wait_for_selector("#shell:not([hidden])", timeout=15000)
            assert "token=" not in page.url
            b.close()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except Exception:  # noqa: BLE001
            proc.kill()
    assert (tmp_path / "profile").is_dir()  # отдельный профиль окна создан
    # профиль не должен содержать токен доступа в открытом виде
    for f in (tmp_path / "profile").rglob("*"):
        if f.is_file() and f.stat().st_size < 2_000_000:
            try:
                data = f.read_bytes()
            except OSError:
                continue
            assert live.svc.auth.token.encode() not in data, f"токен утёк в {f}"


# ---------------------------------------------------------------- ярлык на рабочем столе

def test_linux_shortcut_is_written_and_valid(tmp_path):
    """Реальная установка ярлыка в подставной HOME: файлы созданы, Exec/Icon/Path заполнены."""
    from bcc import desktop_install

    spec = desktop_install.build_spec(executable="/usr/bin/python3", workdir=tmp_path, port=8800)
    (tmp_path / "Desktop").mkdir()
    created = desktop_install.install(spec, home=tmp_path, system="Linux")
    assert created, "ярлык не создан"
    entry = (tmp_path / ".local/share/applications/bossman.desktop").read_text(encoding="utf-8")
    assert "[Desktop Entry]" in entry
    assert "Name=BOSSMAN" in entry
    assert "-m bcc.desktop" in entry and "--port 8800" in entry
    assert "Terminal=true" in entry          # консоль с токеном открывается вместе с окном
    assert f"Path={tmp_path}" in entry
    icon = tmp_path / ".local/share/icons/hicolor/512x512/apps/bossman.png"
    assert icon.exists() and icon.stat().st_size > 1000, "значок не установлен"
    assert f"Icon={icon}" in entry
    assert "token" not in entry.lower()
    # ярлык на рабочем столе тоже есть и исполняемый
    desk = tmp_path / "Desktop" / "bossman.desktop"
    assert desk.exists() and os.access(desk, os.X_OK)
    removed = desktop_install.uninstall(home=tmp_path, system="Linux")
    assert len(removed) == 3 and not desk.exists()


def test_windows_shortcut_script_quotes_safely(tmp_path):
    """Скрипт .lnk: экранирование кавычек, никакого shell-склеивания, значок .ico."""
    from bcc import desktop_install

    spec = desktop_install.build_spec(executable=r"C:\Py'thon\pythonw.exe", workdir=r"C:\BOSS MAN", port=8801)
    script = desktop_install.powershell_shortcut_script(spec, [r"C:\Users\o\Desktop\BOSSMAN.lnk"])
    assert "WScript.Shell" in script
    assert "'C:\\Py''thon\\pythonw.exe'" in script      # одинарная кавычка удвоена
    assert "-m bcc.desktop --port 8801" in script
    assert "'C:\\BOSS MAN'" in script
    assert ".Save()" in script
    assert "token" not in script.lower()


def test_install_windows_uses_powershell_argv(tmp_path, monkeypatch):
    """Windows-путь вызывает powershell только через argv и уважает код возврата."""
    from bcc import desktop_install

    calls = []
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData" / "Roaming"))
    spec = desktop_install.build_spec(executable="python.exe", workdir=tmp_path)
    created = desktop_install.install(spec, home=tmp_path, system="Windows",
                                      runner=lambda argv: calls.append(argv) or 0)
    assert len(created) == 2 and created[0].name == "BOSSMAN.lnk"
    assert calls and calls[0][0] == "powershell" and "-NoProfile" in calls[0]
    with pytest.raises(RuntimeError):
        desktop_install.install(spec, home=tmp_path, system="Windows", runner=lambda argv: 1)


def test_run_install_shortcut_exits_zero(tmp_path, monkeypatch):
    """`bcc-desktop --install-shortcut` не запускает ни сервер, ни браузер."""
    monkeypatch.setattr(desktop, "find_browser", lambda *a, **k: "/bin/true")
    from bcc import desktop_install

    monkeypatch.setattr(desktop_install, "install", lambda spec=None, **kw: [tmp_path / "BOSSMAN.lnk"])
    out = io.StringIO()
    code = desktop.run(["--install-shortcut"], launcher=lambda *a, **k: 99, out=out)
    assert code == 0 and "ярлык BOSSMAN создан" in out.getvalue()


def test_busy_port_with_foreign_app_is_refused(tmp_path):
    """Чужое приложение на порту не выдаётся за Command Center (код 4)."""
    import http.server
    import threading

    class Foreign(http.server.BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"not bossman")

        def log_message(self, *a):  # тишина в тестовом выводе
            return

    from .test_ux2_thinking_pane import _free_port

    port = _free_port()
    srv = http.server.HTTPServer(("127.0.0.1", port), Foreign)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        assert desktop.identify_server(f"http://127.0.0.1:{port}/") is None
        assert desktop.port_busy(f"http://127.0.0.1:{port}/") is True
        out = io.StringIO()
        code = desktop.run(["--port", str(port), "--browser", "/bin/true", "--profile", str(tmp_path)],
                           launcher=lambda *a, **k: 0, out=out)
        assert code == 4, out.getvalue()
        assert "занят другим приложением" in out.getvalue()
    finally:
        srv.shutdown()


def test_identity_of_real_server(live):  # noqa: F811
    """У живого Command Center identity действительно есть и он опознаётся."""
    ident = desktop.identify_server(live.url)
    assert ident and ident["app"] == "bossman-command-center"
    assert ident.get("version")
    assert "token" not in str(ident).lower()

def test_second_window_refused_while_first_instance_alive(tmp_path, monkeypatch):
    """?????? ???? ?? ??? ?? ??????? Chrome ????? ??????????? (profile lock).
    ????? ????? + ????? ?????? = ????? ? ???????? ??????????, ??? ??????? Chrome."""
    from bcc.config import settings

    _use_temp_data_dir(monkeypatch, tmp_path)
    (tmp_path / "desktop.lock").write_text(__import__("json").dumps({"pid": 1, "port": 18923}), encoding="utf-8")
    monkeypatch.setattr(desktop, "identify_server",
                        lambda url, timeout=2.0: {"app": "bossman-command-center"} if ":18923/" in url else None)
    calls = []
    out = io.StringIO()
    code = desktop.run(["--port", "18924", "--browser", "/bin/true", "--profile", str(tmp_path / "prof")],
                       launcher=lambda *a, **k: (calls.append(1), 0)[1], out=out)
    assert code == 0
    assert calls == []
    assert "BOSSMAN" in out.getvalue() and "18923" in out.getvalue()
    assert "browser-exit" not in (tmp_path / "desktop-run.log").read_text(encoding="utf-8")


def test_fast_browser_exit_is_logged_with_hint(tmp_path, monkeypatch):
    """????, ??????????? ?? ???????, ????????? ????: ???, ????? ????? ? ???? ????????."""
    from bcc.config import settings

    _use_temp_data_dir(monkeypatch, tmp_path)
    monkeypatch.setattr(desktop, "identify_server", lambda *a, **k: None)
    monkeypatch.setattr(desktop, "port_busy", lambda *a, **k: False)

    class _FakeServer:
        def __init__(self, host, port):
            pass

        def start(self, url):
            return True

        def stop(self):
            pass

    monkeypatch.setattr(desktop, "_BackgroundServer", _FakeServer)
    out = io.StringIO()
    code = desktop.run(["--port", "18925", "--browser", "/bin/true", "--profile", str(tmp_path / "prof")],
                       launcher=lambda *a, **k: 1, out=out)
    assert code == 1
    assert "chrome_debug.log" in out.getvalue()
    log = (tmp_path / "desktop-run.log").read_text(encoding="utf-8")
    assert "browser-exit code=1" in log
    assert not (tmp_path / "desktop.lock").exists()


# ------------------------------------------------- консоль с токеном при запуске

def test_launcher_shows_access_token_but_never_writes_it_to_logs(live, tmp_path, monkeypatch):  # noqa: F811
    """Владельцу нужен токен при первом входе, поэтому он печатается в консоль.

    Но `desktop-run.log` владелец пересылает при разборе сбоев (так написано в
    docs/ux/DESKTOP_SELF_CLOSE_AUDIT.md), поэтому секрет туда попасть не должен.
    """
    from bcc.config import settings

    data_dir = tmp_path / "desk"
    data_dir.mkdir(exist_ok=True)
    token = "TESTTOKEN-" + "z" * 24
    (data_dir / desktop.TOKEN_FILE_NAME).write_text(token, encoding="utf-8")
    _use_temp_data_dir(monkeypatch, data_dir)

    out = io.StringIO()
    code = desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof")],
                       launcher=lambda *a, **k: 0, out=out)
    assert code == 0
    text = out.getvalue()
    assert token in text                                  # токен виден владельцу
    assert "BOSSMAN — вход в Command Center" in text
    assert str(data_dir / desktop.TOKEN_FILE_NAME) in text  # и путь к файлу

    run_log = (data_dir / "desktop-run.log").read_text(encoding="utf-8")
    assert run_log.strip(), "журнал запусков должен вестись"
    assert token not in run_log, "секрет не должен попадать в пересылаемый журнал"


def test_no_show_token_keeps_the_secret_off_screen(live, tmp_path, monkeypatch):  # noqa: F811
    """Режим без консоли: приложение работает, токен на экран не выводится."""
    from bcc.config import settings

    data_dir = tmp_path / "desk"
    data_dir.mkdir(exist_ok=True)
    token = "TESTTOKEN-" + "q" * 24
    (data_dir / desktop.TOKEN_FILE_NAME).write_text(token, encoding="utf-8")
    _use_temp_data_dir(monkeypatch, data_dir)

    out = io.StringIO()
    assert desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=lambda *a, **k: 0, out=out) == 0
    assert token not in out.getvalue()


def test_shortcut_carries_no_secret_and_console_mode_is_explicit(tmp_path):
    """Ярлык не хранит токен: секрет печатает процесс, а не файл ярлыка."""
    from bcc import desktop_install

    console = desktop_install.build_spec(executable="/usr/bin/python3", workdir=tmp_path, port=8800)
    silent = desktop_install.build_spec(executable="/usr/bin/python3", workdir=tmp_path, port=8800,
                                        console=False)
    assert console.console is True and "--no-show-token" not in console.args
    assert silent.console is False and "--no-show-token" in silent.args
    for spec in (console, silent):
        blob = " ".join(spec.argv) + desktop_install.desktop_entry(spec)
        assert "token" not in blob.lower().replace("--no-show-token", "")


def test_console_python_is_chosen_on_windows(tmp_path):
    """На Windows консольный режим берёт python.exe вместо pythonw.exe."""
    from bcc import desktop_install

    (tmp_path / "python.exe").write_text("")
    (tmp_path / "pythonw.exe").write_text("")
    pyw, py = str(tmp_path / "pythonw.exe"), str(tmp_path / "python.exe")
    assert desktop_install._console_python(pyw, windows=True) == py
    assert desktop_install._windowless_python(py, windows=True) == pyw
    # не Windows — интерпретатор не подменяется
    assert desktop_install._console_python(pyw, windows=False) == pyw


def test_access_banner_warns_only_when_console_owns_the_app():
    """Предупреждение «не закрывайте консоль» уместно только когда сервер наш."""
    from pathlib import Path as _P

    owns = desktop.access_banner("http://127.0.0.1:8800/", "T", _P("/d/token"), console_owns_app=True)
    attached = desktop.access_banner("http://127.0.0.1:8800/", "T", _P("/d/token"), console_owns_app=False)
    assert "закрывать нельзя" in owns
    assert "закрывать нельзя" not in attached
    assert desktop.access_banner("http://x/", None, _P("/d/token"), console_owns_app=False).count("Токен") >= 1


def test_browser_launch_failure_is_reported_and_logged(live, tmp_path, monkeypatch):  # noqa: F811
    """Если браузер не запустился, владелец должен увидеть причину, а не пустую консоль.

    Раньше OSError из Popen улетал трейсбеком, консоль закрывалась вместе с ним,
    и симптом выглядел как «открылась только командная строка».
    """
    from bcc.config import settings

    data_dir = tmp_path / "desk"
    data_dir.mkdir(exist_ok=True)
    _use_temp_data_dir(monkeypatch, data_dir)

    def broken_launcher(*a, **k):
        raise FileNotFoundError(2, "No such file or directory", "chrome.exe")

    out = io.StringIO()
    code = desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=broken_launcher, out=out)
    assert code == 6
    text = out.getvalue()
    assert "не удалось запустить браузер" in text and "chrome.exe" in text
    log = (data_dir / "desktop-run.log").read_text(encoding="utf-8")
    assert "browser-launch-failed FileNotFoundError" in log


def test_run_log_records_the_exact_window_command(live, tmp_path, monkeypatch):  # noqa: F811
    """Команда окна попадает в журнал: без неё «окно не появилось» неразбираемо."""
    from bcc.config import settings

    data_dir = tmp_path / "desk"
    data_dir.mkdir(exist_ok=True)
    _use_temp_data_dir(monkeypatch, data_dir)

    out = io.StringIO()
    assert desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=lambda *a, **k: 0, out=out) == 0
    log = (data_dir / "desktop-run.log").read_text(encoding="utf-8")
    assert "browser-argv /bin/true --app=" in log
    assert "--user-data-dir=" in log
    assert "token" not in log.lower()          # argv по-прежнему без секретов


def test_tests_never_write_into_the_owner_data_dir(live, tmp_path):  # noqa: F811
    """Регрессия к засорённому журналу: прогон пишет только во временный каталог."""
    from bcc.config import settings

    out = io.StringIO()
    assert desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=lambda *a, **k: 0, out=out) == 0
    log = Path(settings.data_dir) / "desktop-run.log"
    assert log.exists(), "журнал ведётся"
    assert str(log).startswith(str(Path(tempfile.gettempdir()))), log   # временный, не боевой


def test_every_exit_path_leaves_a_matching_line_in_the_run_log(live, tmp_path, monkeypatch):  # noqa: F811
    """`start` без парной строки итога делал журнал неразбираемым.

    В присланном владельцем логе строка 21:44:24 `start ...` не имеет пары, и по
    журналу нельзя отличить «убили снаружи» от «сервер не поднялся».
    """
    from bcc.config import settings

    log = Path(settings.data_dir) / "desktop-run.log"

    # порт занят чужим приложением
    monkeypatch.setattr(desktop, "identify_server", lambda *a, **k: None)
    monkeypatch.setattr(desktop, "port_busy", lambda *a, **k: True)
    out = io.StringIO()
    assert desktop.run(["--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "p1"), "--no-show-token"],
                       launcher=lambda *a, **k: 0, out=out) == 4
    assert "exit code=4 port-busy-foreign" in log.read_text(encoding="utf-8")

    # браузера нет
    monkeypatch.setattr(desktop, "find_browser", lambda *a, **k: None)
    out = io.StringIO()
    assert desktop.run(["--port", str(live.port), "--profile", str(tmp_path / "p2"),
                        "--no-show-token"], launcher=lambda *a, **k: 0, out=out) == 2
    assert "exit code=2 no-browser-found" in log.read_text(encoding="utf-8")


def test_server_start_failure_reports_the_reason(tmp_path, monkeypatch):
    """«Сервер не поднялся» без причины — тупик; причина обязана дойти до владельца."""
    from bcc.config import settings

    class _Failing:
        def __init__(self, host, port):
            self.error = "OSError: [Errno 98] address already in use"

        def start(self, url, timeout=30.0):
            return False

        def stop(self):
            pass

    monkeypatch.setattr(desktop, "_BackgroundServer", _Failing)
    monkeypatch.setattr(desktop, "identify_server", lambda *a, **k: None)
    monkeypatch.setattr(desktop, "port_busy", lambda *a, **k: False)
    out = io.StringIO()
    assert desktop.run(["--port", "8800", "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=lambda *a, **k: 0, out=out) == 3
    assert "address already in use" in out.getvalue()
    log = (Path(settings.data_dir) / "desktop-run.log").read_text(encoding="utf-8")
    assert "exit code=3 server-start-failed" in log and "address already in use" in log


def test_stale_lock_from_a_killed_run_does_not_block_the_window(live, tmp_path, monkeypatch):  # noqa: F811
    """P1 из свипа владельца: убитый запуск оставляет замок с мёртвым pid.

    Проверки порта мало — на порту может сидеть посторонний живой сервер, и
    тогда guard запирал бы окно навсегда («открывается только консоль»).
    """
    from bcc.config import settings

    data_dir = Path(settings.data_dir)
    dead_pid = 999_999            # заведомо не существует
    (data_dir / "desktop.lock").write_text(
        json.dumps({"pid": dead_pid, "port": live.port}), encoding="utf-8")
    # порт при этом отвечает как Command Center — ровно ситуация владельца
    monkeypatch.setattr(desktop, "identify_server", lambda *a, **k: {"app": "bossman-command-center"})

    opened: list[str] = []
    out = io.StringIO()
    code = desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=lambda *a, **k: opened.append("window") or 0, out=out)
    assert code == 0
    assert opened == ["window"], "окно должно открыться: замок протух"
    log = (data_dir / "desktop-run.log").read_text(encoding="utf-8")
    assert f"stale-lock-cleared pid={dead_pid}" in log
    assert "refused-second-window" not in log


def test_live_lock_still_refuses_a_second_window(live, tmp_path, monkeypatch):  # noqa: F811
    """Обратная сторона: живой владелец замка по-прежнему запрещает второе окно."""
    from bcc.config import settings

    data_dir = Path(settings.data_dir)
    (data_dir / "desktop.lock").write_text(
        json.dumps({"pid": os.getpid(), "port": live.port}), encoding="utf-8")   # мы сами живы
    monkeypatch.setattr(desktop, "identify_server", lambda *a, **k: {"app": "bossman-command-center"})

    opened: list[str] = []
    out = io.StringIO()
    assert desktop.run(["--host", "127.0.0.1", "--port", str(live.port), "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=lambda *a, **k: opened.append("window") or 0, out=out) == 0
    assert opened == [], "второе окно на том же профиле открывать нельзя"
    assert "уже запущено" in out.getvalue()


def test_pid_liveness_is_honest_about_this_process_and_a_dead_one():
    assert desktop._pid_alive(os.getpid()) is True
    assert desktop._pid_alive(999_999) is False
    assert desktop._pid_alive(0) is False and desktop._pid_alive(-1) is False


def test_missing_std_streams_are_bound_to_a_file_log(tmp_path, monkeypatch):
    """CR-1: под pythonw консоли нет, и sys.stdout/sys.stderr равны None.

    Тогда любой print — наш, uvicorn'а или чужой библиотеки — падает
    AttributeError, и запуск двойным кликом умирает молча. После подстановки
    писать можно, и написанное лежит в файле, который владелец может прислать.
    """
    data_dir = tmp_path / "gui"
    monkeypatch.setattr(desktop.sys, "stdout", None)
    monkeypatch.setattr(desktop.sys, "stderr", None)

    stream = desktop.bind_missing_std_streams(data_dir)

    assert stream is not None
    assert desktop.sys.stdout is stream and desktop.sys.stderr is stream
    print("проверка вывода без консоли", file=desktop.sys.stdout, flush=True)
    print("и ошибки тоже", file=desktop.sys.stderr, flush=True)
    text = (data_dir / desktop.GUI_CONSOLE_LOG_NAME).read_text(encoding="utf-8")
    assert "запуск без консоли" in text
    assert "проверка вывода без консоли" in text and "и ошибки тоже" in text
    # Владелец должен найти этот файл по журналу запусков, а не наугад.
    assert desktop.GUI_CONSOLE_LOG_NAME in (data_dir / "desktop-run.log").read_text(encoding="utf-8")
    stream.close()


def test_console_binding_is_a_no_op_when_a_console_exists(tmp_path):
    """Живую консоль подменять нельзя: владелец должен видеть токен глазами."""
    before_out, before_err = desktop.sys.stdout, desktop.sys.stderr
    assert desktop.bind_missing_std_streams(tmp_path / "gui") is None
    assert desktop.sys.stdout is before_out and desktop.sys.stderr is before_err
    assert not (tmp_path / "gui" / desktop.GUI_CONSOLE_LOG_NAME).exists()


def test_std_streams_are_never_left_none_even_if_data_dir_is_unusable(tmp_path, monkeypatch):
    """Если писать в data_dir нельзя, поток всё равно должен быть, а не None."""
    blocker = tmp_path / "blocked"
    blocker.write_text("это файл, а не каталог", encoding="utf-8")
    monkeypatch.setattr(desktop.sys, "stdout", None)
    monkeypatch.setattr(desktop.sys, "stderr", None)

    stream = desktop.bind_missing_std_streams(blocker / "data")

    assert stream is not None
    print("не должно упасть", file=desktop.sys.stdout, flush=True)
    stream.close()


def test_gui_console_log_keeps_previous_runs(tmp_path, monkeypatch):
    """Журнал дописывается: причина вчерашнего сбоя не стирается сегодняшним запуском."""
    data_dir = tmp_path / "gui"
    for mark in ("первый", "второй"):
        monkeypatch.setattr(desktop.sys, "stdout", None)
        monkeypatch.setattr(desktop.sys, "stderr", None)
        stream = desktop.bind_missing_std_streams(data_dir)
        print(f"{mark} запуск", file=stream, flush=True)
        stream.close()
        monkeypatch.undo()
    text = (data_dir / desktop.GUI_CONSOLE_LOG_NAME).read_text(encoding="utf-8")
    assert "первый запуск" in text and "второй запуск" in text


def test_gui_launch_keeps_the_token_out_of_the_file_log(tmp_path, monkeypatch):
    """Без консоли баннер читать некому, а журнал владелец пересылает — токена там быть не должно."""
    from bcc.config import settings

    data_dir = tmp_path / "gui"
    _use_temp_data_dir(monkeypatch, data_dir)
    (data_dir).mkdir(parents=True, exist_ok=True)
    (data_dir / desktop.TOKEN_FILE_NAME).write_text("SECRET-TOKEN-XYZ", encoding="utf-8")
    monkeypatch.setattr(desktop.sys, "stdout", None)
    monkeypatch.setattr(desktop.sys, "stderr", None)
    monkeypatch.setattr(desktop.sys, "argv", ["bcc-desktop"])
    monkeypatch.delenv(desktop.TOKEN_STDOUT_ENV, raising=False)
    seen: dict = {}

    def _fake_run(argv=None, **kwargs):
        seen["argv"] = list(argv or [])
        seen["out"] = kwargs.get("out")
        print("сервер запущен", file=kwargs["out"], flush=True)
        return 0

    monkeypatch.setattr(desktop, "run", _fake_run)
    with pytest.raises(SystemExit) as exc:
        desktop.main()

    assert exc.value.code == 0
    assert "--no-show-token" in seen["argv"], "без консоли баннер с токеном не печатаем"
    assert os.environ[desktop.TOKEN_STDOUT_ENV] == "0", "анонс токена сервером тоже выключен"
    seen["out"].close()
    text = (data_dir / desktop.GUI_CONSOLE_LOG_NAME).read_text(encoding="utf-8")
    assert "сервер запущен" in text
    assert "SECRET-TOKEN-XYZ" not in text


def test_console_launch_still_shows_the_token(tmp_path, monkeypatch):
    """С живой консолью ничего не меняется: владелец видит токен и вводит его в окне."""
    from bcc.config import settings

    _use_temp_data_dir(monkeypatch, tmp_path / "console")
    monkeypatch.setattr(desktop.sys, "argv", ["bcc-desktop"])
    monkeypatch.delenv(desktop.TOKEN_STDOUT_ENV, raising=False)
    seen: dict = {}

    monkeypatch.setattr(desktop, "run", lambda argv=None, **kw: seen.setdefault("argv", list(argv or [])) and 0 or 0)
    with pytest.raises(SystemExit):
        desktop.main()

    assert "--no-show-token" not in seen["argv"]
    assert desktop.TOKEN_STDOUT_ENV not in os.environ


def test_token_announce_is_silenced_when_output_goes_to_a_file(tmp_path, monkeypatch, capsys):
    """Сервер тоже не должен печатать токен, когда stdout — файловый журнал."""
    from bcc.auth import TokenAuth

    auth = TokenAuth(tmp_path / "token")
    capsys.readouterr()  # конструктор уже анонсировал токен в живую консоль
    monkeypatch.setenv(desktop.TOKEN_STDOUT_ENV, "0")
    auth.announce(created=True)
    assert auth.token not in capsys.readouterr().out

    monkeypatch.delenv(desktop.TOKEN_STDOUT_ENV)
    auth.announce(created=True)
    assert auth.token not in capsys.readouterr().out


def test_only_a_missing_stdout_hides_the_token(tmp_path, monkeypatch):
    """Подменён только stderr — консоль жива, и баннер с токеном по-прежнему нужен."""
    from bcc.config import settings

    _use_temp_data_dir(monkeypatch, tmp_path / "half")
    monkeypatch.setattr(desktop.sys, "stderr", None)
    monkeypatch.setattr(desktop.sys, "argv", ["bcc-desktop"])
    monkeypatch.delenv(desktop.TOKEN_STDOUT_ENV, raising=False)
    seen: dict = {}

    def _fake_run(argv=None, **kwargs):
        seen["argv"] = list(argv or [])
        return 0

    monkeypatch.setattr(desktop, "run", _fake_run)
    with pytest.raises(SystemExit):
        desktop.main()

    assert desktop.sys.stderr is not None, "stderr всё равно должен быть подменён"
    assert "--no-show-token" not in seen["argv"]
    assert desktop.TOKEN_STDOUT_ENV not in os.environ


def test_explicit_show_token_is_respected_even_without_a_console(tmp_path, monkeypatch):
    """`--show-token` — осознанный выбор владельца; молча его не отменяем."""
    from bcc.config import settings

    _use_temp_data_dir(monkeypatch, tmp_path / "explicit")
    monkeypatch.setattr(desktop.sys, "stdout", None)
    monkeypatch.setattr(desktop.sys, "stderr", None)
    monkeypatch.setattr(desktop.sys, "argv", ["bcc-desktop", "--show-token"])
    monkeypatch.delenv(desktop.TOKEN_STDOUT_ENV, raising=False)
    seen: dict = {}

    def _fake_run(argv=None, **kwargs):
        seen["argv"] = list(argv or [])
        kwargs["out"].close()
        return 0

    monkeypatch.setattr(desktop, "run", _fake_run)
    with pytest.raises(SystemExit):
        desktop.main()

    assert "--no-show-token" not in seen["argv"]
    assert desktop.TOKEN_STDOUT_ENV not in os.environ, "нельзя глушить анонс, когда токен просили явно"



def test_runtime_window_timeout_is_passed_to_launcher(tmp_path, monkeypatch):
    """--window-timeout доходит до launcher'а (по умолчанию BCC_APP_STARTUP_TIMEOUT)."""
    from bcc.config import settings
    _use_temp_data_dir(monkeypatch, tmp_path / "data")
    monkeypatch.setattr(desktop, "find_browser", lambda *a, **k: "/bin/true")
    seen = {}

    def fake_launcher(browser, url, profile_dir, *, extra=(), window_size="1440,900", timeout=None):
        seen["timeout"] = timeout
        return 124

    out = io.StringIO()
    code = desktop.run(["--host", "127.0.0.1", "--port", "0", "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--window-timeout", "3.5",
                        "--no-show-token"], launcher=fake_launcher, out=out)
    assert code == 124
    assert seen["timeout"] == 3.5
    assert "не открылось за отведённое время" in out.getvalue()


def test_lock_records_window_opened_at(tmp_path, monkeypatch):
    """desktop.lock получает window_opened_at — диагностика для --status без CDP."""
    from bcc.config import settings
    _use_temp_data_dir(monkeypatch, tmp_path / "data")
    monkeypatch.setattr(desktop, "find_browser", lambda *a, **k: "/bin/true")
    seen = {}

    def fake_launcher(browser, url, profile_dir, *, extra=(), window_size="1440,900", timeout=None):
        seen["lock"] = json.loads(
            desktop._desktop_lock_path(Path(settings.data_dir)).read_text(encoding="utf-8"))
        return 0

    out = io.StringIO()
    desktop.run(["--host", "127.0.0.1", "--port", "0", "--browser", "/bin/true",
                 "--profile", str(tmp_path / "prof"), "--no-show-token"],
                launcher=fake_launcher, out=out)
    assert "window_opened_at" in seen["lock"]
    assert seen["lock"]["pid"] > 0


def test_status_prints_json_state_without_launching(tmp_path, monkeypatch):
    """--status не запускает окно: печатает desktop.lock и живость сервера."""
    from bcc.config import settings
    _use_temp_data_dir(monkeypatch, tmp_path / "data")
    launched = []
    out = io.StringIO()
    code = desktop.run(["--status", "--port", str(settings.port), "--no-show-token"],
                       launcher=lambda *a, **k: launched.append(1) or 0, out=out)
    assert code == 0
    assert not launched
    state = json.loads(out.getvalue())
    assert state["port"] == settings.port
    assert "server_alive" in state
    assert state["lock"] is None


def test_bcc_open_entry_command_gets_web_flag(monkeypatch):
    """Запуск через `bcc-open` включает --web автоматически."""
    monkeypatch.setattr(desktop.os.path, "basename", lambda p: "bcc-open.exe")
    monkeypatch.setattr(desktop.sys, "argv", ["bcc-open.exe"])
    monkeypatch.setattr(desktop.sys, "stdout", None)
    monkeypatch.setattr(desktop.sys, "stderr", None)
    monkeypatch.setattr(desktop, "bind_missing_std_streams", lambda *a, **k: None)
    seen = {}

    def fake_run(argv=None, **kwargs):
        seen["argv"] = list(argv or [])
        return 0

    monkeypatch.setattr(desktop, "run", fake_run)
    with pytest.raises(SystemExit):
        desktop.main()
    assert seen["argv"][0] == "--web" and "--web" in seen["argv"]


def test_bcc_desktop_entry_does_not_inject_web_flag(monkeypatch):
    """`bcc-desktop` НЕ получает --web — окно остаётся окном."""
    monkeypatch.setattr(desktop.os.path, "basename", lambda p: "bcc-desktop.exe")
    monkeypatch.setattr(desktop.sys, "argv", ["bcc-desktop.exe"])
    monkeypatch.setattr(desktop.sys, "stdout", None)
    monkeypatch.setattr(desktop.sys, "stderr", None)
    monkeypatch.setattr(desktop, "bind_missing_std_streams", lambda *a, **k: None)
    seen = {}

    def fake_run(argv=None, **kwargs):
        seen["argv"] = list(argv or [])
        return 0

    monkeypatch.setattr(desktop, "run", fake_run)
    with pytest.raises(SystemExit):
        desktop.main()
    assert "--web" not in seen["argv"]


def test_desktop_tests_never_touch_the_real_database(monkeypatch, tmp_path):
    """Подмена каталога данных обязана уводить и адрес базы.

    `Settings.database_url` считается один раз в `__post_init__`, поэтому
    подмена только `data_dir` оставляла адрес боевой базы репозитория. Тесты,
    поднимающие настоящий сервер, шли в неё: локально она есть и тест зелёный,
    в CI её нет — сервер падает `unable to open database file`, и `run()`
    возвращает 3 вместо кода launcher'а. Здесь это проверяется прямо.
    """
    from bcc.config import settings

    repo_db = Path(__file__).resolve().parents[1] / "data" / "bcc.db"
    target = _use_temp_data_dir(monkeypatch, tmp_path / "data")

    assert Path(settings.data_dir) == target
    assert str(target) in settings.database_url, "адрес базы не увели во временный каталог"
    assert str(repo_db) not in settings.database_url, "тест смотрит в боевую базу репозитория"
    assert settings.database_url.startswith("sqlite+aiosqlite:///")


def test_server_backed_runs_survive_a_missing_repo_database(tmp_path, monkeypatch):
    """Запуск с настоящим сервером не должен зависеть от боевой базы репозитория.

    Ровно это ломало CI: там каталога `command-center/data` нет вовсе.
    """
    _use_temp_data_dir(monkeypatch, tmp_path / "data")
    monkeypatch.setattr(desktop, "find_browser", lambda *a, **k: "/bin/true")
    seen = {}

    def fake_launcher(browser, url, profile_dir, *, extra=(), window_size="1440,900", timeout=None):
        seen["called"] = True
        return 0

    code = desktop.run(["--host", "127.0.0.1", "--port", "0", "--browser", "/bin/true",
                        "--profile", str(tmp_path / "prof"), "--no-show-token"],
                       launcher=fake_launcher, out=io.StringIO())

    assert seen.get("called"), "сервер не поднялся, и launcher не был вызван"
    assert code == 0
    assert (tmp_path / "data" / "bcc.db").exists(), "база создана во временном каталоге"


# ------------------------------------------- таймаут старта не трогает окно

def _sleeper(seconds: float) -> list[str]:
    return [sys.executable, "-c", f"import time; time.sleep({seconds})"]


def test_working_window_outliving_startup_timeout_is_never_killed(tmp_path, monkeypatch):
    """Главное свойство: таймаут старта не имеет права закрыть рабочее окно.

    Раньше timeout уходил прямо в proc.wait(timeout=...), и по его истечении
    окно получало terminate и kill — владелец, пользовавшийся окном дольше
    таймаута, видел, как оно закрывается само.
    """
    proc_box = {}

    def fake_open(browser, url, profile_dir, *, extra=(), window_size="1440,900"):
        Path(profile_dir).mkdir(parents=True, exist_ok=True)
        proc = subprocess.Popen(_sleeper(1.5), stdin=subprocess.DEVNULL)  # noqa: S603
        proc_box["proc"] = proc
        return proc

    monkeypatch.setattr(desktop, "open_window", fake_open)
    started = time.monotonic()

    code = desktop.launch_window("/bin/true", "http://127.0.0.1:1/", tmp_path / "prof",
                                 timeout=0.3)

    elapsed = time.monotonic() - started
    assert code == 0, "окно завершилось само, кодом 0 — его никто не убивал"
    assert code != desktop.STARTUP_FAILED_CODE
    assert elapsed >= 1.4, f"вернулись через {elapsed:.2f} c — значит окно закрыли по таймауту"
    assert proc_box["proc"].returncode == 0


def test_window_that_dies_early_returns_its_own_exit_code(tmp_path, monkeypatch):
    """Окно, умершее раньше срока, — это и есть «не открылось»; код его собственный."""
    def fake_open(browser, url, profile_dir, *, extra=(), window_size="1440,900"):
        Path(profile_dir).mkdir(parents=True, exist_ok=True)
        return subprocess.Popen([sys.executable, "-c", "raise SystemExit(3)"],  # noqa: S603
                                stdin=subprocess.DEVNULL)

    monkeypatch.setattr(desktop, "open_window", fake_open)

    code = desktop.launch_window("/bin/true", "http://127.0.0.1:1/", tmp_path / "prof",
                                 timeout=10)

    assert code == 3, "код выхода браузера обязан дойти до вызывающего как есть"


def test_unconfirmed_window_is_closed_only_when_readiness_is_checkable(tmp_path, monkeypatch):
    """Завершать окно можно, лишь когда готовность проверяема и не подтвердилась."""
    def fake_open(browser, url, profile_dir, *, extra=(), window_size="1440,900"):
        Path(profile_dir).mkdir(parents=True, exist_ok=True)
        return subprocess.Popen(_sleeper(30), stdin=subprocess.DEVNULL)  # noqa: S603

    monkeypatch.setattr(desktop, "open_window", fake_open)

    code = desktop.launch_window("/bin/true", "http://127.0.0.1:1/", tmp_path / "prof",
                                 timeout=0.4, ready=lambda: False)

    assert code == desktop.STARTUP_FAILED_CODE


def test_confirmed_window_waits_for_the_owner_not_for_the_timeout(tmp_path, monkeypatch):
    """Подтверждённая готовность снимает предел: дальше решает владелец."""
    def fake_open(browser, url, profile_dir, *, extra=(), window_size="1440,900"):
        Path(profile_dir).mkdir(parents=True, exist_ok=True)
        return subprocess.Popen(_sleeper(1.2), stdin=subprocess.DEVNULL)  # noqa: S603

    monkeypatch.setattr(desktop, "open_window", fake_open)
    started = time.monotonic()

    code = desktop.launch_window("/bin/true", "http://127.0.0.1:1/", tmp_path / "prof",
                                 timeout=0.3, ready=lambda: True)

    assert code == 0 and time.monotonic() - started >= 1.1
