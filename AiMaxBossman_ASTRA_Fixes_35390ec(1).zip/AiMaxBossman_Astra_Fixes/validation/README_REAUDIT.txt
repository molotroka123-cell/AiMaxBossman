reaudit-bandit.json refers to the pre-merge production checkpoint.
Final merged broad/SAST/SCA/Windows/CI acceptance is assigned to Fable.
JUnit synthetic-secret parameter labels are redacted; result counts are unchanged.
