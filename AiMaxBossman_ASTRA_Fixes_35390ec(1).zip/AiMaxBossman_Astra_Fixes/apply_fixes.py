#!/usr/bin/env python3
"""Apply exact pre-reviewed file replacements with preflight, backups and safe rollback."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tempfile
import uuid

BUNDLE = Path(__file__).resolve().parent

def sha(data): return hashlib.sha256(data).hexdigest()

def safe(root, relative):
    p=PurePosixPath(relative)
    if p.is_absolute() or not p.parts or any(x in (".","..") for x in p.parts) or "\\" in relative or ":" in relative:
        raise ValueError(f"Unsafe relative path: {relative}")
    target=root.joinpath(*p.parts)
    current=root
    for part in p.parts:
        current=current/part
        if current.is_symlink(): raise ValueError(f"Symlink refused: {current}")
    if not target.resolve().is_relative_to(root.resolve()): raise ValueError("Path escapes root")
    return target

def read_hash(path):
    if not path.exists(): return None
    if not path.is_file(): raise ValueError(f"Expected a file: {path}")
    digest=hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1_048_576), b""):
            digest.update(chunk)
    return digest.hexdigest()

def atomic(path, data, mode=0o644):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix=".astra-write-",dir=path.parent)
    try:
        with os.fdopen(fd,"wb") as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.chmod(temp,mode)
        os.replace(temp,path)
        if os.name == "posix":
            directory_fd=os.open(path.parent,os.O_RDONLY)
            try: os.fsync(directory_fd)
            finally: os.close(directory_fd)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def write_json(path, body): atomic(path,(json.dumps(body,ensure_ascii=False,indent=2)+"\n").encode(),0o600)

def rollback(repo, backup):
    meta=json.loads((backup/"backup.json").read_text(encoding="utf-8"))
    if Path(meta["repo"]).resolve() != repo: raise ValueError("Backup belongs to another checkout")
    changes=meta["files"]
    for entry in changes:
        target=safe(repo,entry["path"]);current=read_hash(target)
        if current not in (entry["before_sha256"], entry["after_sha256"]):
            raise ValueError(f"Rollback would overwrite a later edit: {entry['path']}")
        if entry["before_sha256"] is not None:
            if read_hash(safe(backup/"files",entry["path"])) != entry["before_sha256"]:
                raise ValueError("Backup content integrity failure")
    for entry in reversed(changes):
        target=safe(repo,entry["path"])
        if read_hash(target) == entry["before_sha256"]: continue
        if entry["before_sha256"] is None: target.unlink()
        else: atomic(target,safe(backup/"files",entry["path"]).read_bytes(),entry["before_mode"])
    meta["state"]="rolled_back";write_json(backup/"backup.json",meta)
    print("Rollback completed. Source files restored; runtime databases were not rolled back.")

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo",required=True,help="Path to the AiMaxBossman repository root")
    action=parser.add_mutually_exclusive_group()
    action.add_argument("--check",action="store_true",help="Validate only (default)")
    action.add_argument("--apply",action="store_true",help="Apply with source backups")
    action.add_argument("--rollback",type=Path,metavar="BACKUP_DIRECTORY")
    args=parser.parse_args();repo=Path(args.repo).expanduser().resolve()
    if not (repo/"bossman-core").is_dir() or not (repo/"command-center").is_dir():
        raise ValueError("--repo must name the repository root containing bossman-core and command-center")
    lock=repo/".astra-install.lock"
    lockfd=None
    try:
        if args.apply or args.rollback:
            lockfd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            os.write(lockfd,str(os.getpid()).encode());os.fsync(lockfd)
        if args.rollback:
            rollback(repo,args.rollback.resolve());return 0
        manifest=json.loads((BUNDLE/"manifest.json").read_text(encoding="utf-8"))
        changes=[]
        for entry in manifest["files"]:
            target=safe(repo,entry["path"]);payload=safe(BUNDLE/"payload",entry["path"])
            if read_hash(payload) != entry["after_sha256"]: raise ValueError(f"Damaged payload: {entry['path']}")
            current=read_hash(target)
            if current == entry["after_sha256"]: continue
            if current not in [entry["before_sha256"], *entry.get("upgrade_from_sha256", [])]:
                raise ValueError(f"Conflict: {entry['path']}. No files replaced; reconcile this checkout first.")
            changes.append({**entry,"before_sha256":current,"before_mode":stat.S_IMODE(target.stat().st_mode) if target.exists() else None})
        print(f"Validated {len(manifest['files'])} files against base {manifest['base_sha'][:12]}.")
        if not changes:
            print("All fixes are already installed.");return 0
        if not args.apply:
            print(f"Ready: {len(changes)} files need installation. Run again with --apply.");return 0
        stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")+"-"+uuid.uuid4().hex[:8]
        backup=BUNDLE/"backups"/stamp;backup.mkdir(parents=True)
        for entry in changes:
            if entry["before_sha256"] is not None:
                atomic(safe(backup/"files",entry["path"]),safe(repo,entry["path"]).read_bytes(),0o600)
        meta={"repo":str(repo),"state":"prepared","files":changes}
        write_json(backup/"backup.json",meta)
        try:
            for entry in changes:
                target=safe(repo,entry["path"])
                if read_hash(target) != entry["before_sha256"]:
                    raise ValueError(f"Concurrent edit detected: {entry['path']}")
                atomic(target,safe(BUNDLE/"payload",entry["path"]).read_bytes(),entry["mode"])
            meta["state"]="installed";write_json(backup/"backup.json",meta)
        except BaseException:
            print(f"Installation interrupted. Recovery backup: {backup}",file=sys.stderr)
            rollback(repo,backup)
            raise
        print(f"Installed {len(changes)} files. Backup: {backup}")
        print("Next: update dependencies and run VERIFY.py from this bundle. See README_RU.md.")
        return 0
    finally:
        if lockfd is not None:
            os.close(lockfd);lock.unlink(missing_ok=True)

if __name__ == "__main__":
    try: raise SystemExit(main())
    except (OSError,ValueError,KeyError) as exc:
        print(f"STOP: {exc}",file=sys.stderr);raise SystemExit(2)
